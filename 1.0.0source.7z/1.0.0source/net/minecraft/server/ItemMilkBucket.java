// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, ItemStack, World, EntityHuman, 
//            EnumAnimation

public class ItemMilkBucket extends Item
{

    public ItemMilkBucket(int i)
    {
        super(i);
        e(1);
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        itemstack.count--;
        if(!world.isStatic)
            entityhuman.ar();
        if(itemstack.count <= 0)
            return new ItemStack(Item.BUCKET);
        else
            return itemstack;
    }

    public int c(ItemStack itemstack)
    {
        return 32;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.c;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        entityhuman.a(itemstack, c(itemstack));
        return itemstack;
    }
}
