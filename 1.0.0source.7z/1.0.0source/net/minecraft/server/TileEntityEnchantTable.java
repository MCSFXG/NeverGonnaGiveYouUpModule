// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            TileEntity, World, EntityHuman

public class TileEntityEnchantTable extends TileEntity
{

    public TileEntityEnchantTable()
    {
    }

    public void l_()
    {
        super.l_();
        g = f;
        i = h;
        EntityHuman entityhuman = world.a((float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F, 3D);
        if(entityhuman != null)
        {
            double d1 = entityhuman.locX - (double)((float)x + 0.5F);
            double d2 = entityhuman.locZ - (double)((float)z + 0.5F);
            j = (float)Math.atan2(d2, d1);
            f += 0.1F;
            if(f < 0.5F || r.nextInt(40) == 0)
            {
                float f1 = d;
                do
                    d += r.nextInt(4) - r.nextInt(4);
                while(f1 == d);
            }
        } else
        {
            j += 0.02F;
            f -= 0.1F;
        }
        for(; h >= 3.141593F; h -= 6.283185F);
        for(; h < -3.141593F; h += 6.283185F);
        for(; j >= 3.141593F; j -= 6.283185F);
        for(; j < -3.141593F; j += 6.283185F);
        float f2;
        for(f2 = j - h; f2 >= 3.141593F; f2 -= 6.283185F);
        for(; f2 < -3.141593F; f2 += 6.283185F);
        h += f2 * 0.4F;
        if(f < 0.0F)
            f = 0.0F;
        if(f > 1.0F)
            f = 1.0F;
        a++;
        c = b;
        float f3 = (d - b) * 0.4F;
        float f4 = 0.2F;
        if(f3 < -f4)
            f3 = -f4;
        if(f3 > f4)
            f3 = f4;
        e += (f3 - e) * 0.9F;
        b = b + e;
    }

    public int a;
    public float b;
    public float c;
    public float d;
    public float e;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    private static Random r = new Random();

}
