// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Entity, EntityComplex, NBTTagCompound, DamageSource

public class EntityComplexPart extends Entity
{

    public EntityComplexPart(EntityComplex entitycomplex, String s, float f, float f1)
    {
        super(entitycomplex.world);
        b(f, f1);
        a = entitycomplex;
        b = s;
    }

    protected void b()
    {
    }

    protected void a(NBTTagCompound nbttagcompound)
    {
    }

    protected void b(NBTTagCompound nbttagcompound)
    {
    }

    public boolean e_()
    {
        return true;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        return a.a(this, damagesource, i);
    }

    public boolean a(Entity entity)
    {
        return this == entity || a == entity;
    }

    public final EntityComplex a;
    public final String b;
}
