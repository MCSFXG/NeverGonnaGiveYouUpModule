// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagShort extends NBTBase
{

    public NBTTagShort(String s)
    {
        super(s);
    }

    public NBTTagShort(String s, short word0)
    {
        super(s);
        a = word0;
    }

    void a(DataOutput dataoutput)
    {
        dataoutput.writeShort(a);
    }

    void a(DataInput datainput)
    {
        a = datainput.readShort();
    }

    public byte a()
    {
        return 2;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(a).toString();
    }

    public NBTBase b()
    {
        return new NBTTagShort(c(), a);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagShort nbttagshort = (NBTTagShort)obj;
            return a == nbttagshort.a;
        } else
        {
            return false;
        }
    }

    public short a;
}
