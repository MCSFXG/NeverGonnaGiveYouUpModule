// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ItemFood.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Item, MobEffect, ItemStack, EntityHuman, 
//            FoodMetaData, World, EnumAnimation

public class ItemFood extends Item
{

    public ItemFood(int i, int j, float f, boolean flag)
    {
        super(i);
        a = 32;
        b = j;
        bS = flag;
        bR = f;
    }

    public ItemFood(int i, int j, boolean flag)
    {
        this(i, j, 0.6F, flag);
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        itemstack.count--;
        int oldFoodLevel = entityhuman.getFoodData().foodLevel;
        FoodLevelChangeEvent event = new FoodLevelChangeEvent(entityhuman.getBukkitEntity(), Math.min(n() + entityhuman.getFoodData().foodLevel, 20));
        entityhuman.world.getServer().getPluginManager().callEvent(event);
        if(!event.isCancelled())
            entityhuman.getFoodData().a(event.getFoodLevel() - oldFoodLevel, o());
        if(!world.isStatic && bU > 0 && world.random.nextFloat() < bX)
            entityhuman.addEffect(new MobEffect(bU, bV * 20, bW));
        return itemstack;
    }

    public int c(ItemStack itemstack)
    {
        return 32;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.b;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        if(entityhuman.b(bT))
            entityhuman.a(itemstack, c(itemstack));
        return itemstack;
    }

    public int n()
    {
        return b;
    }

    public float o()
    {
        return bR;
    }

    public boolean p()
    {
        return bS;
    }

    public ItemFood a(int i, int j, int k, float f)
    {
        bU = i;
        bV = j;
        bW = k;
        bX = f;
        return this;
    }

    public ItemFood q()
    {
        bT = true;
        return this;
    }

    public Item a(String s)
    {
        return super.a(s);
    }

    public final int a;
    private final int b;
    private final float bR;
    private final boolean bS;
    private boolean bT;
    private int bU;
    private int bV;
    private int bW;
    private float bX;
}
