// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            IChunkProvider, NoiseGeneratorOctaves, World, Block, 
//            Chunk, WorldChunkManager, MathHelper, BlockSand, 
//            BiomeBase, ChunkCoordIntPair, IProgressUpdate, EnumCreatureType, 
//            ChunkPosition

public class ChunkProviderSky
    implements IChunkProvider
{

    public ChunkProviderSky(World world, long l1)
    {
        h = new int[32][32];
        m = world;
        i = new Random(l1);
        j = new NoiseGeneratorOctaves(i, 16);
        k = new NoiseGeneratorOctaves(i, 16);
        l = new NoiseGeneratorOctaves(i, 8);
        a = new NoiseGeneratorOctaves(i, 10);
        b = new NoiseGeneratorOctaves(i, 16);
    }

    public void a(int i1, int j1, byte abyte0[], BiomeBase abiomebase[])
    {
        byte byte0 = 2;
        int k1 = byte0 + 1;
        int l1 = m.height / 4 + 1;
        int i2 = byte0 + 1;
        n = a(n, i1 * byte0, 0, j1 * byte0, k1, l1, i2);
        for(int j2 = 0; j2 < byte0; j2++)
        {
            for(int k2 = 0; k2 < byte0; k2++)
            {
                for(int l2 = 0; l2 < m.height / 4; l2++)
                {
                    double d1 = 0.25D;
                    double d2 = n[((j2 + 0) * i2 + (k2 + 0)) * l1 + (l2 + 0)];
                    double d3 = n[((j2 + 0) * i2 + (k2 + 1)) * l1 + (l2 + 0)];
                    double d4 = n[((j2 + 1) * i2 + (k2 + 0)) * l1 + (l2 + 0)];
                    double d5 = n[((j2 + 1) * i2 + (k2 + 1)) * l1 + (l2 + 0)];
                    double d6 = (n[((j2 + 0) * i2 + (k2 + 0)) * l1 + (l2 + 1)] - d2) * d1;
                    double d7 = (n[((j2 + 0) * i2 + (k2 + 1)) * l1 + (l2 + 1)] - d3) * d1;
                    double d8 = (n[((j2 + 1) * i2 + (k2 + 0)) * l1 + (l2 + 1)] - d4) * d1;
                    double d9 = (n[((j2 + 1) * i2 + (k2 + 1)) * l1 + (l2 + 1)] - d5) * d1;
                    for(int i3 = 0; i3 < 4; i3++)
                    {
                        double d10 = 0.125D;
                        double d11 = d2;
                        double d12 = d3;
                        double d13 = (d4 - d2) * d10;
                        double d14 = (d5 - d3) * d10;
                        for(int j3 = 0; j3 < 8; j3++)
                        {
                            int k3 = j3 + j2 * 8 << m.heightBitsPlusFour | 0 + k2 * 8 << m.heightBits | l2 * 4 + i3;
                            int l3 = 1 << m.heightBits;
                            double d15 = 0.125D;
                            double d16 = d11;
                            double d17 = (d12 - d11) * d15;
                            for(int i4 = 0; i4 < 8; i4++)
                            {
                                int j4 = 0;
                                if(d16 > 0.0D)
                                    j4 = Block.WHITESTONE.id;
                                abyte0[k3] = (byte)j4;
                                k3 += l3;
                                d16 += d17;
                            }

                            d11 += d13;
                            d12 += d14;
                        }

                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                        d5 += d9;
                    }

                }

            }

        }

    }

    public void b(int i1, int j1, byte abyte0[], BiomeBase abiomebase[])
    {
        for(int k1 = 0; k1 < 16; k1++)
        {
            for(int l1 = 0; l1 < 16; l1++)
            {
                int i2 = 1;
                int j2 = -1;
                byte byte0 = (byte)Block.WHITESTONE.id;
                byte byte1 = (byte)Block.WHITESTONE.id;
                for(int k2 = m.heightMinusOne; k2 >= 0; k2--)
                {
                    int l2 = (l1 * 16 + k1) * m.height + k2;
                    byte byte2 = abyte0[l2];
                    if(byte2 == 0)
                    {
                        j2 = -1;
                        continue;
                    }
                    if(byte2 != Block.STONE.id)
                        continue;
                    if(j2 == -1)
                    {
                        if(i2 <= 0)
                        {
                            byte0 = 0;
                            byte1 = (byte)Block.WHITESTONE.id;
                        }
                        j2 = i2;
                        if(k2 >= 0)
                            abyte0[l2] = byte0;
                        else
                            abyte0[l2] = byte1;
                        continue;
                    }
                    if(j2 > 0)
                    {
                        j2--;
                        abyte0[l2] = byte1;
                    }
                }

            }

        }

    }

    public Chunk getChunkAt(int i1, int j1)
    {
        return getOrCreateChunk(i1, j1);
    }

    public Chunk getOrCreateChunk(int i1, int j1)
    {
        i.setSeed((long)i1 * 0x4f9939f508L + (long)j1 * 0x1ef1565bd5L);
        byte abyte0[] = new byte[16 * m.height * 16];
        Chunk chunk = new Chunk(m, abyte0, i1, j1);
        o = m.getWorldChunkManager().a(o, i1 * 16, j1 * 16, 16, 16);
        a(i1, j1, abyte0, o);
        b(i1, j1, abyte0, o);
        chunk.initLighting();
        return chunk;
    }

    private double[] a(double ad[], int i1, int j1, int k1, int l1, int i2, int j2)
    {
        if(ad == null)
            ad = new double[l1 * i2 * j2];
        double d1 = 684.41200000000003D;
        double d2 = 684.41200000000003D;
        f = a.a(f, i1, k1, l1, j2, 1.121D, 1.121D, 0.5D);
        g = b.a(g, i1, k1, l1, j2, 200D, 200D, 0.5D);
        d1 *= 2D;
        c = l.a(c, i1, j1, k1, l1, i2, j2, d1 / 80D, d2 / 160D, d1 / 80D);
        d = j.a(d, i1, j1, k1, l1, i2, j2, d1, d2, d1);
        e = k.a(e, i1, j1, k1, l1, i2, j2, d1, d2, d1);
        int k2 = 0;
        int l2 = 0;
        for(int i3 = 0; i3 < l1; i3++)
        {
            for(int j3 = 0; j3 < j2; j3++)
            {
                double d3 = (f[l2] + 256D) / 512D;
                if(d3 > 1.0D)
                    d3 = 1.0D;
                double d4 = g[l2] / 8000D;
                if(d4 < 0.0D)
                    d4 = -d4 * 0.29999999999999999D;
                d4 = d4 * 3D - 2D;
                float f1 = (float)((i3 + i1) - 0) / 1.0F;
                float f2 = (float)((j3 + k1) - 0) / 1.0F;
                float f3 = 100F - MathHelper.c(f1 * f1 + f2 * f2) * 8F;
                if(f3 > 80F)
                    f3 = 80F;
                if(f3 < -100F)
                    f3 = -100F;
                if(d4 > 1.0D)
                    d4 = 1.0D;
                d4 /= 8D;
                d4 = 0.0D;
                if(d3 < 0.0D)
                    d3 = 0.0D;
                d3 += 0.5D;
                d4 = (d4 * (double)i2) / 16D;
                l2++;
                double d5 = (double)i2 / 2D;
                for(int k3 = 0; k3 < i2; k3++)
                {
                    double d6 = 0.0D;
                    double d7 = (((double)k3 - d5) * 8D) / d3;
                    if(d7 < 0.0D)
                        d7 *= -1D;
                    double d8 = d[k2] / 512D;
                    double d9 = e[k2] / 512D;
                    double d10 = (c[k2] / 10D + 1.0D) / 2D;
                    if(d10 < 0.0D)
                        d6 = d8;
                    else
                    if(d10 > 1.0D)
                        d6 = d9;
                    else
                        d6 = d8 + (d9 - d8) * d10;
                    d6 -= 8D;
                    d6 += f3;
                    int l3 = 2;
                    if(k3 > i2 / 2 - l3)
                    {
                        double d11 = (float)(k3 - (i2 / 2 - l3)) / 64F;
                        if(d11 < 0.0D)
                            d11 = 0.0D;
                        if(d11 > 1.0D)
                            d11 = 1.0D;
                        d6 = d6 * (1.0D - d11) + -3000D * d11;
                    }
                    l3 = 8;
                    if(k3 < l3)
                    {
                        double d12 = (float)(l3 - k3) / ((float)l3 - 1.0F);
                        d6 = d6 * (1.0D - d12) + -30D * d12;
                    }
                    ad[k2] = d6;
                    k2++;
                }

            }

        }

        return ad;
    }

    public boolean isChunkLoaded(int i1, int j1)
    {
        return true;
    }

    public void getChunkAt(IChunkProvider ichunkprovider, int i1, int j1)
    {
        BlockSand.instaFall = true;
        int k1 = i1 * 16;
        int l1 = j1 * 16;
        BiomeBase biomebase = m.getWorldChunkManager().getBiome(k1 + 16, l1 + 16);
        biomebase.a(m, m.random, k1, l1);
        BlockSand.instaFall = false;
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unloadChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public List a(EnumCreatureType enumcreaturetype, int i1, int j1, int k1)
    {
        WorldChunkManager worldchunkmanager = m.getWorldChunkManager();
        if(worldchunkmanager == null)
            return null;
        BiomeBase biomebase = worldchunkmanager.a(new ChunkCoordIntPair(i1 >> 4, k1 >> 4));
        if(biomebase == null)
            return null;
        else
            return biomebase.a(enumcreaturetype);
    }

    public ChunkPosition a(World world, String s, int i1, int j1, int k1)
    {
        return null;
    }

    private Random i;
    private NoiseGeneratorOctaves j;
    private NoiseGeneratorOctaves k;
    private NoiseGeneratorOctaves l;
    public NoiseGeneratorOctaves a;
    public NoiseGeneratorOctaves b;
    private World m;
    private double n[];
    private BiomeBase o[];
    double c[];
    double d[];
    double e[];
    double f[];
    double g[];
    int h[][];
}
