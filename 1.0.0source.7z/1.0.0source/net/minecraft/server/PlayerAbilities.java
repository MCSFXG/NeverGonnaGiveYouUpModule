// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            NBTTagCompound

public class PlayerAbilities
{

    public PlayerAbilities()
    {
        isInvulnerable = false;
        isFlying = false;
        canFly = false;
        canInstantlyBuild = false;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.a("invulnerable", isInvulnerable);
        nbttagcompound1.a("flying", isInvulnerable);
        nbttagcompound1.a("mayfly", canFly);
        nbttagcompound1.a("instabuild", canInstantlyBuild);
        nbttagcompound.a("abilities", nbttagcompound1);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        if(nbttagcompound.hasKey("abilities"))
        {
            NBTTagCompound nbttagcompound1 = nbttagcompound.l("abilities");
            isInvulnerable = nbttagcompound1.n("invulnerable");
            isFlying = nbttagcompound1.n("flying");
            canFly = nbttagcompound1.n("mayfly");
            canInstantlyBuild = nbttagcompound1.n("instabuild");
        }
    }

    public boolean isInvulnerable;
    public boolean isFlying;
    public boolean canFly;
    public boolean canInstantlyBuild;
}
