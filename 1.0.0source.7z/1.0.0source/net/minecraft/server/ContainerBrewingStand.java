// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            Container, SlotPotionBottle, InventoryPlayer, SlotBrewing, 
//            Slot, TileEntityBrewingStand, ICrafting, ItemStack, 
//            EntityHuman

public class ContainerBrewingStand extends Container
{

    public ContainerBrewingStand(InventoryPlayer inventoryplayer, TileEntityBrewingStand tileentitybrewingstand)
    {
        b = 0;
        a = tileentitybrewingstand;
        a(new SlotPotionBottle(this, inventoryplayer.d, tileentitybrewingstand, 0, 56, 46));
        a(new SlotPotionBottle(this, inventoryplayer.d, tileentitybrewingstand, 1, 79, 53));
        a(new SlotPotionBottle(this, inventoryplayer.d, tileentitybrewingstand, 2, 102, 46));
        a(new SlotBrewing(this, tileentitybrewingstand, 3, 79, 17));
        for(int i = 0; i < 3; i++)
        {
            for(int k = 0; k < 9; k++)
                a(new Slot(inventoryplayer, k + i * 9 + 9, 8 + k * 18, 84 + i * 18));

        }

        for(int j = 0; j < 9; j++)
            a(new Slot(inventoryplayer, j, 8 + j * 18, 142));

    }

    public void a(ICrafting icrafting)
    {
        super.a(icrafting);
        icrafting.a(this, 0, a.h());
    }

    public void a()
    {
        super.a();
        for(int i = 0; i < listeners.size(); i++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i);
            if(b != a.h())
                icrafting.a(this, 0, a.h());
        }

        b = a.h();
    }

    public boolean b(EntityHuman entityhuman)
    {
        return a.a(entityhuman);
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i >= 0 && i <= 2 || i == 3)
            {
                if(!a(itemstack1, 4, 40, true))
                    return null;
            } else
            if(i >= 4 && i < 31)
            {
                if(!a(itemstack1, 31, 40, false))
                    return null;
            } else
            if(i >= 31 && i < 40)
            {
                if(!a(itemstack1, 4, 31, false))
                    return null;
            } else
            if(!a(itemstack1, 4, 40, false))
                return null;
            if(itemstack1.count == 0)
                slot.c(null);
            else
                slot.d();
            if(itemstack1.count != itemstack.count)
                slot.b(itemstack1);
            else
                return null;
        }
        return itemstack;
    }

    private TileEntityBrewingStand a;
    private int b;
}
