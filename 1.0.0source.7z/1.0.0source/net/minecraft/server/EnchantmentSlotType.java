// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemArmor, ItemSword, ItemTool, Item

public final class EnchantmentSlotType extends Enum
{

    public static EnchantmentSlotType[] values()
    {
        return (EnchantmentSlotType[])i.clone();
    }

    public static EnchantmentSlotType valueOf(String s)
    {
        return (EnchantmentSlotType)Enum.valueOf(net/minecraft/server/EnchantmentSlotType, s);
    }

    private EnchantmentSlotType(String s, int j)
    {
        super(s, j);
    }

    public boolean a(Item item)
    {
        if(this == ALL)
            return true;
        if(item instanceof ItemArmor)
        {
            if(this == ARMOR)
                return true;
            ItemArmor itemarmor = (ItemArmor)item;
            if(itemarmor.a == 0)
                return this == ARMOR_HEAD;
            if(itemarmor.a == 2)
                return this == ARMOR_LEGS;
            if(itemarmor.a == 1)
                return this == ARMOR_TORSO;
            if(itemarmor.a == 3)
                return this == ARMOR_FEET;
            else
                return false;
        }
        if(item instanceof ItemSword)
            return this == WEAPON;
        if(item instanceof ItemTool)
            return this == DIGGER;
        else
            return false;
    }

    public static final EnchantmentSlotType ALL;
    public static final EnchantmentSlotType ARMOR;
    public static final EnchantmentSlotType ARMOR_FEET;
    public static final EnchantmentSlotType ARMOR_LEGS;
    public static final EnchantmentSlotType ARMOR_TORSO;
    public static final EnchantmentSlotType ARMOR_HEAD;
    public static final EnchantmentSlotType WEAPON;
    public static final EnchantmentSlotType DIGGER;
    private static final EnchantmentSlotType i[];

    static 
    {
        ALL = new EnchantmentSlotType("all", 0);
        ARMOR = new EnchantmentSlotType("armor", 1);
        ARMOR_FEET = new EnchantmentSlotType("armor_feet", 2);
        ARMOR_LEGS = new EnchantmentSlotType("armor_legs", 3);
        ARMOR_TORSO = new EnchantmentSlotType("armor_torso", 4);
        ARMOR_HEAD = new EnchantmentSlotType("armor_head", 5);
        WEAPON = new EnchantmentSlotType("weapon", 6);
        DIGGER = new EnchantmentSlotType("digger", 7);
        i = (new EnchantmentSlotType[] {
            ALL, ARMOR, ARMOR_FEET, ARMOR_LEGS, ARMOR_TORSO, ARMOR_HEAD, WEAPON, DIGGER
        });
    }
}
