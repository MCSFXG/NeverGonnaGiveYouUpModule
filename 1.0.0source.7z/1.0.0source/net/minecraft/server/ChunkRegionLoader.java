// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            IChunkLoader, IAsyncChunkSaver, ChunkCoordIntPair, PendingChunkToSave, 
//            RegionFileCache, CompressedStreamTools, NBTTagCompound, ChunkLoader, 
//            Chunk, World, FileIOThread

public class ChunkRegionLoader
    implements IChunkLoader, IAsyncChunkSaver
{

    public ChunkRegionLoader(File file)
    {
        a = new ArrayList();
        b = new HashSet();
        c = new Object();
        d = file;
    }

    public Chunk a(World world, int i, int j)
    {
        NBTTagCompound nbttagcompound = null;
        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(i, j);
        synchronized(c)
        {
            if(b.contains(chunkcoordintpair))
            {
                int k = 0;
                do
                {
                    if(k >= a.size())
                        break;
                    if(((PendingChunkToSave)a.get(k)).a.equals(chunkcoordintpair))
                    {
                        nbttagcompound = ((PendingChunkToSave)a.get(k)).b;
                        break;
                    }
                    k++;
                } while(true);
            }
        }
        if(nbttagcompound == null)
        {
            java.io.DataInputStream datainputstream = RegionFileCache.b(d, i, j);
            if(datainputstream != null)
                nbttagcompound = CompressedStreamTools.a(datainputstream);
            else
                return null;
        }
        if(!nbttagcompound.hasKey("Level"))
        {
            System.out.println((new StringBuilder()).append("Chunk file at ").append(i).append(",").append(j).append(" is missing level data, skipping").toString());
            return null;
        }
        if(!nbttagcompound.l("Level").hasKey("Blocks"))
        {
            System.out.println((new StringBuilder()).append("Chunk file at ").append(i).append(",").append(j).append(" is missing block data, skipping").toString());
            return null;
        }
        Chunk chunk = ChunkLoader.a(world, nbttagcompound.l("Level"));
        if(!chunk.a(i, j))
        {
            System.out.println((new StringBuilder()).append("Chunk file at ").append(i).append(",").append(j).append(" is in the wrong location; relocating. (Expected ").append(i).append(", ").append(j).append(", got ").append(chunk.x).append(", ").append(chunk.z).append(")").toString());
            nbttagcompound.a("xPos", i);
            nbttagcompound.a("zPos", j);
            chunk = ChunkLoader.a(world, nbttagcompound.l("Level"));
        }
        chunk.h();
        return chunk;
    }

    public void a(World world, Chunk chunk)
    {
        world.l();
        try
        {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound.a("Level", nbttagcompound1);
            ChunkLoader.a(chunk, world, nbttagcompound1);
            a(chunk.j(), nbttagcompound);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    private void a(ChunkCoordIntPair chunkcoordintpair, NBTTagCompound nbttagcompound)
    {
        Object obj = c;
        JVM INSTR monitorenter ;
        int i;
        if(!b.contains(chunkcoordintpair))
            break MISSING_BLOCK_LABEL_91;
        i = 0;
_L2:
        if(i >= a.size())
            break MISSING_BLOCK_LABEL_91;
        if(!((PendingChunkToSave)a.get(i)).a.equals(chunkcoordintpair))
            break MISSING_BLOCK_LABEL_85;
        a.set(i, new PendingChunkToSave(chunkcoordintpair, nbttagcompound));
        return;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
        a.add(new PendingChunkToSave(chunkcoordintpair, nbttagcompound));
        b.add(chunkcoordintpair);
        FileIOThread.a.a(this);
        return;
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public boolean c()
    {
        PendingChunkToSave pendingchunktosave = null;
        Object obj = c;
        JVM INSTR monitorenter ;
        if(a.size() > 0)
        {
            pendingchunktosave = (PendingChunkToSave)a.remove(0);
            b.remove(pendingchunktosave.a);
        } else
        {
            return false;
        }
        obj;
        JVM INSTR monitorexit ;
          goto _L1
        Exception exception1;
        exception1;
        throw exception1;
_L1:
        if(pendingchunktosave != null)
            try
            {
                a(pendingchunktosave);
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
        return true;
    }

    public void a(PendingChunkToSave pendingchunktosave)
    {
        DataOutputStream dataoutputstream = RegionFileCache.c(d, pendingchunktosave.a.x, pendingchunktosave.a.z);
        CompressedStreamTools.a(pendingchunktosave.b, dataoutputstream);
        dataoutputstream.close();
    }

    public void b(World world, Chunk chunk)
    {
    }

    public void a()
    {
    }

    public void b()
    {
    }

    private List a;
    private Set b;
    private Object c;
    private final File d;
}
