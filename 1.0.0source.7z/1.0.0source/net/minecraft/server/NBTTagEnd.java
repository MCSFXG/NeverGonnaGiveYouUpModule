// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagEnd extends NBTBase
{

    public NBTTagEnd()
    {
        super(null);
    }

    void a(DataInput datainput)
    {
    }

    void a(DataOutput dataoutput)
    {
    }

    public byte a()
    {
        return 0;
    }

    public String toString()
    {
        return "END";
    }

    public NBTBase b()
    {
        return new NBTTagEnd();
    }

    public boolean equals(Object obj)
    {
        return super.equals(obj);
    }
}
