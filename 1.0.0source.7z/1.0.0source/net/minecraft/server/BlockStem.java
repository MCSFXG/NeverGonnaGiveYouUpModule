// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockFlower, Block, World, IBlockAccess, 
//            Item, EntityItem, ItemStack

public class BlockStem extends BlockFlower
{

    protected BlockStem(int j, Block block)
    {
        super(j, 111);
        a = block;
        a(true);
        float f1 = 0.125F;
        a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, 0.25F, 0.5F + f1);
    }

    protected boolean d(int j)
    {
        return j == Block.SOIL.id;
    }

    public void a(World world, int j, int k, int l, Random random)
    {
        super.a(world, j, k, l, random);
        if(world.getLightLevel(j, k + 1, l) >= 9)
        {
            float f1 = i(world, j, k, l);
            if(random.nextInt((int)(25F / f1) + 1) == 0)
            {
                int i1 = world.getData(j, k, l);
                if(i1 < 7)
                {
                    i1++;
                    world.setData(j, k, l, i1);
                } else
                {
                    if(world.getTypeId(j - 1, k, l) == a.id)
                        return;
                    if(world.getTypeId(j + 1, k, l) == a.id)
                        return;
                    if(world.getTypeId(j, k, l - 1) == a.id)
                        return;
                    if(world.getTypeId(j, k, l + 1) == a.id)
                        return;
                    int j1 = random.nextInt(4);
                    int k1 = j;
                    int l1 = l;
                    if(j1 == 0)
                        k1--;
                    if(j1 == 1)
                        k1++;
                    if(j1 == 2)
                        l1--;
                    if(j1 == 3)
                        l1++;
                    if(world.getTypeId(k1, k, l1) == 0 && world.getTypeId(k1, k - 1, l1) == Block.SOIL.id)
                        world.setTypeId(k1, k, l1, a.id);
                }
            }
        }
    }

    public void g(World world, int j, int k, int l)
    {
        world.setData(j, k, l, 7);
    }

    private float i(World world, int j, int k, int l)
    {
        float f1 = 1.0F;
        int i1 = world.getTypeId(j, k, l - 1);
        int j1 = world.getTypeId(j, k, l + 1);
        int k1 = world.getTypeId(j - 1, k, l);
        int l1 = world.getTypeId(j + 1, k, l);
        int i2 = world.getTypeId(j - 1, k, l - 1);
        int j2 = world.getTypeId(j + 1, k, l - 1);
        int k2 = world.getTypeId(j + 1, k, l + 1);
        int l2 = world.getTypeId(j - 1, k, l + 1);
        boolean flag = k1 == id || l1 == id;
        boolean flag1 = i1 == id || j1 == id;
        boolean flag2 = i2 == id || j2 == id || k2 == id || l2 == id;
        for(int i3 = j - 1; i3 <= j + 1; i3++)
        {
            for(int j3 = l - 1; j3 <= l + 1; j3++)
            {
                int k3 = world.getTypeId(i3, k - 1, j3);
                float f2 = 0.0F;
                if(k3 == Block.SOIL.id)
                {
                    f2 = 1.0F;
                    if(world.getData(i3, k - 1, j3) > 0)
                        f2 = 3F;
                }
                if(i3 != j || j3 != l)
                    f2 /= 4F;
                f1 += f2;
            }

        }

        if(flag2 || flag && flag1)
            f1 /= 2.0F;
        return f1;
    }

    public int a(int j, int k)
    {
        return textureId;
    }

    public void f()
    {
        float f1 = 0.125F;
        a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, 0.25F, 0.5F + f1);
    }

    public void a(IBlockAccess iblockaccess, int j, int k, int l)
    {
        maxY = (float)(iblockaccess.getData(j, k, l) * 2 + 2) / 16F;
        float f1 = 0.125F;
        a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, (float)maxY, 0.5F + f1);
    }

    public int c()
    {
        return 19;
    }

    public void dropNaturally(World world, int j, int k, int l, int i1, float f1, int j1)
    {
        super.dropNaturally(world, j, k, l, i1, f1, j1);
        if(world.isStatic)
            return;
        Item item = null;
        if(a == Block.PUMPKIN)
            item = Item.PUMPKIN_SEEDS;
        if(a == Block.MELON)
            item = Item.MELON_SEEDS;
        for(int k1 = 0; k1 < 3; k1++)
            if(world.random.nextInt(15) <= i1)
            {
                float f2 = 0.7F;
                float f3 = world.random.nextFloat() * f2 + (1.0F - f2) * 0.5F;
                float f4 = world.random.nextFloat() * f2 + (1.0F - f2) * 0.5F;
                float f5 = world.random.nextFloat() * f2 + (1.0F - f2) * 0.5F;
                EntityItem entityitem = new EntityItem(world, (float)j + f3, (float)k + f4, (float)l + f5, new ItemStack(item));
                entityitem.pickupDelay = 10;
                world.addEntity(entityitem);
            }

    }

    public int a(int j, Random random, int k)
    {
        if(j != 7);
        return -1;
    }

    public int a(Random random)
    {
        return 1;
    }

    private Block a;
}
