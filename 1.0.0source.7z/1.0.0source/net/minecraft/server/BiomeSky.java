// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            BiomeBase, BiomeMeta, EntityEnderman, Block, 
//            BiomeDecoratorSpikes

public class BiomeSky extends BiomeBase
{

    public BiomeSky(int i)
    {
        super(i);
        C.clear();
        D.clear();
        E.clear();
        C.add(new BiomeMeta(net/minecraft/server/EntityEnderman, 10, 4, 4));
        t = (byte)Block.DIRT.id;
        u = (byte)Block.DIRT.id;
        B = new BiomeDecoratorSpikes(this);
    }
}
