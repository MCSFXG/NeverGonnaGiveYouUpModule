// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityLiving.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, EntityExperienceOrb, EntityHuman, EntityWolf, 
//            NBTTagList, MobEffect, NBTTagCompound, AxisAlignedBB, 
//            DataWatcher, Vec3D, World, DamageSource, 
//            Material, MobEffectList, MathHelper, EnchantmentManager, 
//            Block, StepSound, PotionBrewer, EnchantmentDamage, 
//            ItemStack, Item

public abstract class EntityLiving extends Entity
{

    public EntityLiving(World world)
    {
        super(world);
        maxNoDamageTicks = 20;
        V = 0.0F;
        W = 0.0F;
        ab = true;
        texture = "/mob/char.png";
        ad = true;
        ae = 0.0F;
        af = null;
        ag = 1.0F;
        ah = 0;
        ai = 0.0F;
        aj = false;
        ak = 0.1F;
        al = 0.02F;
        health = getMaxHealth();
        at = 0.0F;
        deathTicks = 0;
        attackTicks = 0;
        ay = false;
        aA = -1;
        aB = (float)(Math.random() * 0.89999997615814209D + 0.10000000149011612D);
        aF = null;
        aG = 0;
        aH = 0;
        aI = 0;
        effects = new HashMap();
        b = true;
        aQ = 0.0F;
        lastDamage = 0;
        aS = 0;
        aW = false;
        aX = 0.0F;
        aY = 0.7F;
        d = 0;
        aZ = 0;
        expToDrop = 0;
        bc = true;
        U = (float)(Math.random() + 1.0D) * 0.01F;
        setPosition(locX, locY, locZ);
        T = (float)Math.random() * 12398F;
        yaw = (float)(Math.random() * 3.1415927410125732D * 2D);
        bM = 0.5F;
    }

    protected void b()
    {
        datawatcher.a(8, Integer.valueOf(c));
    }

    public boolean g(Entity entity)
    {
        return world.a(Vec3D.create(locX, locY + (double)x(), locZ), Vec3D.create(entity.locX, entity.locY + (double)entity.x(), entity.locZ)) == null;
    }

    public boolean e_()
    {
        return !dead;
    }

    public boolean f_()
    {
        return !dead;
    }

    public float x()
    {
        return width * 0.85F;
    }

    public int h()
    {
        return 80;
    }

    public void ae()
    {
        String s = c_();
        if(s != null)
            world.makeSound(this, s, o(), w());
    }

    public void af()
    {
        am = an;
        super.af();
        if(random.nextInt(1000) < a++)
        {
            a = -h();
            ae();
        }
        if(aj() && T())
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.SUFFOCATION, 1);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                damageEntity(DamageSource.STUCK, event.getDamage());
        }
        if(ax() || world.isStatic)
            aw();
        if(aj() && a(Material.WATER) && !f() && !effects.containsKey(Integer.valueOf(MobEffectList.WATER_BREATHING.id)))
        {
            setAirTicks(f(getAirTicks()));
            if(getAirTicks() == -20)
            {
                setAirTicks(0);
                for(int i = 0; i < 8; i++)
                {
                    float f = random.nextFloat() - random.nextFloat();
                    float f1 = random.nextFloat() - random.nextFloat();
                    float f2 = random.nextFloat() - random.nextFloat();
                    world.a("bubble", locX + (double)f, locY + (double)f1, locZ + (double)f2, motX, motY, motZ);
                }

                EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.DROWNING, 2);
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled() && event.getDamage() != 0)
                    damageEntity(DamageSource.DROWN, event.getDamage());
            }
            aw();
        } else
        {
            setAirTicks(300);
        }
        aw = ax;
        if(attackTicks > 0)
            attackTicks--;
        if(hurtTicks > 0)
            hurtTicks--;
        if(noDamageTicks > 0)
            noDamageTicks--;
        if(health <= 0)
            ag();
        if(aG > 0)
            aG--;
        else
            aF = null;
        aq();
        aa = Z;
        W = V;
        lastYaw = yaw;
        lastPitch = pitch;
    }

    public int getExpReward()
    {
        int exp = a(aF);
        if(!world.isStatic && (aG > 0 || ac()) && !l())
            return exp;
        else
            return 0;
    }

    protected void ag()
    {
        deathTicks++;
        if(deathTicks == 20)
        {
            for(int i = expToDrop; i > 0;)
            {
                int j = EntityExperienceOrb.b(i);
                i -= j;
                world.addEntity(new EntityExperienceOrb(world, locX, locY, locZ, j));
            }

            an();
            die();
            for(int i = 0; i < 20; i++)
            {
                double d0 = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                world.a("explode", (locX + (double)(random.nextFloat() * length * 2.0F)) - (double)length, locY + (double)(random.nextFloat() * width), (locZ + (double)(random.nextFloat() * length * 2.0F)) - (double)length, d0, d1, d2);
            }

        }
    }

    protected int f(int i)
    {
        return i - 1;
    }

    protected int a(EntityHuman entityhuman)
    {
        return az;
    }

    protected boolean ac()
    {
        return false;
    }

    public void ah()
    {
        for(int i = 0; i < 20; i++)
        {
            double d0 = random.nextGaussian() * 0.02D;
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            double d3 = 10D;
            world.a("explode", (locX + (double)(random.nextFloat() * length * 2.0F)) - (double)length - d0 * d3, (locY + (double)(random.nextFloat() * width)) - d1 * d3, (locZ + (double)(random.nextFloat() * length * 2.0F)) - (double)length - d2 * d3, d0, d1, d2);
        }

    }

    public void M()
    {
        super.M();
        X = Y;
        Y = 0.0F;
        fallDistance = 0.0F;
    }

    public void w_()
    {
        super.w_();
        if(aH > 0)
        {
            if(aI <= 0)
                aI = 60;
            aI--;
            if(aI <= 0)
                aH--;
        }
        d();
        double d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f = MathHelper.a(d0 * d0 + d1 * d1);
        float f1 = V;
        float f2 = 0.0F;
        X = Y;
        float f3 = 0.0F;
        if(f > 0.05F)
        {
            f3 = 1.0F;
            f2 = f * 3F;
            f1 = ((float)TrigMath.atan2(d1, d0) * 180F) / 3.141593F - 90F;
        }
        if(an > 0.0F)
            f1 = yaw;
        if(!onGround)
            f3 = 0.0F;
        Y += (f3 - Y) * 0.3F;
        float f4;
        for(f4 = f1 - V; f4 < -180F; f4 += 360F);
        for(; f4 >= 180F; f4 -= 360F);
        V += f4 * 0.3F;
        float f5;
        for(f5 = yaw - V; f5 < -180F; f5 += 360F);
        for(; f5 >= 180F; f5 -= 360F);
        boolean flag = f5 < -90F || f5 >= 90F;
        if(f5 < -75F)
            f5 = -75F;
        if(f5 >= 75F)
            f5 = 75F;
        V = yaw - f5;
        if(f5 * f5 > 2500F)
            V += f5 * 0.2F;
        if(flag)
            f2 *= -1F;
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        for(; V - W < -180F; W -= 360F);
        for(; V - W >= 180F; W += 360F);
        for(; pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        Z += f2;
    }

    protected void b(float f, float f1)
    {
        super.b(f, f1);
    }

    public void d(int i)
    {
        d(i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.CUSTOM);
    }

    public void d(int i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason regainReason)
    {
        if(health > 0)
        {
            EntityRegainHealthEvent event = new EntityRegainHealthEvent(getBukkitEntity(), i, regainReason);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                health += event.getAmount();
            if(health > getMaxHealth())
                health = getMaxHealth();
            noDamageTicks = maxNoDamageTicks / 2;
        }
    }

    public abstract int getMaxHealth();

    public int getHealth()
    {
        return health;
    }

    public void setHealth(int i)
    {
        health = i;
        if(i > getMaxHealth())
            i = getMaxHealth();
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(world.isStatic)
            return false;
        aS = 0;
        if(health <= 0)
            return false;
        if(damagesource.k() && hasEffect(MobEffectList.FIRE_RESISTANCE))
            return false;
        aD = 1.5F;
        boolean flag = true;
        if((float)noDamageTicks > (float)maxNoDamageTicks / 2.0F)
        {
            if(i <= lastDamage)
                return false;
            c(damagesource, i - lastDamage);
            lastDamage = i;
            flag = false;
        } else
        {
            lastDamage = i;
            ap = health;
            noDamageTicks = maxNoDamageTicks;
            c(damagesource, i);
            hurtTicks = as = 10;
        }
        at = 0.0F;
        Entity entity = damagesource.getEntity();
        if(entity != null)
            if(entity instanceof EntityHuman)
            {
                aG = 60;
                aF = (EntityHuman)entity;
            } else
            if(entity instanceof EntityWolf)
            {
                EntityWolf entitywolf = (EntityWolf)entity;
                if(entitywolf.isTamed())
                {
                    aG = 60;
                    aF = null;
                }
            }
        if(flag)
        {
            world.a(this, (byte)2);
            aB();
            if(entity != null)
            {
                double d0 = entity.locX - locX;
                double d1;
                for(d1 = entity.locZ - locZ; d0 * d0 + d1 * d1 < 0.0001D; d1 = (Math.random() - Math.random()) * 0.01D)
                    d0 = (Math.random() - Math.random()) * 0.01D;

                at = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - yaw;
                a(entity, i, d0, d1);
            } else
            {
                at = (int)(Math.random() * 2D) * 180;
            }
        }
        if(health <= 0)
        {
            if(flag)
                world.makeSound(this, n(), o(), w());
            die(damagesource);
        } else
        if(flag)
            world.makeSound(this, m(), o(), w());
        return true;
    }

    private float w()
    {
        return l() ? (random.nextFloat() - random.nextFloat()) * 0.2F + 1.5F : (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F;
    }

    protected int O()
    {
        return 0;
    }

    protected void g(int j)
    {
    }

    protected int d(DamageSource damagesource, int i)
    {
        if(!damagesource.ignoresArmor())
        {
            int j = 25 - O();
            int k = i * j + aq;
            g(i);
            i = k / 25;
            aq = k % 25;
        }
        return i;
    }

    protected int b(DamageSource damagesource, int i)
    {
        if(hasEffect(MobEffectList.RESISTANCE))
        {
            int j = (getEffect(MobEffectList.RESISTANCE).getAmplifier() + 1) * 5;
            int k = 25 - j;
            int l = i * k + aq;
            i = l / 25;
            aq = l % 25;
        }
        return i;
    }

    protected void c(DamageSource damagesource, int i)
    {
        i = d(damagesource, i);
        i = b(damagesource, i);
        health -= i;
    }

    protected float o()
    {
        return 1.0F;
    }

    protected String c_()
    {
        return null;
    }

    protected String m()
    {
        return "damage.hurtflesh";
    }

    protected String n()
    {
        return "damage.hurtflesh";
    }

    public void a(Entity entity, int i, double d0, double d1)
    {
        cb = true;
        float f = MathHelper.a(d0 * d0 + d1 * d1);
        float f1 = 0.4F;
        motX /= 2D;
        motY /= 2D;
        motZ /= 2D;
        motX -= (d0 / (double)f) * (double)f1;
        motY += 0.40000000596046448D;
        motZ -= (d1 / (double)f) * (double)f1;
        if(motY > 0.40000000596046448D)
            motY = 0.40000000596046448D;
    }

    public void die(DamageSource damagesource)
    {
        Entity entity = damagesource.getEntity();
        if(ah >= 0 && entity != null)
            entity.b(this, ah);
        if(entity != null)
            entity.a(this);
        ay = true;
        if(!world.isStatic)
        {
            int i = 0;
            if(entity instanceof EntityHuman)
                i = EnchantmentManager.f(((EntityHuman)entity).inventory);
            if(!l())
                a(aG > 0, i);
        }
        world.a(this, (byte)3);
    }

    protected void a(boolean flag, int i)
    {
        int j = e();
        List loot = new ArrayList();
        if(j > 0)
        {
            int k = random.nextInt(3);
            if(i > 0)
                k += random.nextInt(i + 1);
            if(k > 0)
                loot.add(new ItemStack(j, k));
            CraftEventFactory.callEntityDeathEvent(this, loot);
        }
    }

    protected int e()
    {
        return 0;
    }

    protected void b(float f)
    {
        super.b(f);
        int i = (int)Math.ceil(f - 3F);
        if(i > 0)
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL, i);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled() && event.getDamage() != 0)
            {
                i = event.getDamage();
                if(i > 4)
                    world.makeSound(this, "damage.fallbig", 1.0F, 1.0F);
                else
                    world.makeSound(this, "damage.fallsmall", 1.0F, 1.0F);
                damageEntity(DamageSource.FALL, i);
            }
            int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(locY - 0.20000000298023224D - (double)height), MathHelper.floor(locZ));
            if(j > 0)
            {
                StepSound stepsound = Block.byId[j].stepSound;
                world.makeSound(this, stepsound.getName(), stepsound.getVolume1() * 0.5F, stepsound.getVolume2() * 0.75F);
            }
        }
    }

    public void a(float f, float f1)
    {
        double d0;
        if(az())
        {
            d0 = locY;
            a(f, f1, 0.02F);
            move(motX, motY, motZ);
            motX *= 0.80000001192092896D;
            motY *= 0.80000001192092896D;
            motZ *= 0.80000001192092896D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        if(aA())
        {
            d0 = locY;
            a(f, f1, 0.02F);
            move(motX, motY, motZ);
            motX *= 0.5D;
            motY *= 0.5D;
            motZ *= 0.5D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        {
            float f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int i = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(i > 0)
                    f2 = Block.byId[i].frictionFactor * 0.91F;
            }
            float f3 = 0.1627714F / (f2 * f2 * f2);
            float f4 = onGround ? ak * f3 : al;
            a(f, f1, f4);
            f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(j > 0)
                    f2 = Block.byId[j].frictionFactor * 0.91F;
            }
            if(r())
            {
                float f5 = 0.15F;
                if(motX < (double)(-f5))
                    motX = -f5;
                if(motX > (double)f5)
                    motX = f5;
                if(motZ < (double)(-f5))
                    motZ = -f5;
                if(motZ > (double)f5)
                    motZ = f5;
                fallDistance = 0.0F;
                if(motY < -0.14999999999999999D)
                    motY = -0.14999999999999999D;
                if(isSneaking() && motY < 0.0D)
                    motY = 0.0D;
            }
            move(motX, motY, motZ);
            if(positionChanged && r())
                motY = 0.20000000000000001D;
            motY -= 0.080000000000000002D;
            motY *= 0.98000001907348633D;
            motX *= f2;
            motZ *= f2;
        }
        aC = aD;
        d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f6 = MathHelper.a(d0 * d0 + d1 * d1) * 4F;
        if(f6 > 1.0F)
            f6 = 1.0F;
        aD += (f6 - aD) * 0.4F;
        aE += aD;
    }

    public boolean r()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        return world.getTypeId(i, j, k) == Block.LADDER.id;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("Health", (short)health);
        nbttagcompound.a("HurtTime", (short)hurtTicks);
        nbttagcompound.a("DeathTime", (short)deathTicks);
        nbttagcompound.a("AttackTime", (short)attackTicks);
        if(!effects.isEmpty())
        {
            NBTTagList nbttaglist = new NBTTagList();
            NBTTagCompound nbttagcompound1;
            for(Iterator iterator = effects.values().iterator(); iterator.hasNext(); nbttaglist.a(nbttagcompound1))
            {
                MobEffect mobeffect = (MobEffect)iterator.next();
                nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.a("Id", (byte)mobeffect.getEffectId());
                nbttagcompound1.a("Amplifier", (byte)mobeffect.getAmplifier());
                nbttagcompound1.a("Duration", mobeffect.getDuration());
            }

            nbttagcompound.a("ActiveEffects", nbttaglist);
        }
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        health = nbttagcompound.e("Health");
        if(!nbttagcompound.hasKey("Health"))
            health = getMaxHealth();
        hurtTicks = nbttagcompound.e("HurtTime");
        deathTicks = nbttagcompound.e("DeathTime");
        attackTicks = nbttagcompound.e("AttackTime");
        if(nbttagcompound.hasKey("ActiveEffects"))
        {
            NBTTagList nbttaglist = nbttagcompound.m("ActiveEffects");
            for(int i = 0; i < nbttaglist.d(); i++)
            {
                NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.a(i);
                byte b0 = nbttagcompound1.d("Id");
                byte b1 = nbttagcompound1.d("Amplifier");
                int j = nbttagcompound1.f("Duration");
                effects.put(Integer.valueOf(b0), new MobEffect(b0, j, b1));
            }

        }
    }

    public boolean aj()
    {
        return !dead && health > 0;
    }

    public boolean f()
    {
        return false;
    }

    public void d()
    {
        if(d > 0)
            d--;
        if(aK > 0)
        {
            double d0 = locX + (aL - locX) / (double)aK;
            double d1 = locY + (aM - locY) / (double)aK;
            double d2 = locZ + (aN - locZ) / (double)aK;
            double d3;
            for(d3 = aO - (double)yaw; d3 < -180D; d3 += 360D);
            for(; d3 >= 180D; d3 -= 360D);
            yaw = (float)((double)yaw + d3 / (double)aK);
            pitch = (float)((double)pitch + (aP - (double)pitch) / (double)aK);
            aK--;
            setPosition(d0, d1, d2);
            c(yaw, pitch);
            List list = world.getEntities(this, boundingBox.shrink(0.03125D, 0.0D, 0.03125D));
            if(list.size() > 0)
            {
                double d4 = 0.0D;
                for(int i = 0; i < list.size(); i++)
                {
                    AxisAlignedBB axisalignedbb = (AxisAlignedBB)list.get(i);
                    if(axisalignedbb.e > d4)
                        d4 = axisalignedbb.e;
                }

                d1 += d4 - boundingBox.b;
                setPosition(d0, d1, d2);
            }
        }
        if(L())
        {
            aW = false;
            aT = 0.0F;
            aU = 0.0F;
            aV = 0.0F;
        } else
        if(!aj)
            m_();
        boolean flag = az();
        boolean flag1 = aA();
        if(aW)
        {
            if(flag)
                motY += 0.039999999105930328D;
            else
            if(flag1)
                motY += 0.039999999105930328D;
            else
            if(onGround && d == 0)
            {
                X();
                d = 10;
            }
        } else
        {
            d = 0;
        }
        aT *= 0.98F;
        aU *= 0.98F;
        aV *= 0.9F;
        float f = ak;
        ak *= F();
        a(aT, aU);
        ak = f;
        List list1 = world.b(this, boundingBox.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
        if(list1 != null && list1.size() > 0)
        {
            for(int j = 0; j < list1.size(); j++)
            {
                Entity entity = (Entity)list1.get(j);
                if(entity.f_())
                    entity.collide(this);
            }

        }
    }

    protected boolean L()
    {
        return health <= 0;
    }

    public boolean K()
    {
        return false;
    }

    protected void X()
    {
        motY = 0.41999998688697815D;
        if(hasEffect(MobEffectList.JUMP))
            motY += (float)(getEffect(MobEffectList.JUMP).getAmplifier() + 1) * 0.1F;
        if(isSprinting())
        {
            float f = yaw * 0.01745329F;
            motX -= MathHelper.sin(f) * 0.2F;
            motZ += MathHelper.cos(f) * 0.2F;
        }
        cb = true;
    }

    protected boolean d_()
    {
        return true;
    }

    protected void ak()
    {
        EntityHuman entityhuman = world.findNearbyPlayer(this, -1D);
        if(entityhuman != null)
        {
            double d0 = entityhuman.locX - locX;
            double d1 = entityhuman.locY - locY;
            double d2 = entityhuman.locZ - locZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if(d_() && d3 > 16384D)
                die();
            if(aS > 600 && random.nextInt(800) == 0 && d3 > 1024D && d_())
                die();
            else
            if(d3 < 1024D)
                aS = 0;
        }
    }

    protected void m_()
    {
        aS++;
        EntityHuman entityhuman = world.findNearbyPlayer(this, -1D);
        ak();
        aT = 0.0F;
        aU = 0.0F;
        float f = 8F;
        if(random.nextFloat() < 0.02F)
        {
            entityhuman = world.findNearbyPlayer(this, f);
            if(entityhuman != null)
            {
                e = entityhuman;
                aZ = 10 + random.nextInt(20);
            } else
            {
                aV = (random.nextFloat() - 0.5F) * 20F;
            }
        }
        if(e != null)
        {
            a(e, 10F, q_());
            if(aZ-- <= 0 || e.dead || e.i(this) > (double)(f * f))
                e = null;
        } else
        {
            if(random.nextFloat() < 0.05F)
                aV = (random.nextFloat() - 0.5F) * 20F;
            yaw += aV;
            pitch = aX;
        }
        boolean flag = az();
        boolean flag1 = aA();
        if(flag || flag1)
            aW = random.nextFloat() < 0.8F;
    }

    protected int q_()
    {
        return 40;
    }

    public void a(Entity entity, float f, float f1)
    {
        double d0 = entity.locX - locX;
        double d1 = entity.locZ - locZ;
        double d2;
        if(entity instanceof EntityLiving)
        {
            EntityLiving entityliving = (EntityLiving)entity;
            d2 = (locY + (double)x()) - (entityliving.locY + (double)entityliving.x());
        } else
        {
            d2 = (entity.boundingBox.b + entity.boundingBox.e) / 2D - (locY + (double)x());
        }
        double d3 = MathHelper.a(d0 * d0 + d1 * d1);
        float f2 = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - 90F;
        float f3 = (float)(-((Math.atan2(d2, d3) * 180D) / 3.1415927410125732D));
        pitch = -b(pitch, f3, f1);
        yaw = b(yaw, f2, f);
    }

    public boolean al()
    {
        return e != null;
    }

    public Entity am()
    {
        return e;
    }

    private float b(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f1 - f; f3 < -180F; f3 += 360F);
        for(; f3 >= 180F; f3 -= 360F);
        if(f3 > f2)
            f3 = f2;
        if(f3 < -f2)
            f3 = -f2;
        return f + f3;
    }

    public void an()
    {
    }

    public boolean g()
    {
        return world.containsEntity(boundingBox) && world.getEntities(this, boundingBox).size() == 0 && !world.c(boundingBox);
    }

    protected void ao()
    {
        EntityDamageByBlockEvent event = new EntityDamageByBlockEvent(null, getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.VOID, 4);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled() || event.getDamage() == 0)
        {
            return;
        } else
        {
            damageEntity(DamageSource.OUT_OF_WORLD, event.getDamage());
            return;
        }
    }

    public Vec3D ap()
    {
        return d(1.0F);
    }

    public Vec3D d(float f)
    {
        if(f == 1.0F)
        {
            float f1 = MathHelper.cos(-yaw * 0.01745329F - 3.141593F);
            float f2 = MathHelper.sin(-yaw * 0.01745329F - 3.141593F);
            float f3 = -MathHelper.cos(-pitch * 0.01745329F);
            float f4 = MathHelper.sin(-pitch * 0.01745329F);
            return Vec3D.create(f2 * f3, f4, f1 * f3);
        } else
        {
            float f1 = lastPitch + (pitch - lastPitch) * f;
            float f2 = lastYaw + (yaw - lastYaw) * f;
            float f3 = MathHelper.cos(-f2 * 0.01745329F - 3.141593F);
            float f4 = MathHelper.sin(-f2 * 0.01745329F - 3.141593F);
            float f5 = -MathHelper.cos(-f1 * 0.01745329F);
            float f6 = MathHelper.sin(-f1 * 0.01745329F);
            return Vec3D.create(f4 * f5, f6, f3 * f5);
        }
    }

    public int p()
    {
        return 4;
    }

    public boolean isSleeping()
    {
        return false;
    }

    protected void aq()
    {
        Iterator iterator = effects.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Integer integer = (Integer)iterator.next();
            MobEffect mobeffect = (MobEffect)effects.get(integer);
            if(!mobeffect.tick(this) && !world.isStatic)
            {
                iterator.remove();
                d(mobeffect);
            }
        } while(true);
        if(b)
        {
            if(!world.isStatic)
                if(!effects.isEmpty())
                {
                    int i = PotionBrewer.a(effects.values());
                    datawatcher.watch(8, Integer.valueOf(i));
                } else
                {
                    datawatcher.watch(8, Integer.valueOf(0));
                }
            b = false;
        }
        if(random.nextBoolean())
        {
            int i = datawatcher.getInt(8);
            if(i > 0)
            {
                double d0 = (double)(i >> 16 & 0xff) / 255D;
                double d1 = (double)(i >> 8 & 0xff) / 255D;
                double d2 = (double)(i >> 0 & 0xff) / 255D;
                world.a("mobSpell", locX + (random.nextDouble() - 0.5D) * (double)length, (locY + random.nextDouble() * (double)width) - (double)height, locZ + (random.nextDouble() - 0.5D) * (double)length, d0, d1, d2);
            }
        }
    }

    public void ar()
    {
        Iterator iterator = effects.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Integer integer = (Integer)iterator.next();
            MobEffect mobeffect = (MobEffect)effects.get(integer);
            if(!world.isStatic)
            {
                iterator.remove();
                d(mobeffect);
            }
        } while(true);
    }

    public Collection getEffects()
    {
        return effects.values();
    }

    public boolean hasEffect(MobEffectList mobeffectlist)
    {
        return effects.containsKey(Integer.valueOf(mobeffectlist.id));
    }

    public MobEffect getEffect(MobEffectList mobeffectlist)
    {
        return (MobEffect)effects.get(Integer.valueOf(mobeffectlist.id));
    }

    public void addEffect(MobEffect mobeffect)
    {
        if(a(mobeffect))
            if(effects.containsKey(Integer.valueOf(mobeffect.getEffectId())))
            {
                ((MobEffect)effects.get(Integer.valueOf(mobeffect.getEffectId()))).a(mobeffect);
                c((MobEffect)effects.get(Integer.valueOf(mobeffect.getEffectId())));
            } else
            {
                effects.put(Integer.valueOf(mobeffect.getEffectId()), mobeffect);
                b(mobeffect);
            }
    }

    public boolean a(MobEffect mobeffect)
    {
        if(t() == EnchantmentDamage.b)
        {
            int i = mobeffect.getEffectId();
            if(i == MobEffectList.REGENERATION.id || i == MobEffectList.POISON.id)
                return false;
        }
        return true;
    }

    public boolean at()
    {
        return t() == EnchantmentDamage.b;
    }

    protected void b(MobEffect mobeffect)
    {
        b = true;
    }

    protected void c(MobEffect mobeffect)
    {
        b = true;
    }

    protected void d(MobEffect mobeffect)
    {
        b = true;
    }

    protected float F()
    {
        float f = 1.0F;
        if(hasEffect(MobEffectList.FASTER_MOVEMENT))
            f *= 1.0F + 0.2F * (float)(getEffect(MobEffectList.FASTER_MOVEMENT).getAmplifier() + 1);
        if(hasEffect(MobEffectList.SLOWER_MOVEMENT))
            f *= 1.0F - 0.15F * (float)(getEffect(MobEffectList.SLOWER_MOVEMENT).getAmplifier() + 1);
        return f;
    }

    public void a_(double d0, double d1, double d2)
    {
        setPositionRotation(d0, d1, d2, yaw, pitch);
    }

    public boolean l()
    {
        return false;
    }

    public EnchantmentDamage t()
    {
        return EnchantmentDamage.a;
    }

    public void c(net.minecraft.server.ItemStack itemstack)
    {
        world.makeSound(this, "random.break", 0.8F, 0.8F + world.random.nextFloat() * 0.4F);
        for(int i = 0; i < 5; i++)
        {
            Vec3D vec3d = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
            vec3d.a((-pitch * 3.141593F) / 180F);
            vec3d.b((-yaw * 3.141593F) / 180F);
            Vec3D vec3d1 = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-random.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
            vec3d1.a((-pitch * 3.141593F) / 180F);
            vec3d1.b((-yaw * 3.141593F) / 180F);
            vec3d1 = vec3d1.add(locX, locY + (double)x(), locZ);
            world.a((new StringBuilder()).append("iconcrack_").append(itemstack.getItem().id).toString(), vec3d1.a, vec3d1.b, vec3d1.c, vec3d.a, vec3d.b + 0.050000000000000003D, vec3d.c);
        }

    }

    public int maxNoDamageTicks;
    public float T;
    public float U;
    public float V;
    public float W;
    protected float X;
    protected float Y;
    protected float Z;
    protected float aa;
    protected boolean ab;
    protected String texture;
    protected boolean ad;
    protected float ae;
    protected String af;
    protected float ag;
    protected int ah;
    protected float ai;
    public boolean aj;
    public float ak;
    public float al;
    public float am;
    public float an;
    protected int health;
    public int ap;
    protected int aq;
    private int a;
    public int hurtTicks;
    public int as;
    public float at;
    public int deathTicks;
    public int attackTicks;
    public float aw;
    public float ax;
    protected boolean ay;
    protected int az;
    public int aA;
    public float aB;
    public float aC;
    public float aD;
    public float aE;
    protected EntityHuman aF;
    protected int aG;
    public int aH;
    public int aI;
    protected HashMap effects;
    private boolean b;
    private int c;
    protected int aK;
    protected double aL;
    protected double aM;
    protected double aN;
    protected double aO;
    protected double aP;
    float aQ;
    public int lastDamage;
    protected int aS;
    protected float aT;
    protected float aU;
    protected float aV;
    protected boolean aW;
    protected float aX;
    protected float aY;
    private int d;
    private Entity e;
    protected int aZ;
    public int expToDrop;
}
