// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Block, BlockGrass, WorldGenTrees, WorldGenBigTree, 
//            WorldGenForest, WorldGenSwampTree, BiomeMeta, EntitySheep, 
//            EntityPig, EntityChicken, EntityCow, EntitySpider, 
//            EntityZombie, EntitySkeleton, EntityCreeper, EntitySlime, 
//            EntityEnderman, EntitySquid, BiomeDecorator, EnumCreatureType, 
//            BiomeOcean, BiomePlains, BiomeDesert, BiomeBigHills, 
//            BiomeForest, BiomeTaiga, BiomeSwamp, BiomeRiver, 
//            BiomeHell, BiomeSky, BiomeIcePlains, BiomeMushrooms, 
//            WorldGenerator, World

public abstract class BiomeBase
{

    protected BiomeBase(int i)
    {
        t = (byte)Block.GRASS.id;
        u = (byte)Block.DIRT.id;
        v = 0x4ee031;
        w = 0.1F;
        x = 0.3F;
        y = 0.5F;
        z = 0.5F;
        A = 0xffffff;
        C = new ArrayList();
        D = new ArrayList();
        E = new ArrayList();
        L = true;
        G = new WorldGenTrees(false);
        H = new WorldGenBigTree(false);
        I = new WorldGenForest(false);
        J = new WorldGenSwampTree();
        F = i;
        a[i] = this;
        B = a();
        D.add(new BiomeMeta(net/minecraft/server/EntitySheep, 12, 4, 4));
        D.add(new BiomeMeta(net/minecraft/server/EntityPig, 10, 4, 4));
        D.add(new BiomeMeta(net/minecraft/server/EntityChicken, 10, 4, 4));
        D.add(new BiomeMeta(net/minecraft/server/EntityCow, 8, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntitySpider, 10, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntityZombie, 10, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntitySkeleton, 10, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntityCreeper, 10, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntitySlime, 10, 4, 4));
        C.add(new BiomeMeta(net/minecraft/server/EntityEnderman, 1, 1, 4));
        E.add(new BiomeMeta(net/minecraft/server/EntitySquid, 10, 4, 4));
    }

    protected BiomeDecorator a()
    {
        return new BiomeDecorator(this);
    }

    private BiomeBase a(float f1, float f2)
    {
        if(f1 > 0.1F && f1 < 0.2F)
        {
            throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
        } else
        {
            y = f1;
            z = f2;
            return this;
        }
    }

    private BiomeBase b(float f1, float f2)
    {
        w = f1;
        x = f2;
        return this;
    }

    private BiomeBase g()
    {
        L = false;
        return this;
    }

    public WorldGenerator a(Random random)
    {
        if(random.nextInt(10) == 0)
            return H;
        else
            return G;
    }

    protected BiomeBase a(String s1)
    {
        r = s1;
        return this;
    }

    protected BiomeBase a(int i)
    {
        v = i;
        return this;
    }

    protected BiomeBase b(int i)
    {
        s = i;
        return this;
    }

    public List a(EnumCreatureType enumcreaturetype)
    {
        if(enumcreaturetype == EnumCreatureType.MONSTER)
            return C;
        if(enumcreaturetype == EnumCreatureType.CREATURE)
            return D;
        if(enumcreaturetype == EnumCreatureType.WATER_CREATURE)
            return E;
        else
            return null;
    }

    public boolean b()
    {
        return K;
    }

    public boolean c()
    {
        if(K)
            return false;
        else
            return L;
    }

    public float d()
    {
        return 0.1F;
    }

    public final int e()
    {
        return (int)(z * 65536F);
    }

    public final int f()
    {
        return (int)(y * 65536F);
    }

    public void a(World world, Random random, int i, int j)
    {
        B.a(world, random, i, j);
    }

    public static final BiomeBase a[] = new BiomeBase[256];
    public static final BiomeBase OCEAN = (new BiomeOcean(0)).b(112).a("Ocean").b(-1F, 0.4F);
    public static final BiomeBase PLAINS = (new BiomePlains(1)).b(0x8db360).a("Plains").a(0.8F, 0.4F);
    public static final BiomeBase DESERT = (new BiomeDesert(2)).b(0xfa9418).a("Desert").g().a(2.0F, 0.0F).b(0.1F, 0.2F);
    public static final BiomeBase EXTREME_HILLS = (new BiomeBigHills(3)).b(0x606060).a("Extreme Hills").b(0.2F, 1.8F).a(0.2F, 0.3F);
    public static final BiomeBase FOREST = (new BiomeForest(4)).b(0x56621).a("Forest").a(0x4eba31).a(0.7F, 0.8F);
    public static final BiomeBase TAIGA = (new BiomeTaiga(5)).b(0xb6659).a("Taiga").a(0x4eba31).a(0.3F, 0.8F).b(0.1F, 0.4F);
    public static final BiomeBase SWAMPLAND = (new BiomeSwamp(6)).b(0x7f9b2).a("Swampland").a(0x8baf48).b(-0.2F, 0.1F).a(0.8F, 0.9F);
    public static final BiomeBase RIVER = (new BiomeRiver(7)).b(255).a("River").b(-0.5F, 0.0F);
    public static final BiomeBase HELL = (new BiomeHell(8)).b(0xff0000).a("Hell").g().a(2.0F, 0.0F);
    public static final BiomeBase SKY = (new BiomeSky(9)).b(0x8080ff).a("Sky").g();
    public static final BiomeBase FROZEN_OCEAN = (new BiomeOcean(10)).b(0x9090a0).a("FrozenOcean").b(-1F, 0.5F).a(0.0F, 0.5F);
    public static final BiomeBase FROZEN_RIVER = (new BiomeRiver(11)).b(0xa0a0ff).a("FrozenRiver").b(-0.5F, 0.0F).a(0.0F, 0.5F);
    public static final BiomeBase ICE_PLAINS = (new BiomeIcePlains(12)).b(0xffffff).a("Ice Plains").a(0.0F, 0.5F);
    public static final BiomeBase ICE_MOUNTAINS = (new BiomeIcePlains(13)).b(0xa0a0a0).a("Ice Mountains").b(0.2F, 1.8F).a(0.0F, 0.5F);
    public static final BiomeBase MUSHROOM_ISLAND = (new BiomeMushrooms(14)).b(0xff00ff).a("MushroomIsland").a(0.9F, 1.0F).b(0.2F, 1.0F);
    public static final BiomeBase MUSHROOM_SHORE = (new BiomeMushrooms(15)).b(0xa000ff).a("MushroomIslandShore").a(0.9F, 1.0F).b(-1F, 0.1F);
    public String r;
    public int s;
    public byte t;
    public byte u;
    public int v;
    public float w;
    public float x;
    public float y;
    public float z;
    public int A;
    public BiomeDecorator B;
    protected List C;
    protected List D;
    protected List E;
    private boolean K;
    private boolean L;
    public final int F;
    protected WorldGenTrees G;
    protected WorldGenBigTree H;
    protected WorldGenForest I;
    protected WorldGenSwampTree J;

}
