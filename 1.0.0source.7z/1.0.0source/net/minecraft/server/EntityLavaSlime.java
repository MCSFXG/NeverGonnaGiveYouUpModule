// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityLavaSlime.java

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            EntitySlime, World

public class EntityLavaSlime extends EntitySlime
{

    public EntityLavaSlime(World world)
    {
        super(world);
        texture = "/mob/lava.png";
        fireProof = true;
        ak = 0.2F;
    }

    public boolean g()
    {
        return world.difficulty > 0 && world.containsEntity(boundingBox) && world.getEntities(this, boundingBox).size() == 0 && !world.c(boundingBox);
    }

    protected int O()
    {
        return getSize() * 3;
    }

    public float a(float f)
    {
        return 1.0F;
    }

    protected String w()
    {
        return "flame";
    }

    protected EntitySlime y()
    {
        return new EntityLavaSlime(world);
    }

    protected int e()
    {
        return 0;
    }

    public boolean z()
    {
        return false;
    }

    protected int A()
    {
        return super.A() * 4;
    }

    protected void B()
    {
        a *= 0.9F;
    }

    protected void X()
    {
        motY = 0.42F + (float)getSize() * 0.1F;
        cb = true;
    }

    protected void b(float f1)
    {
    }

    protected boolean C()
    {
        return true;
    }

    protected int D()
    {
        return super.D() + 2;
    }

    protected String m()
    {
        return "mob.slime";
    }

    protected String n()
    {
        return "mob.slime";
    }

    protected String E()
    {
        return getSize() <= 1 ? "mob.magmacube.small" : "mob.magmacube.big";
    }

    public boolean aA()
    {
        return false;
    }

    protected boolean G()
    {
        return true;
    }
}
