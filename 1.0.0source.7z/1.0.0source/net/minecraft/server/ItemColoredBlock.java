// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemBlock, Block, ItemStack

public class ItemColoredBlock extends ItemBlock
{

    public ItemColoredBlock(int i, boolean flag)
    {
        super(i);
        a = Block.byId[a()];
        if(flag)
        {
            f(0);
            a(true);
        }
    }

    public int filterData(int i)
    {
        return i;
    }

    public ItemColoredBlock a(String as[])
    {
        b = as;
        return this;
    }

    public String a(ItemStack itemstack)
    {
        if(b == null)
            return super.a(itemstack);
        int i = itemstack.getData();
        if(i >= 0 && i < b.length)
            return (new StringBuilder()).append(super.a(itemstack)).append(".").append(b[i]).toString();
        else
            return super.a(itemstack);
    }

    private final Block a;
    private String b[];
}
