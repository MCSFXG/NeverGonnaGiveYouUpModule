// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EnchantmentModifier1.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EnchantmentModifier, Enchantment, DamageSource, EmptyClass3

final class EnchantmentModifier1
    implements EnchantmentModifier
{

    private EnchantmentModifier1()
    {
    }

    public void a(Enchantment enchantment, int i)
    {
        a += enchantment.a(i, b);
    }

    EnchantmentModifier1(EmptyClass3 emptyclass3)
    {
        this();
    }

    public int a;
    public DamageSource b;
}
