// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, EnumArmorMaterial

public class ItemArmor extends Item
{

    public ItemArmor(int i, EnumArmorMaterial enumarmormaterial, int j, int k)
    {
        super(i);
        bT = enumarmormaterial;
        a = k;
        bR = j;
        b = enumarmormaterial.b(k);
        f(enumarmormaterial.a(k));
        maxStackSize = 1;
    }

    public int c()
    {
        return bT.a();
    }

    static int[] n()
    {
        return bS;
    }

    private static final int bS[] = {
        11, 16, 15, 13
    };
    public final int a;
    public final int b;
    public final int bR;
    private final EnumArmorMaterial bT;

}
