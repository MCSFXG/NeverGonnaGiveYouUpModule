// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World

public class BlockMycel extends Block
{

    protected BlockMycel(int i)
    {
        super(i, Material.GRASS);
        textureId = 77;
        a(true);
    }

    public int a(int i, int j)
    {
        if(i == 1)
            return 78;
        return i != 0 ? 77 : 2;
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        if(world.isStatic)
            return;
        if(world.getLightLevel(i, j + 1, k) < 4 && Block.q[world.getTypeId(i, j + 1, k)] > 2)
            world.setTypeId(i, j, k, Block.DIRT.id);
        else
        if(world.getLightLevel(i, j + 1, k) >= 9)
        {
            for(int l = 0; l < 4; l++)
            {
                int i1 = (i + random.nextInt(3)) - 1;
                int j1 = (j + random.nextInt(5)) - 3;
                int k1 = (k + random.nextInt(3)) - 1;
                int l1 = world.getTypeId(i1, j1 + 1, k1);
                if(world.getTypeId(i1, j1, k1) == Block.DIRT.id && world.getLightLevel(i1, j1 + 1, k1) >= 4 && Block.q[l1] <= 2)
                    world.setTypeId(i1, j1, k1, id);
            }

        }
    }

    public int a(int i, Random random, int j)
    {
        return Block.DIRT.a(0, random, j);
    }
}
