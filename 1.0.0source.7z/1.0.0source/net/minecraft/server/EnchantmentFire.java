// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType

public class EnchantmentFire extends Enchantment
{

    protected EnchantmentFire(int i, int j)
    {
        super(i, j, EnchantmentSlotType.WEAPON);
        a("fire");
    }

    public int a(int i)
    {
        return 10 + 20 * (i - 1);
    }

    public int b(int i)
    {
        return super.a(i) + 50;
    }

    public int getMaxLevel()
    {
        return 2;
    }
}
