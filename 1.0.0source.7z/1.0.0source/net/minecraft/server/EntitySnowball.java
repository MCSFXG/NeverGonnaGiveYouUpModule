// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySnowball.java

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftLivingEntity;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityProjectile, EntityBlaze, EntityLiving, MovingObjectPosition, 
//            World, Entity, DamageSource

public class EntitySnowball extends EntityProjectile
{

    public EntitySnowball(World world)
    {
        super(world);
    }

    public EntitySnowball(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntitySnowball(World world, double d0, double d1, double d2)
    {
        super(world, d0, d1, d2);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(movingobjectposition.entity != null)
        {
            byte b0 = 0;
            if(movingobjectposition.entity instanceof EntityBlaze)
                b0 = 3;
            ProjectileHitEvent hitEvent = new ProjectileHitEvent((Projectile)getBukkitEntity());
            world.getServer().getPluginManager().callEvent(hitEvent);
            boolean stick = false;
            if(movingobjectposition.entity != null)
                if(movingobjectposition.entity instanceof EntityLiving)
                {
                    org.bukkit.entity.Entity damagee = movingobjectposition.entity.getBukkitEntity();
                    Projectile projectile = (Projectile)getBukkitEntity();
                    EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(projectile, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.PROJECTILE, b0);
                    world.getServer().getPluginManager().callEvent(event);
                    shooter = projectile.getShooter() != null ? ((CraftLivingEntity)projectile.getShooter()).getHandle() : null;
                    b0 = (byte)event.getDamage();
                    if(event.isCancelled())
                        stick = !projectile.doesBounce();
                    else
                        stick = movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), b0);
                } else
                {
                    stick = movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), b0);
                }
            if(!stick);
        }
        for(int i = 0; i < 8; i++)
            world.a("snowballpoof", locX, locY, locZ, 0.0D, 0.0D, 0.0D);

        if(!world.isStatic)
            die();
    }
}
