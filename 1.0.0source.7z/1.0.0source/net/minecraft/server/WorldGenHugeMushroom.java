// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenerator, World, Block, BlockLeaves, 
//            BlockGrass, BlockMycel, BlockFlower

public class WorldGenHugeMushroom extends WorldGenerator
{

    public WorldGenHugeMushroom(int i)
    {
        a = -1;
        a = i;
    }

    public WorldGenHugeMushroom()
    {
        a = -1;
    }

    public boolean a(World world, Random random, int i, int j, int k)
    {
        int l = random.nextInt(2);
        if(a >= 0)
            l = a;
        int i1 = random.nextInt(3) + 4;
        boolean flag = true;
        if(j < 1 || j + i1 + 1 > world.height)
            return false;
        for(int j1 = j; j1 <= j + 1 + i1; j1++)
        {
            byte byte0 = 3;
            if(j1 == j)
                byte0 = 0;
            for(int i2 = i - byte0; i2 <= i + byte0 && flag; i2++)
            {
                for(int l2 = k - byte0; l2 <= k + byte0 && flag; l2++)
                    if(j1 >= 0 && j1 < world.height)
                    {
                        int k3 = world.getTypeId(i2, j1, l2);
                        if(k3 != 0 && k3 != Block.LEAVES.id)
                            flag = false;
                    } else
                    {
                        flag = false;
                    }

            }

        }

        if(!flag)
            return false;
        int k1 = world.getTypeId(i, j - 1, k);
        if(k1 != Block.DIRT.id && k1 != Block.GRASS.id && k1 != Block.MYCEL.id)
            return false;
        if(!Block.BROWN_MUSHROOM.canPlace(world, i, j, k))
            return false;
        world.setRawTypeId(i, j - 1, k, Block.DIRT.id);
        int l1 = j + i1;
        if(l == 1)
            l1 = (j + i1) - 3;
        for(int j2 = l1; j2 <= j + i1; j2++)
        {
            int i3 = 1;
            if(j2 < j + i1)
                i3++;
            if(l == 0)
                i3 = 3;
            for(int l3 = i - i3; l3 <= i + i3; l3++)
            {
                for(int i4 = k - i3; i4 <= k + i3; i4++)
                {
                    int j4 = 5;
                    if(l3 == i - i3)
                        j4--;
                    if(l3 == i + i3)
                        j4++;
                    if(i4 == k - i3)
                        j4 -= 3;
                    if(i4 == k + i3)
                        j4 += 3;
                    if(l == 0 || j2 < j + i1)
                    {
                        if((l3 == i - i3 || l3 == i + i3) && (i4 == k - i3 || i4 == k + i3))
                            continue;
                        if(l3 == i - (i3 - 1) && i4 == k - i3)
                            j4 = 1;
                        if(l3 == i - i3 && i4 == k - (i3 - 1))
                            j4 = 1;
                        if(l3 == i + (i3 - 1) && i4 == k - i3)
                            j4 = 3;
                        if(l3 == i + i3 && i4 == k - (i3 - 1))
                            j4 = 3;
                        if(l3 == i - (i3 - 1) && i4 == k + i3)
                            j4 = 7;
                        if(l3 == i - i3 && i4 == k + (i3 - 1))
                            j4 = 7;
                        if(l3 == i + (i3 - 1) && i4 == k + i3)
                            j4 = 9;
                        if(l3 == i + i3 && i4 == k + (i3 - 1))
                            j4 = 9;
                    }
                    if(j4 == 5 && j2 < j + i1)
                        j4 = 0;
                    if((j4 != 0 || j >= (j + i1) - 1) && !Block.o[world.getTypeId(l3, j2, i4)])
                        world.setRawTypeIdAndData(l3, j2, i4, Block.BIG_MUSHROOM_1.id + l, j4);
                }

            }

        }

        for(int k2 = 0; k2 < i1; k2++)
        {
            int j3 = world.getTypeId(i, j + k2, k);
            if(!Block.o[j3])
                world.setRawTypeIdAndData(i, j + k2, k, Block.BIG_MUSHROOM_1.id + l, 10);
        }

        return true;
    }

    private int a;
}
