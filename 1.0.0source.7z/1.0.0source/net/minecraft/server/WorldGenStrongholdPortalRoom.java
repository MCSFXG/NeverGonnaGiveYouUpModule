// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenStrongholdPiece, WorldGenStrongholdStairs2, StructureBoundingBox, StructurePiece, 
//            WorldGenStrongholdPieces, WorldGenStrongholdDoorType, Block, World, 
//            TileEntityMobSpawner

public class WorldGenStrongholdPortalRoom extends WorldGenStrongholdPiece
{

    public WorldGenStrongholdPortalRoom(int i, Random random, StructureBoundingBox structureboundingbox, int j)
    {
        super(i);
        h = j;
        g = structureboundingbox;
    }

    public void a(StructurePiece structurepiece, List list, Random random)
    {
        if(structurepiece != null)
            ((WorldGenStrongholdStairs2)structurepiece).b = this;
    }

    public static WorldGenStrongholdPortalRoom a(List list, Random random, int i, int j, int k, int l, int i1)
    {
        StructureBoundingBox structureboundingbox = StructureBoundingBox.a(i, j, k, -4, -1, 0, 11, 8, 16, l);
        if(!a(structureboundingbox) || StructurePiece.a(list, structureboundingbox) != null)
            return null;
        else
            return new WorldGenStrongholdPortalRoom(i1, random, structureboundingbox, l);
    }

    public boolean a(World world, Random random, StructureBoundingBox structureboundingbox)
    {
        a(world, structureboundingbox, 0, 0, 0, 10, 7, 15, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, random, structureboundingbox, WorldGenStrongholdDoorType.c, 4, 1, 0);
        byte byte0 = 6;
        a(world, structureboundingbox, 1, byte0, 1, 1, byte0, 14, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 9, byte0, 1, 9, byte0, 14, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 2, byte0, 1, 8, byte0, 2, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 2, byte0, 14, 8, byte0, 14, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 1, 1, 1, 2, 1, 4, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 8, 1, 1, 9, 1, 4, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 1, 1, 1, 1, 1, 3, Block.LAVA.id, Block.LAVA.id, false);
        a(world, structureboundingbox, 9, 1, 1, 9, 1, 3, Block.LAVA.id, Block.LAVA.id, false);
        a(world, structureboundingbox, 3, 1, 8, 7, 1, 12, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 4, 1, 9, 6, 1, 11, Block.LAVA.id, Block.LAVA.id, false);
        for(int j = 3; j < 14; j += 2)
        {
            a(world, structureboundingbox, 0, 3, j, 0, 4, j, Block.IRON_FENCE.id, Block.IRON_FENCE.id, false);
            a(world, structureboundingbox, 10, 3, j, 10, 4, j, Block.IRON_FENCE.id, Block.IRON_FENCE.id, false);
        }

        for(int k = 2; k < 9; k += 2)
            a(world, structureboundingbox, k, 3, 15, k, 4, 15, Block.IRON_FENCE.id, Block.IRON_FENCE.id, false);

        int l = c(Block.STONE_STAIRS.id, 3);
        a(world, structureboundingbox, 4, 1, 5, 6, 1, 7, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 4, 2, 6, 6, 2, 7, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        a(world, structureboundingbox, 4, 3, 7, 6, 3, 7, false, random, ((StructurePIeceBlockSelector) (WorldGenStrongholdPieces.b())));
        for(int i1 = 4; i1 <= 6; i1++)
        {
            a(world, Block.STONE_STAIRS.id, l, i1, 1, 4, structureboundingbox);
            a(world, Block.STONE_STAIRS.id, l, i1, 2, 5, structureboundingbox);
            a(world, Block.STONE_STAIRS.id, l, i1, 3, 6, structureboundingbox);
        }

        byte byte1 = 2;
        byte byte2 = 0;
        byte byte3 = 3;
        byte byte4 = 1;
        switch(h)
        {
        case 0: // '\0'
            byte1 = 0;
            byte2 = 2;
            break;

        case 3: // '\003'
            byte1 = 3;
            byte2 = 1;
            byte3 = 0;
            byte4 = 2;
            break;

        case 1: // '\001'
            byte1 = 1;
            byte2 = 3;
            byte3 = 0;
            byte4 = 2;
            break;
        }
        a(world, Block.ENDER_PORTAL_FRAME.id, byte1 + (random.nextFloat() <= 0.9F ? 0 : 4), 4, 3, 8, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte1 + (random.nextFloat() <= 0.9F ? 0 : 4), 5, 3, 8, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte1 + (random.nextFloat() <= 0.9F ? 0 : 4), 6, 3, 8, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte2 + (random.nextFloat() <= 0.9F ? 0 : 4), 4, 3, 12, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte2 + (random.nextFloat() <= 0.9F ? 0 : 4), 5, 3, 12, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte2 + (random.nextFloat() <= 0.9F ? 0 : 4), 6, 3, 12, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte3 + (random.nextFloat() <= 0.9F ? 0 : 4), 3, 3, 9, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte3 + (random.nextFloat() <= 0.9F ? 0 : 4), 3, 3, 10, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte3 + (random.nextFloat() <= 0.9F ? 0 : 4), 3, 3, 11, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte4 + (random.nextFloat() <= 0.9F ? 0 : 4), 7, 3, 9, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte4 + (random.nextFloat() <= 0.9F ? 0 : 4), 7, 3, 10, structureboundingbox);
        a(world, Block.ENDER_PORTAL_FRAME.id, byte4 + (random.nextFloat() <= 0.9F ? 0 : 4), 7, 3, 11, structureboundingbox);
        if(!a)
        {
            int i = b(3);
            int j1 = a(5, 6);
            int k1 = b(5, 6);
            if(structureboundingbox.b(j1, i, k1))
            {
                a = true;
                world.setTypeId(j1, i, k1, Block.MOB_SPAWNER.id);
                TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)world.getTileEntity(j1, i, k1);
                if(tileentitymobspawner != null)
                    tileentitymobspawner.a("Silverfish");
            }
        }
        return true;
    }

    private boolean a;
}
