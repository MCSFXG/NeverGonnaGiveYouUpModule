// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType, EntityLiving, EnchantmentDamage

public class EnchantmentWeaponDamage extends Enchantment
{

    public EnchantmentWeaponDamage(int i, int j, int k)
    {
        super(i, j, EnchantmentSlotType.WEAPON);
        a = k;
    }

    public int a(int i)
    {
        return x[a] + (i - 1) * y[a];
    }

    public int b(int i)
    {
        return a(i) + z[a];
    }

    public int getMaxLevel()
    {
        return 5;
    }

    public int a(int i, EntityLiving entityliving)
    {
        if(a == 0)
            return i * 3;
        if(a == 1 && entityliving.t() == EnchantmentDamage.b)
            return i * 4;
        if(a == 2 && entityliving.t() == EnchantmentDamage.c)
            return i * 4;
        else
            return 0;
    }

    public boolean a(Enchantment enchantment)
    {
        return !(enchantment instanceof EnchantmentWeaponDamage);
    }

    private static final String w[] = {
        "all", "undead", "arthropods"
    };
    private static final int x[] = {
        1, 5, 5
    };
    private static final int y[] = {
        16, 8, 8
    };
    private static final int z[] = {
        20, 20, 20
    };
    public final int a;

}
