// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityBoat.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.vehicle.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, EntityHuman, World, DataWatcher, 
//            DamageSource, Block, Item, AxisAlignedBB, 
//            Material, MathHelper, NBTTagCompound

public class EntityBoat extends Entity
{

    public void collide(Entity entity)
    {
        org.bukkit.entity.Entity hitEntity = entity != null ? entity.getBukkitEntity() : null;
        VehicleEntityCollisionEvent event = new VehicleEntityCollisionEvent((Vehicle)getBukkitEntity(), hitEntity);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled())
        {
            return;
        } else
        {
            super.collide(entity);
            return;
        }
    }

    public EntityBoat(World world)
    {
        super(world);
        maxSpeed = 0.40000000000000002D;
        occupiedDeceleration = 0.20000000000000001D;
        unoccupiedDeceleration = -1D;
        landBoats = false;
        bc = true;
        b(1.5F, 0.6F);
        height = width / 2.0F;
    }

    protected boolean g_()
    {
        return false;
    }

    protected void b()
    {
        datawatcher.a(17, new Integer(0));
        datawatcher.a(18, new Integer(1));
        datawatcher.a(19, new Integer(0));
    }

    public AxisAlignedBB a_(Entity entity)
    {
        return entity.boundingBox;
    }

    public AxisAlignedBB h_()
    {
        return boundingBox;
    }

    public boolean f_()
    {
        return true;
    }

    public EntityBoat(World world, double d0, double d1, double d2)
    {
        this(world);
        setPosition(d0, d1 + (double)height, d2);
        motX = 0.0D;
        motY = 0.0D;
        motZ = 0.0D;
        lastX = d0;
        lastY = d1;
        lastZ = d2;
        this.world.getServer().getPluginManager().callEvent(new VehicleCreateEvent((Vehicle)getBukkitEntity()));
    }

    public double q()
    {
        return (double)width * 0.0D - 0.30000001192092896D;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(!world.isStatic && !dead)
        {
            Vehicle vehicle = (Vehicle)getBukkitEntity();
            org.bukkit.entity.Entity attacker = damagesource.getEntity() != null ? damagesource.getEntity().getBukkitEntity() : null;
            VehicleDamageEvent event = new VehicleDamageEvent(vehicle, attacker, i);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return true;
            d(-l());
            c(10);
            setDamage(getDamage() + i * 10);
            aB();
            if(getDamage() > 40)
            {
                VehicleDestroyEvent destroyEvent = new VehicleDestroyEvent(vehicle, attacker);
                world.getServer().getPluginManager().callEvent(destroyEvent);
                if(destroyEvent.isCancelled())
                {
                    setDamage(40);
                    return true;
                }
                if(passenger != null)
                    passenger.mount(this);
                for(int j = 0; j < 3; j++)
                    a(Block.WOOD.id, 1, 0.0F);

                for(int j = 0; j < 2; j++)
                    a(Item.STICK.id, 1, 0.0F);

                die();
            }
            return true;
        } else
        {
            return true;
        }
    }

    public boolean e_()
    {
        return !dead;
    }

    public void w_()
    {
        double prevX = locX;
        double prevY = locY;
        double prevZ = locZ;
        float prevYaw = yaw;
        float prevPitch = pitch;
        super.w_();
        if(k() > 0)
            c(k() - 1);
        if(getDamage() > 0)
            setDamage(getDamage() - 1);
        lastX = locX;
        lastY = locY;
        lastZ = locZ;
        byte b0 = 5;
        double d0 = 0.0D;
        for(int i = 0; i < b0; i++)
        {
            double d1 = (boundingBox.b + ((boundingBox.e - boundingBox.b) * (double)(i + 0)) / (double)b0) - 0.125D;
            double d2 = (boundingBox.b + ((boundingBox.e - boundingBox.b) * (double)(i + 1)) / (double)b0) - 0.125D;
            AxisAlignedBB axisalignedbb = AxisAlignedBB.b(boundingBox.a, d1, boundingBox.c, boundingBox.d, d2, boundingBox.f);
            if(world.b(axisalignedbb, Material.WATER))
                d0 += 1.0D / (double)b0;
        }

        double d3 = Math.sqrt(motX * motX + motZ * motZ);
        if(d3 > 0.14999999999999999D)
        {
            double d4 = Math.cos(((double)yaw * 3.1415926535897931D) / 180D);
            double d5 = Math.sin(((double)yaw * 3.1415926535897931D) / 180D);
            for(int j = 0; (double)j < 1.0D + d3 * 60D; j++)
            {
                double d6 = random.nextFloat() * 2.0F - 1.0F;
                double d7 = (double)(random.nextInt(2) * 2 - 1) * 0.69999999999999996D;
                if(random.nextBoolean())
                {
                    double d8 = (locX - d4 * d6 * 0.80000000000000004D) + d5 * d7;
                    double d9 = locZ - d5 * d6 * 0.80000000000000004D - d4 * d7;
                    world.a("splash", d8, locY - 0.125D, d9, motX, motY, motZ);
                } else
                {
                    double d8 = locX + d4 + d5 * d6 * 0.69999999999999996D;
                    double d9 = (locZ + d5) - d4 * d6 * 0.69999999999999996D;
                    world.a("splash", d8, locY - 0.125D, d9, motX, motY, motZ);
                }
            }

        }
        if(world.isStatic)
        {
            if(a > 0)
            {
                double d4 = locX + (b - locX) / (double)a;
                double d5 = locY + (c - locY) / (double)a;
                double d10 = locZ + (d - locZ) / (double)a;
                double d11;
                for(d11 = e - (double)yaw; d11 < -180D; d11 += 360D);
                for(; d11 >= 180D; d11 -= 360D);
                yaw = (float)((double)yaw + d11 / (double)a);
                pitch = (float)((double)pitch + (f - (double)pitch) / (double)a);
                a--;
                setPosition(d4, d5, d10);
                c(yaw, pitch);
            } else
            {
                double d4 = locX + motX;
                double d5 = locY + motY;
                double d10 = locZ + motZ;
                setPosition(d4, d5, d10);
                if(onGround)
                {
                    motX *= 0.5D;
                    motY *= 0.5D;
                    motZ *= 0.5D;
                }
                motX *= 0.99000000953674316D;
                motY *= 0.94999998807907104D;
                motZ *= 0.99000000953674316D;
            }
        } else
        {
            double d4;
            if(d0 < 1.0D)
            {
                d4 = d0 * 2D - 1.0D;
                motY += 0.039999999105930328D * d4;
            } else
            {
                if(motY < 0.0D)
                    motY /= 2D;
                motY += 0.0070000002160668373D;
            }
            if(passenger != null)
            {
                motX += passenger.motX * occupiedDeceleration;
                motZ += passenger.motZ * occupiedDeceleration;
            } else
            if(unoccupiedDeceleration >= 0.0D)
            {
                motX *= unoccupiedDeceleration;
                motZ *= unoccupiedDeceleration;
                if(motX <= 1.0000000000000001E-005D)
                    motX = 0.0D;
                if(motZ <= 1.0000000000000001E-005D)
                    motZ = 0.0D;
            }
            d4 = maxSpeed;
            if(motX < -d4)
                motX = -d4;
            if(motX > d4)
                motX = d4;
            if(motZ < -d4)
                motZ = -d4;
            if(motZ > d4)
                motZ = d4;
            if(onGround && !landBoats)
            {
                motX *= 0.5D;
                motY *= 0.5D;
                motZ *= 0.5D;
            }
            move(motX, motY, motZ);
            if(positionChanged && d3 > 0.20000000000000001D)
            {
                if(!world.isStatic)
                {
                    Vehicle vehicle = (Vehicle)getBukkitEntity();
                    VehicleDestroyEvent destroyEvent = new VehicleDestroyEvent(vehicle, null);
                    world.getServer().getPluginManager().callEvent(destroyEvent);
                    if(!destroyEvent.isCancelled())
                    {
                        die();
                        for(int k = 0; k < 3; k++)
                            a(Block.WOOD.id, 1, 0.0F);

                        for(int k = 0; k < 2; k++)
                            a(Item.STICK.id, 1, 0.0F);

                    }
                }
            } else
            {
                motX *= 0.99000000953674316D;
                motY *= 0.94999998807907104D;
                motZ *= 0.99000000953674316D;
            }
            pitch = 0.0F;
            double d5 = yaw;
            double d10 = lastX - locX;
            double d11 = lastZ - locZ;
            if(d10 * d10 + d11 * d11 > 0.001D)
                d5 = (float)((Math.atan2(d11, d10) * 180D) / 3.1415926535897931D);
            double d12;
            for(d12 = d5 - (double)yaw; d12 >= 180D; d12 -= 360D);
            for(; d12 < -180D; d12 += 360D);
            if(d12 > 20D)
                d12 = 20D;
            if(d12 < -20D)
                d12 = -20D;
            yaw = (float)((double)yaw + d12);
            c(yaw, pitch);
            Server server = world.getServer();
            org.bukkit.World bworld = world.getWorld();
            Location from = new Location(bworld, prevX, prevY, prevZ, prevYaw, prevPitch);
            Location to = new Location(bworld, locX, locY, locZ, yaw, pitch);
            Vehicle vehicle = (Vehicle)getBukkitEntity();
            server.getPluginManager().callEvent(new VehicleUpdateEvent(vehicle));
            if(!from.equals(to))
            {
                VehicleMoveEvent event = new VehicleMoveEvent(vehicle, from, to);
                server.getPluginManager().callEvent(event);
            }
            List list = world.b(this, boundingBox.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
            if(list != null && list.size() > 0)
            {
                for(int l = 0; l < list.size(); l++)
                {
                    Entity entity = (Entity)list.get(l);
                    if(entity != passenger && entity.f_() && (entity instanceof EntityBoat))
                        entity.collide(this);
                }

            }
            for(int l = 0; l < 4; l++)
            {
                int i1 = MathHelper.floor(locX + ((double)(l % 2) - 0.5D) * 0.80000000000000004D);
                int j1 = MathHelper.floor(locY);
                int k1 = MathHelper.floor(locZ + ((double)(l / 2) - 0.5D) * 0.80000000000000004D);
                if(world.getTypeId(i1, j1, k1) == Block.SNOW.id)
                    world.setTypeId(i1, j1, k1, 0);
            }

            if(passenger != null && passenger.dead)
            {
                passenger.vehicle = null;
                passenger = null;
            }
        }
    }

    public void i()
    {
        if(passenger != null)
        {
            double d0 = Math.cos(((double)yaw * 3.1415926535897931D) / 180D) * 0.40000000000000002D;
            double d1 = Math.sin(((double)yaw * 3.1415926535897931D) / 180D) * 0.40000000000000002D;
            passenger.setPosition(locX + d0, locY + q() + passenger.R(), locZ + d1);
        }
    }

    protected void b(NBTTagCompound nbttagcompound1)
    {
    }

    protected void a(NBTTagCompound nbttagcompound1)
    {
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(passenger != null && (passenger instanceof EntityHuman) && passenger != entityhuman)
            return true;
        if(!world.isStatic)
        {
            VehicleEnterEvent event = new VehicleEnterEvent((Vehicle)getBukkitEntity(), entityhuman.getBukkitEntity());
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return true;
            entityhuman.mount(this);
        }
        return true;
    }

    public void setDamage(int i)
    {
        datawatcher.watch(19, Integer.valueOf(i));
    }

    public int getDamage()
    {
        return datawatcher.getInt(19);
    }

    public void c(int i)
    {
        datawatcher.watch(17, Integer.valueOf(i));
    }

    public int k()
    {
        return datawatcher.getInt(17);
    }

    public void d(int i)
    {
        datawatcher.watch(18, Integer.valueOf(i));
    }

    public int l()
    {
        return datawatcher.getInt(18);
    }

    private int a;
    private double b;
    private double c;
    private double d;
    private double e;
    private double f;
    public double maxSpeed;
    public double occupiedDeceleration;
    public double unoccupiedDeceleration;
    public boolean landBoats;
}
