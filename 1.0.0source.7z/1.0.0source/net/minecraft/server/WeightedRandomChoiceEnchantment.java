// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            WeightedRandomChoice, Enchantment

public class WeightedRandomChoiceEnchantment extends WeightedRandomChoice
{

    public WeightedRandomChoiceEnchantment(Enchantment enchantment, int i)
    {
        super(enchantment.getRandomWeight());
        a = enchantment;
        b = i;
    }

    public final Enchantment a;
    public final int b;
}
