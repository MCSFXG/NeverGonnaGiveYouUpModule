// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Slot, ContainerEnchantTable, IInventory, ItemStack

class SlotEnchant extends Slot
{

    SlotEnchant(ContainerEnchantTable containerenchanttable, IInventory iinventory, int i, int j, int k)
    {
        a = containerenchanttable;
        super(iinventory, i, j, k);
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        return true;
    }

    final ContainerEnchantTable a;
}
