// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Block, Material, AxisAlignedBB, IBlockAccess, 
//            World

public class BlockFence extends Block
{

    public BlockFence(int i, int j)
    {
        super(i, j, Material.WOOD);
    }

    public BlockFence(int i, int j, Material material)
    {
        super(i, j, material);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return super.canPlace(world, i, j, k);
    }

    public AxisAlignedBB e(World world, int i, int j, int k)
    {
        boolean flag = b(world, i, j, k - 1);
        boolean flag1 = b(world, i, j, k + 1);
        boolean flag2 = b(world, i - 1, j, k);
        boolean flag3 = b(world, i + 1, j, k);
        float f = 0.375F;
        float f1 = 0.625F;
        float f2 = 0.375F;
        float f3 = 0.625F;
        if(flag)
            f2 = 0.0F;
        if(flag1)
            f3 = 1.0F;
        if(flag2)
            f = 0.0F;
        if(flag3)
            f1 = 1.0F;
        return AxisAlignedBB.b((float)i + f, j, (float)k + f2, (float)i + f1, (float)j + 1.5F, (float)k + f3);
    }

    public void a(IBlockAccess iblockaccess, int i, int j, int k)
    {
        boolean flag = b(iblockaccess, i, j, k - 1);
        boolean flag1 = b(iblockaccess, i, j, k + 1);
        boolean flag2 = b(iblockaccess, i - 1, j, k);
        boolean flag3 = b(iblockaccess, i + 1, j, k);
        float f = 0.375F;
        float f1 = 0.625F;
        float f2 = 0.375F;
        float f3 = 0.625F;
        if(flag)
            f2 = 0.0F;
        if(flag1)
            f3 = 1.0F;
        if(flag2)
            f = 0.0F;
        if(flag3)
            f1 = 1.0F;
        a(f, 0.0F, f2, f1, 1.0F, f3);
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public int c()
    {
        return 11;
    }

    public boolean b(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getTypeId(i, j, k);
        if(l == id || l == Block.FENCE_GATE.id)
            return true;
        Block block = Block.byId[l];
        if(block != null && block.material.j() && block.b())
            return block.material != Material.PUMPKIN;
        else
            return false;
    }
}
