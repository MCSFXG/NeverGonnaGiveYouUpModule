// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;

// Referenced classes of package net.minecraft.server:
//            RemoteConnectionThread, IMinecraftServer, StatusChallengeUtils

public class RemoteControlSession extends RemoteConnectionThread
{

    RemoteControlSession(IMinecraftServer iminecraftserver, Socket socket)
    {
        super(iminecraftserver);
        g = false;
        i = new byte[1460];
        h = socket;
        j = iminecraftserver.a("rcon.password", "");
        info((new StringBuilder()).append("Rcon connection from: ").append(socket.getInetAddress()).toString());
    }

    public void run()
    {
_L2:
        if(!running)
            break; /* Loop/switch isn't completed */
        int k;
        BufferedInputStream bufferedinputstream = new BufferedInputStream(h.getInputStream());
        k = bufferedinputstream.read(i, 0, 1460);
        if(10 > k)
        {
            f();
            return;
        }
        int l;
        int i1;
        l = 0;
        i1 = StatusChallengeUtils.b(i, 0, k);
        if(i1 != k - 4)
        {
            f();
            return;
        }
        try
        {
            l += 4;
            int j1 = StatusChallengeUtils.b(i, l, k);
            l += 4;
            int k1 = StatusChallengeUtils.a(i, l);
            l += 4;
            switch(k1)
            {
            case 3: // '\003'
                String s = StatusChallengeUtils.a(i, l, k);
                l += s.length();
                if(0 != s.length() && s.equals(j))
                {
                    g = true;
                    a(j1, 2, "");
                } else
                {
                    g = false;
                    e();
                }
                break;

            case 2: // '\002'
                if(g)
                {
                    String s1 = StatusChallengeUtils.a(i, l, k);
                    try
                    {
                        a(j1, server.d(s1));
                    }
                    catch(Exception exception1)
                    {
                        a(j1, (new StringBuilder()).append("Error executing: ").append(s1).append(" (").append(exception1.getMessage()).append(")").toString());
                    }
                } else
                {
                    e();
                }
                break;

            default:
                a(j1, String.format("Unknown request %s", new Object[] {
                    Integer.toHexString(k1)
                }));
                break;
            }
        }
        catch(SocketTimeoutException sockettimeoutexception) { }
        catch(IOException ioexception)
        {
            if(running)
                info((new StringBuilder()).append("IO: ").append(ioexception.getMessage()).toString());
        }
        if(true) goto _L2; else goto _L1
_L1:
        f();
        break MISSING_BLOCK_LABEL_393;
        Exception exception;
        exception;
        System.out.println(exception);
        f();
        break MISSING_BLOCK_LABEL_393;
        Exception exception2;
        exception2;
        f();
        throw exception2;
    }

    private void a(int k, int l, String s)
    {
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(1248);
        DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);
        dataoutputstream.writeInt(Integer.reverseBytes(s.length() + 10));
        dataoutputstream.writeInt(Integer.reverseBytes(k));
        dataoutputstream.writeInt(Integer.reverseBytes(l));
        dataoutputstream.writeBytes(s);
        dataoutputstream.write(0);
        dataoutputstream.write(0);
        h.getOutputStream().write(bytearrayoutputstream.toByteArray());
    }

    private void e()
    {
        a(-1, 2, "");
    }

    private void a(int k, String s)
    {
        int l = s.length();
        do
        {
            int i1 = 4096 > l ? l : 4096;
            a(k, 0, s.substring(0, i1));
            s = s.substring(i1);
            l = s.length();
        } while(0 != l);
    }

    private void f()
    {
        if(null == h)
            return;
        try
        {
            h.close();
        }
        catch(IOException ioexception)
        {
            warning((new StringBuilder()).append("IO: ").append(ioexception.getMessage()).toString());
        }
        h = null;
    }

    private boolean g;
    private Socket h;
    private byte i[];
    private String j;
}
