// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityHuman.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.World;
import org.bukkit.craftbukkit.*;
import org.bukkit.craftbukkit.entity.CraftItem;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityLiving, InventoryPlayer, FoodMetaData, PlayerAbilities, 
//            ContainerPlayer, Entity, ItemStack, EntityItem, 
//            ChunkCoordinates, NBTTagList, EntityMonster, EntityArrow, 
//            EntityCreeper, EntityGhast, EntityWolf, EntityMinecart, 
//            EntityBoat, EntityPig, World, DataWatcher, 
//            Item, EnumAnimation, Container, StatisticList, 
//            Vec3D, MobEffectList, MobEffect, MathHelper, 
//            AxisAlignedBB, EnchantmentManager, Material, NBTTagCompound, 
//            DamageSource, AchievementList, EnumBedError, WorldProvider, 
//            BlockBed, Block, IChunkProvider, WorldData, 
//            EntityFishingHook, IInventory, TileEntityFurnace, TileEntityDispenser, 
//            TileEntitySign, TileEntityBrewingStand, Statistic

public abstract class EntityHuman extends EntityLiving
{

    public EntityHuman(net.minecraft.server.World world)
    {
        super(world);
        inventory = new InventoryPlayer(this);
        foodData = new FoodMetaData();
        o = 0;
        p = 0;
        q = 0;
        t = false;
        u = 0;
        x = 0;
        spawnWorld = "";
        I = 20;
        J = false;
        abilities = new PlayerAbilities();
        P = 0.1F;
        Q = 0.02F;
        hookedFish = null;
        defaultContainer = new ContainerPlayer(inventory, !world.isStatic);
        activeContainer = defaultContainer;
        height = 1.62F;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        setPositionRotation((double)chunkcoordinates.x + 0.5D, chunkcoordinates.y + 1, (double)chunkcoordinates.z + 0.5D, 0.0F, 0.0F);
        af = "humanoid";
        ae = 180F;
        maxFireTicks = 20;
        texture = "/mob/char.png";
    }

    public int getMaxHealth()
    {
        return 20;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
        datawatcher.a(17, Byte.valueOf((byte)0));
    }

    public boolean H()
    {
        return d != null;
    }

    public void I()
    {
        if(d != null)
            d.a(world, this, e);
        J();
    }

    public void J()
    {
        d = null;
        e = 0;
        if(!world.isStatic)
            g(false);
    }

    public boolean K()
    {
        return H() && Item.byId[d.id].d(d) == EnumAnimation.d;
    }

    public void w_()
    {
        if(d != null)
        {
            net.minecraft.server.ItemStack itemstack = inventory.getItemInHand();
            if(itemstack != d)
            {
                J();
            } else
            {
                if(e <= 25 && e % 4 == 0)
                    b(itemstack, 5);
                if(--e == 0 && !world.isStatic)
                    G();
            }
        }
        if(x > 0)
            x--;
        if(isSleeping())
        {
            sleepTicks++;
            if(sleepTicks > 100)
                sleepTicks = 100;
            if(!world.isStatic)
                if(!C())
                    a(true, true, false);
                else
                if(world.e())
                    a(false, true, true);
        } else
        if(sleepTicks > 0)
        {
            sleepTicks++;
            if(sleepTicks >= 110)
                sleepTicks = 0;
        }
        super.w_();
        if(!world.isStatic && activeContainer != null && !activeContainer.b(this))
        {
            closeInventory();
            activeContainer = defaultContainer;
        }
        if(abilities.isFlying)
        {
            for(int i = 0; i < 8; i++);
        }
        if(z() && abilities.isInvulnerable)
            aw();
        y = B;
        z = C;
        A = D;
        double d0 = locX - B;
        double d1 = locY - C;
        double d2 = locZ - D;
        double d3 = 10D;
        if(d0 > d3)
            y = B = locX;
        if(d2 > d3)
            A = D = locZ;
        if(d1 > d3)
            z = C = locY;
        if(d0 < -d3)
            y = B = locX;
        if(d2 < -d3)
            A = D = locZ;
        if(d1 < -d3)
            z = C = locY;
        B += d0 * 0.25D;
        D += d2 * 0.25D;
        C += d1 * 0.25D;
        a(StatisticList.k, 1);
        if(vehicle == null)
            c = null;
        if(!world.isStatic)
            foodData.a(this);
    }

    protected void b(net.minecraft.server.ItemStack itemstack, int i)
    {
        if(itemstack.m() == EnumAnimation.c)
            world.makeSound(this, "random.drink", 0.5F, world.random.nextFloat() * 0.1F + 0.9F);
        if(itemstack.m() == EnumAnimation.b)
        {
            for(int j = 0; j < i; j++)
            {
                Vec3D vec3d = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                vec3d.a((-pitch * 3.141593F) / 180F);
                vec3d.b((-yaw * 3.141593F) / 180F);
                Vec3D vec3d1 = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-random.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                vec3d1.a((-pitch * 3.141593F) / 180F);
                vec3d1.b((-yaw * 3.141593F) / 180F);
                vec3d1 = vec3d1.add(locX, locY + (double)x(), locZ);
                world.a((new StringBuilder()).append("iconcrack_").append(itemstack.getItem().id).toString(), vec3d1.a, vec3d1.b, vec3d1.c, vec3d.a, vec3d.b + 0.050000000000000003D, vec3d.c);
            }

            world.makeSound(this, "random.eat", 0.5F + 0.5F * (float)random.nextInt(2), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void G()
    {
        if(d != null)
        {
            b(d, 16);
            int i = d.count;
            net.minecraft.server.ItemStack itemstack = d.b(world, this);
            if(itemstack != d || itemstack != null && itemstack.count != i)
            {
                inventory.items[inventory.itemInHandIndex] = itemstack;
                if(itemstack.count == 0)
                    inventory.items[inventory.itemInHandIndex] = null;
            }
            J();
        }
    }

    protected boolean L()
    {
        return getHealth() <= 0 || isSleeping();
    }

    protected void closeInventory()
    {
        activeContainer = defaultContainer;
    }

    public void M()
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        super.M();
        r = s;
        s = 0.0F;
        h(locX - d0, locY - d1, locZ - d2);
    }

    private int A()
    {
        return hasEffect(MobEffectList.FASTER_DIG) ? 6 - (1 + getEffect(MobEffectList.FASTER_DIG).getAmplifier()) * 1 : hasEffect(MobEffectList.SLOWER_DIG) ? 6 + (1 + getEffect(MobEffectList.SLOWER_DIG).getAmplifier()) * 2 : 6;
    }

    protected void m_()
    {
        int i = A();
        if(t)
        {
            u++;
            if(u >= i)
            {
                u = 0;
                t = false;
            }
        } else
        {
            u = 0;
        }
        an = (float)u / (float)i;
    }

    public void d()
    {
        if(o > 0)
            o--;
        if(world.difficulty == 0 && getHealth() < getMaxHealth() && (ticksLived % 20) * 12 == 0)
            d(1, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.REGEN);
        inventory.i();
        r = s;
        super.d();
        ak = P;
        al = Q;
        if(isSprinting())
        {
            ak = (float)((double)ak + (double)P * 0.29999999999999999D);
            al = (float)((double)al + (double)Q * 0.29999999999999999D);
        }
        float f = MathHelper.a(motX * motX + motZ * motZ);
        float f1 = (float)TrigMath.atan(-motY * 0.20000000298023224D) * 15F;
        if(f > 0.1F)
            f = 0.1F;
        if(!onGround || getHealth() <= 0)
            f = 0.0F;
        if(onGround || getHealth() <= 0)
            f1 = 0.0F;
        s += (f - s) * 0.4F;
        ax += (f1 - ax) * 0.8F;
        if(getHealth() > 0)
        {
            List list = world.b(this, boundingBox.b(1.0D, 0.0D, 1.0D));
            if(list != null)
            {
                for(int i = 0; i < list.size(); i++)
                {
                    Entity entity = (Entity)list.get(i);
                    if(!entity.dead)
                        k(entity);
                }

            }
        }
    }

    private void k(Entity entity)
    {
        entity.a_(this);
    }

    public void die(DamageSource damagesource)
    {
        super.die(damagesource);
        b(0.2F, 0.2F);
        setPosition(locX, locY, locZ);
        motY = 0.10000000149011612D;
        if(name.equals("Notch"))
            a(new net.minecraft.server.ItemStack(Item.APPLE, 1), true);
        inventory.k();
        if(damagesource != null)
        {
            motX = -MathHelper.cos(((at + yaw) * 3.141593F) / 180F) * 0.1F;
            motZ = -MathHelper.sin(((at + yaw) * 3.141593F) / 180F) * 0.1F;
        } else
        {
            motX = motZ = 0.0D;
        }
        height = 0.1F;
        a(StatisticList.y, 1);
    }

    public void b(Entity entity, int i)
    {
        q += i;
        if(entity instanceof EntityHuman)
            a(StatisticList.A, 1);
        else
            a(StatisticList.z, 1);
    }

    protected int f(int i)
    {
        int j = EnchantmentManager.a(inventory);
        return j <= 0 || random.nextInt(j + 1) <= 0 ? super.f(i) : i;
    }

    public void N()
    {
        a(inventory.splitStack(inventory.itemInHandIndex, 1), false);
    }

    public void b(net.minecraft.server.ItemStack itemstack)
    {
        a(itemstack, false);
    }

    public void a(net.minecraft.server.ItemStack itemstack, boolean flag)
    {
        if(itemstack != null)
        {
            EntityItem entityitem = new EntityItem(world, locX, (locY - 0.30000001192092896D) + (double)x(), locZ, itemstack);
            entityitem.pickupDelay = 40;
            float f = 0.1F;
            if(flag)
            {
                float f1 = random.nextFloat() * 0.5F;
                float f2 = random.nextFloat() * 3.141593F * 2.0F;
                entityitem.motX = -MathHelper.sin(f2) * f1;
                entityitem.motZ = MathHelper.cos(f2) * f1;
                entityitem.motY = 0.20000000298023224D;
            } else
            {
                f = 0.3F;
                entityitem.motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
                entityitem.motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
                entityitem.motY = -MathHelper.sin((pitch / 180F) * 3.141593F) * f + 0.1F;
                f = 0.02F;
                float f1 = random.nextFloat() * 3.141593F * 2.0F;
                f *= random.nextFloat();
                entityitem.motX += Math.cos(f1) * (double)f;
                entityitem.motY += (random.nextFloat() - random.nextFloat()) * 0.1F;
                entityitem.motZ += Math.sin(f1) * (double)f;
            }
            Player player = (Player)getBukkitEntity();
            CraftItem drop = new CraftItem(world.getServer(), entityitem);
            PlayerDropItemEvent event = new PlayerDropItemEvent(player, drop);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
            {
                player.getInventory().addItem(new ItemStack[] {
                    drop.getItemStack()
                });
                return;
            }
            a(entityitem);
            a(StatisticList.v, 1);
        }
    }

    protected void a(EntityItem entityitem)
    {
        world.addEntity(entityitem);
    }

    public float a(Block block)
    {
        float f = inventory.a(block);
        float f1 = f;
        int i = EnchantmentManager.b(inventory);
        if(i > 0 && inventory.b(block))
            f1 = f + (float)(i * i + 1);
        if(hasEffect(MobEffectList.FASTER_DIG))
            f1 *= 1.0F + (float)(getEffect(MobEffectList.FASTER_DIG).getAmplifier() + 1) * 0.2F;
        if(hasEffect(MobEffectList.SLOWER_DIG))
            f1 *= 1.0F - (float)(getEffect(MobEffectList.SLOWER_DIG).getAmplifier() + 1) * 0.2F;
        if(a(Material.WATER) && !EnchantmentManager.g(inventory))
            f1 /= 5F;
        if(!onGround)
            f1 /= 5F;
        return f1;
    }

    public boolean b(Block block)
    {
        return inventory.b(block);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.m("Inventory");
        inventory.b(nbttaglist);
        dimension = nbttagcompound.f("Dimension");
        sleeping = nbttagcompound.n("Sleeping");
        sleepTicks = nbttagcompound.e("SleepTimer");
        expLevel = nbttagcompound.h("XpP");
        expTotal = nbttagcompound.f("XpLevel");
        exp = nbttagcompound.f("XpTotal");
        if(sleeping)
        {
            F = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
            a(true, true, false);
        }
        spawnWorld = nbttagcompound.getString("SpawnWorld");
        if("".equals(spawnWorld))
            spawnWorld = ((World)world.getServer().getWorlds().get(0)).getName();
        if(nbttagcompound.hasKey("SpawnX") && nbttagcompound.hasKey("SpawnY") && nbttagcompound.hasKey("SpawnZ"))
            b = new ChunkCoordinates(nbttagcompound.f("SpawnX"), nbttagcompound.f("SpawnY"), nbttagcompound.f("SpawnZ"));
        foodData.a(nbttagcompound);
        abilities.b(nbttagcompound);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Inventory", inventory.a(new NBTTagList()));
        nbttagcompound.a("Dimension", dimension);
        nbttagcompound.a("Sleeping", sleeping);
        nbttagcompound.a("SleepTimer", (short)sleepTicks);
        nbttagcompound.a("XpP", expLevel);
        nbttagcompound.a("XpLevel", expTotal);
        nbttagcompound.a("XpTotal", exp);
        if(b != null)
        {
            nbttagcompound.a("SpawnX", b.x);
            nbttagcompound.a("SpawnY", b.y);
            nbttagcompound.a("SpawnZ", b.z);
            nbttagcompound.setString("SpawnWorld", spawnWorld);
        }
        foodData.b(nbttagcompound);
        abilities.a(nbttagcompound);
    }

    public void a(IInventory iinventory1)
    {
    }

    public void c(int l, int i1, int j1)
    {
    }

    public void b(int l, int i1, int j1)
    {
    }

    public void receive(Entity entity1, int j)
    {
    }

    public float x()
    {
        return 0.12F;
    }

    protected void w()
    {
        height = 1.62F;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(abilities.isInvulnerable && !damagesource.ignoresInvulnerability())
            return false;
        aS = 0;
        if(getHealth() <= 0)
            return false;
        if(isSleeping() && !world.isStatic)
            a(true, true, false);
        Entity entity = damagesource.getEntity();
        if((entity instanceof EntityMonster) || (entity instanceof EntityArrow))
        {
            if(world.difficulty == 0)
                i = 0;
            if(world.difficulty == 1)
                i = i / 2 + 1;
            if(world.difficulty == 3)
                i = (i * 3) / 2;
        }
        if(i == 0)
            return false;
        Entity entity1 = entity;
        if((entity instanceof EntityArrow) && ((EntityArrow)entity).shooter != null)
            entity1 = ((EntityArrow)entity).shooter;
        if(entity1 instanceof EntityLiving)
        {
            if(!(entity.getBukkitEntity() instanceof Projectile))
            {
                org.bukkit.entity.Entity damager = entity1.getBukkitEntity();
                org.bukkit.entity.Entity damagee = getBukkitEntity();
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK, i);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled() || event.getDamage() == 0)
                    return false;
                i = event.getDamage();
            }
            a((EntityLiving)entity1, false);
        }
        a(StatisticList.x, i);
        return super.damageEntity(damagesource, i);
    }

    protected int b(DamageSource damagesource, int i)
    {
        int j = super.b(damagesource, i);
        if(j <= 0)
            return 0;
        int k = EnchantmentManager.a(inventory, damagesource);
        if(k > 20)
            k = 20;
        if(k > 0 && k <= 20)
        {
            int l = 25 - k;
            int i1 = j * l + aq;
            j = i1 / 25;
            aq = i1 % 25;
        }
        return j;
    }

    protected boolean y()
    {
        return false;
    }

    protected void a(EntityLiving entityliving, boolean flag)
    {
        if(!(entityliving instanceof EntityCreeper) && !(entityliving instanceof EntityGhast))
        {
            if(entityliving instanceof EntityWolf)
            {
                EntityWolf entitywolf = (EntityWolf)entityliving;
                if(entitywolf.isTamed() && name.equals(entitywolf.getOwnerName()))
                    return;
            }
            if(!(entityliving instanceof EntityHuman) || y())
            {
                List list = world.a(net/minecraft/server/EntityWolf, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).b(16D, 4D, 16D));
                Iterator iterator = list.iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    Entity entity = (Entity)iterator.next();
                    EntityWolf entitywolf1 = (EntityWolf)entity;
                    if(entitywolf1.isTamed() && entitywolf1.E() == null && name.equals(entitywolf1.getOwnerName()) && (!flag || !entitywolf1.isSitting()))
                    {
                        org.bukkit.entity.Entity bukkitTarget = entity != null ? entityliving.getBukkitEntity() : null;
                        EntityTargetEvent event;
                        if(flag)
                            event = new EntityTargetEvent(entitywolf1.getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.OWNER_ATTACKED_TARGET);
                        else
                            event = new EntityTargetEvent(entitywolf1.getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_ATTACKED_OWNER);
                        world.getServer().getPluginManager().callEvent(event);
                        if(!event.isCancelled())
                        {
                            entitywolf1.setSitting(false);
                            entitywolf1.setTarget(entityliving);
                        }
                    }
                } while(true);
            }
        }
    }

    protected void g(int i)
    {
        inventory.d(i);
    }

    protected int O()
    {
        return inventory.j();
    }

    protected void c(DamageSource damagesource, int i)
    {
        if(!damagesource.ignoresArmor() && K())
            i = 1 + i >> 1;
        i = d(damagesource, i);
        i = b(damagesource, i);
        c(damagesource.e());
        super.c(damagesource, i);
    }

    public void a(TileEntityFurnace tileentityfurnace1)
    {
    }

    public void a(TileEntityDispenser tileentitydispenser1)
    {
    }

    public void a(TileEntitySign tileentitysign1)
    {
    }

    public void a(TileEntityBrewingStand tileentitybrewingstand1)
    {
    }

    public void e(Entity entity)
    {
        if(!entity.b(this))
        {
            net.minecraft.server.ItemStack itemstack = P();
            if(itemstack != null && (entity instanceof EntityLiving))
            {
                itemstack.a((EntityLiving)entity);
                if(itemstack.count == 0)
                {
                    itemstack.a(this);
                    Q();
                }
            }
        }
    }

    public net.minecraft.server.ItemStack P()
    {
        return inventory.getItemInHand();
    }

    public void Q()
    {
        inventory.setItem(inventory.itemInHandIndex, (net.minecraft.server.ItemStack)null);
    }

    public double R()
    {
        return (double)(height - 0.5F);
    }

    public void r_()
    {
        if(!t || u >= A() / 2 || u < 0)
        {
            u = -1;
            t = true;
        }
    }

    public void f(Entity entity)
    {
        int i = inventory.a(entity);
        if(hasEffect(MobEffectList.INCREASE_DAMAGE))
            i += 3 << getEffect(MobEffectList.INCREASE_DAMAGE).getAmplifier();
        if(hasEffect(MobEffectList.WEAKNESS))
            i -= 2 << getEffect(MobEffectList.WEAKNESS).getAmplifier();
        int j = 0;
        int k = 0;
        if(entity instanceof EntityLiving)
        {
            k = EnchantmentManager.a(inventory, (EntityLiving)entity);
            j += EnchantmentManager.b(inventory, (EntityLiving)entity);
        }
        if(isSprinting())
            j++;
        if(i > 0 || k > 0)
        {
            boolean flag = fallDistance > 0.0F && !onGround && !r() && !az() && !hasEffect(MobEffectList.BLINDNESS) && vehicle == null && (entity instanceof EntityLiving);
            if(flag)
                i += random.nextInt(i / 2 + 2);
            if((entity instanceof EntityLiving) && !(entity instanceof EntityHuman))
            {
                org.bukkit.entity.Entity damager = getBukkitEntity();
                org.bukkit.entity.Entity damagee = entity != null ? entity.getBukkitEntity() : null;
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK, i);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled() || event.getDamage() == 0)
                    return;
                i = event.getDamage();
            }
            i += k;
            boolean flag1 = entity.damageEntity(DamageSource.playerAttack(this), i);
            if(!flag1)
                return;
            if(flag1)
            {
                if(j > 0)
                {
                    entity.b_(-MathHelper.sin((yaw * 3.141593F) / 180F) * (float)j * 0.5F, 0.10000000000000001D, MathHelper.cos((yaw * 3.141593F) / 180F) * (float)j * 0.5F);
                    motX *= 0.59999999999999998D;
                    motZ *= 0.59999999999999998D;
                    setSprinting(false);
                }
                if(flag)
                    c(entity);
                if(k > 0)
                    d(entity);
                if(i >= 18)
                    a(AchievementList.E);
            }
            net.minecraft.server.ItemStack itemstack = P();
            if(itemstack != null && (entity instanceof EntityLiving))
            {
                itemstack.a((EntityLiving)entity, this);
                if(itemstack.count == 0)
                {
                    itemstack.a(this);
                    Q();
                }
            }
            if(entity instanceof EntityLiving)
            {
                if(entity.aj())
                    a((EntityLiving)entity, true);
                a(StatisticList.w, i);
                int l = EnchantmentManager.c(inventory, (EntityLiving)entity);
                if(l > 0)
                    entity.j(l * 4);
            }
            c(0.3F);
        }
    }

    public void c(Entity entity1)
    {
    }

    public void d(Entity entity1)
    {
    }

    public void a(net.minecraft.server.ItemStack itemstack1)
    {
    }

    public void die()
    {
        super.die();
        defaultContainer.a(this);
        if(activeContainer != null)
            activeContainer.a(this);
    }

    public boolean T()
    {
        return !sleeping && super.T();
    }

    public EnumBedError a(int i, int j, int k)
    {
        if(!world.isStatic)
        {
            if(isSleeping() || !aj())
                return EnumBedError.OTHER_PROBLEM;
            if(world.worldProvider.c)
                return EnumBedError.NOT_POSSIBLE_HERE;
            if(world.e())
                return EnumBedError.NOT_POSSIBLE_NOW;
            if(Math.abs(locX - (double)i) > 3D || Math.abs(locY - (double)j) > 2D || Math.abs(locZ - (double)k) > 3D)
                return EnumBedError.TOO_FAR_AWAY;
            double d0 = 8D;
            double d1 = 5D;
            List list = world.a(net/minecraft/server/EntityMonster, AxisAlignedBB.b((double)i - d0, (double)j - d1, (double)k - d0, (double)i + d0, (double)j + d1, (double)k + d0));
            if(!list.isEmpty())
                return EnumBedError.NOT_SAFE;
        }
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed = world.getWorld().getBlockAt(i, j, k);
            PlayerBedEnterEvent event = new PlayerBedEnterEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return EnumBedError.OTHER_PROBLEM;
        }
        b(0.2F, 0.2F);
        height = 0.2F;
        if(world.isLoaded(i, j, k))
        {
            int l = world.getData(i, j, k);
            int i1 = BlockBed.d(l);
            float f = 0.5F;
            float f1 = 0.5F;
            switch(i1)
            {
            case 0: // '\0'
                f1 = 0.9F;
                break;

            case 1: // '\001'
                f = 0.1F;
                break;

            case 2: // '\002'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f = 0.9F;
                break;
            }
            c(i1);
            setPosition((float)i + f, (float)j + 0.9375F, (float)k + f1);
        } else
        {
            setPosition((float)i + 0.5F, (float)j + 0.9375F, (float)k + 0.5F);
        }
        sleeping = true;
        sleepTicks = 0;
        F = new ChunkCoordinates(i, j, k);
        motX = motZ = motY = 0.0D;
        if(!world.isStatic)
            world.everyoneSleeping();
        return EnumBedError.OK;
    }

    private void c(int i)
    {
        G = 0.0F;
        H = 0.0F;
        switch(i)
        {
        case 0: // '\0'
            H = -1.8F;
            break;

        case 1: // '\001'
            G = 1.8F;
            break;

        case 2: // '\002'
            H = 1.8F;
            break;

        case 3: // '\003'
            G = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        if(fauxSleeping && !sleeping)
            return;
        b(0.6F, 1.8F);
        w();
        ChunkCoordinates chunkcoordinates = F;
        ChunkCoordinates chunkcoordinates1 = F;
        if(chunkcoordinates != null && world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) == Block.BED.id)
        {
            BlockBed.a(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, false);
            chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            if(chunkcoordinates1 == null)
                chunkcoordinates1 = new ChunkCoordinates(chunkcoordinates.x, chunkcoordinates.y + 1, chunkcoordinates.z);
            setPosition((float)chunkcoordinates1.x + 0.5F, (float)chunkcoordinates1.y + height + 0.1F, (float)chunkcoordinates1.z + 0.5F);
        }
        sleeping = false;
        if(!world.isStatic && flag1)
            world.everyoneSleeping();
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed;
            if(chunkcoordinates != null)
                bed = world.getWorld().getBlockAt(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z);
            else
                bed = world.getWorld().getBlockAt(player.getLocation());
            PlayerBedLeaveEvent event = new PlayerBedLeaveEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
        }
        if(flag)
            sleepTicks = 0;
        else
            sleepTicks = 100;
        if(flag2)
            a(F);
    }

    private boolean C()
    {
        return world.getTypeId(F.x, F.y, F.z) == Block.BED.id;
    }

    public static ChunkCoordinates getBed(net.minecraft.server.World world, ChunkCoordinates chunkcoordinates)
    {
        IChunkProvider ichunkprovider = world.p();
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z + 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z + 3 >> 4);
        if(world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) != Block.BED.id)
        {
            return null;
        } else
        {
            ChunkCoordinates chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            return chunkcoordinates1;
        }
    }

    public boolean isSleeping()
    {
        return sleeping;
    }

    public boolean isDeeplySleeping()
    {
        return sleeping && sleepTicks >= 100;
    }

    public void a(String s1)
    {
    }

    public ChunkCoordinates getBed()
    {
        return b;
    }

    public void a(ChunkCoordinates chunkcoordinates)
    {
        if(chunkcoordinates != null)
        {
            b = new ChunkCoordinates(chunkcoordinates);
            spawnWorld = world.worldData.name;
        } else
        {
            b = null;
        }
    }

    public void a(Statistic statistic)
    {
        a(statistic, 1);
    }

    public void a(Statistic statistic1, int j)
    {
    }

    protected void X()
    {
        super.X();
        a(StatisticList.u, 1);
        if(isSprinting())
            c(0.8F);
        else
            c(0.2F);
    }

    public void a(float f, float f1)
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        if(abilities.isFlying)
        {
            double d3 = motY;
            float f2 = al;
            al = 0.05F;
            super.a(f, f1);
            motY = d3 * 0.59999999999999998D;
            al = f2;
        } else
        {
            super.a(f, f1);
        }
        b(locX - d0, locY - d1, locZ - d2);
    }

    public void b(double d0, double d1, double d2)
    {
        if(vehicle == null)
            if(a(Material.WATER))
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.q, i);
                    c(0.015F * (float)i * 0.01F);
                }
            } else
            if(az())
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.m, i);
                    c(0.015F * (float)i * 0.01F);
                }
            } else
            if(r())
            {
                if(d1 > 0.0D)
                    a(StatisticList.o, (int)Math.round(d1 * 100D));
            } else
            if(onGround)
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.l, i);
                    if(isSprinting())
                        c(0.09999999F * (float)i * 0.01F);
                    else
                        c(0.01F * (float)i * 0.01F);
                }
            } else
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 25)
                    a(StatisticList.p, i);
            }
    }

    private void h(double d0, double d1, double d2)
    {
        if(vehicle != null)
        {
            int i = Math.round(MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
            if(i > 0)
                if(vehicle instanceof EntityMinecart)
                {
                    a(StatisticList.r, i);
                    if(c == null)
                        c = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
                    else
                    if(c.a(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) >= 1000D)
                        a(AchievementList.q, 1);
                } else
                if(vehicle instanceof EntityBoat)
                    a(StatisticList.s, i);
                else
                if(vehicle instanceof EntityPig)
                    a(StatisticList.t, i);
        }
    }

    protected void b(float f)
    {
        if(!abilities.canFly)
        {
            if(f >= 2.0F)
                a(StatisticList.n, (int)Math.round((double)f * 100D));
            super.b(f);
        }
    }

    public void a(EntityLiving entityliving)
    {
        if(entityliving instanceof EntityMonster)
            a(((Statistic) (AchievementList.s)));
    }

    public void Y()
    {
        if(I > 0)
            I = 10;
        else
            J = true;
    }

    public void h(int i)
    {
        q += i;
        expLevel += (float)i / (float)Z();
        exp += i;
        while(expLevel >= 1.0F) 
        {
            expLevel--;
            D();
        }
    }

    public void b(int i)
    {
        expTotal -= i;
        if(expTotal < 0)
            expTotal = 0;
    }

    public int Z()
    {
        return 7 + (expTotal * 7 >> 1);
    }

    private void D()
    {
        expTotal++;
    }

    public void c(float f)
    {
        if(!abilities.isInvulnerable && !world.isStatic)
            foodData.a(f);
    }

    public FoodMetaData getFoodData()
    {
        return foodData;
    }

    public boolean b(boolean flag)
    {
        return (flag || foodData.b()) && !abilities.isInvulnerable;
    }

    public boolean ab()
    {
        return getHealth() > 0 && getHealth() < getMaxHealth();
    }

    public void a(net.minecraft.server.ItemStack itemstack, int i)
    {
        if(itemstack != d)
        {
            d = itemstack;
            e = i;
            if(!world.isStatic)
                g(true);
        }
    }

    public boolean d(int i, int j, int k)
    {
        return true;
    }

    protected int a(EntityHuman entityhuman)
    {
        int i = expTotal * 7;
        return i <= 100 ? i : 100;
    }

    protected boolean ac()
    {
        return true;
    }

    public String ad()
    {
        return name;
    }

    public void e(int j)
    {
    }

    public void copyTo(EntityHuman entityhuman)
    {
        inventory.a(entityhuman.inventory);
        health = entityhuman.health;
        foodData = entityhuman.foodData;
        expTotal = entityhuman.expTotal;
        exp = entityhuman.exp;
        expLevel = entityhuman.expLevel;
        q = entityhuman.q;
    }

    public InventoryPlayer inventory;
    public Container defaultContainer;
    public Container activeContainer;
    protected FoodMetaData foodData;
    protected int o;
    public byte p;
    public int q;
    public float r;
    public float s;
    public boolean t;
    public int u;
    public String name;
    public int dimension;
    public int x;
    public double y;
    public double z;
    public double A;
    public double B;
    public double C;
    public double D;
    public boolean sleeping;
    public boolean fauxSleeping;
    public String spawnWorld;
    public ChunkCoordinates F;
    public int sleepTicks;
    public float G;
    public float H;
    private ChunkCoordinates b;
    private ChunkCoordinates c;
    public int I;
    protected boolean J;
    public float K;
    public PlayerAbilities abilities;
    public int expTotal;
    public int exp;
    public float expLevel;
    private net.minecraft.server.ItemStack d;
    private int e;
    protected float P;
    protected float Q;
    public EntityFishingHook hookedFish;
}
