// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Slot, Item, ItemStack, ContainerBrewingStand, 
//            IInventory

class SlotBrewing extends Slot
{

    public SlotBrewing(ContainerBrewingStand containerbrewingstand, IInventory iinventory, int i, int j, int k)
    {
        a = containerbrewingstand;
        super(iinventory, i, j, k);
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        if(itemstack != null)
            return Item.byId[itemstack.id].m();
        else
            return false;
    }

    public int a()
    {
        return 64;
    }

    final ContainerBrewingStand a;
}
