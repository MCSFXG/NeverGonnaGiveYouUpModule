// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.IOException;
import java.net.*;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            RemoteConnectionThread, IMinecraftServer, RemoteStatusReply, StatusChallengeUtils, 
//            RemoteStatusChallenge

public class RemoteStatusListener extends RemoteConnectionThread
{

    public RemoteStatusListener(IMinecraftServer iminecraftserver)
    {
        super(iminecraftserver);
        socket = null;
        n = new byte[1460];
        o = null;
        bindPort = iminecraftserver.getProperty("query.port", 0);
        motd = iminecraftserver.getMotd();
        serverPort = iminecraftserver.getPort();
        localAddress = iminecraftserver.getServerAddress();
        maxPlayers = iminecraftserver.getMaxPlayers();
        worldName = iminecraftserver.getWorldName();
        cacheTime = 0L;
        hostname = "0.0.0.0";
        if(0 == motd.length() || hostname.equals(motd))
        {
            motd = "0.0.0.0";
            try
            {
                InetAddress inetaddress = InetAddress.getLocalHost();
                hostname = inetaddress.getHostAddress();
            }
            catch(UnknownHostException unknownhostexception)
            {
                warning((new StringBuilder()).append("Unable to determine local host IP, please set server-ip in '").append(iminecraftserver.getPropertiesFile()).append("' : ").append(unknownhostexception.getMessage()).toString());
            }
        } else
        {
            hostname = motd;
        }
        if(0 == bindPort)
        {
            bindPort = serverPort;
            info((new StringBuilder()).append("Setting default query port to ").append(bindPort).toString());
            iminecraftserver.a("query.port", Integer.valueOf(bindPort));
            iminecraftserver.a("debug", Boolean.valueOf(false));
            iminecraftserver.c();
        }
        p = new HashMap();
        cachedReply = new RemoteStatusReply(1460);
        challenges = new HashMap();
        t = (new Date()).getTime();
    }

    private void send(byte abyte0[], DatagramPacket datagrampacket)
    {
        socket.send(new DatagramPacket(abyte0, abyte0.length, datagrampacket.getSocketAddress()));
    }

    private boolean parsePacket(DatagramPacket datagrampacket)
    {
        byte abyte0[] = datagrampacket.getData();
        int i = datagrampacket.getLength();
        SocketAddress socketaddress = datagrampacket.getSocketAddress();
        debug((new StringBuilder()).append("Packet len ").append(i).append(" [").append(socketaddress).append("]").toString());
        if(3 > i || -2 != abyte0[0] || -3 != abyte0[1])
        {
            debug((new StringBuilder()).append("Invalid packet [").append(socketaddress).append("]").toString());
            return false;
        }
        debug((new StringBuilder()).append("Packet '").append(StatusChallengeUtils.a(abyte0[2])).append("' [").append(socketaddress).append("]").toString());
        switch(abyte0[2])
        {
        case 9: // '\t'
            createChallenge(datagrampacket);
            debug((new StringBuilder()).append("Challenge [").append(socketaddress).append("]").toString());
            return true;

        case 0: // '\0'
            if(!hasChallenged(datagrampacket).booleanValue())
            {
                debug((new StringBuilder()).append("Invalid challenge [").append(socketaddress).append("]").toString());
                return false;
            }
            if(15 != i)
            {
                RemoteStatusReply remotestatusreply = new RemoteStatusReply(1460);
                remotestatusreply.write(0);
                remotestatusreply.write(getIdentityToken(datagrampacket.getSocketAddress()));
                remotestatusreply.write(localAddress);
                remotestatusreply.write("SMP");
                remotestatusreply.write(worldName);
                remotestatusreply.write(Integer.toString(c()));
                remotestatusreply.write(Integer.toString(maxPlayers));
                remotestatusreply.write((short)serverPort);
                remotestatusreply.write(hostname);
                send(remotestatusreply.getBytes(), datagrampacket);
                debug((new StringBuilder()).append("Status [").append(socketaddress).append("]").toString());
            } else
            {
                send(getFullReply(datagrampacket), datagrampacket);
                debug((new StringBuilder()).append("Rules [").append(socketaddress).append("]").toString());
            }
            break;
        }
        return true;
    }

    private byte[] getFullReply(DatagramPacket datagrampacket)
    {
        long l = System.currentTimeMillis();
        if(l < cacheTime + 5000L)
        {
            byte abyte0[] = cachedReply.getBytes();
            byte abyte1[] = getIdentityToken(datagrampacket.getSocketAddress());
            abyte0[1] = abyte1[0];
            abyte0[2] = abyte1[1];
            abyte0[3] = abyte1[2];
            abyte0[4] = abyte1[3];
            return abyte0;
        }
        cacheTime = l;
        cachedReply.reset();
        cachedReply.write(0);
        cachedReply.write(getIdentityToken(datagrampacket.getSocketAddress()));
        cachedReply.write("splitnum");
        cachedReply.write(128);
        cachedReply.write(0);
        cachedReply.write("hostname");
        cachedReply.write(localAddress);
        cachedReply.write("gametype");
        cachedReply.write("SMP");
        cachedReply.write("game_id");
        cachedReply.write("MINECRAFT");
        cachedReply.write("version");
        cachedReply.write(server.getVersion());
        cachedReply.write("plugins");
        cachedReply.write(server.getPlugins());
        cachedReply.write("map");
        cachedReply.write(worldName);
        cachedReply.write("numplayers");
        cachedReply.write((new StringBuilder()).append("").append(c()).toString());
        cachedReply.write("maxplayers");
        cachedReply.write((new StringBuilder()).append("").append(maxPlayers).toString());
        cachedReply.write("hostport");
        cachedReply.write((new StringBuilder()).append("").append(serverPort).toString());
        cachedReply.write("hostip");
        cachedReply.write(hostname);
        cachedReply.write(0);
        cachedReply.write(1);
        cachedReply.write("player_");
        cachedReply.write(0);
        String as[] = server.getPlayers();
        byte byte0 = (byte)as.length;
        for(byte byte1 = (byte)(byte0 - 1); byte1 >= 0; byte1--)
            cachedReply.write(as[byte1]);

        cachedReply.write(0);
        return cachedReply.getBytes();
    }

    private byte[] getIdentityToken(SocketAddress socketaddress)
    {
        return ((RemoteStatusChallenge)challenges.get(socketaddress)).getIdentityToken();
    }

    private Boolean hasChallenged(DatagramPacket datagrampacket)
    {
        SocketAddress socketaddress = datagrampacket.getSocketAddress();
        if(!challenges.containsKey(socketaddress))
            return Boolean.valueOf(false);
        byte abyte0[] = datagrampacket.getData();
        if(((RemoteStatusChallenge)challenges.get(socketaddress)).getToken() != StatusChallengeUtils.c(abyte0, 7, datagrampacket.getLength()))
            return Boolean.valueOf(false);
        else
            return Boolean.valueOf(true);
    }

    private void createChallenge(DatagramPacket datagrampacket)
    {
        RemoteStatusChallenge remotestatuschallenge = new RemoteStatusChallenge(this, datagrampacket);
        challenges.put(datagrampacket.getSocketAddress(), remotestatuschallenge);
        send(remotestatuschallenge.getChallengeResponse(), datagrampacket);
    }

    private void cleanChallenges()
    {
        if(!running)
            return;
        long l = System.currentTimeMillis();
        if(l < clearedTime + 30000L)
            return;
        clearedTime = l;
        Iterator iterator = challenges.entrySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            if(((RemoteStatusChallenge)entry.getValue()).isExpired(l).booleanValue())
                iterator.remove();
        } while(true);
    }

    public void run()
    {
        info((new StringBuilder()).append("Query running on ").append(motd).append(":").append(bindPort).toString());
        clearedTime = System.currentTimeMillis();
        o = new DatagramPacket(n, n.length);
        while(running) 
            try
            {
                socket.receive(o);
                cleanChallenges();
                parsePacket(o);
            }
            catch(SocketTimeoutException sockettimeoutexception)
            {
                cleanChallenges();
            }
            catch(PortUnreachableException portunreachableexception) { }
            catch(IOException ioexception)
            {
                a(ioexception);
            }
        d();
        break MISSING_BLOCK_LABEL_136;
        Exception exception;
        exception;
        d();
        throw exception;
    }

    public void a()
    {
        if(running)
            return;
        if(0 >= bindPort || 65535 < bindPort)
        {
            warning((new StringBuilder()).append("Invalid query port ").append(bindPort).append(" found in '").append(server.getPropertiesFile()).append("' (queries disabled)").toString());
            return;
        }
        if(f())
            super.a();
    }

    private void a(Exception exception)
    {
        if(!running)
            return;
        warning((new StringBuilder()).append("Unexpected exception, buggy JRE? (").append(exception.toString()).append(")").toString());
        if(!f())
        {
            error("Failed to recover from buggy JRE, shutting down!");
            running = false;
            server.o();
        }
    }

    private boolean f()
    {
        try
        {
            socket = new DatagramSocket(bindPort, InetAddress.getByName(motd));
            a(socket);
            socket.setSoTimeout(500);
            return true;
        }
        catch(SocketException socketexception)
        {
            warning((new StringBuilder()).append("Unable to initialise query system on ").append(motd).append(":").append(bindPort).append(" (Socket): ").append(socketexception.getMessage()).toString());
        }
        catch(UnknownHostException unknownhostexception)
        {
            warning((new StringBuilder()).append("Unable to initialise query system on ").append(motd).append(":").append(bindPort).append(" (Unknown Host): ").append(unknownhostexception.getMessage()).toString());
        }
        catch(Exception exception)
        {
            warning((new StringBuilder()).append("Unable to initialise query system on ").append(motd).append(":").append(bindPort).append(" (E): ").append(exception.getMessage()).toString());
        }
        return false;
    }

    private long clearedTime;
    private int bindPort;
    private int serverPort;
    private int maxPlayers;
    private String localAddress;
    private String worldName;
    private DatagramSocket socket;
    private byte n[];
    private DatagramPacket o;
    private HashMap p;
    private String hostname;
    private String motd;
    private HashMap challenges;
    private long t;
    private RemoteStatusReply cachedReply;
    private long cacheTime;
}
