// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            BlockContainer, Material, TileEntityEnchantTable, World, 
//            EntityHuman, TileEntity

public class BlockEnchantmentTable extends BlockContainer
{

    protected BlockEnchantmentTable(int i)
    {
        super(i, 166, Material.STONE);
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
        g(0);
    }

    public boolean b()
    {
        return false;
    }

    public boolean a()
    {
        return false;
    }

    public int a(int i, int j)
    {
        return a(i);
    }

    public int a(int i)
    {
        if(i == 0)
            return textureId + 17;
        if(i == 1)
            return textureId;
        else
            return textureId + 16;
    }

    public TileEntity a_()
    {
        return new TileEntityEnchantTable();
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(world.isStatic)
        {
            return true;
        } else
        {
            entityhuman.c(i, j, k);
            return true;
        }
    }
}
