// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockFlower, Block, World, EntityItem, 
//            ItemStack, Item

public class BlockCrops extends BlockFlower
{

    protected BlockCrops(int j, int k)
    {
        super(j, k);
        textureId = k;
        a(true);
        float f = 0.5F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
    }

    protected boolean d(int j)
    {
        return j == Block.SOIL.id;
    }

    public void a(World world, int j, int k, int l, Random random)
    {
        super.a(world, j, k, l, random);
        if(world.getLightLevel(j, k + 1, l) >= 9)
        {
            int i1 = world.getData(j, k, l);
            if(i1 < 7)
            {
                float f = i(world, j, k, l);
                if(random.nextInt((int)(25F / f) + 1) == 0)
                {
                    i1++;
                    world.setData(j, k, l, i1);
                }
            }
        }
    }

    public void g(World world, int j, int k, int l)
    {
        world.setData(j, k, l, 7);
    }

    private float i(World world, int j, int k, int l)
    {
        float f = 1.0F;
        int i1 = world.getTypeId(j, k, l - 1);
        int j1 = world.getTypeId(j, k, l + 1);
        int k1 = world.getTypeId(j - 1, k, l);
        int l1 = world.getTypeId(j + 1, k, l);
        int i2 = world.getTypeId(j - 1, k, l - 1);
        int j2 = world.getTypeId(j + 1, k, l - 1);
        int k2 = world.getTypeId(j + 1, k, l + 1);
        int l2 = world.getTypeId(j - 1, k, l + 1);
        boolean flag = k1 == id || l1 == id;
        boolean flag1 = i1 == id || j1 == id;
        boolean flag2 = i2 == id || j2 == id || k2 == id || l2 == id;
        for(int i3 = j - 1; i3 <= j + 1; i3++)
        {
            for(int j3 = l - 1; j3 <= l + 1; j3++)
            {
                int k3 = world.getTypeId(i3, k - 1, j3);
                float f1 = 0.0F;
                if(k3 == Block.SOIL.id)
                {
                    f1 = 1.0F;
                    if(world.getData(i3, k - 1, j3) > 0)
                        f1 = 3F;
                }
                if(i3 != j || j3 != l)
                    f1 /= 4F;
                f += f1;
            }

        }

        if(flag2 || flag && flag1)
            f /= 2.0F;
        return f;
    }

    public int a(int j, int k)
    {
        if(k < 0)
            k = 7;
        return textureId + k;
    }

    public int c()
    {
        return 6;
    }

    public void dropNaturally(World world, int j, int k, int l, int i1, float f, int j1)
    {
        super.dropNaturally(world, j, k, l, i1, f, 0);
        if(world.isStatic)
            return;
        int k1 = 3 + j1;
        for(int l1 = 0; l1 < k1; l1++)
            if(world.random.nextInt(15) <= i1)
            {
                float f1 = 0.7F;
                float f2 = world.random.nextFloat() * f1 + (1.0F - f1) * 0.5F;
                float f3 = world.random.nextFloat() * f1 + (1.0F - f1) * 0.5F;
                float f4 = world.random.nextFloat() * f1 + (1.0F - f1) * 0.5F;
                EntityItem entityitem = new EntityItem(world, (float)j + f2, (float)k + f3, (float)l + f4, new ItemStack(Item.SEEDS));
                entityitem.pickupDelay = 10;
                world.addEntity(entityitem);
            }

    }

    public int a(int j, Random random, int k)
    {
        if(j == 7)
            return Item.WHEAT.id;
        else
            return -1;
    }

    public int a(Random random)
    {
        return 1;
    }
}
