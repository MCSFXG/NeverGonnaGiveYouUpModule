// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityMinecart.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.vehicle.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, ItemStack, EntityItem, BlockMinecartTrack, 
//            NBTTagList, NBTTagCompound, EntityLiving, EntityHuman, 
//            IInventory, DataWatcher, World, DamageSource, 
//            Item, Block, MathHelper, Vec3D, 
//            AxisAlignedBB, InventoryPlayer

public class EntityMinecart extends Entity
    implements IInventory
{

    public ItemStack[] getContents()
    {
        return items;
    }

    public EntityMinecart(World world)
    {
        super(world);
        slowWhenEmpty = true;
        derailedX = 0.5D;
        derailedY = 0.5D;
        derailedZ = 0.5D;
        flyingX = 0.94999999999999996D;
        flyingY = 0.94999999999999996D;
        flyingZ = 0.94999999999999996D;
        maxSpeed = 0.40000000000000002D;
        items = new ItemStack[27];
        e = 0;
        f = false;
        bc = true;
        b(0.98F, 0.7F);
        height = width / 2.0F;
    }

    protected boolean g_()
    {
        return false;
    }

    protected void b()
    {
        datawatcher.a(16, new Byte((byte)0));
        datawatcher.a(17, new Integer(0));
        datawatcher.a(18, new Integer(1));
        datawatcher.a(19, new Integer(0));
    }

    public AxisAlignedBB a_(Entity entity)
    {
        return entity.boundingBox;
    }

    public AxisAlignedBB h_()
    {
        return null;
    }

    public boolean f_()
    {
        return true;
    }

    public EntityMinecart(World world, double d0, double d1, double d2, 
            int i)
    {
        this(world);
        setPosition(d0, d1 + (double)height, d2);
        motX = 0.0D;
        motY = 0.0D;
        motZ = 0.0D;
        lastX = d0;
        lastY = d1;
        lastZ = d2;
        type = i;
        this.world.getServer().getPluginManager().callEvent(new VehicleCreateEvent((Vehicle)getBukkitEntity()));
    }

    public double q()
    {
        return (double)width * 0.0D - 0.30000001192092896D;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(!world.isStatic && !dead)
        {
            Vehicle vehicle = (Vehicle)getBukkitEntity();
            org.bukkit.entity.Entity passenger = damagesource.getEntity() != null ? damagesource.getEntity().getBukkitEntity() : null;
            VehicleDamageEvent event = new VehicleDamageEvent(vehicle, passenger, i);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return true;
            i = event.getDamage();
            d(-m());
            c(10);
            aB();
            setDamage(getDamage() + i * 10);
            if(getDamage() > 40)
            {
                if(this.passenger != null)
                    this.passenger.mount(this);
                VehicleDestroyEvent destroyEvent = new VehicleDestroyEvent(vehicle, passenger);
                world.getServer().getPluginManager().callEvent(destroyEvent);
                if(destroyEvent.isCancelled())
                {
                    setDamage(40);
                    return true;
                }
                die();
                a(Item.MINECART.id, 1, 0.0F);
                if(type == 1)
                {
                    EntityMinecart entityminecart = this;
label0:
                    for(int j = 0; j < entityminecart.getSize(); j++)
                    {
                        ItemStack itemstack = entityminecart.getItem(j);
                        if(itemstack == null)
                            continue;
                        float f = random.nextFloat() * 0.8F + 0.1F;
                        float f1 = random.nextFloat() * 0.8F + 0.1F;
                        float f2 = random.nextFloat() * 0.8F + 0.1F;
                        do
                        {
                            if(itemstack.count <= 0)
                                continue label0;
                            int k = random.nextInt(21) + 10;
                            if(k > itemstack.count)
                                k = itemstack.count;
                            itemstack.count -= k;
                            EntityItem entityitem = new EntityItem(world, locX + (double)f, locY + (double)f1, locZ + (double)f2, new ItemStack(itemstack.id, k, itemstack.getData()));
                            float f3 = 0.05F;
                            entityitem.motX = (float)random.nextGaussian() * f3;
                            entityitem.motY = (float)random.nextGaussian() * f3 + 0.2F;
                            entityitem.motZ = (float)random.nextGaussian() * f3;
                            world.addEntity(entityitem);
                        } while(true);
                    }

                    a(Block.CHEST.id, 1, 0.0F);
                } else
                if(type == 2)
                    a(Block.FURNACE.id, 1, 0.0F);
            }
            return true;
        } else
        {
            return true;
        }
    }

    public boolean e_()
    {
        return !dead;
    }

    public void die()
    {
label0:
        for(int i = 0; i < getSize(); i++)
        {
            ItemStack itemstack = getItem(i);
            if(itemstack == null)
                continue;
            float f = random.nextFloat() * 0.8F + 0.1F;
            float f1 = random.nextFloat() * 0.8F + 0.1F;
            float f2 = random.nextFloat() * 0.8F + 0.1F;
            do
            {
                if(itemstack.count <= 0)
                    continue label0;
                int j = random.nextInt(21) + 10;
                if(j > itemstack.count)
                    j = itemstack.count;
                itemstack.count -= j;
                EntityItem entityitem = new EntityItem(world, locX + (double)f, locY + (double)f1, locZ + (double)f2, new ItemStack(itemstack.id, j, itemstack.getData()));
                float f3 = 0.05F;
                entityitem.motX = (float)random.nextGaussian() * f3;
                entityitem.motY = (float)random.nextGaussian() * f3 + 0.2F;
                entityitem.motZ = (float)random.nextGaussian() * f3;
                world.addEntity(entityitem);
            } while(true);
        }

        super.die();
    }

    public void w_()
    {
        double prevX = locX;
        double prevY = locY;
        double prevZ = locZ;
        float prevYaw = yaw;
        float prevPitch = pitch;
        if(l() > 0)
            c(l() - 1);
        if(getDamage() > 0)
            setDamage(getDamage() - 1);
        if(j() && random.nextInt(4) == 0)
            world.a("largesmoke", locX, locY + 0.80000000000000004D, locZ, 0.0D, 0.0D, 0.0D);
        if(world.isStatic)
        {
            if(h > 0)
            {
                double d0 = locX + (this.i - locX) / (double)h;
                double d1 = locY + (this.j - locY) / (double)h;
                double d2 = locZ + (this.k - locZ) / (double)h;
                double d3;
                for(d3 = this.l - (double)yaw; d3 < -180D; d3 += 360D);
                for(; d3 >= 180D; d3 -= 360D);
                yaw = (float)((double)yaw + d3 / (double)h);
                pitch = (float)((double)pitch + (m - (double)pitch) / (double)h);
                h--;
                setPosition(d0, d1, d2);
                c(yaw, pitch);
            } else
            {
                setPosition(locX, locY, locZ);
                c(yaw, pitch);
            }
        } else
        {
            lastX = locX;
            lastY = locY;
            lastZ = locZ;
            motY -= 0.039999999105930328D;
            int i = MathHelper.floor(locX);
            int j = MathHelper.floor(locY);
            int k = MathHelper.floor(locZ);
            if(BlockMinecartTrack.g(world, i, j - 1, k))
                j--;
            double d4 = maxSpeed;
            double d5 = 0.0078125D;
            int l = world.getTypeId(i, j, k);
            if(BlockMinecartTrack.d(l))
            {
                Vec3D vec3d = h(locX, locY, locZ);
                int i1 = world.getData(i, j, k);
                locY = j;
                boolean flag = false;
                boolean flag1 = false;
                if(l == Block.GOLDEN_RAIL.id)
                {
                    flag = (i1 & 8) != 0;
                    flag1 = !flag;
                }
                if(((BlockMinecartTrack)Block.byId[l]).h())
                    i1 &= 7;
                if(i1 >= 2 && i1 <= 5)
                    locY = j + 1;
                if(i1 == 2)
                    motX -= d5;
                if(i1 == 3)
                    motX += d5;
                if(i1 == 4)
                    motZ += d5;
                if(i1 == 5)
                    motZ -= d5;
                int aint[][] = matrix[i1];
                double d6 = aint[1][0] - aint[0][0];
                double d7 = aint[1][2] - aint[0][2];
                double d8 = Math.sqrt(d6 * d6 + d7 * d7);
                double d9 = motX * d6 + motZ * d7;
                if(d9 < 0.0D)
                {
                    d6 = -d6;
                    d7 = -d7;
                }
                double d10 = Math.sqrt(motX * motX + motZ * motZ);
                motX = (d10 * d6) / d8;
                motZ = (d10 * d7) / d8;
                double d11;
                if(flag1)
                {
                    d11 = Math.sqrt(motX * motX + motZ * motZ);
                    if(d11 < 0.029999999999999999D)
                    {
                        motX *= 0.0D;
                        motY *= 0.0D;
                        motZ *= 0.0D;
                    } else
                    {
                        motX *= 0.5D;
                        motY *= 0.0D;
                        motZ *= 0.5D;
                    }
                }
                d11 = 0.0D;
                double d12 = (double)i + 0.5D + (double)aint[0][0] * 0.5D;
                double d13 = (double)k + 0.5D + (double)aint[0][2] * 0.5D;
                double d14 = (double)i + 0.5D + (double)aint[1][0] * 0.5D;
                double d15 = (double)k + 0.5D + (double)aint[1][2] * 0.5D;
                d6 = d14 - d12;
                d7 = d15 - d13;
                double d16;
                double d18;
                if(d6 == 0.0D)
                {
                    locX = (double)i + 0.5D;
                    d11 = locZ - (double)k;
                } else
                if(d7 == 0.0D)
                {
                    locZ = (double)k + 0.5D;
                    d11 = locX - (double)i;
                } else
                {
                    d16 = locX - d12;
                    d18 = locZ - d13;
                    double d17 = (d16 * d6 + d18 * d7) * 2D;
                    d11 = d17;
                }
                locX = d12 + d6 * d11;
                locZ = d13 + d7 * d11;
                setPosition(locX, locY + (double)height, locZ);
                d16 = motX;
                d18 = motZ;
                if(passenger != null)
                {
                    d16 *= 0.75D;
                    d18 *= 0.75D;
                }
                if(d16 < -d4)
                    d16 = -d4;
                if(d16 > d4)
                    d16 = d4;
                if(d18 < -d4)
                    d18 = -d4;
                if(d18 > d4)
                    d18 = d4;
                move(d16, 0.0D, d18);
                if(aint[0][1] != 0 && MathHelper.floor(locX) - i == aint[0][0] && MathHelper.floor(locZ) - k == aint[0][2])
                    setPosition(locX, locY + (double)aint[0][1], locZ);
                else
                if(aint[1][1] != 0 && MathHelper.floor(locX) - i == aint[1][0] && MathHelper.floor(locZ) - k == aint[1][2])
                    setPosition(locX, locY + (double)aint[1][1], locZ);
                if(passenger != null || !slowWhenEmpty)
                {
                    motX *= 0.99699997901916504D;
                    motY *= 0.0D;
                    motZ *= 0.99699997901916504D;
                } else
                {
                    if(type == 2)
                    {
                        double d17 = MathHelper.a(b * b + c * c);
                        if(d17 > 0.01D)
                        {
                            b /= d17;
                            c /= d17;
                            double d19 = 0.040000000000000001D;
                            motX *= 0.80000001192092896D;
                            motY *= 0.0D;
                            motZ *= 0.80000001192092896D;
                            motX += b * d19;
                            motZ += c * d19;
                        } else
                        {
                            motX *= 0.89999997615814209D;
                            motY *= 0.0D;
                            motZ *= 0.89999997615814209D;
                        }
                    }
                    motX *= 0.95999997854232788D;
                    motY *= 0.0D;
                    motZ *= 0.95999997854232788D;
                }
                Vec3D vec3d1 = h(locX, locY, locZ);
                if(vec3d1 != null && vec3d != null)
                {
                    double d20 = (vec3d.b - vec3d1.b) * 0.050000000000000003D;
                    d10 = Math.sqrt(motX * motX + motZ * motZ);
                    if(d10 > 0.0D)
                    {
                        motX = (motX / d10) * (d10 + d20);
                        motZ = (motZ / d10) * (d10 + d20);
                    }
                    setPosition(locX, vec3d1.b, locZ);
                }
                int j1 = MathHelper.floor(locX);
                int k1 = MathHelper.floor(locZ);
                if(j1 != i || k1 != k)
                {
                    d10 = Math.sqrt(motX * motX + motZ * motZ);
                    motX = d10 * (double)(j1 - i);
                    motZ = d10 * (double)(k1 - k);
                }
                if(type == 2)
                {
                    double d21 = MathHelper.a(b * b + c * c);
                    if(d21 > 0.01D && motX * motX + motZ * motZ > 0.001D)
                    {
                        b /= d21;
                        c /= d21;
                        if(b * motX + c * motZ < 0.0D)
                        {
                            b = 0.0D;
                            c = 0.0D;
                        } else
                        {
                            b = motX;
                            c = motZ;
                        }
                    }
                }
                if(flag)
                {
                    double d21 = Math.sqrt(motX * motX + motZ * motZ);
                    if(d21 > 0.01D)
                    {
                        double d22 = 0.059999999999999998D;
                        motX += (motX / d21) * d22;
                        motZ += (motZ / d21) * d22;
                    } else
                    if(i1 == 1)
                    {
                        if(world.e(i - 1, j, k))
                            motX = 0.02D;
                        else
                        if(world.e(i + 1, j, k))
                            motX = -0.02D;
                    } else
                    if(i1 == 0)
                        if(world.e(i, j, k - 1))
                            motZ = 0.02D;
                        else
                        if(world.e(i, j, k + 1))
                            motZ = -0.02D;
                }
            } else
            {
                if(motX < -d4)
                    motX = -d4;
                if(motX > d4)
                    motX = d4;
                if(motZ < -d4)
                    motZ = -d4;
                if(motZ > d4)
                    motZ = d4;
                if(onGround)
                {
                    motX *= derailedX;
                    motY *= derailedY;
                    motZ *= derailedZ;
                }
                move(motX, motY, motZ);
                if(!onGround)
                {
                    motX *= flyingX;
                    motY *= flyingY;
                    motZ *= flyingZ;
                }
            }
            pitch = 0.0F;
            double d23 = lastX - locX;
            double d24 = lastZ - locZ;
            if(d23 * d23 + d24 * d24 > 0.001D)
            {
                yaw = (float)((Math.atan2(d24, d23) * 180D) / 3.1415926535897931D);
                if(f)
                    yaw += 180F;
            }
            double d25;
            for(d25 = yaw - lastYaw; d25 >= 180D; d25 -= 360D);
            for(; d25 < -180D; d25 += 360D);
            if(d25 < -170D || d25 >= 170D)
            {
                yaw += 180F;
                f = !f;
            }
            c(yaw, pitch);
            org.bukkit.World bworld = world.getWorld();
            Location from = new Location(bworld, prevX, prevY, prevZ, prevYaw, prevPitch);
            Location to = new Location(bworld, locX, locY, locZ, yaw, pitch);
            Vehicle vehicle = (Vehicle)getBukkitEntity();
            world.getServer().getPluginManager().callEvent(new VehicleUpdateEvent(vehicle));
            if(!from.equals(to))
                world.getServer().getPluginManager().callEvent(new VehicleMoveEvent(vehicle, from, to));
            List list = world.b(this, boundingBox.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
            if(list != null && list.size() > 0)
            {
                for(int l1 = 0; l1 < list.size(); l1++)
                {
                    Entity entity = (Entity)list.get(l1);
                    if(entity != passenger && entity.f_() && (entity instanceof EntityMinecart))
                        entity.collide(this);
                }

            }
            if(passenger != null && passenger.dead)
            {
                if(passenger.vehicle == this)
                    passenger.vehicle = null;
                passenger = null;
            }
            if(e > 0)
                e--;
            if(e <= 0)
                b = c = 0.0D;
            a(e > 0);
        }
    }

    public Vec3D h(double d0, double d1, double d2)
    {
        int i = MathHelper.floor(d0);
        int j = MathHelper.floor(d1);
        int k = MathHelper.floor(d2);
        if(BlockMinecartTrack.g(world, i, j - 1, k))
            j--;
        int l = world.getTypeId(i, j, k);
        if(BlockMinecartTrack.d(l))
        {
            int i1 = world.getData(i, j, k);
            d1 = j;
            if(((BlockMinecartTrack)Block.byId[l]).h())
                i1 &= 7;
            if(i1 >= 2 && i1 <= 5)
                d1 = j + 1;
            int aint[][] = matrix[i1];
            double d3 = 0.0D;
            double d4 = (double)i + 0.5D + (double)aint[0][0] * 0.5D;
            double d5 = (double)j + 0.5D + (double)aint[0][1] * 0.5D;
            double d6 = (double)k + 0.5D + (double)aint[0][2] * 0.5D;
            double d7 = (double)i + 0.5D + (double)aint[1][0] * 0.5D;
            double d8 = (double)j + 0.5D + (double)aint[1][1] * 0.5D;
            double d9 = (double)k + 0.5D + (double)aint[1][2] * 0.5D;
            double d10 = d7 - d4;
            double d11 = (d8 - d5) * 2D;
            double d12 = d9 - d6;
            if(d10 == 0.0D)
            {
                d0 = (double)i + 0.5D;
                d3 = d2 - (double)k;
            } else
            if(d12 == 0.0D)
            {
                d2 = (double)k + 0.5D;
                d3 = d0 - (double)i;
            } else
            {
                double d13 = d0 - d4;
                double d14 = d2 - d6;
                double d15 = (d13 * d10 + d14 * d12) * 2D;
                d3 = d15;
            }
            d0 = d4 + d10 * d3;
            d1 = d5 + d11 * d3;
            d2 = d6 + d12 * d3;
            if(d11 < 0.0D)
                d1++;
            if(d11 > 0.0D)
                d1 += 0.5D;
            return Vec3D.create(d0, d1, d2);
        } else
        {
            return null;
        }
    }

    protected void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("Type", type);
        if(type == 2)
        {
            nbttagcompound.a("PushX", b);
            nbttagcompound.a("PushZ", c);
            nbttagcompound.a("Fuel", (short)e);
        } else
        if(type == 1)
        {
            NBTTagList nbttaglist = new NBTTagList();
            for(int i = 0; i < items.length; i++)
                if(items[i] != null)
                {
                    NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                    nbttagcompound1.a("Slot", (byte)i);
                    items[i].b(nbttagcompound1);
                    nbttaglist.a(nbttagcompound1);
                }

            nbttagcompound.a("Items", nbttaglist);
        }
    }

    protected void a(NBTTagCompound nbttagcompound)
    {
        type = nbttagcompound.f("Type");
        if(type == 2)
        {
            b = nbttagcompound.i("PushX");
            c = nbttagcompound.i("PushZ");
            e = nbttagcompound.e("Fuel");
        } else
        if(type == 1)
        {
            NBTTagList nbttaglist = nbttagcompound.m("Items");
            items = new ItemStack[getSize()];
            for(int i = 0; i < nbttaglist.d(); i++)
            {
                NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.a(i);
                int j = nbttagcompound1.d("Slot") & 0xff;
                if(j >= 0 && j < items.length)
                    items[j] = ItemStack.a(nbttagcompound1);
            }

        }
    }

    public void collide(Entity entity)
    {
        if(!world.isStatic && entity != passenger)
        {
            Vehicle vehicle = (Vehicle)getBukkitEntity();
            org.bukkit.entity.Entity hitEntity = entity != null ? entity.getBukkitEntity() : null;
            VehicleEntityCollisionEvent collisionEvent = new VehicleEntityCollisionEvent(vehicle, hitEntity);
            world.getServer().getPluginManager().callEvent(collisionEvent);
            if(collisionEvent.isCancelled())
                return;
            if((entity instanceof EntityLiving) && !(entity instanceof EntityHuman) && type == 0 && motX * motX + motZ * motZ > 0.01D && passenger == null && entity.vehicle == null && !collisionEvent.isPickupCancelled())
            {
                VehicleEnterEvent enterEvent = new VehicleEnterEvent(vehicle, hitEntity);
                world.getServer().getPluginManager().callEvent(enterEvent);
                if(!enterEvent.isCancelled())
                    entity.mount(this);
            }
            double d0 = entity.locX - locX;
            double d1 = entity.locZ - locZ;
            double d2 = d0 * d0 + d1 * d1;
            if(d2 >= 9.9999997473787516E-005D && !collisionEvent.isCollisionCancelled())
            {
                d2 = MathHelper.a(d2);
                d0 /= d2;
                d1 /= d2;
                double d3 = 1.0D / d2;
                if(d3 > 1.0D)
                    d3 = 1.0D;
                d0 *= d3;
                d1 *= d3;
                d0 *= 0.10000000149011612D;
                d1 *= 0.10000000149011612D;
                d0 *= 1.0F - bO;
                d1 *= 1.0F - bO;
                d0 *= 0.5D;
                d1 *= 0.5D;
                if(entity instanceof EntityMinecart)
                {
                    double d4 = entity.locX - locX;
                    double d5 = entity.locZ - locZ;
                    Vec3D vec3d = Vec3D.create(d4, 0.0D, d5).b();
                    Vec3D vec3d1 = Vec3D.create(MathHelper.cos((yaw * 3.141593F) / 180F), 0.0D, MathHelper.sin((yaw * 3.141593F) / 180F)).b();
                    double d6 = Math.abs(vec3d.a(vec3d1));
                    if(d6 < 0.80000001192092896D)
                        return;
                    double d7 = entity.motX + motX;
                    double d8 = entity.motZ + motZ;
                    if(((EntityMinecart)entity).type == 2 && type != 2)
                    {
                        motX *= 0.20000000298023224D;
                        motZ *= 0.20000000298023224D;
                        b_(entity.motX - d0, 0.0D, entity.motZ - d1);
                        entity.motX *= 0.94999998807907104D;
                        entity.motZ *= 0.94999998807907104D;
                    } else
                    if(((EntityMinecart)entity).type != 2 && type == 2)
                    {
                        entity.motX *= 0.20000000298023224D;
                        entity.motZ *= 0.20000000298023224D;
                        entity.b_(motX + d0, 0.0D, motZ + d1);
                        motX *= 0.94999998807907104D;
                        motZ *= 0.94999998807907104D;
                    } else
                    {
                        d7 /= 2D;
                        d8 /= 2D;
                        motX *= 0.20000000298023224D;
                        motZ *= 0.20000000298023224D;
                        b_(d7 - d0, 0.0D, d8 - d1);
                        entity.motX *= 0.20000000298023224D;
                        entity.motZ *= 0.20000000298023224D;
                        entity.b_(d7 + d0, 0.0D, d8 + d1);
                    }
                } else
                {
                    b_(-d0, 0.0D, -d1);
                    entity.b_(d0 / 4D, 0.0D, d1 / 4D);
                }
            }
        }
    }

    public int getSize()
    {
        return 27;
    }

    public ItemStack getItem(int i)
    {
        return items[i];
    }

    public ItemStack splitStack(int i, int j)
    {
        if(items[i] != null)
        {
            ItemStack itemstack;
            if(items[i].count <= j)
            {
                itemstack = items[i];
                items[i] = null;
                return itemstack;
            }
            itemstack = items[i].a(j);
            if(items[i].count == 0)
                items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        items[i] = itemstack;
        if(itemstack != null && itemstack.count > getMaxStackSize())
            itemstack.count = getMaxStackSize();
    }

    public String getName()
    {
        return "Minecart";
    }

    public int getMaxStackSize()
    {
        return 64;
    }

    public void update()
    {
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(type == 0)
        {
            if(passenger != null && (passenger instanceof EntityHuman) && passenger != entityhuman)
                return true;
            if(!world.isStatic)
            {
                org.bukkit.entity.Entity player = entityhuman != null ? entityhuman.getBukkitEntity() : null;
                VehicleEnterEvent event = new VehicleEnterEvent((Vehicle)getBukkitEntity(), player);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled())
                    return true;
                entityhuman.mount(this);
            }
        } else
        if(type == 1)
        {
            if(!world.isStatic)
                entityhuman.a(this);
        } else
        if(type == 2)
        {
            ItemStack itemstack = entityhuman.inventory.getItemInHand();
            if(itemstack != null && itemstack.id == Item.COAL.id)
            {
                if(--itemstack.count == 0)
                    entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack)null);
                e += 3600;
            }
            b = locX - entityhuman.locX;
            c = locZ - entityhuman.locZ;
        }
        return true;
    }

    public boolean a(EntityHuman entityhuman)
    {
        return dead ? false : entityhuman.i(this) <= 64D;
    }

    protected boolean j()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    protected void a(boolean flag)
    {
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)(datawatcher.getByte(16) | 1)));
        else
            datawatcher.watch(16, Byte.valueOf((byte)(datawatcher.getByte(16) & -2)));
    }

    public void f()
    {
    }

    public void g()
    {
    }

    public void setDamage(int i)
    {
        datawatcher.watch(19, Integer.valueOf(i));
    }

    public int getDamage()
    {
        return datawatcher.getInt(19);
    }

    public void c(int i)
    {
        datawatcher.watch(17, Integer.valueOf(i));
    }

    public int l()
    {
        return datawatcher.getInt(17);
    }

    public void d(int i)
    {
        datawatcher.watch(18, Integer.valueOf(i));
    }

    public int m()
    {
        return datawatcher.getInt(18);
    }

    private ItemStack items[];
    private int e;
    private boolean f;
    public int type;
    public double b;
    public double c;
    private static final int matrix[][][] = {
        {
            {
                0, 0, -1
            }, {
                0, 0, 1
            }
        }, {
            {
                -1, 0, 0
            }, {
                1, 0, 0
            }
        }, {
            {
                -1, -1, 0
            }, {
                1, 0, 0
            }
        }, {
            {
                -1, 0, 0
            }, {
                1, -1, 0
            }
        }, {
            {
                0, 0, -1
            }, {
                0, -1, 1
            }
        }, {
            {
                0, -1, -1
            }, {
                0, 0, 1
            }
        }, {
            {
                0, 0, 1
            }, {
                1, 0, 0
            }
        }, {
            {
                0, 0, 1
            }, {
                -1, 0, 0
            }
        }, {
            {
                0, 0, -1
            }, {
                -1, 0, 0
            }
        }, {
            {
                0, 0, -1
            }, {
                1, 0, 0
            }
        }
    };
    private int h;
    private double i;
    private double j;
    private double k;
    private double l;
    private double m;
    public boolean slowWhenEmpty;
    public double derailedX;
    public double derailedY;
    public double derailedZ;
    public double flyingX;
    public double flyingY;
    public double flyingZ;
    public double maxSpeed;

}
