// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemArmor

public final class EnumArmorMaterial extends Enum
{

    public static EnumArmorMaterial[] values()
    {
        return (EnumArmorMaterial[])i.clone();
    }

    public static EnumArmorMaterial valueOf(String s)
    {
        return (EnumArmorMaterial)Enum.valueOf(net/minecraft/server/EnumArmorMaterial, s);
    }

    private EnumArmorMaterial(String s, int j, int k, int ai[], int l)
    {
        super(s, j);
        f = k;
        g = ai;
        h = l;
    }

    public int a(int j)
    {
        return ItemArmor.n()[j] * f;
    }

    public int b(int j)
    {
        return g[j];
    }

    public int a()
    {
        return h;
    }

    public static final EnumArmorMaterial CLOTH;
    public static final EnumArmorMaterial IRON;
    public static final EnumArmorMaterial CHAIN;
    public static final EnumArmorMaterial GOLD;
    public static final EnumArmorMaterial DIAMOND;
    private int f;
    private int g[];
    private int h;
    private static final EnumArmorMaterial i[];

    static 
    {
        CLOTH = new EnumArmorMaterial("CLOTH", 0, 5, new int[] {
            1, 3, 2, 1
        }, 15);
        IRON = new EnumArmorMaterial("CHAIN", 1, 15, new int[] {
            2, 5, 4, 1
        }, 12);
        CHAIN = new EnumArmorMaterial("IRON", 2, 15, new int[] {
            2, 6, 5, 2
        }, 9);
        GOLD = new EnumArmorMaterial("GOLD", 3, 7, new int[] {
            2, 5, 3, 1
        }, 25);
        DIAMOND = new EnumArmorMaterial("DIAMOND", 4, 33, new int[] {
            3, 8, 6, 3
        }, 10);
        i = (new EnumArmorMaterial[] {
            CLOTH, IRON, CHAIN, GOLD, DIAMOND
        });
    }
}
