// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityEgg.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.Location;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.entity.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerEggThrowEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityProjectile, EntityLiving, EntityPlayer, World, 
//            MovingObjectPosition, Entity, DamageSource

public class EntityEgg extends EntityProjectile
{

    public EntityEgg(World world)
    {
        super(world);
    }

    public EntityEgg(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityEgg(World world, double d0, double d1, double d2)
    {
        super(world, d0, d1, d2);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        ProjectileHitEvent phe = new ProjectileHitEvent((Projectile)getBukkitEntity());
        world.getServer().getPluginManager().callEvent(phe);
        if(movingobjectposition.entity != null)
        {
            boolean stick;
            if(movingobjectposition.entity instanceof EntityLiving)
            {
                org.bukkit.entity.Entity damagee = movingobjectposition.entity.getBukkitEntity();
                Projectile projectile = (Projectile)getBukkitEntity();
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(projectile, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.PROJECTILE, 0);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled())
                    stick = !projectile.doesBounce();
                else
                    stick = movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), event.getDamage());
            } else
            {
                stick = movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), 0);
            }
            if(!stick);
        }
        boolean hatching = !world.isStatic && random.nextInt(8) == 0;
        int numHatching = random.nextInt(32) != 0 ? 1 : 4;
        if(!hatching)
            numHatching = 0;
        CreatureType hatchingType = CreatureType.CHICKEN;
        if(shooter instanceof EntityPlayer)
        {
            Player player = shooter != null ? (Player)shooter.getBukkitEntity() : null;
            PlayerEggThrowEvent event = new PlayerEggThrowEvent(player, (Egg)getBukkitEntity(), hatching, (byte)numHatching, hatchingType);
            world.getServer().getPluginManager().callEvent(event);
            hatching = event.isHatching();
            numHatching = event.getNumHatches();
            hatchingType = event.getHatchType();
        }
        if(hatching)
        {
            for(int k = 0; k < numHatching; k++)
            {
                org.bukkit.entity.Entity entity = world.getWorld().spawn(new Location(world.getWorld(), locX, locY, locZ, yaw, 0.0F), hatchingType.getEntityClass(), org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.EGG);
                if(entity instanceof Animals)
                    ((Animals)entity).setAge(-24000);
            }

        }
        for(int j = 0; j < 8; j++)
            world.a("snowballpoof", locX, locY, locZ, 0.0D, 0.0D, 0.0D);

        if(!world.isStatic)
            die();
    }
}
