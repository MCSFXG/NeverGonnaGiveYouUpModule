// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public final class EnchantmentDamage extends Enum
{

    public static EnchantmentDamage[] values()
    {
        return (EnchantmentDamage[])d.clone();
    }

    public static EnchantmentDamage valueOf(String s)
    {
        return (EnchantmentDamage)Enum.valueOf(net/minecraft/server/EnchantmentDamage, s);
    }

    private EnchantmentDamage(String s, int i)
    {
        super(s, i);
    }

    public static final EnchantmentDamage a;
    public static final EnchantmentDamage b;
    public static final EnchantmentDamage c;
    private static final EnchantmentDamage d[];

    static 
    {
        a = new EnchantmentDamage("UNDEFINED", 0);
        b = new EnchantmentDamage("UNDEAD", 1);
        c = new EnchantmentDamage("ARTHROPOD", 2);
        d = (new EnchantmentDamage[] {
            a, b, c
        });
    }
}
