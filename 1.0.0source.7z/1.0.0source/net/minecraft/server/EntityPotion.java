// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Iterator;
import java.util.List;

// Referenced classes of package net.minecraft.server:
//            EntityProjectile, World, Item, ItemPotion, 
//            AxisAlignedBB, EntityLiving, Entity, MovingObjectPosition, 
//            MobEffect, MobEffectList

public class EntityPotion extends EntityProjectile
{

    public EntityPotion(World world)
    {
        super(world);
    }

    public EntityPotion(World world, EntityLiving entityliving, int i)
    {
        super(world, entityliving);
        d = i;
    }

    public EntityPotion(World world, double d1, double d2, double d3, 
            int i)
    {
        super(world, d1, d2, d3);
        d = i;
    }

    protected float e()
    {
        return 0.05F;
    }

    protected float c()
    {
        return 0.5F;
    }

    protected float d()
    {
        return -20F;
    }

    public int f()
    {
        return d;
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(!world.isStatic)
        {
            List list = Item.POTION.b(d);
            if(list != null && !list.isEmpty())
            {
                AxisAlignedBB axisalignedbb = boundingBox.b(4D, 2D, 4D);
                List list1 = world.a(net/minecraft/server/EntityLiving, axisalignedbb);
                if(list1 != null && !list1.isEmpty())
                {
                    for(Iterator iterator = list1.iterator(); iterator.hasNext();)
                    {
                        Entity entity = (Entity)iterator.next();
                        double d1 = i(entity);
                        if(d1 < 16D)
                        {
                            double d2 = 1.0D - Math.sqrt(d1) / 4D;
                            if(entity == movingobjectposition.entity)
                                d2 = 1.0D;
                            Iterator iterator1 = list.iterator();
                            while(iterator1.hasNext()) 
                            {
                                MobEffect mobeffect = (MobEffect)iterator1.next();
                                int i = mobeffect.getEffectId();
                                if(MobEffectList.byId[i].b())
                                {
                                    MobEffectList.byId[i].a(shooter, (EntityLiving)entity, mobeffect.getAmplifier(), d2);
                                } else
                                {
                                    int j = (int)(d2 * (double)mobeffect.getDuration() + 0.5D);
                                    if(j > 20)
                                        ((EntityLiving)entity).addEffect(new MobEffect(i, j, mobeffect.getAmplifier()));
                                }
                            }
                        }
                    }

                }
            }
            world.f(2002, (int)Math.round(locX), (int)Math.round(locY), (int)Math.round(locZ), d);
            die();
        }
    }

    private int d;
}
