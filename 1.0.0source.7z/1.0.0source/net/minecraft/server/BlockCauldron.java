// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, EntityHuman, 
//            InventoryPlayer, ItemStack, Item, PlayerAbilities, 
//            EntityItem, AxisAlignedBB

public class BlockCauldron extends Block
{

    public BlockCauldron(int i)
    {
        super(i, Material.ORE);
        textureId = 154;
    }

    public int a(int i, int j)
    {
        if(i == 1)
            return 138;
        return i != 0 ? 154 : 155;
    }

    public void a(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, ArrayList arraylist)
    {
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
        super.a(world, i, j, k, axisalignedbb, arraylist);
        float f1 = 0.125F;
        a(0.0F, 0.0F, 0.0F, f1, 1.0F, 1.0F);
        super.a(world, i, j, k, axisalignedbb, arraylist);
        a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f1);
        super.a(world, i, j, k, axisalignedbb, arraylist);
        a(1.0F - f1, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        super.a(world, i, j, k, axisalignedbb, arraylist);
        a(0.0F, 0.0F, 1.0F - f1, 1.0F, 1.0F, 1.0F);
        super.a(world, i, j, k, axisalignedbb, arraylist);
        f();
    }

    public void f()
    {
        a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public boolean a()
    {
        return false;
    }

    public int c()
    {
        return 24;
    }

    public boolean b()
    {
        return false;
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(world.isStatic)
            return true;
        ItemStack itemstack = entityhuman.inventory.getItemInHand();
        if(itemstack == null)
            return true;
        int l = world.getData(i, j, k);
        if(itemstack.id == Item.WATER_BUCKET.id)
        {
            if(l < 3)
            {
                if(!entityhuman.abilities.canInstantlyBuild)
                    entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, new ItemStack(Item.BUCKET));
                world.setData(i, j, k, 3);
            }
            return true;
        }
        if(itemstack.id == Item.GLASS_BOTTLE.id && l > 0)
        {
            ItemStack itemstack1 = new ItemStack(Item.POTION, 1, 0);
            if(!entityhuman.inventory.pickup(itemstack1))
                world.addEntity(new EntityItem(world, (double)i + 0.5D, (double)j + 1.5D, (double)k + 0.5D, itemstack1));
            itemstack.count--;
            if(itemstack.count <= 0)
                entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, null);
            world.setData(i, j, k, l - 1);
        }
        return true;
    }

    public int a(int i, Random random, int j)
    {
        return Item.CAULDRON.id;
    }
}
