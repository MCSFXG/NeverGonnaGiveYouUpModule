// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Chunk.java

package net.minecraft.server;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.craftbukkit.CraftChunk;
import org.bukkit.craftbukkit.CraftWorld;

// Referenced classes of package net.minecraft.server:
//            EmptyChunk, NibbleArray, BlockContainer, ChunkPosition, 
//            TileEntity, Entity, EntityPlayer, ChunkCoordIntPair, 
//            World, Block, WorldProvider, EnumSkyBlock, 
//            MathHelper, AxisAlignedBB, BlockRegister, IChunkProvider, 
//            Material

public class Chunk
{

    public Chunk(World world, int i, int j)
    {
        c = new int[256];
        d = new boolean[256];
        v = false;
        tileEntities = new HashMap();
        done = false;
        q = false;
        s = false;
        t = 0L;
        u = false;
        entitySlices = new List[world.height / 16];
        this.world = world;
        x = i;
        z = j;
        heightMap = new byte[256];
        for(int k = 0; k < entitySlices.length; k++)
            entitySlices[k] = new ArrayList();

        Arrays.fill(c, -999);
        if(!(this instanceof EmptyChunk))
        {
            CraftWorld cworld = this.world.getWorld();
            bukkitChunk = cworld != null ? cworld.popPreservedChunk(i, j) : null;
            if(bukkitChunk == null)
                bukkitChunk = new CraftChunk(this);
        }
    }

    public Chunk(World world, byte abyte[], int i, int j)
    {
        this(world, i, j);
        b = abyte;
        g = new NibbleArray(abyte.length, world.heightBits);
        h = new NibbleArray(abyte.length, world.heightBits);
        this.i = new NibbleArray(abyte.length, world.heightBits);
    }

    public boolean a(int i, int j)
    {
        return i == x && j == z;
    }

    public int b(int i, int j)
    {
        return heightMap[j << 4 | i] & 0xff;
    }

    public void a()
    {
    }

    public void initLighting()
    {
        int i = world.height - 1;
        for(int j = 0; j < 16; j++)
        {
            for(int k = 0; k < 16; k++)
            {
                int l = world.height - 1;
                int i1;
                for(i1 = j << world.heightBitsPlusFour | k << world.heightBits; l > 0 && Block.q[b[(i1 + l) - 1] & 0xff] == 0; l--);
                heightMap[k << 4 | j] = (byte)l;
                if(l < i)
                    i = l;
                if(world.worldProvider.e)
                    continue;
                int j1 = 15;
                int k1 = world.height - 1;
                do
                {
                    j1 -= Block.q[b[i1 + k1] & 0xff];
                    if(j1 > 0)
                        h.a(j, k1, k, j1);
                } while(--k1 > 0 && j1 > 0);
            }

        }

        this.k = i;
        for(int j = 0; j < 16; j++)
        {
            for(int k = 0; k < 16; k++)
                d(j, k);

        }

        q = true;
    }

    public void loadNOP()
    {
    }

    private void d(int i, int j)
    {
        d[i + j * 16] = true;
        v = true;
    }

    private void k()
    {
        if(world.areChunksLoaded(x * 16 + 8, world.height / 2, z * 16 + 8, 16))
        {
            for(int i = 0; i < 16; i++)
            {
                for(int j = 0; j < 16; j++)
                {
                    if(!d[i + j * 16])
                        continue;
                    d[i + j * 16] = false;
                    int k = b(i, j);
                    int l = x * 16 + i;
                    int i1 = z * 16 + j;
                    int j1 = world.getHighestBlockYAt(l - 1, i1);
                    int k1 = world.getHighestBlockYAt(l + 1, i1);
                    int l1 = world.getHighestBlockYAt(l, i1 - 1);
                    int i2 = world.getHighestBlockYAt(l, i1 + 1);
                    if(k1 < j1)
                        j1 = k1;
                    if(l1 < j1)
                        j1 = l1;
                    if(i2 < j1)
                        j1 = i2;
                    f(l, i1, j1);
                    f(l - 1, i1, k);
                    f(l + 1, i1, k);
                    f(l, i1 - 1, k);
                    f(l, i1 + 1, k);
                    v = false;
                }

            }

        }
    }

    private void f(int i, int j, int k)
    {
        int l = world.getHighestBlockYAt(i, j);
        if(l > k)
            d(i, j, k, l + 1);
        else
        if(l < k)
            d(i, j, l, k + 1);
    }

    private void d(int i, int j, int k, int l)
    {
        if(l > k && world.areChunksLoaded(i, world.height / 2, j, 16))
        {
            for(int i1 = k; i1 < l; i1++)
                world.b(EnumSkyBlock.SKY, i, i1, j);

            q = true;
        }
    }

    private void g(int i, int j, int k)
    {
        int l = heightMap[k << 4 | i] & 0xff;
        int i1 = l;
        if(j > l)
            i1 = j;
        for(int j1 = i << world.heightBitsPlusFour | k << world.heightBits; i1 > 0 && Block.q[b[(j1 + i1) - 1] & 0xff] == 0; i1--);
        if(i1 != l)
        {
            world.g(i, k, i1, l);
            heightMap[k << 4 | i] = (byte)i1;
            int k1;
            int l1;
            if(i1 < this.k)
            {
                this.k = i1;
            } else
            {
                k1 = world.height - 1;
                for(l1 = 0; l1 < 16; l1++)
                {
                    for(int i2 = 0; i2 < 16; i2++)
                        if((heightMap[i2 << 4 | l1] & 0xff) < k1)
                            k1 = heightMap[i2 << 4 | l1] & 0xff;

                }

                this.k = k1;
            }
            k1 = x * 16 + i;
            l1 = z * 16 + k;
            int j2;
            if(!world.worldProvider.e)
            {
                if(i1 < l)
                {
                    for(int i2 = i1; i2 < l; i2++)
                        h.a(i, i2, k, 15);

                } else
                {
                    for(int i2 = l; i2 < i1; i2++)
                        h.a(i, i2, k, 0);

                }
                for(int i2 = 15; i1 > 0 && i2 > 0;)
                {
                    i1--;
                    j2 = Block.q[getTypeId(i, i1, k)];
                    if(j2 == 0)
                        j2 = 1;
                    i2 -= j2;
                    if(i2 < 0)
                        i2 = 0;
                    h.a(i, i1, k, i2);
                }

            }
            byte b0 = heightMap[k << 4 | i];
            j2 = l;
            int k2 = b0;
            if(b0 < l)
            {
                j2 = b0;
                k2 = l;
            }
            if(!world.worldProvider.e)
            {
                d(k1 - 1, l1, j2, k2);
                d(k1 + 1, l1, j2, k2);
                d(k1, l1 - 1, j2, k2);
                d(k1, l1 + 1, j2, k2);
                d(k1, l1, j2, k2);
            }
            q = true;
        }
    }

    public int getTypeId(int i, int j, int k)
    {
        return b[i << world.heightBitsPlusFour | k << world.heightBits | j] & 0xff;
    }

    public boolean a(int i, int j, int k, int l, int i1)
    {
        byte b0 = (byte)l;
        int j1 = k << 4 | i;
        if(j >= c[j1] - 1)
            c[j1] = -999;
        int k1 = heightMap[k << 4 | i] & 0xff;
        int l1 = b[i << world.heightBitsPlusFour | k << world.heightBits | j] & 0xff;
        if(l1 == l && g.a(i, j, k) == i1)
            return false;
        int i2 = x * 16 + i;
        int j2 = z * 16 + k;
        b[i << world.heightBitsPlusFour | k << world.heightBits | j] = (byte)(b0 & 0xff);
        if(l1 != 0)
            if(!world.isStatic)
                Block.byId[l1].remove(world, i2, j, j2);
            else
            if(Block.byId[l1] instanceof BlockContainer)
                world.n(i2, j, j2);
        g.a(i, j, k, i1);
        if(!world.worldProvider.e)
        {
            if(Block.q[b0 & 0xff] != 0)
            {
                if(j >= k1)
                    g(i, j + 1, k);
            } else
            if(j == k1 - 1)
                g(i, j, k);
            world.a(EnumSkyBlock.SKY, i2, j, j2, i2, j, j2);
        }
        world.a(EnumSkyBlock.BLOCK, i2, j, j2, i2, j, j2);
        d(i, k);
        g.a(i, j, k, i1);
        if(l != 0)
        {
            if(!world.isStatic)
                Block.byId[l].a(world, i2, j, j2);
            if(Block.byId[l] instanceof BlockContainer)
            {
                TileEntity tileentity = d(i, j, k);
                if(tileentity == null)
                {
                    tileentity = ((BlockContainer)Block.byId[l]).a_();
                    world.setTileEntity(i2, j, j2, tileentity);
                }
                if(tileentity != null)
                    tileentity.d();
            }
        } else
        if(l1 > 0 && (Block.byId[l1] instanceof BlockContainer))
        {
            TileEntity tileentity = d(i, j, k);
            if(tileentity != null)
                tileentity.d();
        }
        q = true;
        return true;
    }

    public boolean a(int i, int j, int k, int l)
    {
        byte b0 = (byte)l;
        int i1 = k << 4 | i;
        if(j >= c[i1] - 1)
            c[i1] = -999;
        int j1 = heightMap[i1] & 0xff;
        int k1 = b[i << world.heightBitsPlusFour | k << world.heightBits | j] & 0xff;
        if(k1 == l)
            return false;
        int l1 = x * 16 + i;
        int i2 = z * 16 + k;
        b[i << world.heightBitsPlusFour | k << world.heightBits | j] = (byte)(b0 & 0xff);
        if(k1 != 0)
            Block.byId[k1].remove(world, l1, j, i2);
        g.a(i, j, k, 0);
        if(Block.q[b0 & 0xff] != 0)
        {
            if(j >= j1)
                g(i, j + 1, k);
        } else
        if(j == j1 - 1)
            g(i, j, k);
        world.a(EnumSkyBlock.SKY, l1, j, i2, l1, j, i2);
        world.a(EnumSkyBlock.BLOCK, l1, j, i2, l1, j, i2);
        d(i, k);
        if(l != 0)
        {
            if(!world.isStatic)
                Block.byId[l].a(world, l1, j, i2);
            if(l > 0 && (Block.byId[l] instanceof BlockContainer))
            {
                TileEntity tileentity = d(i, j, k);
                if(tileentity == null)
                {
                    tileentity = ((BlockContainer)Block.byId[l]).a_();
                    world.setTileEntity(l1, j, i2, tileentity);
                }
                if(tileentity != null)
                    tileentity.d();
            }
        } else
        if(k1 > 0 && (Block.byId[k1] instanceof BlockContainer))
        {
            TileEntity tileentity = d(i, j, k);
            if(tileentity != null)
                tileentity.d();
        }
        q = true;
        return true;
    }

    public int getData(int i, int j, int k)
    {
        return g.a(i, j, k);
    }

    public boolean b(int i, int j, int k, int l)
    {
        q = true;
        int i1 = g.a(i, j, k);
        if(i1 == l)
            return false;
        g.a(i, j, k, l);
        int j1 = getTypeId(i, j, k);
        if(j1 > 0 && (Block.byId[j1] instanceof BlockContainer))
        {
            TileEntity tileentity = d(i, j, k);
            if(tileentity != null)
            {
                tileentity.d();
                tileentity.p = l;
            }
        }
        return true;
    }

    public int a(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        return enumskyblock != EnumSkyBlock.SKY ? enumskyblock != EnumSkyBlock.BLOCK ? 0 : this.i.a(i, j, k) : h.a(i, j, k);
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
    {
        q = true;
        if(enumskyblock == EnumSkyBlock.SKY)
        {
            if(!world.worldProvider.e)
                h.a(i, j, k, l);
        } else
        {
            if(enumskyblock != EnumSkyBlock.BLOCK)
                return;
            this.i.a(i, j, k, l);
        }
    }

    public int c(int i, int j, int k, int l)
    {
        int i1 = world.worldProvider.e ? 0 : h.a(i, j, k);
        if(i1 > 0)
            a = true;
        i1 -= l;
        int j1 = this.i.a(i, j, k);
        if(j1 > i1)
            i1 = j1;
        return i1;
    }

    public void a(Entity entity)
    {
        s = true;
        int i = MathHelper.floor(entity.locX / 16D);
        int j = MathHelper.floor(entity.locZ / 16D);
        if(i != x || j != z)
        {
            Bukkit.getLogger().warning((new StringBuilder()).append("Wrong location for ").append(entity).append(" in world '").append(world.getWorld().getName()).append("'!").toString());
            Bukkit.getLogger().warning((new StringBuilder()).append("Entity is at ").append(entity.locX).append(",").append(entity.locZ).append(" (chunk ").append(i).append(",").append(j).append(") but was stored in chunk ").append(x).append(",").append(z).toString());
        }
        int k = MathHelper.floor(entity.locY / 16D);
        if(k < 0)
            k = 0;
        if(k >= entitySlices.length)
            k = entitySlices.length - 1;
        entity.bW = true;
        entity.bX = x;
        entity.bY = k;
        entity.bZ = z;
        entitySlices[k].add(entity);
    }

    public void b(Entity entity)
    {
        a(entity, entity.bY);
    }

    public void a(Entity entity, int i)
    {
        if(i < 0)
            i = 0;
        if(i >= entitySlices.length)
            i = entitySlices.length - 1;
        entitySlices[i].remove(entity);
    }

    public boolean c(int i, int j, int k)
    {
        return j >= (heightMap[k << 4 | i] & 0xff);
    }

    public TileEntity d(int i, int j, int k)
    {
        ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        TileEntity tileentity = (TileEntity)tileEntities.get(chunkposition);
        if(tileentity == null)
        {
            int l = getTypeId(i, j, k);
            if(!Block.isTileEntity[l])
                return null;
            if(tileentity == null)
            {
                tileentity = ((BlockContainer)Block.byId[l]).a_();
                world.setTileEntity(x * 16 + i, j, z * 16 + k, tileentity);
            }
            tileentity = (TileEntity)tileEntities.get(chunkposition);
        }
        if(tileentity != null && tileentity.l())
        {
            tileEntities.remove(chunkposition);
            return null;
        } else
        {
            return tileentity;
        }
    }

    public void a(TileEntity tileentity)
    {
        int i = tileentity.x - x * 16;
        int j = tileentity.y;
        int k = tileentity.z - z * 16;
        a(i, j, k, tileentity);
        if(e)
            world.h.add(tileentity);
    }

    public void a(int i, int j, int k, TileEntity tileentity)
    {
        ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        tileentity.world = world;
        tileentity.x = x * 16 + i;
        tileentity.y = j;
        tileentity.z = z * 16 + k;
        if(getTypeId(i, j, k) != 0 && (Block.byId[getTypeId(i, j, k)] instanceof BlockContainer))
        {
            tileentity.m();
            tileEntities.put(chunkposition, tileentity);
        } else
        {
            System.out.println((new StringBuilder()).append("Attempted to place a tile entity (").append(tileentity).append(") at ").append(tileentity.x).append(",").append(tileentity.y).append(",").append(tileentity.z).append(" (").append(Material.getMaterial(getTypeId(i, j, k))).append(") where there was no entity tile!").toString());
        }
    }

    public void e(int i, int j, int k)
    {
        ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        if(e)
        {
            TileEntity tileentity = (TileEntity)tileEntities.remove(chunkposition);
            if(tileentity != null)
                tileentity.i();
        }
    }

    public void addEntities()
    {
        e = true;
        world.a(tileEntities.values());
        for(int i = 0; i < entitySlices.length; i++)
            world.a(entitySlices[i]);

    }

    public void removeEntities()
    {
        e = false;
        TileEntity tileentity;
        for(Iterator iterator = tileEntities.values().iterator(); iterator.hasNext(); world.a(tileentity))
            tileentity = (TileEntity)iterator.next();

        for(int i = 0; i < entitySlices.length; i++)
        {
            Iterator iter = entitySlices[i].iterator();
            do
            {
                if(!iter.hasNext())
                    break;
                Entity entity = (Entity)iter.next();
                int cx = Location.locToBlock(entity.locX) >> 4;
                int cz = Location.locToBlock(entity.locZ) >> 4;
                if((entity instanceof EntityPlayer) && (cx != x || cz != z))
                    iter.remove();
            } while(true);
            world.b(entitySlices[i]);
        }

    }

    public void f()
    {
        q = true;
    }

    public void a(Entity entity, AxisAlignedBB axisalignedbb, List list)
    {
        int i = MathHelper.floor((axisalignedbb.b - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.e + 2D) / 16D);
        if(i < 0)
            i = 0;
        if(j >= entitySlices.length)
            j = entitySlices.length - 1;
        for(int k = i; k <= j; k++)
        {
            List list1 = entitySlices[k];
            for(int l = 0; l < list1.size(); l++)
            {
                Entity entity1 = (Entity)list1.get(l);
                if(entity1 == entity || !entity1.boundingBox.a(axisalignedbb))
                    continue;
                list.add(entity1);
                Entity aentity[] = entity1.aG();
                if(aentity == null)
                    continue;
                for(int i1 = 0; i1 < aentity.length; i1++)
                {
                    entity1 = aentity[i1];
                    if(entity1 != entity && entity1.boundingBox.a(axisalignedbb))
                        list.add(entity1);
                }

            }

        }

    }

    public void a(Class oclass, AxisAlignedBB axisalignedbb, List list)
    {
        int i = MathHelper.floor((axisalignedbb.b - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.e + 2D) / 16D);
        if(i < 0)
            i = 0;
        else
        if(i >= entitySlices.length)
            i = entitySlices.length - 1;
        if(j >= entitySlices.length)
            j = entitySlices.length - 1;
        else
        if(j < 0)
            j = 0;
        for(int k = i; k <= j; k++)
        {
            List list1 = entitySlices[k];
            for(int l = 0; l < list1.size(); l++)
            {
                Entity entity = (Entity)list1.get(l);
                if(oclass.isAssignableFrom(entity.getClass()) && entity.boundingBox.a(axisalignedbb))
                    list.add(entity);
            }

        }

    }

    public boolean a(boolean flag)
    {
        if(r)
            return false;
        if(flag)
        {
            if(s && world.getTime() != t)
                return true;
        } else
        if(s && world.getTime() >= t + 600L)
            return true;
        return q;
    }

    public int getData(byte abyte[], int i, int j, int k, int l, int i1, int j1, 
            int k1)
    {
        int l1 = l - i;
        int i2 = i1 - j;
        int j2 = j1 - k;
        if(l1 * i2 * j2 == b.length)
        {
            System.arraycopy(b, 0, abyte, k1, b.length);
            k1 += b.length;
            System.arraycopy(g.a, 0, abyte, k1, g.a.length);
            k1 += g.a.length;
            System.arraycopy(this.i.a, 0, abyte, k1, this.i.a.length);
            k1 += this.i.a.length;
            System.arraycopy(h.a, 0, abyte, k1, h.a.length);
            k1 += h.a.length;
            return k1;
        }
        for(int k2 = i; k2 < l; k2++)
        {
            for(int l2 = k; l2 < j1; l2++)
            {
                int i3 = k2 << world.heightBitsPlusFour | l2 << world.heightBits | j;
                int j3 = i1 - j;
                System.arraycopy(b, i3, abyte, k1, j3);
                k1 += j3;
            }

        }

        for(int k2 = i; k2 < l; k2++)
        {
            for(int l2 = k; l2 < j1; l2++)
            {
                int i3 = (k2 << world.heightBitsPlusFour | l2 << world.heightBits | j) >> 1;
                int j3 = (i1 - j) / 2;
                System.arraycopy(g.a, i3, abyte, k1, j3);
                k1 += j3;
            }

        }

        for(int k2 = i; k2 < l; k2++)
        {
            for(int l2 = k; l2 < j1; l2++)
            {
                int i3 = (k2 << world.heightBitsPlusFour | l2 << world.heightBits | j) >> 1;
                int j3 = (i1 - j) / 2;
                System.arraycopy(this.i.a, i3, abyte, k1, j3);
                k1 += j3;
            }

        }

        for(int k2 = i; k2 < l; k2++)
        {
            for(int l2 = k; l2 < j1; l2++)
            {
                int i3 = (k2 << world.heightBitsPlusFour | l2 << world.heightBits | j) >> 1;
                int j3 = (i1 - j) / 2;
                System.arraycopy(h.a, i3, abyte, k1, j3);
                k1 += j3;
            }

        }

        return k1;
    }

    public Random a(long i)
    {
        return new Random(world.getSeed() + (long)(x * x * 0x4c1906) + (long)(x * 0x5ac0db) + (long)(z * z) * 0x4307a7L + (long)(z * 0x5f24f) ^ i);
    }

    public boolean isEmpty()
    {
        return false;
    }

    public void h()
    {
        BlockRegister.a(b);
    }

    public void a(IChunkProvider ichunkprovider, IChunkProvider ichunkprovider1, int i, int j)
    {
        if(!done && ichunkprovider.isChunkLoaded(i + 1, j + 1) && ichunkprovider.isChunkLoaded(i, j + 1) && ichunkprovider.isChunkLoaded(i + 1, j))
            ichunkprovider.getChunkAt(ichunkprovider1, i, j);
        if(ichunkprovider.isChunkLoaded(i - 1, j) && !ichunkprovider.getOrCreateChunk(i - 1, j).done && ichunkprovider.isChunkLoaded(i - 1, j + 1) && ichunkprovider.isChunkLoaded(i, j + 1) && ichunkprovider.isChunkLoaded(i - 1, j + 1))
            ichunkprovider.getChunkAt(ichunkprovider1, i - 1, j);
        if(ichunkprovider.isChunkLoaded(i, j - 1) && !ichunkprovider.getOrCreateChunk(i, j - 1).done && ichunkprovider.isChunkLoaded(i + 1, j - 1) && ichunkprovider.isChunkLoaded(i + 1, j - 1) && ichunkprovider.isChunkLoaded(i + 1, j))
            ichunkprovider.getChunkAt(ichunkprovider1, i, j - 1);
        if(ichunkprovider.isChunkLoaded(i - 1, j - 1) && !ichunkprovider.getOrCreateChunk(i - 1, j - 1).done && ichunkprovider.isChunkLoaded(i, j - 1) && ichunkprovider.isChunkLoaded(i - 1, j))
            ichunkprovider.getChunkAt(ichunkprovider1, i - 1, j - 1);
    }

    public int c(int i, int j)
    {
        int k = i | j << 4;
        int l = c[k];
        if(l == -999)
        {
            int i1 = world.height - 1;
            for(l = -1; i1 > 0 && l == -1;)
            {
                int j1 = getTypeId(i, i1, j);
                net.minecraft.server.Material material = j1 != 0 ? Block.byId[j1].material : Material.AIR;
                if(!material.isSolid() && !material.isLiquid())
                    i1--;
                else
                    l = i1 + 1;
            }

            c[k] = l;
        }
        return l;
    }

    public void i()
    {
        if(v && !world.worldProvider.e)
            k();
    }

    public ChunkCoordIntPair j()
    {
        return new ChunkCoordIntPair(x, z);
    }

    public static boolean a;
    public byte b[];
    public int c[];
    public boolean d[];
    public boolean e;
    public World world;
    public NibbleArray g;
    public NibbleArray h;
    public NibbleArray i;
    public byte heightMap[];
    public int k;
    public final int x;
    public final int z;
    private boolean v;
    public Map tileEntities;
    public List entitySlices[];
    public boolean done;
    public boolean q;
    public boolean r;
    public boolean s;
    public long t;
    boolean u;
    public org.bukkit.Chunk bukkitChunk;
}
