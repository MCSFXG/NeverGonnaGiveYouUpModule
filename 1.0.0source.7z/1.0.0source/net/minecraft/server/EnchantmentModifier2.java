// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EnchantmentModifier2.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EnchantmentModifier, Enchantment, EntityLiving, EmptyClass3

final class EnchantmentModifier2
    implements EnchantmentModifier
{

    private EnchantmentModifier2()
    {
    }

    public void a(Enchantment enchantment, int i)
    {
        a += enchantment.a(i, b);
    }

    EnchantmentModifier2(EmptyClass3 emptyclass3)
    {
        this();
    }

    public int a;
    public EntityLiving b;
}
