// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityCreature, NPC, NBTTagCompound, World

public class EntityVillager extends EntityCreature
    implements NPC
{

    public EntityVillager(World world)
    {
        this(world, 0);
    }

    public EntityVillager(World world, int i)
    {
        super(world);
        profession = i;
        y();
        aY = 0.5F;
    }

    public int getMaxHealth()
    {
        return 20;
    }

    public void d()
    {
        super.d();
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Profession", profession);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        profession = nbttagcompound.f("Profession");
        y();
    }

    private void y()
    {
        texture = "/mob/villager/villager.png";
        if(profession == 0)
            texture = "/mob/villager/farmer.png";
        if(profession == 1)
            texture = "/mob/villager/librarian.png";
        if(profession == 2)
            texture = "/mob/villager/priest.png";
        if(profession == 3)
            texture = "/mob/villager/smith.png";
        if(profession == 4)
            texture = "/mob/villager/butcher.png";
    }

    protected boolean d_()
    {
        return false;
    }

    protected String c_()
    {
        return "mob.villager.default";
    }

    protected String m()
    {
        return "mob.villager.defaulthurt";
    }

    protected String n()
    {
        return "mob.villager.defaultdeath";
    }

    private int profession;
}
