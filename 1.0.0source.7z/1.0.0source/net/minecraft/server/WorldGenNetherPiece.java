// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            StructurePiece, WorldGenNetherPieceWeight, WorldGenNetherPiece15, WorldGenNetherPieces, 
//            WorldGenNetherPiece4, StructureBoundingBox

abstract class WorldGenNetherPiece extends StructurePiece
{

    protected WorldGenNetherPiece(int i)
    {
        super(i);
    }

    private int a(List list)
    {
        boolean flag = false;
        int i = 0;
        for(Iterator iterator = list.iterator(); iterator.hasNext();)
        {
            WorldGenNetherPieceWeight worldgennetherpieceweight = (WorldGenNetherPieceWeight)iterator.next();
            if(worldgennetherpieceweight.d > 0 && worldgennetherpieceweight.c < worldgennetherpieceweight.d)
                flag = true;
            i += worldgennetherpieceweight.b;
        }

        return flag ? i : -1;
    }

    private WorldGenNetherPiece a(WorldGenNetherPiece15 worldgennetherpiece15, List list, List list1, Random random, int i, int j, int k, 
            int l, int i1)
    {
        int j1;
        boolean flag;
        int k1;
        j1 = a(list);
        flag = j1 > 0 && i1 <= 30;
        k1 = 0;
_L2:
        int l1;
        Iterator iterator;
        if(k1 >= 5 || !flag)
            break MISSING_BLOCK_LABEL_195;
        k1++;
        l1 = random.nextInt(j1);
        iterator = list.iterator();
_L4:
        if(!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        WorldGenNetherPieceWeight worldgennetherpieceweight;
        worldgennetherpieceweight = (WorldGenNetherPieceWeight)iterator.next();
        l1 -= worldgennetherpieceweight.b;
        if(l1 >= 0) goto _L4; else goto _L3
_L3:
        if(worldgennetherpieceweight.a(i1) && (worldgennetherpieceweight != worldgennetherpiece15.a || worldgennetherpieceweight.e)) goto _L5; else goto _L2
_L5:
        WorldGenNetherPiece worldgennetherpiece = WorldGenNetherPieces.a(worldgennetherpieceweight, list1, random, i, j, k, l, i1);
        if(worldgennetherpiece == null) goto _L4; else goto _L6
_L6:
        worldgennetherpieceweight.c++;
        worldgennetherpiece15.a = worldgennetherpieceweight;
        if(!worldgennetherpieceweight.a())
            list.remove(worldgennetherpieceweight);
        return worldgennetherpiece;
        WorldGenNetherPiece4 worldgennetherpiece4 = WorldGenNetherPiece4.a(list1, random, i, j, k, l, i1);
        return worldgennetherpiece4;
    }

    private StructurePiece a(WorldGenNetherPiece15 worldgennetherpiece15, List list, Random random, int i, int j, int k, int l, 
            int i1, boolean flag)
    {
        if(Math.abs(i - worldgennetherpiece15.b().a) > 112 || Math.abs(k - worldgennetherpiece15.b().c) > 112)
        {
            WorldGenNetherPiece4 worldgennetherpiece4 = WorldGenNetherPiece4.a(list, random, i, j, k, l, i1);
            return worldgennetherpiece4;
        }
        List list1 = worldgennetherpiece15.b;
        if(flag)
            list1 = worldgennetherpiece15.c;
        WorldGenNetherPiece worldgennetherpiece = a(worldgennetherpiece15, list1, list, random, i, j, k, l, i1 + 1);
        if(worldgennetherpiece != null)
        {
            list.add(worldgennetherpiece);
            worldgennetherpiece15.d.add(worldgennetherpiece);
        }
        return worldgennetherpiece;
    }

    protected StructurePiece a(WorldGenNetherPiece15 worldgennetherpiece15, List list, Random random, int i, int j, boolean flag)
    {
        switch(h)
        {
        case 2: // '\002'
            return a(worldgennetherpiece15, list, random, g.a + i, g.b + j, g.c - 1, h, c(), flag);

        case 0: // '\0'
            return a(worldgennetherpiece15, list, random, g.a + i, g.b + j, g.f + 1, h, c(), flag);

        case 1: // '\001'
            return a(worldgennetherpiece15, list, random, g.a - 1, g.b + j, g.c + i, h, c(), flag);

        case 3: // '\003'
            return a(worldgennetherpiece15, list, random, g.d + 1, g.b + j, g.c + i, h, c(), flag);
        }
        return null;
    }

    protected StructurePiece b(WorldGenNetherPiece15 worldgennetherpiece15, List list, Random random, int i, int j, boolean flag)
    {
        switch(h)
        {
        case 2: // '\002'
            return a(worldgennetherpiece15, list, random, g.a - 1, g.b + i, g.c + j, 1, c(), flag);

        case 0: // '\0'
            return a(worldgennetherpiece15, list, random, g.a - 1, g.b + i, g.c + j, 1, c(), flag);

        case 1: // '\001'
            return a(worldgennetherpiece15, list, random, g.a + j, g.b + i, g.c - 1, 2, c(), flag);

        case 3: // '\003'
            return a(worldgennetherpiece15, list, random, g.a + j, g.b + i, g.c - 1, 2, c(), flag);
        }
        return null;
    }

    protected StructurePiece c(WorldGenNetherPiece15 worldgennetherpiece15, List list, Random random, int i, int j, boolean flag)
    {
        switch(h)
        {
        case 2: // '\002'
            return a(worldgennetherpiece15, list, random, g.d + 1, g.b + i, g.c + j, 3, c(), flag);

        case 0: // '\0'
            return a(worldgennetherpiece15, list, random, g.d + 1, g.b + i, g.c + j, 3, c(), flag);

        case 1: // '\001'
            return a(worldgennetherpiece15, list, random, g.a + j, g.b + i, g.f + 1, 0, c(), flag);

        case 3: // '\003'
            return a(worldgennetherpiece15, list, random, g.a + j, g.b + i, g.f + 1, 0, c(), flag);
        }
        return null;
    }

    protected static boolean a(StructureBoundingBox structureboundingbox)
    {
        return structureboundingbox != null && structureboundingbox.b > 10;
    }
}
