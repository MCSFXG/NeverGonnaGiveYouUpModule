// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySnowman.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.inventory.ItemStack;

// Referenced classes of package net.minecraft.server:
//            EntityGolem, EntityMonster, Entity, EntitySnowball, 
//            World, AxisAlignedBB, MathHelper, WorldChunkManager, 
//            DamageSource, Block, Item, NBTTagCompound

public class EntitySnowman extends EntityGolem
{

    public EntitySnowman(World world)
    {
        super(world);
        texture = "/mob/snowman.png";
        b(0.4F, 1.8F);
    }

    public int getMaxHealth()
    {
        return 4;
    }

    public void d()
    {
        super.d();
        if(target == null && !D() && world.random.nextInt(100) == 0)
        {
            List list = world.a(net/minecraft/server/EntityMonster, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).b(16D, 4D, 16D));
            if(!list.isEmpty())
                setTarget((Entity)list.get(world.random.nextInt(list.size())));
        }
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locY);
        int k = MathHelper.floor(locZ);
        if(world.getWorldChunkManager().a(i, j, k) > 1.0F)
            damageEntity(DamageSource.BURN, 1);
        for(i = 0; i < 4; i++)
        {
            j = MathHelper.floor(locX + (double)((float)((i % 2) * 2 - 1) * 0.25F));
            k = MathHelper.floor(locY);
            int l = MathHelper.floor(locZ + (double)((float)(((i / 2) % 2) * 2 - 1) * 0.25F));
            if(world.getTypeId(j, k, l) == 0 && world.getWorldChunkManager().a(j, k, l) < 0.8F && Block.SNOW.canPlace(world, j, k, l))
                world.setTypeId(j, k, l, Block.SNOW.id);
        }

    }

    protected void a(Entity entity, float f)
    {
        if(f < 10F)
        {
            double d0 = entity.locX - locX;
            double d1 = entity.locZ - locZ;
            if(attackTicks == 0)
            {
                EntitySnowball entitysnowball = new EntitySnowball(world, this);
                double d2 = (entity.locY + (double)entity.x()) - 1.1000000238418579D - entitysnowball.locY;
                float f1 = MathHelper.a(d0 * d0 + d1 * d1) * 0.2F;
                world.makeSound(this, "random.bow", 1.0F, 1.0F / (random.nextFloat() * 0.4F + 0.8F));
                world.addEntity(entitysnowball);
                entitysnowball.a(d0, d2 + (double)f1, d1, 1.6F, 12F);
                attackTicks = 10;
            }
            yaw = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - 90F;
            e = true;
        }
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int e()
    {
        return Item.SNOW_BALL.id;
    }

    protected void a(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = random.nextInt(16);
        if(j > 0)
            loot.add(new ItemStack(Item.SNOW_BALL.id, j));
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }
}
