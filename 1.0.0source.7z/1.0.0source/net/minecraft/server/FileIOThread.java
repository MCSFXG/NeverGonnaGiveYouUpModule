// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            IAsyncChunkSaver

public class FileIOThread
    implements Runnable
{

    private FileIOThread()
    {
        b = Collections.synchronizedList(new ArrayList());
        c = 0L;
        d = 0L;
        e = false;
        Thread thread = new Thread(this, "File IO Thread");
        thread.setPriority(1);
        thread.start();
    }

    public void run()
    {
        do
            b();
        while(true);
    }

    private void b()
    {
        for(int i = 0; i < b.size(); i++)
        {
            IAsyncChunkSaver iasyncchunksaver = (IAsyncChunkSaver)b.get(i);
            boolean flag = iasyncchunksaver.c();
            if(!flag)
            {
                b.remove(i--);
                d++;
            }
            try
            {
                if(!e)
                    Thread.sleep(10L);
                else
                    Thread.sleep(0L);
            }
            catch(InterruptedException interruptedexception1)
            {
                interruptedexception1.printStackTrace();
            }
        }

        if(b.isEmpty())
            try
            {
                Thread.sleep(25L);
            }
            catch(InterruptedException interruptedexception)
            {
                interruptedexception.printStackTrace();
            }
    }

    public void a(IAsyncChunkSaver iasyncchunksaver)
    {
        if(b.contains(iasyncchunksaver))
        {
            return;
        } else
        {
            c++;
            b.add(iasyncchunksaver);
            return;
        }
    }

    public void a()
    {
        e = true;
        while(c != d) 
            Thread.sleep(10L);
        e = false;
    }

    public static final FileIOThread a = new FileIOThread();
    private List b;
    private volatile long c;
    private volatile long d;
    private volatile boolean e;

}
