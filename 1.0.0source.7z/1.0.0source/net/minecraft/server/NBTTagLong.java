// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagLong extends NBTBase
{

    public NBTTagLong(String s)
    {
        super(s);
    }

    public NBTTagLong(String s, long l)
    {
        super(s);
        a = l;
    }

    void a(DataOutput dataoutput)
    {
        dataoutput.writeLong(a);
    }

    void a(DataInput datainput)
    {
        a = datainput.readLong();
    }

    public byte a()
    {
        return 4;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(a).toString();
    }

    public NBTBase b()
    {
        return new NBTTagLong(c(), a);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagLong nbttaglong = (NBTTagLong)obj;
            return a == nbttaglong.a;
        } else
        {
            return false;
        }
    }

    public long a;
}
