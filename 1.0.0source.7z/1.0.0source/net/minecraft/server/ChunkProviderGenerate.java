// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            IChunkProvider, MapGenCaves, WorldGenStronghold, WorldGenVillage, 
//            WorldGenMineshaft, WorldGenCanyon, NoiseGeneratorOctaves, World, 
//            WorldChunkManager, Block, BiomeBase, Chunk, 
//            MapGenBase, MathHelper, BlockSand, WorldGenLakes, 
//            WorldGenDungeons, SpawnerCreature, ChunkCoordIntPair, IProgressUpdate, 
//            EnumCreatureType, ChunkPosition

public class ChunkProviderGenerate
    implements IChunkProvider
{

    public ChunkProviderGenerate(World world, long l1, boolean flag)
    {
        v = new double[256];
        w = new MapGenCaves();
        d = new WorldGenStronghold();
        e = new WorldGenVillage();
        f = new WorldGenMineshaft();
        x = new WorldGenCanyon();
        m = new int[32][32];
        s = world;
        t = flag;
        n = new Random(l1);
        o = new NoiseGeneratorOctaves(n, 16);
        p = new NoiseGeneratorOctaves(n, 16);
        q = new NoiseGeneratorOctaves(n, 8);
        r = new NoiseGeneratorOctaves(n, 4);
        a = new NoiseGeneratorOctaves(n, 10);
        b = new NoiseGeneratorOctaves(n, 16);
        c = new NoiseGeneratorOctaves(n, 8);
    }

    public void a(int i1, int j1, byte abyte0[])
    {
        byte byte0 = 4;
        int k1 = s.height / 8;
        int l1 = s.seaLevel;
        int i2 = byte0 + 1;
        int j2 = s.height / 8 + 1;
        int k2 = byte0 + 1;
        y = s.getWorldChunkManager().getBiomes(y, i1 * 4 - 2, j1 * 4 - 2, i2 + 5, k2 + 5);
        u = a(u, i1 * byte0, 0, j1 * byte0, i2, j2, k2);
        for(int l2 = 0; l2 < byte0; l2++)
        {
            for(int i3 = 0; i3 < byte0; i3++)
            {
                for(int j3 = 0; j3 < k1; j3++)
                {
                    double d1 = 0.125D;
                    double d2 = u[((l2 + 0) * k2 + (i3 + 0)) * j2 + (j3 + 0)];
                    double d3 = u[((l2 + 0) * k2 + (i3 + 1)) * j2 + (j3 + 0)];
                    double d4 = u[((l2 + 1) * k2 + (i3 + 0)) * j2 + (j3 + 0)];
                    double d5 = u[((l2 + 1) * k2 + (i3 + 1)) * j2 + (j3 + 0)];
                    double d6 = (u[((l2 + 0) * k2 + (i3 + 0)) * j2 + (j3 + 1)] - d2) * d1;
                    double d7 = (u[((l2 + 0) * k2 + (i3 + 1)) * j2 + (j3 + 1)] - d3) * d1;
                    double d8 = (u[((l2 + 1) * k2 + (i3 + 0)) * j2 + (j3 + 1)] - d4) * d1;
                    double d9 = (u[((l2 + 1) * k2 + (i3 + 1)) * j2 + (j3 + 1)] - d5) * d1;
                    for(int k3 = 0; k3 < 8; k3++)
                    {
                        double d10 = 0.25D;
                        double d11 = d2;
                        double d12 = d3;
                        double d13 = (d4 - d2) * d10;
                        double d14 = (d5 - d3) * d10;
                        for(int l3 = 0; l3 < 4; l3++)
                        {
                            int i4 = l3 + l2 * 4 << s.heightBitsPlusFour | 0 + i3 * 4 << s.heightBits | j3 * 8 + k3;
                            int j4 = 1 << s.heightBits;
                            i4 -= j4;
                            double d15 = 0.25D;
                            double d16 = d11;
                            double d17 = (d12 - d11) * d15;
                            d16 -= d17;
                            for(int k4 = 0; k4 < 4; k4++)
                            {
                                if((d16 += d17) > 0.0D)
                                {
                                    abyte0[i4 += j4] = (byte)Block.STONE.id;
                                    continue;
                                }
                                if(j3 * 8 + k3 < l1)
                                    abyte0[i4 += j4] = (byte)Block.STATIONARY_WATER.id;
                                else
                                    abyte0[i4 += j4] = 0;
                            }

                            d11 += d13;
                            d12 += d14;
                        }

                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                        d5 += d9;
                    }

                }

            }

        }

    }

    public void a(int i1, int j1, byte abyte0[], BiomeBase abiomebase[])
    {
        int k1 = s.seaLevel;
        double d1 = 0.03125D;
        v = r.a(v, i1 * 16, j1 * 16, 0, 16, 16, 1, d1 * 2D, d1 * 2D, d1 * 2D);
        float af[] = s.getWorldChunkManager().a(i1 * 16, j1 * 16, 16, 16);
        for(int l1 = 0; l1 < 16; l1++)
        {
            for(int i2 = 0; i2 < 16; i2++)
            {
                float f1 = af[i2 + l1 * 16];
                BiomeBase biomebase = abiomebase[i2 + l1 * 16];
                int j2 = (int)(v[l1 + i2 * 16] / 3D + 3D + n.nextDouble() * 0.25D);
                int k2 = -1;
                byte byte0 = biomebase.t;
                byte byte1 = biomebase.u;
                for(int l2 = s.heightMinusOne; l2 >= 0; l2--)
                {
                    int i3 = (i2 * 16 + l1) * s.height + l2;
                    if(l2 <= 0 + n.nextInt(5))
                    {
                        abyte0[i3] = (byte)Block.BEDROCK.id;
                        continue;
                    }
                    byte byte2 = abyte0[i3];
                    if(byte2 == 0)
                    {
                        k2 = -1;
                        continue;
                    }
                    if(byte2 != Block.STONE.id)
                        continue;
                    if(k2 == -1)
                    {
                        if(j2 <= 0)
                        {
                            byte0 = 0;
                            byte1 = (byte)Block.STONE.id;
                        } else
                        if(l2 >= k1 - 4 && l2 <= k1 + 1)
                        {
                            byte0 = biomebase.t;
                            byte1 = biomebase.u;
                        }
                        if(l2 < k1 && byte0 == 0)
                            if(f1 < 0.15F)
                                byte0 = (byte)Block.ICE.id;
                            else
                                byte0 = (byte)Block.STATIONARY_WATER.id;
                        k2 = j2;
                        if(l2 >= k1 - 1)
                            abyte0[i3] = byte0;
                        else
                            abyte0[i3] = byte1;
                        continue;
                    }
                    if(k2 <= 0)
                        continue;
                    k2--;
                    abyte0[i3] = byte1;
                    if(k2 == 0 && byte1 == Block.SAND.id)
                    {
                        k2 = n.nextInt(4);
                        byte1 = (byte)Block.SANDSTONE.id;
                    }
                }

            }

        }

    }

    public Chunk getChunkAt(int i1, int j1)
    {
        return getOrCreateChunk(i1, j1);
    }

    public Chunk getOrCreateChunk(int i1, int j1)
    {
        n.setSeed((long)i1 * 0x4f9939f508L + (long)j1 * 0x1ef1565bd5L);
        byte abyte0[] = new byte[16 * s.height * 16];
        Chunk chunk = new Chunk(s, abyte0, i1, j1);
        a(i1, j1, abyte0);
        y = s.getWorldChunkManager().a(y, i1 * 16, j1 * 16, 16, 16);
        a(i1, j1, abyte0, y);
        w.a(this, s, i1, j1, abyte0);
        x.a(this, s, i1, j1, abyte0);
        if(t)
        {
            f.a(this, s, i1, j1, abyte0);
            e.a(this, s, i1, j1, abyte0);
            d.a(this, s, i1, j1, abyte0);
        }
        chunk.initLighting();
        return chunk;
    }

    private double[] a(double ad[], int i1, int j1, int k1, int l1, int i2, int j2)
    {
        if(ad == null)
            ad = new double[l1 * i2 * j2];
        if(l == null)
        {
            l = new float[25];
            for(int k2 = -2; k2 <= 2; k2++)
            {
                for(int l2 = -2; l2 <= 2; l2++)
                {
                    float f1 = 10F / MathHelper.c((float)(k2 * k2 + l2 * l2) + 0.2F);
                    l[k2 + 2 + (l2 + 2) * 5] = f1;
                }

            }

        }
        double d1 = 684.41200000000003D;
        double d2 = 684.41200000000003D;
        j = a.a(j, i1, k1, l1, j2, 1.121D, 1.121D, 0.5D);
        k = b.a(k, i1, k1, l1, j2, 200D, 200D, 0.5D);
        g = q.a(g, i1, j1, k1, l1, i2, j2, d1 / 80D, d2 / 160D, d1 / 80D);
        h = o.a(h, i1, j1, k1, l1, i2, j2, d1, d2, d1);
        i = p.a(i, i1, j1, k1, l1, i2, j2, d1, d2, d1);
        i1 = k1 = 0;
        int i3 = 0;
        int j3 = 0;
        for(int k3 = 0; k3 < l1; k3++)
        {
            for(int l3 = 0; l3 < j2; l3++)
            {
                float f2 = 0.0F;
                float f3 = 0.0F;
                float f4 = 0.0F;
                byte byte0 = 2;
                BiomeBase biomebase = y[k3 + 2 + (l3 + 2) * (l1 + 5)];
                for(int i4 = -byte0; i4 <= byte0; i4++)
                {
                    for(int j4 = -byte0; j4 <= byte0; j4++)
                    {
                        BiomeBase biomebase1 = y[k3 + i4 + 2 + (l3 + j4 + 2) * (l1 + 5)];
                        float f5 = l[i4 + 2 + (j4 + 2) * 5] / (biomebase1.w + 2.0F);
                        if(biomebase1.w > biomebase.w)
                            f5 /= 2.0F;
                        f2 += biomebase1.x * f5;
                        f3 += biomebase1.w * f5;
                        f4 += f5;
                    }

                }

                f2 /= f4;
                f3 /= f4;
                f2 = f2 * 0.9F + 0.1F;
                f3 = (f3 * 4F - 1.0F) / 8F;
                double d3 = k[j3] / 8000D;
                if(d3 < 0.0D)
                    d3 = -d3 * 0.29999999999999999D;
                d3 = d3 * 3D - 2D;
                if(d3 < 0.0D)
                {
                    d3 /= 2D;
                    if(d3 < -1D)
                        d3 = -1D;
                    d3 /= 1.3999999999999999D;
                    d3 /= 2D;
                } else
                {
                    if(d3 > 1.0D)
                        d3 = 1.0D;
                    d3 /= 8D;
                }
                j3++;
                for(int k4 = 0; k4 < i2; k4++)
                {
                    double d4 = f3;
                    double d5 = f2;
                    d4 += d3 * 0.20000000000000001D;
                    d4 = (d4 * (double)i2) / 16D;
                    double d6 = (double)i2 / 2D + d4 * 4D;
                    double d7 = 0.0D;
                    double d8 = (((double)k4 - d6) * 12D * 128D) / (double)s.height / d5;
                    if(d8 < 0.0D)
                        d8 *= 4D;
                    double d9 = h[i3] / 512D;
                    double d10 = i[i3] / 512D;
                    double d11 = (g[i3] / 10D + 1.0D) / 2D;
                    if(d11 < 0.0D)
                        d7 = d9;
                    else
                    if(d11 > 1.0D)
                        d7 = d10;
                    else
                        d7 = d9 + (d10 - d9) * d11;
                    d7 -= d8;
                    if(k4 > i2 - 4)
                    {
                        double d12 = (float)(k4 - (i2 - 4)) / 3F;
                        d7 = d7 * (1.0D - d12) + -10D * d12;
                    }
                    ad[i3] = d7;
                    i3++;
                }

            }

        }

        return ad;
    }

    public boolean isChunkLoaded(int i1, int j1)
    {
        return true;
    }

    public void getChunkAt(IChunkProvider ichunkprovider, int i1, int j1)
    {
        BlockSand.instaFall = true;
        int k1 = i1 * 16;
        int l1 = j1 * 16;
        BiomeBase biomebase = s.getWorldChunkManager().getBiome(k1 + 16, l1 + 16);
        n.setSeed(s.getSeed());
        long l2 = (n.nextLong() / 2L) * 2L + 1L;
        long l3 = (n.nextLong() / 2L) * 2L + 1L;
        n.setSeed((long)i1 * l2 + (long)j1 * l3 ^ s.getSeed());
        boolean flag = false;
        if(t)
        {
            f.a(s, n, i1, j1);
            flag = e.a(s, n, i1, j1);
            d.a(s, n, i1, j1);
        }
        if(!flag && n.nextInt(4) == 0)
        {
            int i2 = k1 + n.nextInt(16) + 8;
            int j3 = n.nextInt(s.height);
            int k4 = l1 + n.nextInt(16) + 8;
            (new WorldGenLakes(Block.STATIONARY_WATER.id)).a(s, n, i2, j3, k4);
        }
        if(!flag && n.nextInt(8) == 0)
        {
            int j2 = k1 + n.nextInt(16) + 8;
            int k3 = n.nextInt(n.nextInt(s.height - 8) + 8);
            int l4 = l1 + n.nextInt(16) + 8;
            if(k3 < s.seaLevel || n.nextInt(10) == 0)
                (new WorldGenLakes(Block.STATIONARY_LAVA.id)).a(s, n, j2, k3, l4);
        }
        for(int k2 = 0; k2 < 8; k2++)
        {
            int i4 = k1 + n.nextInt(16) + 8;
            int i5 = n.nextInt(s.height);
            int k5 = l1 + n.nextInt(16) + 8;
            if(!(new WorldGenDungeons()).a(s, n, i4, i5, k5));
        }

        biomebase.a(s, n, k1, l1);
        SpawnerCreature.a(s, biomebase, k1 + 8, l1 + 8, 16, 16, n);
        k1 += 8;
        l1 += 8;
        for(int i3 = 0; i3 < 16; i3++)
        {
            for(int j4 = 0; j4 < 16; j4++)
            {
                int j5 = s.e(k1 + i3, l1 + j4);
                if(s.p(i3 + k1, j5 - 1, j4 + l1))
                    s.setTypeId(i3 + k1, j5 - 1, j4 + l1, Block.ICE.id);
                if(s.r(i3 + k1, j5, j4 + l1))
                    s.setTypeId(i3 + k1, j5, j4 + l1, Block.SNOW.id);
            }

        }

        BlockSand.instaFall = false;
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unloadChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public List a(EnumCreatureType enumcreaturetype, int i1, int j1, int k1)
    {
        WorldChunkManager worldchunkmanager = s.getWorldChunkManager();
        if(worldchunkmanager == null)
            return null;
        BiomeBase biomebase = worldchunkmanager.a(new ChunkCoordIntPair(i1 >> 4, k1 >> 4));
        if(biomebase == null)
            return null;
        else
            return biomebase.a(enumcreaturetype);
    }

    public ChunkPosition a(World world, String s1, int i1, int j1, int k1)
    {
        if("Stronghold".equals(s1) && d != null)
            return d.a(world, i1, j1, k1);
        else
            return null;
    }

    private Random n;
    private NoiseGeneratorOctaves o;
    private NoiseGeneratorOctaves p;
    private NoiseGeneratorOctaves q;
    private NoiseGeneratorOctaves r;
    public NoiseGeneratorOctaves a;
    public NoiseGeneratorOctaves b;
    public NoiseGeneratorOctaves c;
    private World s;
    private final boolean t;
    private double u[];
    private double v[];
    private MapGenBase w;
    public WorldGenStronghold d;
    public WorldGenVillage e;
    public WorldGenMineshaft f;
    private MapGenBase x;
    private BiomeBase y[];
    double g[];
    double h[];
    double i[];
    double j[];
    double k[];
    float l[];
    int m[][];
}
