// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, World, EntityDamageSource, Entity, 
//            AxisAlignedBB, DamageSource, MathHelper, Block, 
//            PistonBlockTextures, BlockMonsterEggs, EnchantmentDamage, NBTTagCompound

public class EntitySilverfish extends EntityMonster
{

    public EntitySilverfish(World world)
    {
        super(world);
        texture = "/mob/silverfish.png";
        b(0.3F, 0.7F);
        aY = 0.6F;
        damage = 1;
    }

    public int getMaxHealth()
    {
        return 8;
    }

    protected boolean g_()
    {
        return false;
    }

    protected Entity findTarget()
    {
        double d = 8D;
        return world.b(this, d);
    }

    protected String c_()
    {
        return "mob.silverfish.say";
    }

    protected String m()
    {
        return "mob.silverfish.hit";
    }

    protected String n()
    {
        return "mob.silverfish.kill";
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(a <= 0 && (damagesource instanceof EntityDamageSource))
            a = 20;
        return super.damageEntity(damagesource, i);
    }

    protected void a(Entity entity, float f)
    {
        if(attackTicks <= 0 && f < 1.2F && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            attackTicks = 20;
            entity.damageEntity(DamageSource.mobAttack(this), damage);
        }
    }

    protected void a(int i, int j, int k, int l)
    {
        world.makeSound(this, "mob.silverfish.step", 1.0F, 1.0F);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int e()
    {
        return 0;
    }

    public void w_()
    {
        V = yaw;
        super.w_();
    }

    protected void m_()
    {
        super.m_();
        if(world.isStatic)
            return;
        if(a > 0)
        {
            a--;
            if(a == 0)
            {
                int i = MathHelper.floor(locX);
                int k = MathHelper.floor(locY);
                int i1 = MathHelper.floor(locZ);
                boolean flag = false;
                for(int l1 = 0; !flag && l1 <= 5 && l1 >= -5; l1 = l1 > 0 ? 0 - l1 : 1 - l1)
                {
                    for(int j2 = 0; !flag && j2 <= 10 && j2 >= -10; j2 = j2 > 0 ? 0 - j2 : 1 - j2)
                    {
                        for(int k2 = 0; !flag && k2 <= 10 && k2 >= -10; k2 = k2 > 0 ? 0 - k2 : 1 - k2)
                        {
                            int l2 = world.getTypeId(i + j2, k + l1, i1 + k2);
                            if(l2 != Block.MONSTER_EGGS.id)
                                continue;
                            world.f(2001, i + j2, k + l1, i1 + k2, Block.MONSTER_EGGS.id + world.getData(i + j2, k + l1, i1 + k2) * 256);
                            world.setTypeId(i + j2, k + l1, i1 + k2, 0);
                            Block.MONSTER_EGGS.postBreak(world, i + j2, k + l1, i1 + k2, 0);
                            if(!random.nextBoolean())
                                continue;
                            flag = true;
                            break;
                        }

                    }

                }

            }
        }
        if(target == null && !D())
        {
            int j = MathHelper.floor(locX);
            int l = MathHelper.floor(locY + 0.5D);
            int j1 = MathHelper.floor(locZ);
            int k1 = random.nextInt(6);
            int i2 = world.getTypeId(j + PistonBlockTextures.b[k1], l + PistonBlockTextures.c[k1], j1 + PistonBlockTextures.d[k1]);
            if(BlockMonsterEggs.d(i2))
            {
                world.setTypeIdAndData(j + PistonBlockTextures.b[k1], l + PistonBlockTextures.c[k1], j1 + PistonBlockTextures.d[k1], Block.MONSTER_EGGS.id, BlockMonsterEggs.e(i2));
                ah();
                die();
            } else
            {
                C();
            }
        } else
        if(target != null && !D())
            target = null;
    }

    protected float a(int i, int j, int k)
    {
        if(world.getTypeId(i, j - 1, k) == Block.STONE.id)
            return 10F;
        else
            return super.a(i, j, k);
    }

    protected boolean y()
    {
        return true;
    }

    public boolean g()
    {
        if(super.g())
        {
            EntityHuman entityhuman = world.findNearbyPlayer(this, 5D);
            return entityhuman == null;
        } else
        {
            return false;
        }
    }

    public EnchantmentDamage t()
    {
        return EnchantmentDamage.c;
    }

    private int a;
}
