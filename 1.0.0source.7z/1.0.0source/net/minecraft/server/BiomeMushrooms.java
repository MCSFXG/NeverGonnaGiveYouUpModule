// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            BiomeBase, BiomeDecorator, Block, BlockMycel, 
//            BiomeMeta, EntityMushroomCow

public class BiomeMushrooms extends BiomeBase
{

    public BiomeMushrooms(int i)
    {
        super(i);
        B.z = -100;
        B.A = -100;
        B.B = -100;
        B.D = 1;
        B.J = 1;
        t = (byte)Block.MYCEL.id;
        C.clear();
        D.clear();
        E.clear();
        D.add(new BiomeMeta(net/minecraft/server/EntityMushroomCow, 8, 4, 8));
    }
}
