// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityFireball, World, MovingObjectPosition, Entity, 
//            DamageSource, Block, BlockFire, EntityLiving

public class EntitySmallFireball extends EntityFireball
{

    public EntitySmallFireball(World world)
    {
        super(world);
        b(0.3125F, 0.3125F);
    }

    public EntitySmallFireball(World world, EntityLiving entityliving, double d, double d1, double d2)
    {
        super(world, entityliving, d, d1, d2);
        b(0.3125F, 0.3125F);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(!world.isStatic)
        {
            if(movingobjectposition.entity != null)
            {
                if(!movingobjectposition.entity.ax() && movingobjectposition.entity.damageEntity(DamageSource.fireball(this, shooter), 5))
                    movingobjectposition.entity.j(5);
            } else
            {
                int i = movingobjectposition.b;
                int j = movingobjectposition.c;
                int k = movingobjectposition.d;
                switch(movingobjectposition.face)
                {
                case 1: // '\001'
                    j++;
                    break;

                case 0: // '\0'
                    j--;
                    break;

                case 2: // '\002'
                    k--;
                    break;

                case 3: // '\003'
                    k++;
                    break;

                case 5: // '\005'
                    i++;
                    break;

                case 4: // '\004'
                    i--;
                    break;
                }
                if(world.isEmpty(i, j, k))
                    world.setTypeId(i, j, k, Block.FIRE.id);
            }
            die();
        }
    }

    public boolean e_()
    {
        return false;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        return false;
    }
}
