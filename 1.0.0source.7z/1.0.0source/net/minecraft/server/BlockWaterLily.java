// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            BlockFlower, AxisAlignedBB, Block, World, 
//            Material

public class BlockWaterLily extends BlockFlower
{

    protected BlockWaterLily(int i, int j)
    {
        super(i, j);
        float f1 = 0.5F;
        float f2 = 0.015625F;
        a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f2, 0.5F + f1);
    }

    public int c()
    {
        return 23;
    }

    public AxisAlignedBB e(World world, int i, int j, int k)
    {
        return AxisAlignedBB.b((double)i + minX, (double)j + minY, (double)k + minZ, (double)i + maxX, (double)j + maxY, (double)k + maxZ);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return super.canPlace(world, i, j, k);
    }

    protected boolean d(int i)
    {
        return i == Block.STATIONARY_WATER.id;
    }

    public boolean f(World world, int i, int j, int k)
    {
        if(j < 0 || j >= world.height)
            return false;
        else
            return world.getMaterial(i, j - 1, k) == Material.WATER && world.getData(i, j - 1, k) == 0;
    }
}
