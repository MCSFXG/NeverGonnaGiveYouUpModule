// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenStrongholdStairs, WorldGenStrongholdPortalRoom, WorldGenStrongholdPieceWeight, ChunkPosition

public class WorldGenStrongholdStairs2 extends WorldGenStrongholdStairs
{

    public WorldGenStrongholdStairs2(int i, Random random, int j, int k)
    {
        super(0, random, j, k);
        c = new ArrayList();
    }

    public ChunkPosition b_()
    {
        if(b != null)
            return b.b_();
        else
            return super.b_();
    }

    public WorldGenStrongholdPieceWeight a;
    public WorldGenStrongholdPortalRoom b;
    public ArrayList c;
}
