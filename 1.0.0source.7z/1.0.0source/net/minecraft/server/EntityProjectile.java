// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityProjectile.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Entity, MovingObjectPosition, EntityLiving, MathHelper, 
//            World, Vec3D, AxisAlignedBB, NBTTagCompound, 
//            EntityHuman

public abstract class EntityProjectile extends Entity
{

    public EntityProjectile(World world)
    {
        super(world);
        blockX = -1;
        blockY = -1;
        blockZ = -1;
        inBlockId = 0;
        inGround = false;
        shake = 0;
        i = 0;
        b(0.25F, 0.25F);
    }

    protected void b()
    {
    }

    public EntityProjectile(World world, EntityLiving entityliving)
    {
        super(world);
        blockX = -1;
        blockY = -1;
        blockZ = -1;
        inBlockId = 0;
        inGround = false;
        shake = 0;
        i = 0;
        shooter = entityliving;
        b(0.25F, 0.25F);
        setPositionRotation(entityliving.locX, entityliving.locY + (double)entityliving.x(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        locX -= MathHelper.cos((yaw / 180F) * 3.141593F) * 0.16F;
        locY -= 0.10000000149011612D;
        locZ -= MathHelper.sin((yaw / 180F) * 3.141593F) * 0.16F;
        setPosition(locX, locY, locZ);
        height = 0.0F;
        float f = 0.4F;
        motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
        motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
        motY = -MathHelper.sin(((pitch + d()) / 180F) * 3.141593F) * f;
        a(motX, motY, motZ, c(), 1.0F);
    }

    public EntityProjectile(World world, double d0, double d1, double d2)
    {
        super(world);
        blockX = -1;
        blockY = -1;
        blockZ = -1;
        inBlockId = 0;
        inGround = false;
        shake = 0;
        i = 0;
        h = 0;
        b(0.25F, 0.25F);
        setPosition(d0, d1, d2);
        height = 0.0F;
    }

    protected float c()
    {
        return 1.5F;
    }

    protected float d()
    {
        return 0.0F;
    }

    public void a(double d0, double d1, double d2, float f, 
            float f1)
    {
        float f2 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= f2;
        d1 /= f2;
        d2 /= f2;
        d0 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d1 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d2 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d0 *= f;
        d1 *= f;
        d2 *= f;
        motX = d0;
        motY = d1;
        motZ = d2;
        float f3 = MathHelper.a(d0 * d0 + d2 * d2);
        lastYaw = yaw = (float)((Math.atan2(d0, d2) * 180D) / 3.1415927410125732D);
        lastPitch = pitch = (float)((Math.atan2(d1, f3) * 180D) / 3.1415927410125732D);
        h = 0;
    }

    public void w_()
    {
        bI = locX;
        bJ = locY;
        bK = locZ;
        super.w_();
        if(shake > 0)
            shake--;
        if(inGround)
        {
            int i = world.getTypeId(blockX, blockY, blockZ);
            if(i == inBlockId)
            {
                h++;
                if(h == 1200)
                    die();
                return;
            }
            inGround = false;
            motX *= random.nextFloat() * 0.2F;
            motY *= random.nextFloat() * 0.2F;
            motZ *= random.nextFloat() * 0.2F;
            h = 0;
            this.i = 0;
        } else
        {
            this.i++;
        }
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if(movingobjectposition != null)
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        if(!world.isStatic)
        {
            Entity entity = null;
            List list = world.b(this, boundingBox.a(motX, motY, motZ).b(1.0D, 1.0D, 1.0D));
            double d0 = 0.0D;
            for(int j = 0; j < list.size(); j++)
            {
                Entity entity1 = (Entity)list.get(j);
                if(!entity1.e_() || entity1 == shooter && this.i < 5)
                    continue;
                float f = 0.3F;
                AxisAlignedBB axisalignedbb = entity1.boundingBox.b(f, f, f);
                MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
                if(movingobjectposition1 == null)
                    continue;
                double d1 = vec3d.b(movingobjectposition1.f);
                if(d1 < d0 || d0 == 0.0D)
                {
                    entity = entity1;
                    d0 = d1;
                }
            }

            if(entity != null)
                movingobjectposition = new MovingObjectPosition(entity);
        }
        if(movingobjectposition != null)
            a(movingobjectposition);
        locX += motX;
        locY += motY;
        locZ += motZ;
        float f1 = MathHelper.a(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for(pitch = (float)((Math.atan2(motY, f1) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        float f2 = 0.99F;
        float f3 = e();
        if(az())
        {
            for(int k = 0; k < 4; k++)
            {
                float f4 = 0.25F;
                world.a("bubble", locX - motX * (double)f4, locY - motY * (double)f4, locZ - motZ * (double)f4, motX, motY, motZ);
            }

            f2 = 0.8F;
        }
        motX *= f2;
        motY *= f2;
        motZ *= f2;
        motY -= f3;
        setPosition(locX, locY, locZ);
    }

    protected float e()
    {
        return 0.03F;
    }

    protected abstract void a(MovingObjectPosition movingobjectposition);

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("xTile", (short)blockX);
        nbttagcompound.a("yTile", (short)blockY);
        nbttagcompound.a("zTile", (short)blockZ);
        nbttagcompound.a("inTile", (byte)inBlockId);
        nbttagcompound.a("shake", (byte)shake);
        nbttagcompound.a("inGround", (byte)(inGround ? 1 : 0));
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        blockX = nbttagcompound.e("xTile");
        blockY = nbttagcompound.e("yTile");
        blockZ = nbttagcompound.e("zTile");
        inBlockId = nbttagcompound.d("inTile") & 0xff;
        shake = nbttagcompound.d("shake") & 0xff;
        inGround = nbttagcompound.d("inGround") == 1;
    }

    public void a_(EntityHuman entityhuman1)
    {
    }

    private int blockX;
    private int blockY;
    private int blockZ;
    private int inBlockId;
    protected boolean inGround;
    public int shake;
    public EntityLiving shooter;
    private int h;
    private int i;
}
