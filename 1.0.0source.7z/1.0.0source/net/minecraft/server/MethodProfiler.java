// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

public class MethodProfiler
{

    public MethodProfiler()
    {
    }

    public static void a(String s)
    {
        if(!a)
            return;
        if(d.length() > 0)
            d = (new StringBuilder()).append(d).append(".").toString();
        d = (new StringBuilder()).append(d).append(s).toString();
        b.add(d);
        c.add(Long.valueOf(System.nanoTime()));
    }

    public static void a()
    {
        if(!a)
            return;
        long l = System.nanoTime();
        long l1 = ((Long)c.remove(c.size() - 1)).longValue();
        b.remove(b.size() - 1);
        long l2 = l - l1;
        if(e.containsKey(d))
            e.put(d, Long.valueOf(((Long)e.get(d)).longValue() + l2));
        else
            e.put(d, Long.valueOf(l2));
        d = b.size() <= 0 ? "" : (String)b.get(b.size() - 1);
    }

    public static void b(String s)
    {
        a();
        a(s);
    }

    public static boolean a = false;
    private static List b = new ArrayList();
    private static List c = new ArrayList();
    private static String d = "";
    private static Map e = new HashMap();

}
