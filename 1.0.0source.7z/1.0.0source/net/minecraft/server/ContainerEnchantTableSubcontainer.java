// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            IInventory, ItemStack, UnknownInterface01, EntityHuman

public class ContainerEnchantTableSubcontainer
    implements IInventory
{

    public ContainerEnchantTableSubcontainer(String s, int i)
    {
        a = s;
        b = i;
        c = new ItemStack[i];
    }

    public ItemStack getItem(int i)
    {
        return c[i];
    }

    public ItemStack splitStack(int i, int j)
    {
        if(c[i] != null)
        {
            if(c[i].count <= j)
            {
                ItemStack itemstack = c[i];
                c[i] = null;
                update();
                return itemstack;
            }
            ItemStack itemstack1 = c[i].a(j);
            if(c[i].count == 0)
                c[i] = null;
            update();
            return itemstack1;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        c[i] = itemstack;
        if(itemstack != null && itemstack.count > getMaxStackSize())
            itemstack.count = getMaxStackSize();
        update();
    }

    public int getSize()
    {
        return b;
    }

    public String getName()
    {
        return a;
    }

    public int getMaxStackSize()
    {
        return 64;
    }

    public void update()
    {
        if(d != null)
        {
            for(int i = 0; i < d.size(); i++)
                ((UnknownInterface01)d.get(i)).a(this);

        }
    }

    public boolean a(EntityHuman entityhuman)
    {
        return true;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    private String a;
    private int b;
    private ItemStack c[];
    private List d;
}
