// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Container, ContainerEnchantTableInventory, SlotEnchant, Slot, 
//            ICrafting, IInventory, ItemStack, World, 
//            Block, EnchantmentManager, EntityHuman, WeightedRandomChoiceEnchantment, 
//            InventoryPlayer

public class ContainerEnchantTable extends Container
{

    public ContainerEnchantTable(InventoryPlayer inventoryplayer, World world, int i1, int j1, int k1)
    {
        a = new ContainerEnchantTableInventory(this, "Enchant", 1);
        l = new Random();
        c = new int[3];
        h = world;
        i = i1;
        j = j1;
        k = k1;
        a(new SlotEnchant(this, a, 0, 25, 47));
        for(int l1 = 0; l1 < 3; l1++)
        {
            for(int j2 = 0; j2 < 9; j2++)
                a(new Slot(inventoryplayer, j2 + l1 * 9 + 9, 8 + j2 * 18, 84 + l1 * 18));

        }

        for(int i2 = 0; i2 < 9; i2++)
            a(new Slot(inventoryplayer, i2, 8 + i2 * 18, 142));

    }

    public void a(ICrafting icrafting)
    {
        super.a(icrafting);
        icrafting.a(this, 0, c[0]);
        icrafting.a(this, 1, c[1]);
        icrafting.a(this, 2, c[2]);
    }

    public void a()
    {
        super.a();
        for(int i1 = 0; i1 < listeners.size(); i1++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i1);
            icrafting.a(this, 0, c[0]);
            icrafting.a(this, 1, c[1]);
            icrafting.a(this, 2, c[2]);
        }

    }

    public void a(IInventory iinventory)
    {
        if(iinventory == a)
        {
            ItemStack itemstack = iinventory.getItem(0);
            if(itemstack == null || !itemstack.q())
            {
                for(int i1 = 0; i1 < 3; i1++)
                    c[i1] = 0;

            } else
            {
                b = l.nextLong();
                if(!h.isStatic)
                {
                    int j1 = 0;
                    for(int k1 = -1; k1 <= 1; k1++)
                    {
                        for(int i2 = -1; i2 <= 1; i2++)
                        {
                            if(k1 == 0 && i2 == 0 || !h.isEmpty(i + i2, j, k + k1) || !h.isEmpty(i + i2, j + 1, k + k1))
                                continue;
                            if(h.getTypeId(i + i2 * 2, j, k + k1 * 2) == Block.BOOKSHELF.id)
                                j1++;
                            if(h.getTypeId(i + i2 * 2, j + 1, k + k1 * 2) == Block.BOOKSHELF.id)
                                j1++;
                            if(i2 == 0 || k1 == 0)
                                continue;
                            if(h.getTypeId(i + i2 * 2, j, k + k1) == Block.BOOKSHELF.id)
                                j1++;
                            if(h.getTypeId(i + i2 * 2, j + 1, k + k1) == Block.BOOKSHELF.id)
                                j1++;
                            if(h.getTypeId(i + i2, j, k + k1 * 2) == Block.BOOKSHELF.id)
                                j1++;
                            if(h.getTypeId(i + i2, j + 1, k + k1 * 2) == Block.BOOKSHELF.id)
                                j1++;
                        }

                    }

                    for(int l1 = 0; l1 < 3; l1++)
                        c[l1] = EnchantmentManager.a(l, l1, j1, itemstack);

                    a();
                }
            }
        }
    }

    public boolean a(EntityHuman entityhuman, int i1)
    {
        ItemStack itemstack = a.getItem(0);
        if(c[i1] > 0 && itemstack != null && entityhuman.expTotal >= c[i1])
        {
            if(!h.isStatic)
            {
                List list = EnchantmentManager.a(l, itemstack, c[i1]);
                if(list != null)
                {
                    entityhuman.b(c[i1]);
                    WeightedRandomChoiceEnchantment weightedrandomchoiceenchantment;
                    for(Iterator iterator = list.iterator(); iterator.hasNext(); itemstack.a(weightedrandomchoiceenchantment.a, weightedrandomchoiceenchantment.b))
                        weightedrandomchoiceenchantment = (WeightedRandomChoiceEnchantment)iterator.next();

                    a(a);
                }
            }
            return true;
        } else
        {
            return false;
        }
    }

    public void a(EntityHuman entityhuman)
    {
        super.a(entityhuman);
        if(h.isStatic)
            return;
        ItemStack itemstack = a.getItem(0);
        if(itemstack != null)
            entityhuman.b(itemstack);
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(h.getTypeId(i, j, k) != Block.ENCHANTMENT_TABLE.id)
            return false;
        return entityhuman.e((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D) <= 64D;
    }

    public ItemStack a(int i1)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i1);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i1 == 0)
            {
                if(!a(itemstack1, 1, 37, true))
                    return null;
            } else
            {
                return null;
            }
            if(itemstack1.count == 0)
                slot.c(null);
            else
                slot.d();
            if(itemstack1.count != itemstack.count)
                slot.b(itemstack1);
            else
                return null;
        }
        return itemstack;
    }

    public IInventory a;
    private World h;
    private int i;
    private int j;
    private int k;
    private Random l;
    public long b;
    public int c[];
}
