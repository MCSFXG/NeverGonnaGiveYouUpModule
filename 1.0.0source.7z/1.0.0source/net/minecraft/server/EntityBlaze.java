// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityBlaze.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.inventory.ItemStack;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, EntityHuman, EntitySmallFireball, DataWatcher, 
//            World, DamageSource, Entity, AxisAlignedBB, 
//            MathHelper, Item, NBTTagCompound

public class EntityBlaze extends EntityMonster
{

    public EntityBlaze(World world)
    {
        super(world);
        a = 0.5F;
        texture = "/mob/fire.png";
        fireProof = true;
        damage = 6;
        az = 10;
    }

    public int getMaxHealth()
    {
        return 20;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Byte((byte)0));
    }

    protected String c_()
    {
        return "mob.blaze.breathe";
    }

    protected String m()
    {
        return "mob.blaze.hit";
    }

    protected String n()
    {
        return "mob.blaze.death";
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        return super.damageEntity(damagesource, i);
    }

    public void die(DamageSource damagesource)
    {
        super.die(damagesource);
    }

    public float a(float f)
    {
        return 1.0F;
    }

    public void d()
    {
        if(!world.isStatic)
        {
            if(ay())
                damageEntity(DamageSource.DROWN, 1);
            b--;
            if(b <= 0)
            {
                b = 100;
                a = 0.5F + (float)random.nextGaussian() * 3F;
            }
            if(E() != null && E().locY + (double)E().x() > locY + (double)x() + (double)a)
                motY += (0.30000001192092896D - motY) * 0.30000001192092896D;
        }
        if(random.nextInt(24) == 0)
            world.makeSound(locX + 0.5D, locY + 0.5D, locZ + 0.5D, "fire.fire", 1.0F + random.nextFloat(), random.nextFloat() * 0.7F + 0.3F);
        if(!onGround && motY < 0.0D)
            motY *= 0.59999999999999998D;
        for(int i = 0; i < 2; i++)
            world.a("largesmoke", locX + (random.nextDouble() - 0.5D) * (double)length, locY + random.nextDouble() * (double)width, locZ + (random.nextDouble() - 0.5D) * (double)length, 0.0D, 0.0D, 0.0D);

        super.d();
    }

    protected void a(Entity entity, float f)
    {
        if(attackTicks <= 0 && f < 2.0F && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            attackTicks = 20;
            d(entity);
        } else
        if(f < 30F)
        {
            double d0 = entity.locX - locX;
            double d1 = (entity.boundingBox.b + (double)(entity.width / 2.0F)) - (locY + (double)(width / 2.0F));
            double d2 = entity.locZ - locZ;
            if(attackTicks == 0)
            {
                g++;
                if(g == 1)
                {
                    attackTicks = 60;
                    a(true);
                } else
                if(g <= 4)
                {
                    attackTicks = 6;
                } else
                {
                    attackTicks = 100;
                    g = 0;
                    a(false);
                }
                if(g > 1)
                {
                    float f1 = MathHelper.c(f) * 0.5F;
                    world.a((EntityHuman)null, 1009, (int)locX, (int)locY, (int)locZ, 0);
                    for(int i = 0; i < 1; i++)
                    {
                        EntitySmallFireball entitysmallfireball = new EntitySmallFireball(world, this, d0 + random.nextGaussian() * (double)f1, d1, d2 + random.nextGaussian() * (double)f1);
                        entitysmallfireball.locY = locY + (double)(width / 2.0F) + 0.5D;
                        world.addEntity(entitysmallfireball);
                    }

                }
            }
            yaw = (float)((Math.atan2(d2, d0) * 180D) / 3.1415927410125732D) - 90F;
            e = true;
        }
    }

    protected void b(float f1)
    {
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int e()
    {
        return Item.BLAZE_ROD.id;
    }

    public boolean z()
    {
        return A();
    }

    protected void a(boolean flag, int i)
    {
        if(flag)
        {
            List loot = new ArrayList();
            int j = random.nextInt(2 + i);
            if(j > 0)
                loot.add(new ItemStack(Item.BLAZE_ROD.id, j));
            CraftEventFactory.callEntityDeathEvent(this, loot);
        }
    }

    public boolean A()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    public void a(boolean flag)
    {
        byte b0 = datawatcher.getByte(16);
        if(flag)
            b0 |= 1;
        else
            b0 &= 0xfe;
        datawatcher.watch(16, Byte.valueOf(b0));
    }

    protected boolean y()
    {
        return true;
    }

    private float a;
    private int b;
    private int g;
}
