// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BiomeBase, BiomeDecorator, WorldGenerator

public class BiomeSwamp extends BiomeBase
{

    protected BiomeSwamp(int i)
    {
        super(i);
        B.z = 2;
        B.A = -999;
        B.C = 1;
        B.D = 8;
        B.E = 10;
        B.I = 1;
        B.y = 4;
        A = 0xe0ff70;
    }

    public WorldGenerator a(Random random)
    {
        return J;
    }
}
