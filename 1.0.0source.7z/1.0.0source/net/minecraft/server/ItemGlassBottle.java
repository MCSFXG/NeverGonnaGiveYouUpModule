// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, MovingObjectPosition, EnumMovingObjectType, World, 
//            EntityHuman, Material, ItemStack, InventoryPlayer, 
//            ItemPotion

public class ItemGlassBottle extends Item
{

    public ItemGlassBottle(int i)
    {
        super(i);
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        MovingObjectPosition movingobjectposition = a(world, entityhuman, true);
        if(movingobjectposition == null)
            return itemstack;
        if(movingobjectposition.type == EnumMovingObjectType.TILE)
        {
            int i = movingobjectposition.b;
            int j = movingobjectposition.c;
            int k = movingobjectposition.d;
            if(!world.a(entityhuman, i, j, k))
                return itemstack;
            if(!entityhuman.d(i, j, k))
                return itemstack;
            if(world.getMaterial(i, j, k) == Material.WATER)
            {
                itemstack.count--;
                if(itemstack.count <= 0)
                    return new ItemStack(Item.POTION);
                if(!entityhuman.inventory.pickup(new ItemStack(Item.POTION)))
                    entityhuman.b(new ItemStack(Item.POTION.id, 1, 0));
            }
        }
        return itemstack;
    }
}
