// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.awt.*;
import java.text.DecimalFormat;
import javax.swing.JComponent;
import javax.swing.Timer;

// Referenced classes of package net.minecraft.server:
//            GuiStatsListener, NetworkManager, MinecraftServer

public class GuiStatsComponent extends JComponent
{

    public GuiStatsComponent(MinecraftServer minecraftserver)
    {
        b = new int[256];
        c = 0;
        d = new String[10];
        e = minecraftserver;
        setPreferredSize(new Dimension(256, 226));
        setMinimumSize(new Dimension(256, 226));
        setMaximumSize(new Dimension(256, 226));
        (new Timer(500, new GuiStatsListener(this))).start();
        setBackground(Color.BLACK);
    }

    private void a()
    {
        long l = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.gc();
        d[0] = (new StringBuilder()).append("Memory use: ").append(l / 1024L / 1024L).append(" mb (").append((Runtime.getRuntime().freeMemory() * 100L) / Runtime.getRuntime().maxMemory()).append("% free)").toString();
        d[1] = (new StringBuilder()).append("Threads: ").append(NetworkManager.b).append(" + ").append(NetworkManager.c).toString();
        d[2] = (new StringBuilder()).append("Avg tick: ").append(a.format(a(e.f) * 9.9999999999999995E-007D)).append(" ms").toString();
        for(int i = 0; i < e.worldServer.length; i++)
            d[3 + i] = (new StringBuilder()).append("Lvl ").append(i).append(" tick: ").append(a.format(a(e.g[i]) * 9.9999999999999995E-007D)).append(" ms").toString();

        b[c++ & 0xff] = (int)((l * 100L) / Runtime.getRuntime().maxMemory());
        repaint();
    }

    private double a(long al[])
    {
        long l = 0L;
        for(int i = 0; i < al.length; i++)
            l += al[i];

        return (double)l / (double)al.length;
    }

    public void paint(Graphics g)
    {
        g.setColor(new Color(0xffffff));
        g.fillRect(0, 0, 256, 226);
        for(int i = 0; i < 256; i++)
        {
            int k = b[i + c & 0xff];
            g.setColor(new Color(k + 28 << 16));
            g.fillRect(i, 100 - k, 1, k);
        }

        g.setColor(Color.BLACK);
        for(int j = 0; j < d.length; j++)
        {
            String s = d[j];
            if(s != null)
                g.drawString(s, 32, 116 + j * 16);
        }

    }

    static void a(GuiStatsComponent guistatscomponent)
    {
        guistatscomponent.a();
    }

    private static final DecimalFormat a = new DecimalFormat("########0.000");
    private int b[];
    private int c;
    private String d[];
    private final MinecraftServer e;

}
