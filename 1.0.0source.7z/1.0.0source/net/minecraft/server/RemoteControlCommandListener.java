// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ICommandListener

public class RemoteControlCommandListener
    implements ICommandListener
{

    public RemoteControlCommandListener()
    {
        b = new StringBuffer();
    }

    public void a()
    {
        b.setLength(0);
    }

    public String b()
    {
        return b.toString();
    }

    public void sendMessage(String s)
    {
        b.append(s);
    }

    public String getName()
    {
        return "Rcon";
    }

    public static final RemoteControlCommandListener a = new RemoteControlCommandListener();
    private StringBuffer b;

}
