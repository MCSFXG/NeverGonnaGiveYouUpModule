// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            GenLayer, IntCache, BiomeBase

public class GenLayerIcePlains extends GenLayer
{

    public GenLayerIcePlains(long l, GenLayer genlayer)
    {
        super(l);
        a = genlayer;
    }

    public int[] a(int i, int j, int k, int l)
    {
        int i1 = i - 1;
        int j1 = j - 1;
        int k1 = k + 2;
        int l1 = l + 2;
        int ai[] = a.a(i1, j1, k1, l1);
        int ai1[] = IntCache.a(k * l);
        for(int i2 = 0; i2 < l; i2++)
        {
            for(int j2 = 0; j2 < k; j2++)
            {
                int k2 = ai[j2 + 1 + (i2 + 1) * k1];
                a(j2 + i, i2 + j);
                if(k2 == 0)
                {
                    ai1[j2 + i2 * k] = 0;
                    continue;
                }
                int l2 = a(5);
                if(l2 == 0)
                    l2 = BiomeBase.ICE_PLAINS.F;
                else
                    l2 = 1;
                ai1[j2 + i2 * k] = l2;
            }

        }

        return ai1;
    }
}
