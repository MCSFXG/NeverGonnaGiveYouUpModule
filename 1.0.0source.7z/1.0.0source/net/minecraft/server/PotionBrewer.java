// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            MobEffect, MobEffectList

public class PotionBrewer
{

    public PotionBrewer()
    {
    }

    public static boolean a(int l, int i1)
    {
        return (l & 1 << i1) != 0;
    }

    private static int b(int l, int i1)
    {
        return a(l, i1) ? 1 : 0;
    }

    private static int c(int l, int i1)
    {
        return a(l, i1) ? 0 : 1;
    }

    public static int a(Collection collection)
    {
        int l = 0x385dc6;
        if(collection == null || collection.isEmpty())
            return l;
        float f1 = 0.0F;
        float f2 = 0.0F;
        float f3 = 0.0F;
        float f4 = 0.0F;
        for(Iterator iterator = collection.iterator(); iterator.hasNext();)
        {
            MobEffect mobeffect = (MobEffect)iterator.next();
            int i1 = MobEffectList.byId[mobeffect.getEffectId()].g();
            int j1 = 0;
            while(j1 <= mobeffect.getAmplifier()) 
            {
                f1 += (float)(i1 >> 16 & 0xff) / 255F;
                f2 += (float)(i1 >> 8 & 0xff) / 255F;
                f3 += (float)(i1 >> 0 & 0xff) / 255F;
                f4++;
                j1++;
            }
        }

        f1 = (f1 / f4) * 255F;
        f2 = (f2 / f4) * 255F;
        f3 = (f3 / f4) * 255F;
        return (int)f1 << 16 | (int)f2 << 8 | (int)f3;
    }

    private static int a(boolean flag, boolean flag1, boolean flag2, int l, int i1, int j1, int k1)
    {
        int l1 = 0;
        if(flag)
            l1 = c(k1, i1);
        else
        if(l != -1)
        {
            if(l == 0 && a(k1) == i1)
                l1 = 1;
            else
            if(l == 1 && a(k1) > i1)
                l1 = 1;
            else
            if(l == 2 && a(k1) < i1)
                l1 = 1;
        } else
        {
            l1 = b(k1, i1);
        }
        if(flag1)
            l1 *= j1;
        if(flag2)
            l1 *= -1;
        return l1;
    }

    private static int a(int l)
    {
        int i1;
        for(i1 = 0; l > 0; i1++)
            l &= l - 1;

        return i1;
    }

    private static int a(String s, int l, int i1, int j1)
    {
        if(l >= s.length() || i1 < 0 || l >= i1)
            return 0;
        int k1 = s.indexOf('|', l);
        if(k1 >= 0 && k1 < i1)
        {
            int l1 = a(s, l, k1 - 1, j1);
            if(l1 > 0)
                return l1;
            int j2 = a(s, k1 + 1, i1, j1);
            if(j2 > 0)
                return j2;
            else
                return 0;
        }
        int i2 = s.indexOf('&', l);
        if(i2 >= 0 && i2 < i1)
        {
            int k2 = a(s, l, i2 - 1, j1);
            if(k2 <= 0)
                return 0;
            int l2 = a(s, i2 + 1, i1, j1);
            if(l2 <= 0)
                return 0;
            if(k2 > l2)
                return k2;
            else
                return l2;
        }
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        boolean flag4 = false;
        byte byte0 = -1;
        int i3 = 0;
        int j3 = 0;
        int k3 = 0;
        for(int l3 = l; l3 < i1; l3++)
        {
            char c1 = s.charAt(l3);
            if(c1 >= '0' && c1 <= '9')
            {
                if(flag)
                {
                    j3 = c1 - 48;
                    flag1 = true;
                } else
                {
                    i3 *= 10;
                    i3 += c1 - 48;
                    flag2 = true;
                }
                continue;
            }
            if(c1 == '*')
            {
                flag = true;
                continue;
            }
            if(c1 == '!')
            {
                if(flag2)
                {
                    k3 += a(flag3, flag1, flag4, byte0, i3, j3, j1);
                    flag2 = flag1 = flag = flag4 = flag3 = false;
                    i3 = j3 = 0;
                    byte0 = -1;
                }
                flag3 = true;
                continue;
            }
            if(c1 == '-')
            {
                if(flag2)
                {
                    k3 += a(flag3, flag1, flag4, byte0, i3, j3, j1);
                    flag2 = flag1 = flag = flag4 = flag3 = false;
                    i3 = j3 = 0;
                    byte0 = -1;
                }
                flag4 = true;
                continue;
            }
            if(c1 == '=' || c1 == '<' || c1 == '>')
            {
                if(flag2)
                {
                    k3 += a(flag3, flag1, flag4, byte0, i3, j3, j1);
                    flag2 = flag1 = flag = flag4 = flag3 = false;
                    i3 = j3 = 0;
                    byte0 = -1;
                }
                if(c1 == '=')
                {
                    byte0 = 0;
                    continue;
                }
                if(c1 == '<')
                {
                    byte0 = 2;
                    continue;
                }
                if(c1 == '>')
                    byte0 = 1;
                continue;
            }
            if(c1 == '+' && flag2)
            {
                k3 += a(flag3, flag1, flag4, byte0, i3, j3, j1);
                flag2 = flag1 = flag = flag4 = flag3 = false;
                i3 = j3 = 0;
                byte0 = -1;
            }
        }

        if(flag2)
            k3 += a(flag3, flag1, flag4, byte0, i3, j3, j1);
        return k3;
    }

    public static List a(int l, boolean flag)
    {
        ArrayList arraylist = null;
        MobEffectList amobeffectlist[] = MobEffectList.byId;
        int i1 = amobeffectlist.length;
        for(int j1 = 0; j1 < i1; j1++)
        {
            MobEffectList mobeffectlist = amobeffectlist[j1];
            if(mobeffectlist == null || mobeffectlist.f() && !flag)
                continue;
            String s = (String)effectDurations.get(Integer.valueOf(mobeffectlist.getId()));
            if(s == null)
                continue;
            int k1 = a(s, 0, s.length(), l);
            if(k1 <= 0)
                continue;
            int l1 = 0;
            String s1 = (String)effectAmplifiers.get(Integer.valueOf(mobeffectlist.getId()));
            if(s1 != null)
            {
                l1 = a(s1, 0, s1.length(), l);
                if(l1 < 0)
                    l1 = 0;
            }
            if(mobeffectlist.b())
            {
                k1 = 1;
            } else
            {
                k1 = 1200 * (k1 * 3 + (k1 - 1) * 2);
                k1 >>= l1;
                k1 = (int)Math.round((double)k1 * mobeffectlist.d());
                if((l & 0x4000) != 0)
                    k1 = (int)Math.round((double)k1 * 0.75D + 0.5D);
            }
            if(arraylist == null)
                arraylist = new ArrayList();
            arraylist.add(new MobEffect(mobeffectlist.getId(), k1, l1));
        }

        return arraylist;
    }

    private static int a(int l, int i1, boolean flag, boolean flag1, boolean flag2)
    {
        if(flag2)
        {
            if(!a(l, i1))
                return 0;
        } else
        if(flag)
            l &= ~(1 << i1);
        else
        if(flag1)
        {
            if((l & 1 << i1) != 0)
                l &= ~(1 << i1);
            else
                l |= 1 << i1;
        } else
        {
            l |= 1 << i1;
        }
        return l;
    }

    public static int a(int l, String s)
    {
        boolean flag = false;
        int i1 = s.length();
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        boolean flag4 = false;
        int j1 = 0;
        for(int k1 = ((flag) ? 1 : 0); k1 < i1; k1++)
        {
            char c1 = s.charAt(k1);
            if(c1 >= '0' && c1 <= '9')
            {
                j1 *= 10;
                j1 += c1 - 48;
                flag1 = true;
                continue;
            }
            if(c1 == '!')
            {
                if(flag1)
                {
                    l = a(l, j1, flag3, flag2, flag4);
                    flag1 = flag3 = flag2 = flag4 = false;
                    j1 = 0;
                }
                flag2 = true;
                continue;
            }
            if(c1 == '-')
            {
                if(flag1)
                {
                    l = a(l, j1, flag3, flag2, flag4);
                    flag1 = flag3 = flag2 = flag4 = false;
                    j1 = 0;
                }
                flag3 = true;
                continue;
            }
            if(c1 == '+')
            {
                if(flag1)
                {
                    l = a(l, j1, flag3, flag2, flag4);
                    flag1 = flag3 = flag2 = flag4 = false;
                    j1 = 0;
                }
                continue;
            }
            if(c1 != '&')
                continue;
            if(flag1)
            {
                l = a(l, j1, flag3, flag2, flag4);
                flag1 = flag3 = flag2 = flag4 = false;
                j1 = 0;
            }
            flag4 = true;
        }

        if(flag1)
            l = a(l, j1, flag3, flag2, flag4);
        return l & 0x7fff;
    }

    public static final String a = null;
    public static final String b = "-0+1-2-3&4-4+13";
    public static final String c = "+0-1-2-3&4-4+13";
    public static final String d = "-0-1+2-3&4-4+13";
    public static final String e = "-0+3-4+13";
    public static final String f = "+0-1+2-3&4-4+13";
    public static final String g = "+0-1-2+3&4-4+13";
    public static final String h = "+0+1-2-3&4-4+13";
    public static final String i = "-5+6-7";
    public static final String j = "+5-6-7";
    public static final String k = "+14&13-13";
    private static final HashMap effectDurations;
    private static final HashMap effectAmplifiers;
    private static final HashMap n = new HashMap();
    private static final String appearances[] = {
        "potion.prefix.mundane", "potion.prefix.uninteresting", "potion.prefix.bland", "potion.prefix.clear", "potion.prefix.milky", "potion.prefix.diffuse", "potion.prefix.artless", "potion.prefix.thin", "potion.prefix.awkward", "potion.prefix.flat", 
        "potion.prefix.bulky", "potion.prefix.bungling", "potion.prefix.buttered", "potion.prefix.smooth", "potion.prefix.suave", "potion.prefix.debonair", "potion.prefix.thick", "potion.prefix.elegant", "potion.prefix.fancy", "potion.prefix.charming", 
        "potion.prefix.dashing", "potion.prefix.refined", "potion.prefix.cordial", "potion.prefix.sparkling", "potion.prefix.potent", "potion.prefix.foul", "potion.prefix.odorless", "potion.prefix.rank", "potion.prefix.harsh", "potion.prefix.acrid", 
        "potion.prefix.gross", "potion.prefix.stinky"
    };

    static 
    {
        effectDurations = new HashMap();
        effectAmplifiers = new HashMap();
        effectDurations.put(Integer.valueOf(MobEffectList.REGENERATION.getId()), "0 & !1 & !2 & !3 & 0+6");
        effectDurations.put(Integer.valueOf(MobEffectList.FASTER_MOVEMENT.getId()), "!0 & 1 & !2 & !3 & 1+6");
        effectDurations.put(Integer.valueOf(MobEffectList.FIRE_RESISTANCE.getId()), "0 & 1 & !2 & !3 & 0+6");
        effectDurations.put(Integer.valueOf(MobEffectList.HEAL.getId()), "0 & !1 & 2 & !3");
        effectDurations.put(Integer.valueOf(MobEffectList.POISON.getId()), "!0 & !1 & 2 & !3 & 2+6");
        effectDurations.put(Integer.valueOf(MobEffectList.WEAKNESS.getId()), "!0 & !1 & !2 & 3 & 3+6");
        effectDurations.put(Integer.valueOf(MobEffectList.HARM.getId()), "!0 & !1 & 2 & 3");
        effectDurations.put(Integer.valueOf(MobEffectList.SLOWER_MOVEMENT.getId()), "!0 & 1 & !2 & 3 & 3+6");
        effectDurations.put(Integer.valueOf(MobEffectList.INCREASE_DAMAGE.getId()), "0 & !1 & !2 & 3 & 3+6");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.FASTER_MOVEMENT.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.FASTER_DIG.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.INCREASE_DAMAGE.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.REGENERATION.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.HARM.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.HEAL.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.RESISTANCE.getId()), "5");
        effectAmplifiers.put(Integer.valueOf(MobEffectList.POISON.getId()), "5");
    }
}
