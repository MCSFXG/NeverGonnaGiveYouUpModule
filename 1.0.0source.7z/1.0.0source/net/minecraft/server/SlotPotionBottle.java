// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Slot, ItemStack, Item, ItemPotion, 
//            AchievementList, EntityHuman, ContainerBrewingStand, IInventory

class SlotPotionBottle extends Slot
{

    public SlotPotionBottle(ContainerBrewingStand containerbrewingstand, EntityHuman entityhuman, IInventory iinventory, int i, int j, int k)
    {
        a = containerbrewingstand;
        super(iinventory, i, j, k);
        f = entityhuman;
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        return itemstack != null && (itemstack.id == Item.POTION.id || itemstack.id == Item.GLASS_BOTTLE.id);
    }

    public int a()
    {
        return 1;
    }

    public void b(ItemStack itemstack)
    {
        if(itemstack.id == Item.POTION.id && itemstack.getData() > 0)
            f.a(AchievementList.A, 1);
        super.b(itemstack);
    }

    private EntityHuman f;
    final ContainerBrewingStand a;
}
