// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            TileEntity, IInventory, ItemStack, World, 
//            Item, ItemPotion, PotionBrewer, NBTTagCompound, 
//            NBTTagList, EntityHuman

public class TileEntityBrewingStand extends TileEntity
    implements IInventory
{

    public TileEntityBrewingStand()
    {
        a = new ItemStack[4];
    }

    public String getName()
    {
        return "Brewing Stand";
    }

    public int getSize()
    {
        return a.length;
    }

    public void l_()
    {
        if(b > 0)
        {
            b--;
            if(b == 0)
            {
                p();
                update();
            } else
            if(!o())
            {
                b = 0;
                update();
            } else
            if(d != a[3].id)
            {
                b = 0;
                update();
            }
        } else
        if(o())
        {
            b = 600;
            d = a[3].id;
        }
        int i = n();
        if(i != c)
        {
            c = i;
            world.setData(x, y, z, i);
        }
        super.l_();
    }

    public int h()
    {
        return b;
    }

    private boolean o()
    {
        if(a[3] == null || a[3].count <= 0)
            return false;
        ItemStack itemstack = a[3];
        if(!Item.byId[itemstack.id].m())
            return false;
        boolean flag = false;
        for(int i = 0; i < 3; i++)
        {
            if(a[i] == null || a[i].id != Item.POTION.id)
                continue;
            int j = a[i].getData();
            int k = b(j, itemstack);
            if(!ItemPotion.c(j) && ItemPotion.c(k))
            {
                flag = true;
                break;
            }
            java.util.List list = Item.POTION.b(j);
            java.util.List list1 = Item.POTION.b(k);
            if(j > 0 && list == list1 || list != null && (list.equals(list1) || list1 == null) || j == k)
                continue;
            flag = true;
            break;
        }

        return flag;
    }

    private void p()
    {
        if(!o())
            return;
        ItemStack itemstack = a[3];
        for(int i = 0; i < 3; i++)
        {
            if(a[i] == null || a[i].id != Item.POTION.id)
                continue;
            int j = a[i].getData();
            int k = b(j, itemstack);
            java.util.List list = Item.POTION.b(j);
            java.util.List list1 = Item.POTION.b(k);
            if(j > 0 && list == list1 || list != null && (list.equals(list1) || list1 == null))
            {
                if(!ItemPotion.c(j) && ItemPotion.c(k))
                    a[i].b(k);
                continue;
            }
            if(j != k)
                a[i].b(k);
        }

        if(Item.byId[itemstack.id].j())
        {
            a[3] = new ItemStack(Item.byId[itemstack.id].i());
        } else
        {
            a[3].count--;
            if(a[3].count <= 0)
                a[3] = null;
        }
    }

    private int b(int i, ItemStack itemstack)
    {
        if(itemstack == null)
            return i;
        if(Item.byId[itemstack.id].m())
            return PotionBrewer.a(i, Item.byId[itemstack.id].l());
        else
            return i;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.m("Items");
        a = new ItemStack[getSize()];
        for(int i = 0; i < nbttaglist.d(); i++)
        {
            NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.a(i);
            byte byte0 = nbttagcompound1.d("Slot");
            if(byte0 >= 0 && byte0 < a.length)
                a[byte0] = ItemStack.a(nbttagcompound1);
        }

        b = nbttagcompound.e("BrewTime");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("BrewTime", (short)b);
        NBTTagList nbttaglist = new NBTTagList();
        for(int i = 0; i < a.length; i++)
            if(a[i] != null)
            {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.a("Slot", (byte)i);
                a[i].b(nbttagcompound1);
                nbttaglist.a(nbttagcompound1);
            }

        nbttagcompound.a("Items", nbttaglist);
    }

    public ItemStack getItem(int i)
    {
        if(i >= 0 && i < a.length)
            return a[i];
        else
            return null;
    }

    public ItemStack splitStack(int i, int j)
    {
        if(i >= 0 && i < a.length)
        {
            ItemStack itemstack = a[i];
            a[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        if(i >= 0 && i < a.length)
            a[i] = itemstack;
    }

    public int getMaxStackSize()
    {
        return 1;
    }

    public boolean a(EntityHuman entityhuman)
    {
        if(world.getTileEntity(x, y, z) != this)
            return false;
        return entityhuman.e((double)x + 0.5D, (double)y + 0.5D, (double)z + 0.5D) <= 64D;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    public int n()
    {
        int i = 0;
        for(int j = 0; j < 3; j++)
            if(a[j] != null)
                i |= 1 << j;

        return i;
    }

    private ItemStack a[];
    private int b;
    private int c;
    private int d;
}
