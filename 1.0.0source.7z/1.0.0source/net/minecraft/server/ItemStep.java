// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemBlock, ItemStack, BlockStep, EntityHuman, 
//            World, Block, StepSound

public class ItemStep extends ItemBlock
{

    public ItemStep(int i)
    {
        super(i);
        f(0);
        a(true);
    }

    public int filterData(int i)
    {
        return i;
    }

    public String a(ItemStack itemstack)
    {
        int i = itemstack.getData();
        if(i < 0 || i >= BlockStep.a.length)
            i = 0;
        return (new StringBuilder()).append(super.b()).append(".").append(BlockStep.a[i]).toString();
    }

    public boolean a(ItemStack itemstack, EntityHuman entityhuman, World world, int i, int j, int k, int l)
    {
        if(l == 1);
        if(itemstack.count == 0)
            return false;
        if(!entityhuman.d(i, j, k))
            return false;
        int i1 = world.getTypeId(i, j, k);
        int j1 = world.getData(i, j, k);
        if(l == 1 && i1 == Block.STEP.id && j1 == itemstack.getData())
        {
            if(world.setTypeIdAndData(i, j, k, Block.DOUBLE_STEP.id, j1))
            {
                world.makeSound((float)i + 0.5F, (float)j + 0.5F, (float)k + 0.5F, Block.DOUBLE_STEP.stepSound.getName(), (Block.DOUBLE_STEP.stepSound.getVolume1() + 1.0F) / 2.0F, Block.DOUBLE_STEP.stepSound.getVolume2() * 0.8F);
                itemstack.count--;
            }
            return true;
        } else
        {
            return super.a(itemstack, entityhuman, world, i, j, k, l);
        }
    }
}
