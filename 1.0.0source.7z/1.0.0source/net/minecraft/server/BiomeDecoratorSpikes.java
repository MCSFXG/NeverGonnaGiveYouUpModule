// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BiomeDecorator, WorldGenEnder, Block, World, 
//            WorldGenerator, EntityEnderDragon, BiomeBase

public class BiomeDecoratorSpikes extends BiomeDecorator
{

    public BiomeDecoratorSpikes(BiomeBase biomebase)
    {
        super(biomebase);
        L = new WorldGenEnder(Block.WHITESTONE.id);
    }

    protected void a()
    {
        b();
        if(b.nextInt(5) == 0)
        {
            int i = c + b.nextInt(16) + 8;
            int j = d + b.nextInt(16) + 8;
            int k = a.f(i, j);
            if(k <= 0);
            L.a(a, b, i, k, j);
        }
        if(c == 0 && d == 0)
        {
            EntityEnderDragon entityenderdragon = new EntityEnderDragon(a);
            entityenderdragon.setPositionRotation(0.0D, 128D, 0.0D, b.nextFloat() * 360F, 0.0F);
            a.addEntity(entityenderdragon);
        }
    }

    protected WorldGenerator L;
}
