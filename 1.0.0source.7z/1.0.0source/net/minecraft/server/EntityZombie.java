// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityZombie.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, World, MathHelper, Item, 
//            EnchantmentDamage

public class EntityZombie extends EntityMonster
{

    public EntityZombie(World world)
    {
        super(world);
        texture = "/mob/zombie.png";
        aY = 0.5F;
        damage = 4;
    }

    public int getMaxHealth()
    {
        return 20;
    }

    protected int O()
    {
        return 2;
    }

    public void d()
    {
        if(world.e() && !world.isStatic)
        {
            float f = a(1.0F);
            if(f > 0.5F && world.isChunkLoaded(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) && random.nextFloat() * 30F < (f - 0.4F) * 2.0F)
            {
                EntityCombustEvent event = new EntityCombustEvent(getBukkitEntity());
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    j(8);
            }
        }
        super.d();
    }

    protected String c_()
    {
        return "mob.zombie";
    }

    protected String m()
    {
        return "mob.zombiehurt";
    }

    protected String n()
    {
        return "mob.zombiedeath";
    }

    protected int e()
    {
        return Item.ROTTEN_FLESH.id;
    }

    public EnchantmentDamage t()
    {
        return EnchantmentDamage.b;
    }
}
