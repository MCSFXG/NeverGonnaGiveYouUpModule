// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            IMinecraftServer

public abstract class RemoteConnectionThread
    implements Runnable
{

    RemoteConnectionThread(IMinecraftServer iminecraftserver)
    {
        running = false;
        d = 5;
        e = new ArrayList();
        f = new ArrayList();
        server = iminecraftserver;
        if(server.isDebugging())
            warning("Debugging is enabled, performance maybe reduced!");
    }

    public synchronized void a()
    {
        thread = new Thread(this);
        thread.start();
        running = true;
    }

    public boolean b()
    {
        return running;
    }

    protected void debug(String s)
    {
        server.debug(s);
    }

    protected void info(String s)
    {
        server.sendMessage(s);
    }

    protected void warning(String s)
    {
        server.warning(s);
    }

    protected void error(String s)
    {
        server.severe(s);
    }

    protected int c()
    {
        return server.getPlayerCount();
    }

    protected void a(DatagramSocket datagramsocket)
    {
        debug((new StringBuilder()).append("registerSocket: ").append(datagramsocket).toString());
        e.add(datagramsocket);
    }

    protected boolean a(DatagramSocket datagramsocket, boolean flag)
    {
        debug((new StringBuilder()).append("closeSocket: ").append(datagramsocket).toString());
        if(null == datagramsocket)
            return false;
        boolean flag1 = false;
        if(!datagramsocket.isClosed())
        {
            datagramsocket.close();
            flag1 = true;
        }
        if(flag)
            e.remove(datagramsocket);
        return flag1;
    }

    protected boolean a(ServerSocket serversocket)
    {
        return a(serversocket, true);
    }

    protected boolean a(ServerSocket serversocket, boolean flag)
    {
        debug((new StringBuilder()).append("closeSocket: ").append(serversocket).toString());
        if(null == serversocket)
            return false;
        boolean flag1 = false;
        try
        {
            if(!serversocket.isClosed())
            {
                serversocket.close();
                flag1 = true;
            }
        }
        catch(IOException ioexception)
        {
            warning((new StringBuilder()).append("IO: ").append(ioexception.getMessage()).toString());
        }
        if(flag)
            f.remove(serversocket);
        return flag1;
    }

    protected void d()
    {
        a(false);
    }

    protected void a(boolean flag)
    {
        int i = 0;
        Iterator iterator = e.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            DatagramSocket datagramsocket = (DatagramSocket)iterator.next();
            if(a(datagramsocket, false))
                i++;
        } while(true);
        e.clear();
        iterator = f.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            ServerSocket serversocket = (ServerSocket)iterator.next();
            if(a(serversocket, false))
                i++;
        } while(true);
        f.clear();
        if(flag && 0 < i)
            warning((new StringBuilder()).append("Force closed ").append(i).append(" sockets").toString());
    }

    protected boolean running;
    protected IMinecraftServer server;
    protected Thread thread;
    protected int d;
    protected List e;
    protected List f;
}
