// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagByteArray extends NBTBase
{

    public NBTTagByteArray(String s)
    {
        super(s);
    }

    public NBTTagByteArray(String s, byte abyte0[])
    {
        super(s);
        a = abyte0;
    }

    void a(DataOutput dataoutput)
    {
        dataoutput.writeInt(a.length);
        dataoutput.write(a);
    }

    void a(DataInput datainput)
    {
        int i = datainput.readInt();
        a = new byte[i];
        datainput.readFully(a);
    }

    public byte a()
    {
        return 7;
    }

    public String toString()
    {
        return (new StringBuilder()).append("[").append(a.length).append(" bytes]").toString();
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagByteArray nbttagbytearray = (NBTTagByteArray)obj;
            return a == null && nbttagbytearray.a == null || a != null && a.equals(nbttagbytearray.a);
        } else
        {
            return false;
        }
    }

    public NBTBase b()
    {
        byte abyte0[] = new byte[a.length];
        System.arraycopy(a, 0, abyte0, 0, a.length);
        return new NBTTagByteArray(c(), abyte0);
    }

    public byte a[];
}
