// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   World.java

package net.minecraft.server;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.block.BlockCanBuildEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            WorldServer, WorldMapCollection, WorldData, ChunkProviderLoadOrGenerate, 
//            IWorldAccess, EntityHuman, EntityLiving, EntityPlayer, 
//            EntityAnimal, EntityWaterAnimal, EntityMonster, EntityGhast, 
//            EntitySlime, EntityItem, Entity, NextTickListEntry, 
//            TileEntity, Explosion, IProgressUpdate, ChunkCoordIntPair, 
//            EntityWeatherStorm, ChunkCache, Pathfinder, ChunkCoordinates, 
//            BiomeMeta, IBlockAccess, WorldProvider, IDataManager, 
//            WorldChunkManager, ChunkPosition, IChunkProvider, Chunk, 
//            Material, Block, EnumSkyBlock, Vec3D, 
//            MathHelper, AxisAlignedBB, BlockFire, BlockFluids, 
//            ServerConfigurationManager, SpawnerCreature, PlayerAbilities, BiomeBase, 
//            WeightedRandom, WorldSettings, MovingObjectPosition, PathEntity, 
//            WorldMapBase, EnumCreatureType

public class World
    implements IBlockAccess
{

    public WorldChunkManager getWorldChunkManager()
    {
        return worldProvider.b;
    }

    private boolean canSpawn(int x, int z)
    {
        if(generator != null)
            return generator.canSpawn(getWorld(), x, z);
        else
            return worldProvider.canSpawn(x, z);
    }

    public CraftWorld getWorld()
    {
        return world;
    }

    public CraftServer getServer()
    {
        return (CraftServer)Bukkit.getServer();
    }

    public World(IDataManager idatamanager, String s, WorldSettings worldsettings, WorldProvider worldprovider, ChunkGenerator gen, org.bukkit.Environment env)
    {
        heightBits = 7;
        keepSpawnInMemory = true;
        lastXAccessed = 0x80000000;
        lastZAccessed = 0x80000000;
        generator = gen;
        world = new CraftWorld((WorldServer)this, gen, env);
        heightBitsPlusFour = heightBits + 4;
        height = 1 << heightBits;
        heightMinusOne = height - 1;
        seaLevel = height / 2 - 1;
        f = false;
        entityList = new ArrayList();
        J = new ArrayList();
        K = new TreeSet();
        L = new HashSet();
        h = new ArrayList();
        M = new ArrayList();
        N = new ArrayList();
        players = new ArrayList();
        j = new ArrayList();
        O = 0xffffffL;
        k = 0;
        l = (new Random()).nextInt();
        r = 0;
        this.s = 0;
        suppressPhysics = false;
        P = System.currentTimeMillis();
        u = 40;
        random = new Random();
        x = false;
        z = new ArrayList();
        R = new ArrayList();
        allowMonsters = true;
        allowAnimals = true;
        T = new HashSet();
        U = random.nextInt(12000);
        H = new int[32768];
        V = new ArrayList();
        isStatic = false;
        B = idatamanager;
        worldMaps = new WorldMapCollection(idatamanager);
        worldData = idatamanager.c();
        x = worldData == null;
        if(worldprovider != null)
            worldProvider = worldprovider;
        else
        if(worldData != null && worldData.h() != 0)
            worldProvider = WorldProvider.byDimension(worldData.h());
        else
            worldProvider = WorldProvider.byDimension(0);
        boolean flag = false;
        if(worldData == null)
        {
            worldData = new WorldData(worldsettings, s);
            flag = true;
        } else
        {
            worldData.a(s);
        }
        worldProvider.a(this);
        chunkProvider = b();
        if(flag)
            c();
        g();
        z();
        getServer().addWorld(world);
    }

    protected IChunkProvider b()
    {
        IChunkLoader ichunkloader = B.a(worldProvider);
        return new ChunkProviderLoadOrGenerate(this, ichunkloader, worldProvider.getChunkProvider());
    }

    protected void c()
    {
        isLoading = true;
        WorldChunkManager worldchunkmanager = getWorldChunkManager();
        List list = worldchunkmanager.a();
        Random random = new Random(getSeed());
        ChunkPosition chunkposition = worldchunkmanager.a(0, 0, 256, list, random);
        int i = 0;
        int j = height / 2;
        int k = 0;
        if(generator != null)
        {
            Random rand = new Random(getSeed());
            Location spawn = generator.getFixedSpawnLocation(((WorldServer)this).getWorld(), rand);
            if(spawn != null)
                if(spawn.getWorld() != ((WorldServer)this).getWorld())
                {
                    throw new IllegalStateException((new StringBuilder()).append("Cannot set spawn point for ").append(worldData.name).append(" to be in another world (").append(spawn.getWorld().getName()).append(")").toString());
                } else
                {
                    worldData.setSpawn(spawn.getBlockX(), spawn.getBlockY(), spawn.getBlockZ());
                    isLoading = false;
                    return;
                }
        }
        if(chunkposition != null)
        {
            i = chunkposition.x;
            k = chunkposition.z;
        } else
        {
            System.out.println("Unable to find spawn biome");
        }
        int l = 0;
        do
        {
            if(canSpawn(i, k))
                break;
            i += random.nextInt(64) - random.nextInt(64);
            k += random.nextInt(64) - random.nextInt(64);
        } while(++l != 1000);
        worldData.setSpawn(i, j, k);
        isLoading = false;
    }

    public ChunkCoordinates d()
    {
        return worldProvider.d();
    }

    public int a(int i, int j)
    {
        int k;
        for(k = seaLevel; !isEmpty(i, k + 1, j); k++);
        return getTypeId(i, k, j);
    }

    public void save(boolean flag, IProgressUpdate iprogressupdate)
    {
        if(chunkProvider.canSave())
        {
            if(iprogressupdate != null)
                iprogressupdate.a("Saving level");
            y();
            if(iprogressupdate != null)
                iprogressupdate.b("Saving chunks");
            chunkProvider.saveChunks(flag, iprogressupdate);
        }
    }

    private void y()
    {
        l();
        B.a(worldData, players);
        worldMaps.a();
    }

    public int getTypeId(int i, int j, int k)
    {
        return i < 0xfe363c80 || k < 0xfe363c80 || i >= 0x1c9c380 || k >= 0x1c9c380 ? 0 : j >= 0 ? j < height ? getChunkAt(i >> 4, k >> 4).getTypeId(i & 0xf, j, k & 0xf) : 0 : 0;
    }

    public boolean isEmpty(int i, int j, int k)
    {
        return getTypeId(i, j, k) == 0;
    }

    public boolean isLoaded(int i, int j, int k)
    {
        return j < 0 || j >= height ? false : isChunkLoaded(i >> 4, k >> 4);
    }

    public boolean areChunksLoaded(int i, int j, int k, int l)
    {
        return a(i - l, j - l, k - l, i + l, j + l, k + l);
    }

    public boolean a(int i, int j, int k, int l, int i1, int j1)
    {
        if(i1 >= 0 && j < height)
        {
            i >>= 4;
            j >>= 4;
            k >>= 4;
            l >>= 4;
            i1 >>= 4;
            j1 >>= 4;
            for(int k1 = i; k1 <= l; k1++)
            {
                for(int l1 = k; l1 <= j1; l1++)
                    if(!isChunkLoaded(k1, l1))
                        return false;

            }

            return true;
        } else
        {
            return false;
        }
    }

    private boolean isChunkLoaded(int i, int j)
    {
        return chunkProvider.isChunkLoaded(i, j);
    }

    public Chunk getChunkAtWorldCoords(int i, int j)
    {
        return getChunkAt(i >> 4, j >> 4);
    }

    public Chunk getChunkAt(int i, int j)
    {
        Chunk result = null;
        synchronized(chunkLock)
        {
            if(lastChunkAccessed == null || lastXAccessed != i || lastZAccessed != j)
            {
                lastXAccessed = i;
                lastZAccessed = j;
                lastChunkAccessed = chunkProvider.getOrCreateChunk(i, j);
            }
            result = lastChunkAccessed;
        }
        return result;
    }

    public boolean setRawTypeIdAndData(int i, int j, int k, int l, int i1)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            if(j < 0)
                return false;
            if(j >= height)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                boolean flag = chunk.a(i & 0xf, j, k & 0xf, l, i1);
                s(i, j, k);
                return flag;
            }
        } else
        {
            return false;
        }
    }

    public boolean setRawTypeId(int i, int j, int k, int l)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            if(j < 0)
                return false;
            if(j >= height)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                boolean flag = chunk.a(i & 0xf, j, k & 0xf, l);
                s(i, j, k);
                return flag;
            }
        } else
        {
            return false;
        }
    }

    public Material getMaterial(int i, int j, int k)
    {
        int l = getTypeId(i, j, k);
        return l != 0 ? Block.byId[l].material : Material.AIR;
    }

    public int getData(int i, int j, int k)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            if(j < 0)
                return 0;
            if(j >= height)
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                return chunk.getData(i, j, k);
            }
        } else
        {
            return 0;
        }
    }

    public void setData(int i, int j, int k, int l)
    {
        if(setRawData(i, j, k, l))
        {
            int i1 = getTypeId(i, j, k);
            if(Block.t[i1 & 0xff])
                update(i, j, k, i1);
            else
                applyPhysics(i, j, k, i1);
        }
    }

    public boolean setRawData(int i, int j, int k, int l)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            if(j < 0)
                return false;
            if(j >= height)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                return chunk.b(i, j, k, l);
            }
        } else
        {
            return false;
        }
    }

    public boolean setTypeId(int i, int j, int k, int l)
    {
        int old = getTypeId(i, j, k);
        if(setRawTypeId(i, j, k, l))
        {
            update(i, j, k, l != 0 ? l : old);
            return true;
        } else
        {
            return false;
        }
    }

    public boolean setTypeIdAndData(int i, int j, int k, int l, int i1)
    {
        int old = getTypeId(i, j, k);
        if(setRawTypeIdAndData(i, j, k, l, i1))
        {
            update(i, j, k, l != 0 ? l : old);
            return true;
        } else
        {
            return false;
        }
    }

    public void notify(int i, int j, int k)
    {
        for(int l = 0; l < z.size(); l++)
            ((IWorldAccess)z.get(l)).a(i, j, k);

    }

    protected void update(int i, int j, int k, int l)
    {
        notify(i, j, k);
        applyPhysics(i, j, k, l);
    }

    public void g(int i, int j, int k, int l)
    {
        if(k > l)
        {
            int i1 = l;
            l = k;
            k = i1;
        }
        if(!worldProvider.e)
        {
            for(int i1 = k; i1 <= l; i1++)
                b(EnumSkyBlock.SKY, i, i1, j);

        }
        b(i, k, j, i, l, j);
    }

    public void i(int i, int j, int k)
    {
        for(int l = 0; l < z.size(); l++)
            ((IWorldAccess)z.get(l)).a(i, j, k, i, j, k);

    }

    public void b(int i, int j, int k, int l, int i1, int j1)
    {
        for(int k1 = 0; k1 < z.size(); k1++)
            ((IWorldAccess)z.get(k1)).a(i, j, k, l, i1, j1);

    }

    public void applyPhysics(int i, int j, int k, int l)
    {
        k(i - 1, j, k, l);
        k(i + 1, j, k, l);
        k(i, j - 1, k, l);
        k(i, j + 1, k, l);
        k(i, j, k - 1, l);
        k(i, j, k + 1, l);
    }

    private void k(int i, int j, int k, int l)
    {
        if(!suppressPhysics && !isStatic)
        {
            net.minecraft.server.Block block = Block.byId[getTypeId(i, j, k)];
            if(block != null)
            {
                CraftWorld world = ((WorldServer)this).getWorld();
                if(world != null)
                {
                    BlockPhysicsEvent event = new BlockPhysicsEvent(world.getBlockAt(i, j, k), l);
                    getServer().getPluginManager().callEvent(event);
                    if(event.isCancelled())
                        return;
                }
                block.doPhysics(this, i, j, k, l);
            }
        }
    }

    public boolean isChunkLoaded(int i, int j, int k)
    {
        return getChunkAt(i >> 4, k >> 4).c(i & 0xf, j, k & 0xf);
    }

    public int k(int i, int j, int k)
    {
        if(j < 0)
            return 0;
        if(j >= height)
            j = height - 1;
        return getChunkAt(i >> 4, k >> 4).c(i & 0xf, j, k & 0xf, 0);
    }

    public int getLightLevel(int i, int j, int k)
    {
        return a(i, j, k, true);
    }

    public int a(int i, int j, int k, boolean flag)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            if(flag)
            {
                int l = getTypeId(i, j, k);
                if(l == Block.STEP.id || l == Block.SOIL.id || l == Block.COBBLESTONE_STAIRS.id || l == Block.WOOD_STAIRS.id)
                {
                    int i1 = a(i, j + 1, k, false);
                    int j1 = a(i + 1, j, k, false);
                    int k1 = a(i - 1, j, k, false);
                    int l1 = a(i, j, k + 1, false);
                    int i2 = a(i, j, k - 1, false);
                    if(j1 > i1)
                        i1 = j1;
                    if(k1 > i1)
                        i1 = k1;
                    if(l1 > i1)
                        i1 = l1;
                    if(i2 > i1)
                        i1 = i2;
                    return i1;
                }
            }
            if(j < 0)
                return 0;
            if(j >= height)
                j = height - 1;
            Chunk chunk = getChunkAt(i >> 4, k >> 4);
            i &= 0xf;
            k &= 0xf;
            return chunk.c(i, j, k, this.k);
        } else
        {
            return 15;
        }
    }

    public int getHighestBlockYAt(int i, int j)
    {
        if(i >= 0xfe363c80 && j >= 0xfe363c80 && i < 0x1c9c380 && j < 0x1c9c380)
        {
            if(!isChunkLoaded(i >> 4, j >> 4))
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, j >> 4);
                return chunk.b(i & 0xf, j & 0xf);
            }
        } else
        {
            return 0;
        }
    }

    public int a(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        if(j < 0)
            j = 0;
        if(j >= height)
            j = height - 1;
        if(j >= 0 && j < height && i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            int l = i >> 4;
            int i1 = k >> 4;
            if(!isChunkLoaded(l, i1))
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(l, i1);
                return chunk.a(enumskyblock, i & 0xf, j, k & 0xf);
            }
        } else
        {
            return enumskyblock.c;
        }
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380 && j >= 0 && j < height && isChunkLoaded(i >> 4, k >> 4))
        {
            Chunk chunk = getChunkAt(i >> 4, k >> 4);
            chunk.a(enumskyblock, i & 0xf, j, k & 0xf, l);
            for(int i1 = 0; i1 < z.size(); i1++)
                ((IWorldAccess)z.get(i1)).a(i, j, k);

        }
    }

    public float m(int i, int j, int k)
    {
        return worldProvider.f[getLightLevel(i, j, k)];
    }

    public boolean e()
    {
        return k < 4;
    }

    public MovingObjectPosition a(Vec3D vec3d, Vec3D vec3d1)
    {
        return rayTrace(vec3d, vec3d1, false, false);
    }

    public MovingObjectPosition rayTrace(Vec3D vec3d, Vec3D vec3d1, boolean flag)
    {
        return rayTrace(vec3d, vec3d1, flag, false);
    }

    public MovingObjectPosition rayTrace(Vec3D vec3d, Vec3D vec3d1, boolean flag, boolean flag1)
    {
        if(!Double.isNaN(vec3d.a) && !Double.isNaN(vec3d.b) && !Double.isNaN(vec3d.c))
        {
            if(!Double.isNaN(vec3d1.a) && !Double.isNaN(vec3d1.b) && !Double.isNaN(vec3d1.c))
            {
                int i = MathHelper.floor(vec3d1.a);
                int j = MathHelper.floor(vec3d1.b);
                int k = MathHelper.floor(vec3d1.c);
                int l = MathHelper.floor(vec3d.a);
                int i1 = MathHelper.floor(vec3d.b);
                int j1 = MathHelper.floor(vec3d.c);
                int k1 = getTypeId(l, i1, j1);
                int l1 = getData(l, i1, j1);
                net.minecraft.server.Block block = Block.byId[k1];
                if((!flag1 || block == null || block.e(this, l, i1, j1) != null) && k1 > 0 && block.a(l1, flag))
                {
                    MovingObjectPosition movingobjectposition = block.a(this, l, i1, j1, vec3d, vec3d1);
                    if(movingobjectposition != null)
                        return movingobjectposition;
                }
                for(k1 = 200; k1-- >= 0;)
                {
                    if(Double.isNaN(vec3d.a) || Double.isNaN(vec3d.b) || Double.isNaN(vec3d.c))
                        return null;
                    if(l == i && i1 == j && j1 == k)
                        return null;
                    boolean flag2 = true;
                    boolean flag3 = true;
                    boolean flag4 = true;
                    double d0 = 999D;
                    double d1 = 999D;
                    double d2 = 999D;
                    if(i > l)
                        d0 = (double)l + 1.0D;
                    else
                    if(i < l)
                        d0 = (double)l + 0.0D;
                    else
                        flag2 = false;
                    if(j > i1)
                        d1 = (double)i1 + 1.0D;
                    else
                    if(j < i1)
                        d1 = (double)i1 + 0.0D;
                    else
                        flag3 = false;
                    if(k > j1)
                        d2 = (double)j1 + 1.0D;
                    else
                    if(k < j1)
                        d2 = (double)j1 + 0.0D;
                    else
                        flag4 = false;
                    double d3 = 999D;
                    double d4 = 999D;
                    double d5 = 999D;
                    double d6 = vec3d1.a - vec3d.a;
                    double d7 = vec3d1.b - vec3d.b;
                    double d8 = vec3d1.c - vec3d.c;
                    if(flag2)
                        d3 = (d0 - vec3d.a) / d6;
                    if(flag3)
                        d4 = (d1 - vec3d.b) / d7;
                    if(flag4)
                        d5 = (d2 - vec3d.c) / d8;
                    boolean flag5 = false;
                    byte b0;
                    if(d3 < d4 && d3 < d5)
                    {
                        if(i > l)
                            b0 = 4;
                        else
                            b0 = 5;
                        vec3d.a = d0;
                        vec3d.b += d7 * d3;
                        vec3d.c += d8 * d3;
                    } else
                    if(d4 < d5)
                    {
                        if(j > i1)
                            b0 = 0;
                        else
                            b0 = 1;
                        vec3d.a += d6 * d4;
                        vec3d.b = d1;
                        vec3d.c += d8 * d4;
                    } else
                    {
                        if(k > j1)
                            b0 = 2;
                        else
                            b0 = 3;
                        vec3d.a += d6 * d5;
                        vec3d.b += d7 * d5;
                        vec3d.c = d2;
                    }
                    Vec3D vec3d2 = Vec3D.create(vec3d.a, vec3d.b, vec3d.c);
                    l = (int)(vec3d2.a = MathHelper.floor(vec3d.a));
                    if(b0 == 5)
                    {
                        l--;
                        vec3d2.a++;
                    }
                    i1 = (int)(vec3d2.b = MathHelper.floor(vec3d.b));
                    if(b0 == 1)
                    {
                        i1--;
                        vec3d2.b++;
                    }
                    j1 = (int)(vec3d2.c = MathHelper.floor(vec3d.c));
                    if(b0 == 3)
                    {
                        j1--;
                        vec3d2.c++;
                    }
                    int i2 = getTypeId(l, i1, j1);
                    int j2 = getData(l, i1, j1);
                    net.minecraft.server.Block block1 = Block.byId[i2];
                    if((!flag1 || block1 == null || block1.e(this, l, i1, j1) != null) && i2 > 0 && block1.a(j2, flag))
                    {
                        MovingObjectPosition movingobjectposition1 = block1.a(this, l, i1, j1, vec3d, vec3d1);
                        if(movingobjectposition1 != null)
                            return movingobjectposition1;
                    }
                }

                return null;
            } else
            {
                return null;
            }
        } else
        {
            return null;
        }
    }

    public void makeSound(Entity entity, String s, float f, float f1)
    {
        for(int i = 0; i < z.size(); i++)
            ((IWorldAccess)z.get(i)).a(s, entity.locX, entity.locY - (double)entity.height, entity.locZ, f, f1);

    }

    public void makeSound(double d0, double d1, double d2, String s, 
            float f, float f1)
    {
        for(int i = 0; i < z.size(); i++)
            ((IWorldAccess)z.get(i)).a(s, d0, d1, d2, f, f1);

    }

    public void a(String s, int i, int j, int k)
    {
        for(int l = 0; l < z.size(); l++)
            ((IWorldAccess)z.get(l)).a(s, i, j, k);

    }

    public void a(String s, double d0, double d1, double d2, 
            double d3, double d4, double d5)
    {
        for(int i = 0; i < z.size(); i++)
            ((IWorldAccess)z.get(i)).a(s, d0, d1, d2, d3, d4, d5);

    }

    public boolean strikeLightning(Entity entity)
    {
        j.add(entity);
        return true;
    }

    public boolean addEntity(Entity entity)
    {
        return addEntity(entity, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.CUSTOM);
    }

    public boolean addEntity(Entity entity, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason spawnReason)
    {
        int i = MathHelper.floor(entity.locX / 16D);
        int j = MathHelper.floor(entity.locZ / 16D);
        boolean flag = false;
        if(entity instanceof EntityHuman)
            flag = true;
        if((entity instanceof EntityLiving) && !(entity instanceof EntityPlayer))
        {
            boolean isAnimal = (entity instanceof EntityAnimal) || (entity instanceof EntityWaterAnimal);
            boolean isMonster = (entity instanceof EntityMonster) || (entity instanceof EntityGhast) || (entity instanceof EntitySlime);
            if((spawnReason == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.NATURAL || spawnReason == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.SPAWNER || spawnReason == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.BED || spawnReason == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.EGG) && (isAnimal && !allowAnimals || isMonster && !allowMonsters))
                return false;
            CreatureSpawnEvent event = CraftEventFactory.callCreatureSpawnEvent((EntityLiving)entity, spawnReason);
            if(event.isCancelled())
                return false;
        } else
        if(entity instanceof EntityItem)
        {
            ItemSpawnEvent event = CraftEventFactory.callItemSpawnEvent((EntityItem)entity);
            if(event.isCancelled())
                return false;
        }
        if(!flag && !isChunkLoaded(i, j))
            return false;
        if(entity instanceof EntityHuman)
        {
            EntityHuman entityhuman = (EntityHuman)entity;
            players.add(entityhuman);
            everyoneSleeping();
        }
        getChunkAt(i, j).a(entity);
        entityList.add(entity);
        c(entity);
        return true;
    }

    protected void c(Entity entity)
    {
        for(int i = 0; i < z.size(); i++)
            ((IWorldAccess)z.get(i)).a(entity);

    }

    protected void d(Entity entity)
    {
        for(int i = 0; i < z.size(); i++)
            ((IWorldAccess)z.get(i)).b(entity);

    }

    public void kill(Entity entity)
    {
        if(entity.passenger != null)
            entity.passenger.mount((Entity)null);
        if(entity.vehicle != null)
            entity.mount((Entity)null);
        entity.die();
        if(entity instanceof EntityHuman)
        {
            players.remove((EntityHuman)entity);
            everyoneSleeping();
        }
    }

    public void removeEntity(Entity entity)
    {
        entity.die();
        if(entity instanceof EntityHuman)
        {
            players.remove((EntityHuman)entity);
            everyoneSleeping();
        }
        int i = entity.bX;
        int j = entity.bZ;
        if(entity.bW && isChunkLoaded(i, j))
            getChunkAt(i, j).b(entity);
        entityList.remove(entity);
        d(entity);
    }

    public void addIWorldAccess(IWorldAccess iworldaccess)
    {
        z.add(iworldaccess);
    }

    public List getEntities(Entity entity, AxisAlignedBB axisalignedbb)
    {
        R.clear();
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = i1; l1 < j1; l1++)
            {
                if(!isLoaded(k1, height / 2, l1))
                    continue;
                for(int i2 = k - 1; i2 < l; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, i2, l1)];
                    if(block != null)
                        block.a(this, k1, i2, l1, axisalignedbb, R);
                }

            }

        }

        double d0 = 0.25D;
        List list = b(entity, axisalignedbb.b(d0, d0, d0));
        for(int j2 = 0; j2 < list.size(); j2++)
        {
            AxisAlignedBB axisalignedbb1 = ((Entity)list.get(j2)).h_();
            if(axisalignedbb1 != null && axisalignedbb1.a(axisalignedbb))
                R.add(axisalignedbb1);
            axisalignedbb1 = entity.a_((Entity)list.get(j2));
            if(axisalignedbb1 != null && axisalignedbb1.a(axisalignedbb))
                R.add(axisalignedbb1);
        }

        return R;
    }

    public int a(float f)
    {
        float f1 = b(f);
        float f2 = 1.0F - (MathHelper.cos(f1 * 3.141593F * 2.0F) * 2.0F + 0.5F);
        if(f2 < 0.0F)
            f2 = 0.0F;
        if(f2 > 1.0F)
            f2 = 1.0F;
        f2 = 1.0F - f2;
        f2 = (float)((double)f2 * (1.0D - (double)(d(f) * 5F) / 16D));
        f2 = (float)((double)f2 * (1.0D - (double)(c(f) * 5F) / 16D));
        f2 = 1.0F - f2;
        return (int)(f2 * 11F);
    }

    public float b(float f)
    {
        return worldProvider.a(worldData.f(), f);
    }

    public int e(int i, int j)
    {
        return getChunkAtWorldCoords(i, j).c(i & 0xf, j & 0xf);
    }

    public int f(int i, int j)
    {
        Chunk chunk = getChunkAtWorldCoords(i, j);
        int k = height - 1;
        i &= 0xf;
        j &= 0xf;
        for(; k > 0; k--)
        {
            int l = chunk.getTypeId(i, k, j);
            if(l != 0 && Block.byId[l].material.isSolid() && Block.byId[l].material != Material.LEAVES)
                return k + 1;
        }

        return -1;
    }

    public void c(int i, int j, int k, int l, int i1)
    {
        NextTickListEntry nextticklistentry = new NextTickListEntry(i, j, k, l);
        byte b0 = 8;
        if(f)
        {
            if(a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0))
            {
                int j1 = getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
                if(j1 == nextticklistentry.d && j1 > 0)
                    Block.byId[j1].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, random);
            }
        } else
        if(a(i - b0, j - b0, k - b0, i + b0, j + b0, k + b0))
        {
            if(l > 0)
                nextticklistentry.a((long)i1 + worldData.f());
            if(!L.contains(nextticklistentry))
            {
                L.add(nextticklistentry);
                K.add(nextticklistentry);
            }
        }
    }

    public void d(int i, int j, int k, int l, int i1)
    {
        NextTickListEntry nextticklistentry = new NextTickListEntry(i, j, k, l);
        if(l > 0)
            nextticklistentry.a((long)i1 + worldData.f());
        if(!L.contains(nextticklistentry))
        {
            L.add(nextticklistentry);
            K.add(nextticklistentry);
        }
    }

    public void tickEntities()
    {
        for(int i = 0; i < this.j.size(); i++)
        {
            Entity entity = (Entity)this.j.get(i);
            if(entity == null)
                continue;
            entity.w_();
            if(entity.dead)
                this.j.remove(i--);
        }

        entityList.removeAll(J);
        for(int i = 0; i < J.size(); i++)
        {
            Entity entity = (Entity)J.get(i);
            int j = entity.bX;
            int k = entity.bZ;
            if(entity.bW && isChunkLoaded(j, k))
                getChunkAt(j, k).b(entity);
        }

        for(int i = 0; i < J.size(); i++)
            d((Entity)J.get(i));

        J.clear();
        for(int i = 0; i < entityList.size(); i++)
        {
            Entity entity = (Entity)entityList.get(i);
            if(entity.vehicle != null)
            {
                if(!entity.vehicle.dead && entity.vehicle.passenger == entity)
                    continue;
                entity.vehicle.passenger = null;
                entity.vehicle = null;
            }
            if(!entity.dead)
                playerJoinedWorld(entity);
            if(!entity.dead)
                continue;
            int j = entity.bX;
            int k = entity.bZ;
            if(entity.bW && isChunkLoaded(j, k))
                getChunkAt(j, k).b(entity);
            entityList.remove(i--);
            d(entity);
        }

        S = true;
        Iterator iterator = h.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            TileEntity tileentity = (TileEntity)iterator.next();
            if(!tileentity.l() && tileentity.world != null && isLoaded(tileentity.x, tileentity.y, tileentity.z))
                tileentity.l_();
            if(tileentity.l())
            {
                iterator.remove();
                if(isChunkLoaded(tileentity.x >> 4, tileentity.z >> 4))
                {
                    Chunk chunk = getChunkAt(tileentity.x >> 4, tileentity.z >> 4);
                    if(chunk != null)
                        chunk.e(tileentity.x & 0xf, tileentity.y, tileentity.z & 0xf);
                }
            }
        } while(true);
        S = false;
        if(!N.isEmpty())
        {
            h.removeAll(N);
            N.clear();
        }
        if(!M.isEmpty())
        {
            Iterator iterator1 = M.iterator();
            do
            {
                if(!iterator1.hasNext())
                    break;
                TileEntity tileentity1 = (TileEntity)iterator1.next();
                if(!tileentity1.l())
                {
                    if(isChunkLoaded(tileentity1.x >> 4, tileentity1.z >> 4))
                    {
                        Chunk chunk1 = getChunkAt(tileentity1.x >> 4, tileentity1.z >> 4);
                        if(chunk1 != null)
                        {
                            chunk1.a(tileentity1.x & 0xf, tileentity1.y, tileentity1.z & 0xf, tileentity1);
                            if(!h.contains(tileentity1))
                                h.add(tileentity1);
                        }
                    }
                    notify(tileentity1.x, tileentity1.y, tileentity1.z);
                }
            } while(true);
            M.clear();
        }
    }

    public void a(Collection collection)
    {
        if(S)
            M.addAll(collection);
        else
            h.addAll(collection);
    }

    public void playerJoinedWorld(Entity entity)
    {
        entityJoinedWorld(entity, true);
    }

    public void entityJoinedWorld(Entity entity, boolean flag)
    {
        int i = MathHelper.floor(entity.locX);
        int j = MathHelper.floor(entity.locZ);
        byte b0 = 32;
        if(!flag || a(i - b0, 0, j - b0, i + b0, height, j + b0))
        {
            entity.bI = entity.locX;
            entity.bJ = entity.locY;
            entity.bK = entity.locZ;
            entity.lastYaw = entity.yaw;
            entity.lastPitch = entity.pitch;
            if(flag && entity.bW)
                if(entity.vehicle != null)
                    entity.M();
                else
                    entity.w_();
            if(Double.isNaN(entity.locX) || Double.isInfinite(entity.locX))
                entity.locX = entity.bI;
            if(Double.isNaN(entity.locY) || Double.isInfinite(entity.locY))
                entity.locY = entity.bJ;
            if(Double.isNaN(entity.locZ) || Double.isInfinite(entity.locZ))
                entity.locZ = entity.bK;
            if(Double.isNaN(entity.pitch) || Double.isInfinite(entity.pitch))
                entity.pitch = entity.lastPitch;
            if(Double.isNaN(entity.yaw) || Double.isInfinite(entity.yaw))
                entity.yaw = entity.lastYaw;
            int k = MathHelper.floor(entity.locX / 16D);
            int l = MathHelper.floor(entity.locY / 16D);
            int i1 = MathHelper.floor(entity.locZ / 16D);
            if(!entity.bW || entity.bX != k || entity.bY != l || entity.bZ != i1)
            {
                if(entity.bW && isChunkLoaded(entity.bX, entity.bZ))
                    getChunkAt(entity.bX, entity.bZ).a(entity, entity.bY);
                if(isChunkLoaded(k, i1))
                {
                    entity.bW = true;
                    getChunkAt(k, i1).a(entity);
                } else
                {
                    entity.bW = false;
                }
            }
            if(flag && entity.bW && entity.passenger != null)
                if(!entity.passenger.dead && entity.passenger.vehicle == entity)
                {
                    playerJoinedWorld(entity.passenger);
                } else
                {
                    entity.passenger.vehicle = null;
                    entity.passenger = null;
                }
        }
    }

    public boolean containsEntity(AxisAlignedBB axisalignedbb)
    {
        List list = b((Entity)null, axisalignedbb);
        for(int i = 0; i < list.size(); i++)
        {
            Entity entity = (Entity)list.get(i);
            if(!entity.dead && entity.bc)
                return false;
        }

        return true;
    }

    public boolean b(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(axisalignedbb.a < 0.0D)
            i--;
        if(axisalignedbb.b < 0.0D)
            k--;
        if(axisalignedbb.c < 0.0D)
            i1--;
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null)
                        return true;
                }

            }

        }

        return false;
    }

    public boolean c(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(axisalignedbb.a < 0.0D)
            i--;
        if(axisalignedbb.b < 0.0D)
            k--;
        if(axisalignedbb.c < 0.0D)
            i1--;
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null && block.material.isLiquid())
                        return true;
                }

            }

        }

        return false;
    }

    public boolean d(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(a(i, k, i1, j, l, j1))
        {
            for(int k1 = i; k1 < j; k1++)
            {
                for(int l1 = k; l1 < l; l1++)
                {
                    for(int i2 = i1; i2 < j1; i2++)
                    {
                        int j2 = getTypeId(k1, l1, i2);
                        if(j2 == Block.FIRE.id || j2 == Block.LAVA.id || j2 == Block.STATIONARY_LAVA.id)
                            return true;
                    }

                }

            }

        }
        return false;
    }

    public boolean a(AxisAlignedBB axisalignedbb, Material material, Entity entity)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(!a(i, k, i1, j, l, j1))
            return false;
        boolean flag = false;
        Vec3D vec3d = Vec3D.create(0.0D, 0.0D, 0.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block == null || block.material != material)
                        continue;
                    double d0 = (float)(l1 + 1) - BlockFluids.d(getData(k1, l1, i2));
                    if((double)l >= d0)
                    {
                        flag = true;
                        block.a(this, k1, l1, i2, entity, vec3d);
                    }
                }

            }

        }

        if(vec3d.c() > 0.0D)
        {
            vec3d = vec3d.b();
            double d1 = 0.014D;
            entity.motX += vec3d.a * d1;
            entity.motY += vec3d.b * d1;
            entity.motZ += vec3d.c * d1;
        }
        return flag;
    }

    public boolean a(AxisAlignedBB axisalignedbb, Material material)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null && block.material == material)
                        return true;
                }

            }

        }

        return false;
    }

    public boolean b(AxisAlignedBB axisalignedbb, Material material)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    net.minecraft.server.Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block == null || block.material != material)
                        continue;
                    int j2 = getData(k1, l1, i2);
                    double d0 = l1 + 1;
                    if(j2 < 8)
                        d0 = (double)(l1 + 1) - (double)j2 / 8D;
                    if(d0 >= axisalignedbb.b)
                        return true;
                }

            }

        }

        return false;
    }

    public Explosion a(Entity entity, double d0, double d1, double d2, 
            float f)
    {
        return createExplosion(entity, d0, d1, d2, f, false);
    }

    public Explosion createExplosion(Entity entity, double d0, double d1, double d2, 
            float f, boolean flag)
    {
        Explosion explosion = new Explosion(this, entity, d0, d1, d2, f);
        explosion.a = flag;
        explosion.a();
        explosion.a(true);
        return explosion;
    }

    public float a(Vec3D vec3d, AxisAlignedBB axisalignedbb)
    {
        double d0 = 1.0D / ((axisalignedbb.d - axisalignedbb.a) * 2D + 1.0D);
        double d1 = 1.0D / ((axisalignedbb.e - axisalignedbb.b) * 2D + 1.0D);
        double d2 = 1.0D / ((axisalignedbb.f - axisalignedbb.c) * 2D + 1.0D);
        int i = 0;
        int j = 0;
        for(float f = 0.0F; f <= 1.0F; f = (float)((double)f + d0))
        {
            for(float f1 = 0.0F; f1 <= 1.0F; f1 = (float)((double)f1 + d1))
            {
                for(float f2 = 0.0F; f2 <= 1.0F; f2 = (float)((double)f2 + d2))
                {
                    double d3 = axisalignedbb.a + (axisalignedbb.d - axisalignedbb.a) * (double)f;
                    double d4 = axisalignedbb.b + (axisalignedbb.e - axisalignedbb.b) * (double)f1;
                    double d5 = axisalignedbb.c + (axisalignedbb.f - axisalignedbb.c) * (double)f2;
                    if(a(Vec3D.create(d3, d4, d5), vec3d) == null)
                        i++;
                    j++;
                }

            }

        }

        return (float)i / (float)j;
    }

    public void douseFire(EntityHuman entityhuman, int i, int j, int k, int l)
    {
        if(l == 0)
            j--;
        if(l == 1)
            j++;
        if(l == 2)
            k--;
        if(l == 3)
            k++;
        if(l == 4)
            i--;
        if(l == 5)
            i++;
        if(getTypeId(i, j, k) == Block.FIRE.id)
        {
            a(entityhuman, 1004, i, j, k, 0);
            setTypeId(i, j, k, 0);
        }
    }

    public TileEntity getTileEntity(int i, int j, int k)
    {
        TileEntity tileentity;
label0:
        {
            Chunk chunk = getChunkAt(i >> 4, k >> 4);
            if(chunk == null)
                return null;
            tileentity = chunk.d(i & 0xf, j, k & 0xf);
            if(tileentity != null)
                break label0;
            Iterator iterator = M.iterator();
            TileEntity tileentity1;
            do
            {
                if(!iterator.hasNext())
                    break label0;
                tileentity1 = (TileEntity)iterator.next();
            } while(tileentity1.l() || tileentity1.x != i || tileentity1.y != j || tileentity1.z != k);
            tileentity = tileentity1;
        }
        return tileentity;
    }

    public void setTileEntity(int i, int j, int k, TileEntity tileentity)
    {
        if(tileentity != null && !tileentity.l())
            if(S)
            {
                tileentity.x = i;
                tileentity.y = j;
                tileentity.z = k;
                M.add(tileentity);
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                if(chunk != null)
                {
                    chunk.a(i & 0xf, j, k & 0xf, tileentity);
                    h.add(tileentity);
                }
            }
    }

    public void n(int i, int j, int k)
    {
        TileEntity tileentity = getTileEntity(i, j, k);
        if(tileentity != null && S)
        {
            tileentity.i();
            M.remove(tileentity);
        } else
        {
            if(tileentity != null)
            {
                M.remove(tileentity);
                h.remove(tileentity);
            }
            Chunk chunk = getChunkAt(i >> 4, k >> 4);
            if(chunk != null)
                chunk.e(i & 0xf, j, k & 0xf);
        }
    }

    public void a(TileEntity tileentity)
    {
        N.add(tileentity);
    }

    public boolean o(int i, int j, int k)
    {
        net.minecraft.server.Block block = Block.byId[getTypeId(i, j, k)];
        return block != null ? block.a() : false;
    }

    public boolean e(int i, int j, int k)
    {
        net.minecraft.server.Block block = Block.byId[getTypeId(i, j, k)];
        return block != null ? block.material.j() && block.b() : false;
    }

    public boolean b(int i, int j, int k, boolean flag)
    {
        if(i >= 0xfe363c80 && k >= 0xfe363c80 && i < 0x1c9c380 && k < 0x1c9c380)
        {
            Chunk chunk = chunkProvider.getOrCreateChunk(i >> 4, k >> 4);
            if(chunk != null && !chunk.isEmpty())
            {
                net.minecraft.server.Block block = Block.byId[getTypeId(i, j, k)];
                return block != null ? block.material.j() && block.b() : false;
            } else
            {
                return flag;
            }
        } else
        {
            return flag;
        }
    }

    public void g()
    {
        int i = a(1.0F);
        if(i != k)
            k = i;
    }

    public void setSpawnFlags(boolean flag, boolean flag1)
    {
        allowMonsters = flag;
        allowAnimals = flag1;
    }

    public void doTick()
    {
        if(r().isHardcore() && difficulty < 3)
            difficulty = 3;
        getWorldChunkManager().b();
        i();
        long i;
        if(everyoneDeeplySleeping())
        {
            boolean flag = false;
            if(allowMonsters)
                if(difficulty < 1);
            if(!flag)
            {
                i = worldData.f() + 24000L;
                worldData.a(i - i % 24000L);
                t();
            }
        }
        if((allowMonsters || allowAnimals) && (this instanceof WorldServer) && getServer().getHandle().players.size() > 0)
            SpawnerCreature.spawnEntities(this, allowMonsters, allowAnimals && worldData.f() % 400L == 0L);
        chunkProvider.unloadChunks();
        int j = a(1.0F);
        if(j != k)
            k = j;
        i = worldData.f() + 1L;
        if(i % (long)u == 0L)
            save(false, (IProgressUpdate)null);
        worldData.a(i);
        a(false);
        k();
    }

    private void z()
    {
        if(worldData.hasStorm())
        {
            o = 1.0F;
            if(worldData.isThundering())
                q = 1.0F;
        }
    }

    protected void i()
    {
        if(!worldProvider.e)
        {
            if(r > 0)
                r--;
            int i = worldData.getThunderDuration();
            if(i <= 0)
            {
                if(worldData.isThundering())
                    worldData.setThunderDuration(random.nextInt(12000) + 3600);
                else
                    worldData.setThunderDuration(random.nextInt(0x29040) + 12000);
            } else
            {
                i--;
                worldData.setThunderDuration(i);
                if(i <= 0)
                {
                    ThunderChangeEvent thunder = new ThunderChangeEvent(getWorld(), !worldData.isThundering());
                    getServer().getPluginManager().callEvent(thunder);
                    if(!thunder.isCancelled())
                        worldData.setThundering(!worldData.isThundering());
                }
            }
            int j = worldData.getWeatherDuration();
            if(j <= 0)
            {
                if(worldData.hasStorm())
                    worldData.setWeatherDuration(random.nextInt(12000) + 12000);
                else
                    worldData.setWeatherDuration(random.nextInt(0x29040) + 12000);
            } else
            {
                j--;
                worldData.setWeatherDuration(j);
                if(j <= 0)
                {
                    WeatherChangeEvent weather = new WeatherChangeEvent(getWorld(), !worldData.hasStorm());
                    getServer().getPluginManager().callEvent(weather);
                    if(!weather.isCancelled())
                        worldData.setStorm(!worldData.hasStorm());
                }
            }
            n = o;
            if(worldData.hasStorm())
                o = (float)((double)o + 0.01D);
            else
                o = (float)((double)o - 0.01D);
            if(o < 0.0F)
                o = 0.0F;
            if(o > 1.0F)
                o = 1.0F;
            p = q;
            if(worldData.isThundering())
                q = (float)((double)q + 0.01D);
            else
                q = (float)((double)q - 0.01D);
            if(q < 0.0F)
                q = 0.0F;
            if(q > 1.0F)
                q = 1.0F;
        }
    }

    private void A()
    {
        WeatherChangeEvent weather = new WeatherChangeEvent(getWorld(), false);
        getServer().getPluginManager().callEvent(weather);
        ThunderChangeEvent thunder = new ThunderChangeEvent(getWorld(), false);
        getServer().getPluginManager().callEvent(thunder);
        if(!weather.isCancelled())
        {
            worldData.setWeatherDuration(0);
            worldData.setStorm(false);
        }
        if(!thunder.isCancelled())
        {
            worldData.setThunderDuration(0);
            worldData.setThundering(false);
        }
    }

    public void j()
    {
        worldData.setWeatherDuration(1);
    }

    protected void k()
    {
        T.clear();
        int i;
        for(i = 0; i < players.size(); i++)
        {
            EntityHuman entityhuman = (EntityHuman)players.get(i);
            int k = MathHelper.floor(entityhuman.locX / 16D);
            int l = MathHelper.floor(entityhuman.locZ / 16D);
            byte b0 = 7;
            for(int j = -b0; j <= b0; j++)
            {
                for(int i1 = -b0; i1 <= b0; i1++)
                    T.add(new ChunkCoordIntPair(j + k, i1 + l));

            }

        }

        if(U > 0)
            U--;
        i = 0;
        int j1 = 0;
        for(Iterator iterator = T.iterator(); iterator.hasNext();)
        {
            ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)iterator.next();
            int k1 = chunkcoordintpair.x * 16;
            int j = chunkcoordintpair.z * 16;
            Chunk chunk = getChunkAt(chunkcoordintpair.x, chunkcoordintpair.z);
            chunk.i();
            int l1;
            int i2;
            int j2;
            int k2;
            if(U == 0)
            {
                this.l = this.l * 3 + 0x3c6ef35f;
                l1 = this.l >> 2;
                i2 = l1 & 0xf;
                j2 = l1 >> 8 & 0xf;
                k2 = l1 >> 16 & heightMinusOne;
                int l2 = chunk.getTypeId(i2, k2, j2);
                i2 += k1;
                j2 += j;
                if(l2 == 0 && k(i2, k2, j2) <= random.nextInt(8) && a(EnumSkyBlock.SKY, i2, k2, j2) <= 0)
                {
                    EntityHuman entityhuman1 = a((double)i2 + 0.5D, (double)k2 + 0.5D, (double)j2 + 0.5D, 8D);
                    if(entityhuman1 != null && entityhuman1.e((double)i2 + 0.5D, (double)k2 + 0.5D, (double)j2 + 0.5D) > 4D)
                    {
                        makeSound((double)i2 + 0.5D, (double)k2 + 0.5D, (double)j2 + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + random.nextFloat() * 0.2F);
                        U = random.nextInt(12000) + 6000;
                    }
                }
            }
            if(random.nextInt(0x186a0) == 0 && w() && v())
            {
                this.l = this.l * 3 + 0x3c6ef35f;
                l1 = this.l >> 2;
                i2 = k1 + (l1 & 0xf);
                j2 = j + (l1 >> 8 & 0xf);
                k2 = e(i2, j2);
                if(v(i2, k2, j2))
                {
                    strikeLightning(new EntityWeatherStorm(this, i2, k2, j2));
                    r = 2;
                }
            }
            this.l = this.l * 3 + 0x3c6ef35f;
            l1 = this.l >> 2;
            i2 = l1 & 0xf;
            j2 = l1 >> 8 & 0xf;
            k2 = e(i2 + k1, j2 + j);
            if(q(i2 + k1, k2 - 1, j2 + j))
            {
                BlockState blockState = getWorld().getBlockAt(i2 + k1, k2 - 1, j2 + j).getState();
                blockState.setTypeId(Block.ICE.id);
                BlockFormEvent iceBlockForm = new BlockFormEvent(blockState.getBlock(), blockState);
                getServer().getPluginManager().callEvent(iceBlockForm);
                if(!iceBlockForm.isCancelled())
                    blockState.update(true);
            }
            if(w() && r(i2 + k1, k2, j2 + j))
            {
                BlockState blockState = getWorld().getBlockAt(i2 + k1, k2, j2 + j).getState();
                blockState.setTypeId(Block.SNOW.id);
                BlockFormEvent snow = new BlockFormEvent(blockState.getBlock(), blockState);
                getServer().getPluginManager().callEvent(snow);
                if(!snow.isCancelled())
                    blockState.update(true);
            }
            s(k1 + random.nextInt(16), random.nextInt(height), j + random.nextInt(16));
            l1 = 0;
            while(l1 < 20) 
            {
                this.l = this.l * 3 + 0x3c6ef35f;
                i2 = this.l >> 2;
                j2 = i2 & 0xf;
                k2 = i2 >> 8 & 0xf;
                int l2 = i2 >> 16 & heightMinusOne;
                int i3 = chunk.b[j2 << heightBitsPlusFour | k2 << heightBits | l2] & 0xff;
                j1++;
                if(Block.n[i3])
                {
                    i++;
                    Block.byId[i3].a(this, j2 + k1, l2, k2 + j, random);
                }
                l1++;
            }
        }

    }

    public boolean p(int i, int j, int k)
    {
        return c(i, j, k, false);
    }

    public boolean q(int i, int j, int k)
    {
        return c(i, j, k, true);
    }

    public boolean c(int i, int j, int k, boolean flag)
    {
        float f = getWorldChunkManager().a(i, j, k);
        if(f > 0.15F)
            return false;
        if(j >= 0 && j < height && a(EnumSkyBlock.BLOCK, i, j, k) < 10)
        {
            int l = getTypeId(i, j, k);
            if((l == Block.STATIONARY_WATER.id || l == Block.WATER.id) && getData(i, j, k) == 0)
            {
                if(!flag)
                    return true;
                boolean flag1 = true;
                if(flag1 && getMaterial(i - 1, j, k) != Material.WATER)
                    flag1 = false;
                if(flag1 && getMaterial(i + 1, j, k) != Material.WATER)
                    flag1 = false;
                if(flag1 && getMaterial(i, j, k - 1) != Material.WATER)
                    flag1 = false;
                if(flag1 && getMaterial(i, j, k + 1) != Material.WATER)
                    flag1 = false;
                if(!flag1)
                    return true;
            }
        }
        return false;
    }

    public boolean r(int i, int j, int k)
    {
        float f = getWorldChunkManager().a(i, j, k);
        if(f > 0.15F)
            return false;
        if(j >= 0 && j < height && a(EnumSkyBlock.BLOCK, i, j, k) < 10)
        {
            int l = getTypeId(i, j - 1, k);
            int i1 = getTypeId(i, j, k);
            if(i1 == 0 && Block.SNOW.canPlace(this, i, j, k) && l != 0 && l != Block.ICE.id && Block.byId[l].material.isSolid())
                return true;
        }
        return false;
    }

    public void s(int i, int j, int k)
    {
        if(!worldProvider.e)
            b(EnumSkyBlock.SKY, i, j, k);
        b(EnumSkyBlock.BLOCK, i, j, k);
    }

    private int d(int i, int j, int k, int l, int i1, int j1)
    {
        int k1 = 0;
        if(isChunkLoaded(j, k, l))
        {
            k1 = 15;
        } else
        {
            if(j1 == 0)
                j1 = 1;
            for(int l1 = 0; l1 < 6; l1++)
            {
                int i2 = (l1 % 2) * 2 - 1;
                int j2 = j + (((l1 / 2) % 3) / 2) * i2;
                int k2 = k + (((l1 / 2 + 1) % 3) / 2) * i2;
                int l2 = l + (((l1 / 2 + 2) % 3) / 2) * i2;
                int i3 = a(EnumSkyBlock.SKY, j2, k2, l2) - j1;
                if(i3 > k1)
                    k1 = i3;
            }

        }
        return k1;
    }

    private int e(int i, int j, int k, int l, int i1, int j1)
    {
        int k1 = Block.s[i1];
        int l1 = a(EnumSkyBlock.BLOCK, j - 1, k, l) - j1;
        int i2 = a(EnumSkyBlock.BLOCK, j + 1, k, l) - j1;
        int j2 = a(EnumSkyBlock.BLOCK, j, k - 1, l) - j1;
        int k2 = a(EnumSkyBlock.BLOCK, j, k + 1, l) - j1;
        int l2 = a(EnumSkyBlock.BLOCK, j, k, l - 1) - j1;
        int i3 = a(EnumSkyBlock.BLOCK, j, k, l + 1) - j1;
        if(l1 > k1)
            k1 = l1;
        if(i2 > k1)
            k1 = i2;
        if(j2 > k1)
            k1 = j2;
        if(k2 > k1)
            k1 = k2;
        if(l2 > k1)
            k1 = l2;
        if(i3 > k1)
            k1 = i3;
        return k1;
    }

    public void b(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        if(areChunksLoaded(i, j, k, 17))
        {
            int l = 0;
            int i1 = 0;
            int j1 = a(enumskyblock, i, j, k);
            boolean flag = false;
            int k1 = getTypeId(i, j, k);
            int l1 = Block.q[k1];
            if(l1 == 0)
                l1 = 1;
            boolean flag1 = false;
            int i2;
            if(enumskyblock == EnumSkyBlock.SKY)
                i2 = d(j1, i, j, k, k1, l1);
            else
                i2 = e(j1, i, j, k, k1, l1);
            if(i2 > j1)
                H[i1++] = 0x20820;
            else
            if(i2 < j1)
            {
                if(enumskyblock == EnumSkyBlock.BLOCK);
                H[i1++] = 0x20820 + (j1 << 18);
                do
                {
                    if(l >= i1)
                        break;
                    int j2 = H[l++];
                    k1 = ((j2 & 0x3f) - 32) + i;
                    l1 = ((j2 >> 6 & 0x3f) - 32) + j;
                    i2 = ((j2 >> 12 & 0x3f) - 32) + k;
                    int k2 = j2 >> 18 & 0xf;
                    int l2 = a(enumskyblock, k1, l1, i2);
                    if(l2 == k2)
                    {
                        a(enumskyblock, k1, l1, i2, 0);
                        if(k2 > 0)
                        {
                            int i3 = k1 - i;
                            int k3 = l1 - j;
                            int j3 = i2 - k;
                            if(i3 < 0)
                                i3 = -i3;
                            if(k3 < 0)
                                k3 = -k3;
                            if(j3 < 0)
                                j3 = -j3;
                            if(i3 + k3 + j3 < 17)
                            {
                                int l3 = 0;
                                while(l3 < 6) 
                                {
                                    int i4 = (l3 % 2) * 2 - 1;
                                    int j4 = k1 + (((l3 / 2) % 3) / 2) * i4;
                                    int k4 = l1 + (((l3 / 2 + 1) % 3) / 2) * i4;
                                    int l4 = i2 + (((l3 / 2 + 2) % 3) / 2) * i4;
                                    l2 = a(enumskyblock, j4, k4, l4);
                                    int i5 = Block.q[getTypeId(j4, k4, l4)];
                                    if(i5 == 0)
                                        i5 = 1;
                                    if(l2 == k2 - i5)
                                        H[i1++] = (j4 - i) + 32 + ((k4 - j) + 32 << 6) + ((l4 - k) + 32 << 12) + (k2 - i5 << 18);
                                    l3++;
                                }
                            }
                        }
                    }
                } while(true);
                l = 0;
            }
            do
            {
                if(l >= i1)
                    break;
                j1 = H[l++];
                int j5 = ((j1 & 0x3f) - 32) + i;
                int j2 = ((j1 >> 6 & 0x3f) - 32) + j;
                k1 = ((j1 >> 12 & 0x3f) - 32) + k;
                l1 = a(enumskyblock, j5, j2, k1);
                i2 = getTypeId(j5, j2, k1);
                int k2 = Block.q[i2];
                if(k2 == 0)
                    k2 = 1;
                boolean flag2 = false;
                int l2;
                if(enumskyblock == EnumSkyBlock.SKY)
                    l2 = d(l1, j5, j2, k1, i2, k2);
                else
                    l2 = e(l1, j5, j2, k1, i2, k2);
                if(l2 != l1)
                {
                    a(enumskyblock, j5, j2, k1, l2);
                    if(l2 > l1)
                    {
                        int i3 = j5 - i;
                        int k3 = j2 - j;
                        int j3 = k1 - k;
                        if(i3 < 0)
                            i3 = -i3;
                        if(k3 < 0)
                            k3 = -k3;
                        if(j3 < 0)
                            j3 = -j3;
                        if(i3 + k3 + j3 < 17 && i1 < H.length - 6)
                        {
                            if(a(enumskyblock, j5 - 1, j2, k1) < l2)
                                H[i1++] = (j5 - 1 - i) + 32 + ((j2 - j) + 32 << 6) + ((k1 - k) + 32 << 12);
                            if(a(enumskyblock, j5 + 1, j2, k1) < l2)
                                H[i1++] = ((j5 + 1) - i) + 32 + ((j2 - j) + 32 << 6) + ((k1 - k) + 32 << 12);
                            if(a(enumskyblock, j5, j2 - 1, k1) < l2)
                                H[i1++] = (j5 - i) + 32 + ((j2 - 1 - j) + 32 << 6) + ((k1 - k) + 32 << 12);
                            if(a(enumskyblock, j5, j2 + 1, k1) < l2)
                                H[i1++] = (j5 - i) + 32 + (((j2 + 1) - j) + 32 << 6) + ((k1 - k) + 32 << 12);
                            if(a(enumskyblock, j5, j2, k1 - 1) < l2)
                                H[i1++] = (j5 - i) + 32 + ((j2 - j) + 32 << 6) + ((k1 - 1 - k) + 32 << 12);
                            if(a(enumskyblock, j5, j2, k1 + 1) < l2)
                                H[i1++] = (j5 - i) + 32 + ((j2 - j) + 32 << 6) + (((k1 + 1) - k) + 32 << 12);
                        }
                    }
                }
            } while(true);
        }
    }

    public boolean a(boolean flag)
    {
        int i = K.size();
        if(i != L.size())
            throw new IllegalStateException("TickNextTick list out of synch");
        if(i > 1000)
            i = 1000;
        for(int j = 0; j < i; j++)
        {
            NextTickListEntry nextticklistentry = (NextTickListEntry)K.first();
            if(!flag && nextticklistentry.e > worldData.f())
                break;
            K.remove(nextticklistentry);
            L.remove(nextticklistentry);
            byte b0 = 8;
            if(!a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0))
                continue;
            int k = getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
            if(k == nextticklistentry.d && k > 0)
                Block.byId[k].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, random);
        }

        return K.size() != 0;
    }

    public List a(Chunk chunk, boolean flag)
    {
        ArrayList arraylist = null;
        ChunkCoordIntPair chunkcoordintpair = chunk.j();
        int i = chunkcoordintpair.x << 4;
        int j = i + 16;
        int k = chunkcoordintpair.z << 4;
        int l = k + 16;
        Iterator iterator = L.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            NextTickListEntry nextticklistentry = (NextTickListEntry)iterator.next();
            if(nextticklistentry.a >= i && nextticklistentry.a < j && nextticklistentry.c >= k && nextticklistentry.c < l)
            {
                if(flag)
                {
                    K.remove(nextticklistentry);
                    iterator.remove();
                }
                if(arraylist == null)
                    arraylist = new ArrayList();
                arraylist.add(nextticklistentry);
            }
        } while(true);
        return arraylist;
    }

    public List b(Entity entity, AxisAlignedBB axisalignedbb)
    {
        V.clear();
        int i = MathHelper.floor((axisalignedbb.a - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.d + 2D) / 16D);
        int k = MathHelper.floor((axisalignedbb.c - 2D) / 16D);
        int l = MathHelper.floor((axisalignedbb.f + 2D) / 16D);
        for(int i1 = i; i1 <= j; i1++)
        {
            for(int j1 = k; j1 <= l; j1++)
                if(isChunkLoaded(i1, j1))
                    getChunkAt(i1, j1).a(entity, axisalignedbb, V);

        }

        return V;
    }

    public List a(Class oclass, AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor((axisalignedbb.a - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.d + 2D) / 16D);
        int k = MathHelper.floor((axisalignedbb.c - 2D) / 16D);
        int l = MathHelper.floor((axisalignedbb.f + 2D) / 16D);
        ArrayList arraylist = new ArrayList();
        for(int i1 = i; i1 <= j; i1++)
        {
            for(int j1 = k; j1 <= l; j1++)
                if(isChunkLoaded(i1, j1))
                    getChunkAt(i1, j1).a(oclass, axisalignedbb, arraylist);

        }

        return arraylist;
    }

    public void b(int i, int j, int k, TileEntity tileentity)
    {
        if(isLoaded(i, j, k))
            getChunkAtWorldCoords(i, k).f();
        for(int l = 0; l < z.size(); l++)
            ((IWorldAccess)z.get(l)).a(i, j, k, tileentity);

    }

    public int a(Class oclass)
    {
        int i = 0;
        for(int j = 0; j < entityList.size(); j++)
        {
            Entity entity = (Entity)entityList.get(j);
            if(oclass.isAssignableFrom(entity.getClass()))
                i++;
        }

        return i;
    }

    public void a(List list)
    {
        Entity entity = null;
        for(int i = 0; i < list.size(); i++)
        {
            entity = (Entity)list.get(i);
            if(entity != null)
            {
                entityList.add(entity);
                c((Entity)list.get(i));
            }
        }

    }

    public void b(List list)
    {
        J.addAll(list);
    }

    public boolean a(int i, int j, int k, int l, boolean flag, int i1)
    {
        int j1 = getTypeId(j, k, l);
        net.minecraft.server.Block block = Block.byId[j1];
        net.minecraft.server.Block block1 = Block.byId[i];
        AxisAlignedBB axisalignedbb = block1.e(this, j, k, l);
        if(flag)
            axisalignedbb = null;
        boolean defaultReturn;
        if(axisalignedbb != null && !containsEntity(axisalignedbb))
        {
            defaultReturn = false;
        } else
        {
            if(block == Block.WATER || block == Block.STATIONARY_WATER || block == Block.LAVA || block == Block.STATIONARY_LAVA || block == Block.FIRE || block == Block.SNOW || block == Block.VINE)
                block = null;
            defaultReturn = i > 0 && block == null && block1.canPlace(this, j, k, l, i1);
        }
        BlockCanBuildEvent event = new BlockCanBuildEvent(getWorld().getBlockAt(j, k, l), i, defaultReturn);
        getServer().getPluginManager().callEvent(event);
        return event.isBuildable();
    }

    public PathEntity findPath(Entity entity, Entity entity1, float f)
    {
        int i = MathHelper.floor(entity.locX);
        int j = MathHelper.floor(entity.locY);
        int k = MathHelper.floor(entity.locZ);
        int l = (int)(f + 16F);
        int i1 = i - l;
        int j1 = j - l;
        int k1 = k - l;
        int l1 = i + l;
        int i2 = j + l;
        int j2 = k + l;
        ChunkCache chunkcache = new ChunkCache(this, i1, j1, k1, l1, i2, j2);
        PathEntity pathentity = (new Pathfinder(chunkcache)).a(entity, entity1, f);
        return pathentity;
    }

    public PathEntity a(Entity entity, int i, int j, int k, float f)
    {
        int l = MathHelper.floor(entity.locX);
        int i1 = MathHelper.floor(entity.locY);
        int j1 = MathHelper.floor(entity.locZ);
        int k1 = (int)(f + 8F);
        int l1 = l - k1;
        int i2 = i1 - k1;
        int j2 = j1 - k1;
        int k2 = l + k1;
        int l2 = i1 + k1;
        int i3 = j1 + k1;
        ChunkCache chunkcache = new ChunkCache(this, l1, i2, j2, k2, l2, i3);
        PathEntity pathentity = (new Pathfinder(chunkcache)).a(entity, i, j, k, f);
        return pathentity;
    }

    public boolean isBlockFacePowered(int i, int j, int k, int l)
    {
        int i1 = getTypeId(i, j, k);
        return i1 != 0 ? Block.byId[i1].d(this, i, j, k, l) : false;
    }

    public boolean isBlockPowered(int i, int j, int k)
    {
        return isBlockFacePowered(i, j - 1, k, 0) ? true : isBlockFacePowered(i, j + 1, k, 1) ? true : isBlockFacePowered(i, j, k - 1, 2) ? true : isBlockFacePowered(i, j, k + 1, 3) ? true : isBlockFacePowered(i - 1, j, k, 4) ? true : isBlockFacePowered(i + 1, j, k, 5);
    }

    public boolean isBlockFaceIndirectlyPowered(int i, int j, int k, int l)
    {
        if(e(i, j, k))
        {
            return isBlockPowered(i, j, k);
        } else
        {
            int i1 = getTypeId(i, j, k);
            return i1 != 0 ? Block.byId[i1].a(this, i, j, k, l) : false;
        }
    }

    public boolean isBlockIndirectlyPowered(int i, int j, int k)
    {
        return isBlockFaceIndirectlyPowered(i, j - 1, k, 0) ? true : isBlockFaceIndirectlyPowered(i, j + 1, k, 1) ? true : isBlockFaceIndirectlyPowered(i, j, k - 1, 2) ? true : isBlockFaceIndirectlyPowered(i, j, k + 1, 3) ? true : isBlockFaceIndirectlyPowered(i - 1, j, k, 4) ? true : isBlockFaceIndirectlyPowered(i + 1, j, k, 5);
    }

    public EntityHuman findNearbyPlayer(Entity entity, double d0)
    {
        return a(entity.locX, entity.locY, entity.locZ, d0);
    }

    public EntityHuman a(double d0, double d1, double d2, double d3)
    {
        double d4 = -1D;
        EntityHuman entityhuman = null;
        for(int i = 0; i < players.size(); i++)
        {
            EntityHuman entityhuman1 = (EntityHuman)players.get(i);
            if(entityhuman1 == null || entityhuman1.dead)
                continue;
            double d5 = entityhuman1.e(d0, d1, d2);
            if((d3 < 0.0D || d5 < d3 * d3) && (d4 == -1D || d5 < d4))
            {
                d4 = d5;
                entityhuman = entityhuman1;
            }
        }

        return entityhuman;
    }

    public EntityHuman b(Entity entity, double d0)
    {
        return b(entity.locX, entity.locY, entity.locZ, d0);
    }

    public EntityHuman b(double d0, double d1, double d2, double d3)
    {
        double d4 = -1D;
        EntityHuman entityhuman = null;
        for(int i = 0; i < players.size(); i++)
        {
            EntityHuman entityhuman1 = (EntityHuman)players.get(i);
            if(entityhuman1.abilities.isInvulnerable)
                continue;
            double d5 = entityhuman1.e(d0, d1, d2);
            if((d3 < 0.0D || d5 < d3 * d3) && (d4 == -1D || d5 < d4))
            {
                d4 = d5;
                entityhuman = entityhuman1;
            }
        }

        return entityhuman;
    }

    public EntityHuman a(String s)
    {
        for(int i = 0; i < players.size(); i++)
            if(s.equals(((EntityHuman)players.get(i)).name))
                return (EntityHuman)players.get(i);

        return null;
    }

    public byte[] getMultiChunkData(int i, int j, int k, int l, int i1, int j1)
    {
        byte abyte[] = new byte[(l * i1 * j1 * 5) / 2];
        int k1 = i >> 4;
        int l1 = k >> 4;
        int i2 = (i + l) - 1 >> 4;
        int j2 = (k + j1) - 1 >> 4;
        int k2 = 0;
        int l2 = j;
        int i3 = j + i1;
        if(j < 0)
            l2 = 0;
        if(i3 > height)
            i3 = height;
        for(int j3 = k1; j3 <= i2; j3++)
        {
            int k3 = i - j3 * 16;
            int l3 = (i + l) - j3 * 16;
            if(k3 < 0)
                k3 = 0;
            if(l3 > 16)
                l3 = 16;
            for(int i4 = l1; i4 <= j2; i4++)
            {
                int j4 = k - i4 * 16;
                int k4 = (k + j1) - i4 * 16;
                if(j4 < 0)
                    j4 = 0;
                if(k4 > 16)
                    k4 = 16;
                k2 = getChunkAt(j3, i4).getData(abyte, k3, l2, j4, l3, i3, k4, k2);
            }

        }

        return abyte;
    }

    public void l()
    {
        B.b();
    }

    public void setTime(long i)
    {
        worldData.a(i);
    }

    public void setTimeAndFixTicklists(long i)
    {
        long j = i - worldData.f();
        for(Iterator iterator = L.iterator(); iterator.hasNext();)
        {
            NextTickListEntry nextticklistentry = (NextTickListEntry)iterator.next();
            nextticklistentry.e += j;
        }

        setTime(i);
    }

    public long getSeed()
    {
        return worldData.getSeed();
    }

    public long getTime()
    {
        return worldData.f();
    }

    public ChunkCoordinates getSpawn()
    {
        return new ChunkCoordinates(worldData.c(), worldData.d(), worldData.e());
    }

    public boolean a(EntityHuman entityhuman, int i, int j, int i1)
    {
        return true;
    }

    public void a(Entity entity1, byte byte0)
    {
    }

    public IChunkProvider p()
    {
        return chunkProvider;
    }

    public void playNote(int i, int j, int k, int l, int i1)
    {
        int j1 = getTypeId(i, j, k);
        if(j1 > 0)
            Block.byId[j1].a(this, i, j, k, l, i1);
    }

    public IDataManager q()
    {
        return B;
    }

    public WorldData r()
    {
        return worldData;
    }

    public void everyoneSleeping()
    {
        Q = !players.isEmpty();
        Iterator iterator = players.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityHuman entityhuman = (EntityHuman)iterator.next();
            if(entityhuman.isSleeping() || entityhuman.fauxSleeping)
                continue;
            Q = false;
            break;
        } while(true);
    }

    public void checkSleepStatus()
    {
        if(!isStatic)
            everyoneSleeping();
    }

    protected void t()
    {
        Q = false;
        Iterator iterator = players.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityHuman entityhuman = (EntityHuman)iterator.next();
            if(entityhuman.isSleeping())
                entityhuman.a(false, false, true);
        } while(true);
        A();
    }

    public boolean everyoneDeeplySleeping()
    {
        if(Q && !isStatic)
        {
            Iterator iterator = players.iterator();
            boolean foundActualSleepers = false;
            EntityHuman entityhuman;
            do
            {
                if(!iterator.hasNext())
                    return foundActualSleepers;
                entityhuman = (EntityHuman)iterator.next();
                if(entityhuman.isDeeplySleeping())
                    foundActualSleepers = true;
            } while(entityhuman.isDeeplySleeping() || entityhuman.fauxSleeping);
            return false;
        } else
        {
            return false;
        }
    }

    public float c(float f)
    {
        return (p + (q - p) * f) * d(f);
    }

    public float d(float f)
    {
        return n + (o - n) * f;
    }

    public boolean v()
    {
        return (double)c(1.0F) > 0.90000000000000002D;
    }

    public boolean w()
    {
        return (double)d(1.0F) > 0.20000000000000001D;
    }

    public boolean v(int i, int j, int k)
    {
        if(!w())
            return false;
        if(!isChunkLoaded(i, j, k))
            return false;
        if(e(i, k) > j)
        {
            return false;
        } else
        {
            BiomeBase biomebase = getWorldChunkManager().getBiome(i, k);
            return biomebase.b() ? false : biomebase.c();
        }
    }

    public void a(String s, WorldMapBase worldmapbase)
    {
        worldMaps.a(s, worldmapbase);
    }

    public WorldMapBase a(Class oclass, String s)
    {
        return worldMaps.a(oclass, s);
    }

    public int b(String s)
    {
        return worldMaps.a(s);
    }

    public void f(int i, int j, int k, int l, int i1)
    {
        a((EntityHuman)null, i, j, k, l, i1);
    }

    public void a(EntityHuman entityhuman, int i, int j, int k, int l, int i1)
    {
        for(int j1 = 0; j1 < z.size(); j1++)
            ((IWorldAccess)z.get(j1)).a(entityhuman, i, j, k, l, i1);

    }

    public Random w(int i, int j, int k)
    {
        long l = (long)i * 0x4f9939f508L + (long)j * 0x1ef1565bd5L + r().getSeed() + (long)k;
        random.setSeed(l);
        return random;
    }

    public boolean x()
    {
        return false;
    }

    public void a(EnumSkyBlock enumskyblock1, int k1, int l1, int i2, int j2, int k2, int l2)
    {
    }

    public BiomeMeta a(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        List list = p().a(enumcreaturetype, i, j, k);
        return list == null || list.isEmpty() ? null : (BiomeMeta)WeightedRandom.a(random, list);
    }

    public ChunkPosition b(String s, int i, int j, int k)
    {
        return p().a(this, s, i, j, k);
    }

    public UUID getUUID()
    {
        return B.getUUID();
    }

    public int heightBits;
    public int heightBitsPlusFour;
    public int height;
    public int heightMinusOne;
    public int seaLevel;
    public boolean f;
    public List entityList;
    private List J;
    private TreeSet K;
    private Set L;
    public List h;
    private List M;
    private List N;
    public List players;
    public List j;
    private long O;
    public int k;
    protected int l;
    protected final int m = 0x3c6ef35f;
    protected float n;
    protected float o;
    protected float p;
    protected float q;
    protected int r;
    public int s;
    public boolean suppressPhysics;
    private long P;
    protected int u;
    public int difficulty;
    public Random random;
    public boolean x;
    public WorldProvider worldProvider;
    protected List z;
    public IChunkProvider chunkProvider;
    protected final IDataManager B;
    public WorldData worldData;
    public boolean isLoading;
    private boolean Q;
    public WorldMapCollection worldMaps;
    private ArrayList R;
    private boolean S;
    public boolean allowMonsters;
    public boolean allowAnimals;
    private Set T;
    private int U;
    int H[];
    private List V;
    public boolean isStatic;
    private final CraftWorld world;
    public boolean pvpMode;
    public boolean keepSpawnInMemory;
    public ChunkGenerator generator;
    Chunk lastChunkAccessed;
    int lastXAccessed;
    int lastZAccessed;
    final Object chunkLock = new Object();
}
