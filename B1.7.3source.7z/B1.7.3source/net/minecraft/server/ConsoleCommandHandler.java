// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsoleCommandHandler.java

package net.minecraft.server;

import java.util.*;
import java.util.logging.Logger;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.command.ColouredConsoleSender;
import org.bukkit.craftbukkit.command.ServerCommandListener;
import org.bukkit.craftbukkit.entity.CraftPlayer;

// Referenced classes of package net.minecraft.server:
//            NetServerHandler, ServerGUI, MinecraftServer, WorldServer, 
//            IProgressUpdate, EntityPlayer, ItemStack, Packet3Chat, 
//            ICommandListener, ServerCommand, ServerConfigurationManager, Item, 
//            PropertyManager

public class ConsoleCommandHandler
{

    public ConsoleCommandHandler(MinecraftServer minecraftserver)
    {
        server = minecraftserver;
    }

    private boolean hasPermission(ICommandListener listener, String perm)
    {
        if(listener instanceof ServerCommandListener)
        {
            ServerCommandListener serv = (ServerCommandListener)listener;
            return serv.getSender().hasPermission(perm);
        }
        if(listener instanceof NetServerHandler)
        {
            NetServerHandler net = (NetServerHandler)listener;
            return net.getPlayer().hasPermission(perm);
        }
        if((listener instanceof ServerGUI) || (listener instanceof MinecraftServer))
            return server.console.hasPermission(perm);
        else
            return false;
    }

    private boolean checkPermission(ICommandListener listener, String command)
    {
        if(hasPermission(listener, (new StringBuilder()).append("bukkit.command.").append(command).toString()))
        {
            return true;
        } else
        {
            listener.sendMessage("I'm sorry, Dave, but I cannot let you do that.");
            return false;
        }
    }

    public boolean handle(ServerCommand servercommand)
    {
        String s;
        ICommandListener icommandlistener;
        String s1;
        ServerConfigurationManager serverconfigurationmanager;
label0:
        {
            s = servercommand.command;
            icommandlistener = servercommand.b;
            s1 = icommandlistener.getName();
            listener = icommandlistener;
            serverconfigurationmanager = server.serverConfigurationManager;
            if(s.toLowerCase().startsWith("help") || s.toLowerCase().startsWith("?"))
                break MISSING_BLOCK_LABEL_2391;
            if(s.toLowerCase().startsWith("list"))
            {
                if(!checkPermission(listener, "list"))
                    return true;
                icommandlistener.sendMessage((new StringBuilder()).append("Connected players: ").append(serverconfigurationmanager.c()).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("stop"))
            {
                if(!checkPermission(listener, "stop"))
                    return true;
                print(s1, "Stopping the server..");
                server.a();
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("save-all"))
            {
                if(!checkPermission(listener, "save.perform"))
                    return true;
                print(s1, "Forcing save..");
                if(serverconfigurationmanager != null)
                    serverconfigurationmanager.savePlayers();
                for(int i = 0; i < server.worlds.size(); i++)
                {
                    WorldServer worldserver = (WorldServer)server.worlds.get(i);
                    boolean save = worldserver.canSave;
                    worldserver.canSave = false;
                    worldserver.save(true, (IProgressUpdate)null);
                    worldserver.canSave = save;
                }

                print(s1, "Save complete.");
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("save-off"))
            {
                if(!checkPermission(listener, "save.disable"))
                    return true;
                print(s1, "Disabling level saving..");
                for(int i = 0; i < server.worlds.size(); i++)
                {
                    WorldServer worldserver = (WorldServer)server.worlds.get(i);
                    worldserver.canSave = true;
                }

                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("save-on"))
            {
                if(!checkPermission(listener, "save.enable"))
                    return true;
                print(s1, "Enabling level saving..");
                for(int i = 0; i < server.worlds.size(); i++)
                {
                    WorldServer worldserver = (WorldServer)server.worlds.get(i);
                    worldserver.canSave = false;
                }

                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("op "))
            {
                if(!checkPermission(listener, "op.give"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.e(s2);
                print(s1, (new StringBuilder()).append("Opping ").append(s2).toString());
                serverconfigurationmanager.a(s2, "\247eYou are now op!");
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("deop "))
            {
                if(!checkPermission(listener, "op.take"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.f(s2);
                serverconfigurationmanager.a(s2, "\247eYou are no longer op!");
                print(s1, (new StringBuilder()).append("De-opping ").append(s2).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("ban-ip "))
            {
                if(!checkPermission(listener, "ban.ip"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.c(s2);
                print(s1, (new StringBuilder()).append("Banning ip ").append(s2).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("pardon-ip "))
            {
                if(!checkPermission(listener, "unban.ip"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.d(s2);
                print(s1, (new StringBuilder()).append("Pardoning ip ").append(s2).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("ban "))
            {
                if(!checkPermission(listener, "ban.player"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.a(s2);
                print(s1, (new StringBuilder()).append("Banning ").append(s2).toString());
                EntityPlayer entityplayer = serverconfigurationmanager.i(s2);
                if(entityplayer != null)
                    entityplayer.netServerHandler.disconnect("Banned by admin");
                break MISSING_BLOCK_LABEL_2411;
            }
            if(s.toLowerCase().startsWith("pardon "))
            {
                if(!checkPermission(listener, "unban.player"))
                    return true;
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.b(s2);
                print(s1, (new StringBuilder()).append("Pardoning ").append(s2).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            int j;
            if(s.toLowerCase().startsWith("kick "))
            {
                if(!checkPermission(listener, "kick"))
                    return true;
                String parts[] = s.split(" ");
                String s2 = parts.length < 2 ? "" : parts[1];
                EntityPlayer entityplayer = null;
                for(j = 0; j < serverconfigurationmanager.players.size(); j++)
                {
                    EntityPlayer entityplayer1 = (EntityPlayer)serverconfigurationmanager.players.get(j);
                    if(entityplayer1.name.equalsIgnoreCase(s2))
                        entityplayer = entityplayer1;
                }

                if(entityplayer != null)
                {
                    entityplayer.netServerHandler.disconnect("Kicked by admin");
                    print(s1, (new StringBuilder()).append("Kicking ").append(entityplayer.name).toString());
                } else
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s2).append(". No kick.").toString());
                }
                break MISSING_BLOCK_LABEL_2411;
            }
            String astring[];
            if(s.toLowerCase().startsWith("tp "))
            {
                if(!checkPermission(listener, "teleport"))
                    return true;
                astring = s.split(" ");
                if(astring.length == 3)
                {
                    EntityPlayer entityplayer = serverconfigurationmanager.i(astring[1]);
                    EntityPlayer entityplayer2 = serverconfigurationmanager.i(astring[2]);
                    if(entityplayer == null)
                        icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(astring[1]).append(". No tp.").toString());
                    else
                    if(entityplayer2 == null)
                        icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(astring[2]).append(". No tp.").toString());
                    else
                    if(entityplayer.dimension != entityplayer2.dimension)
                    {
                        icommandlistener.sendMessage((new StringBuilder()).append("User ").append(astring[1]).append(" and ").append(astring[2]).append(" are in different dimensions. No tp.").toString());
                    } else
                    {
                        entityplayer.netServerHandler.a(entityplayer2.locX, entityplayer2.locY, entityplayer2.locZ, entityplayer2.yaw, entityplayer2.pitch);
                        print(s1, (new StringBuilder()).append("Teleporting ").append(astring[1]).append(" to ").append(astring[2]).append(".").toString());
                    }
                } else
                {
                    icommandlistener.sendMessage("Syntax error, please provice a source and a target.");
                }
                break MISSING_BLOCK_LABEL_2411;
            }
            String s3;
            int k;
            if(s.toLowerCase().startsWith("give "))
            {
                if(!checkPermission(listener, "give"))
                    return true;
                astring = s.split(" ");
                if(astring.length != 3 && astring.length != 4)
                    return true;
                s3 = astring[1];
                EntityPlayer entityplayer2 = serverconfigurationmanager.i(s3);
                if(entityplayer2 != null)
                    try
                    {
                        k = Integer.parseInt(astring[2]);
                        if(Item.byId[k] != null)
                        {
                            print(s1, (new StringBuilder()).append("Giving ").append(entityplayer2.name).append(" some ").append(k).toString());
                            int l = 1;
                            if(astring.length > 3)
                                l = a(astring[3], 1);
                            if(l < 1)
                                l = 1;
                            if(l > 64)
                                l = 64;
                            entityplayer2.b(new ItemStack(k, l, 0));
                        } else
                        {
                            icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(k).toString());
                        }
                    }
                    catch(NumberFormatException numberformatexception)
                    {
                        icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(astring[2]).toString());
                    }
                else
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s3).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
            if(!s.toLowerCase().startsWith("time "))
                break label0;
            astring = s.split(" ");
            if(astring.length != 3)
                return true;
            s3 = astring[1];
            WorldServer worldserver1;
            try
            {
                j = Integer.parseInt(astring[2]);
                if(!"add".equalsIgnoreCase(s3))
                    break MISSING_BLOCK_LABEL_1909;
                if(!checkPermission(listener, "time.add"))
                    return true;
            }
            catch(NumberFormatException numberformatexception1)
            {
                icommandlistener.sendMessage((new StringBuilder()).append("Unable to convert time value, ").append(astring[2]).toString());
                break MISSING_BLOCK_LABEL_2411;
            }
        }
        for(k = 0; k < server.worlds.size(); k++)
        {
            worldserver1 = (WorldServer)server.worlds.get(k);
            worldserver1.setTimeAndFixTicklists(worldserver1.getTime() + (long)j);
        }

        print(s1, (new StringBuilder()).append("Added ").append(j).append(" to time").toString());
        break MISSING_BLOCK_LABEL_2411;
        if(!"set".equalsIgnoreCase(s3))
            break MISSING_BLOCK_LABEL_2016;
        if(!checkPermission(listener, "time.set"))
            return true;
        for(k = 0; k < server.worlds.size(); k++)
        {
            worldserver1 = (WorldServer)server.worlds.get(k);
            worldserver1.setTimeAndFixTicklists(j);
        }

        print(s1, (new StringBuilder()).append("Set time to ").append(j).toString());
        break MISSING_BLOCK_LABEL_2411;
        icommandlistener.sendMessage("Unknown method, use either \"add\" or \"set\"");
        break MISSING_BLOCK_LABEL_2411;
        if(s.toLowerCase().startsWith("say "))
        {
            if(!checkPermission(listener, "say"))
                return true;
            s = s.substring(s.indexOf(" ")).trim();
            a.info((new StringBuilder()).append("[").append(s1).append("] ").append(s).toString());
            serverconfigurationmanager.sendAll(new Packet3Chat((new StringBuilder()).append("\247d[Server] ").append(s).toString()));
        } else
        if(s.toLowerCase().startsWith("tell "))
        {
            if(!checkPermission(listener, "tell"))
                return true;
            String astring[] = s.split(" ");
            if(astring.length >= 3)
            {
                s = s.substring(s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();
                a.info((new StringBuilder()).append("[").append(s1).append("->").append(astring[1]).append("] ").append(s).toString());
                s = (new StringBuilder()).append("\2477").append(s1).append(" whispers ").append(s).toString();
                a.info(s);
                if(!serverconfigurationmanager.a(astring[1], new Packet3Chat(s)))
                    icommandlistener.sendMessage("There's no player by that name online.");
            }
        } else
        if(s.toLowerCase().startsWith("whitelist "))
        {
            a(s1, s, icommandlistener);
        } else
        {
            icommandlistener.sendMessage("Unknown console command. Type \"help\" for help.");
            return false;
        }
        break MISSING_BLOCK_LABEL_2411;
        if(!checkPermission(listener, "help"))
            return true;
        a(icommandlistener);
        return true;
    }

    private void a(String s, String s1, ICommandListener icommandlistener)
    {
        String astring[] = s1.split(" ");
        listener = icommandlistener;
        if(astring.length >= 2)
        {
            String s2 = astring[1].toLowerCase();
            if("on".equals(s2))
            {
                if(!checkPermission(listener, "whitelist.enable"))
                    return;
                print(s, "Turned on white-listing");
                server.propertyManager.b("white-list", true);
            } else
            if("off".equals(s2))
            {
                if(!checkPermission(listener, "whitelist.disable"))
                    return;
                print(s, "Turned off white-listing");
                server.propertyManager.b("white-list", false);
            } else
            if("list".equals(s2))
            {
                if(!checkPermission(listener, "whitelist.list"))
                    return;
                Set set = server.serverConfigurationManager.e();
                String s3 = "";
                for(Iterator iterator = set.iterator(); iterator.hasNext();)
                {
                    String s4 = (String)iterator.next();
                    s3 = (new StringBuilder()).append(s3).append(s4).append(" ").toString();
                }

                icommandlistener.sendMessage((new StringBuilder()).append("White-listed players: ").append(s3).toString());
            } else
            if("add".equals(s2) && astring.length == 3)
            {
                if(!checkPermission(listener, "whitelist.add"))
                    return;
                String s5 = astring[2].toLowerCase();
                server.serverConfigurationManager.k(s5);
                print(s, (new StringBuilder()).append("Added ").append(s5).append(" to white-list").toString());
            } else
            if("remove".equals(s2) && astring.length == 3)
            {
                if(!checkPermission(listener, "whitelist.remove"))
                    return;
                String s5 = astring[2].toLowerCase();
                server.serverConfigurationManager.l(s5);
                print(s, (new StringBuilder()).append("Removed ").append(s5).append(" from white-list").toString());
            } else
            if("reload".equals(s2))
            {
                if(!checkPermission(listener, "whitelist.reload"))
                    return;
                server.serverConfigurationManager.f();
                print(s, "Reloaded white-list from file");
            }
        }
    }

    private void a(ICommandListener icommandlistener)
    {
        icommandlistener.sendMessage("To run the server without a gui, start it like this:");
        icommandlistener.sendMessage("   java -Xmx1024M -Xms1024M -jar minecraft_server.jar nogui");
        icommandlistener.sendMessage("Console commands:");
        icommandlistener.sendMessage("   help  or  ?               shows this message");
        icommandlistener.sendMessage("   kick <player>             removes a player from the server");
        icommandlistener.sendMessage("   ban <player>              bans a player from the server");
        icommandlistener.sendMessage("   pardon <player>           pardons a banned player so that they can connect again");
        icommandlistener.sendMessage("   ban-ip <ip>               bans an IP address from the server");
        icommandlistener.sendMessage("   pardon-ip <ip>            pardons a banned IP address so that they can connect again");
        icommandlistener.sendMessage("   op <player>               turns a player into an op");
        icommandlistener.sendMessage("   deop <player>             removes op status from a player");
        icommandlistener.sendMessage("   tp <player1> <player2>    moves one player to the same location as another player");
        icommandlistener.sendMessage("   give <player> <id> [num]  gives a player a resource");
        icommandlistener.sendMessage("   tell <player> <message>   sends a private message to a player");
        icommandlistener.sendMessage("   stop                      gracefully stops the server");
        icommandlistener.sendMessage("   save-all                  forces a server-wide level save");
        icommandlistener.sendMessage("   save-off                  disables terrain saving (useful for backup scripts)");
        icommandlistener.sendMessage("   save-on                   re-enables terrain saving");
        icommandlistener.sendMessage("   list                      lists all currently connected players");
        icommandlistener.sendMessage("   say <message>             broadcasts a message to all players");
        icommandlistener.sendMessage("   time <add|set> <amount>   adds to or sets the world time (0-24000)");
    }

    private void print(String s, String s1)
    {
        String s2 = (new StringBuilder()).append(s).append(": ").append(s1).toString();
        listener.sendMessage(s1);
        informOps((new StringBuilder()).append("\2477(").append(s2).append(")").toString());
        if(listener instanceof MinecraftServer)
        {
            return;
        } else
        {
            a.info(s2);
            return;
        }
    }

    private void informOps(String msg)
    {
        Packet3Chat packet3chat = new Packet3Chat(msg);
        EntityPlayer sender = null;
        if(listener instanceof ServerCommandListener)
        {
            CommandSender commandSender = ((ServerCommandListener)listener).getSender();
            if(commandSender instanceof CraftPlayer)
                sender = ((CraftPlayer)commandSender).getHandle();
        }
        List players = server.serverConfigurationManager.players;
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityPlayer = (EntityPlayer)players.get(i);
            if(sender != entityPlayer && server.serverConfigurationManager.isOp(entityPlayer.name))
                entityPlayer.netServerHandler.sendPacket(packet3chat);
        }

    }

    private int a(String s, int i)
    {
        try
        {
            return Integer.parseInt(s);
        }
        catch(NumberFormatException numberformatexception)
        {
            return i;
        }
    }

    private static Logger a = Logger.getLogger("Minecraft");
    private MinecraftServer server;
    private ICommandListener listener;

}
