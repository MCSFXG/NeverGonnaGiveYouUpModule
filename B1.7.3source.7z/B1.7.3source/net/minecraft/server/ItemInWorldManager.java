// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ItemInWorldManager.java

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityPlayer, Packet53BlockChange, EntityHuman, WorldServer, 
//            Block, InventoryPlayer, NetServerHandler, ItemStack, 
//            World

public class ItemInWorldManager
{

    public ItemInWorldManager(WorldServer worldserver)
    {
        c = 0.0F;
        world = worldserver;
    }

    public void a()
    {
        currentTick = (int)(System.currentTimeMillis() / 50L);
        if(this.i)
        {
            int i = currentTick - m;
            int j = world.getTypeId(this.j, k, l);
            if(j != 0)
            {
                Block block = Block.byId[j];
                float f = block.getDamage(player) * (float)(i + 1);
                if(f >= 1.0F)
                {
                    this.i = false;
                    c(this.j, k, l);
                }
            } else
            {
                this.i = false;
            }
        }
    }

    public void dig(int i, int j, int k, int l)
    {
        lastDigTick = (int)(System.currentTimeMillis() / 50L);
        int i1 = world.getTypeId(i, j, k);
        if(i1 <= 0)
            return;
        PlayerInteractEvent event = CraftEventFactory.callPlayerInteractEvent(player, Action.LEFT_CLICK_BLOCK, i, j, k, l, player.inventory.getItemInHand());
        if(event.useInteractedBlock() == org.bukkit.event.Event.Result.DENY)
        {
            if(i1 == Block.WOODEN_DOOR.id)
            {
                boolean bottom = (world.getData(i, j, k) & 8) == 0;
                ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j, k, world));
                ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j + (bottom ? 1 : -1), k, world));
            } else
            if(i1 == Block.TRAP_DOOR.id)
                ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j, k, world));
        } else
        {
            Block.byId[i1].b(world, i, j, k, player);
            world.douseFire((EntityHuman)null, i, j, k, l);
        }
        float toolDamage = Block.byId[i1].getDamage(player);
        if(event.useItemInHand() == org.bukkit.event.Event.Result.DENY)
        {
            if(toolDamage > 1.0F)
                ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j, k, world));
            return;
        }
        BlockDamageEvent blockEvent = CraftEventFactory.callBlockDamageEvent(player, i, j, k, player.inventory.getItemInHand(), toolDamage >= 1.0F);
        if(blockEvent.isCancelled())
            return;
        if(blockEvent.getInstaBreak())
            toolDamage = 2.0F;
        if(toolDamage >= 1.0F)
        {
            c(i, j, k);
        } else
        {
            e = i;
            f = j;
            g = k;
        }
    }

    public void a(int i, int j, int k)
    {
        if(i == e && j == this.f && k == g)
        {
            currentTick = (int)(System.currentTimeMillis() / 50L);
            int l = currentTick - lastDigTick;
            int i1 = world.getTypeId(i, j, k);
            if(i1 != 0)
            {
                Block block = Block.byId[i1];
                float f = block.getDamage(player) * (float)(l + 1);
                if(f >= 0.7F)
                    c(i, j, k);
                else
                if(!this.i)
                {
                    this.i = true;
                    this.j = i;
                    this.k = j;
                    this.l = k;
                    m = lastDigTick;
                }
            }
        } else
        {
            ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j, k, world));
        }
        c = 0.0F;
    }

    public boolean b(int i, int j, int k)
    {
        Block block = Block.byId[world.getTypeId(i, j, k)];
        int l = world.getData(i, j, k);
        boolean flag = world.setTypeId(i, j, k, 0);
        if(block != null && flag)
            block.postBreak(world, i, j, k, l);
        return flag;
    }

    public boolean c(int i, int j, int k)
    {
        if(player instanceof EntityPlayer)
        {
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            BlockBreakEvent event = new BlockBreakEvent(block, (Player)player.getBukkitEntity());
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return false;
        }
        int l = world.getTypeId(i, j, k);
        int i1 = world.getData(i, j, k);
        world.a(player, 2001, i, j, k, l + world.getData(i, j, k) * 256);
        boolean flag = b(i, j, k);
        ItemStack itemstack = player.G();
        if(itemstack != null)
        {
            itemstack.a(l, i, j, k, player);
            if(itemstack.count == 0)
            {
                itemstack.a(player);
                player.H();
            }
        }
        if(flag && player.b(Block.byId[l]))
        {
            Block.byId[l].a(world, player, i, j, k, i1);
            ((EntityPlayer)player).netServerHandler.sendPacket(new Packet53BlockChange(i, j, k, world));
        }
        return flag;
    }

    public boolean useItem(EntityHuman entityhuman, World world, ItemStack itemstack)
    {
        int i = itemstack.count;
        ItemStack itemstack1 = itemstack.a(world, entityhuman);
        if(itemstack1 == itemstack && (itemstack1 == null || itemstack1.count == i))
            return false;
        entityhuman.inventory.items[entityhuman.inventory.itemInHandIndex] = itemstack1;
        if(itemstack1.count == 0)
            entityhuman.inventory.items[entityhuman.inventory.itemInHandIndex] = null;
        return true;
    }

    public boolean interact(EntityHuman entityhuman, World world, ItemStack itemstack, int i, int j, int k, int l)
    {
        int i1 = world.getTypeId(i, j, k);
        boolean result = false;
        if(i1 > 0)
        {
            PlayerInteractEvent event = CraftEventFactory.callPlayerInteractEvent(entityhuman, Action.RIGHT_CLICK_BLOCK, i, j, k, l, itemstack);
            if(event.useInteractedBlock() == org.bukkit.event.Event.Result.DENY)
            {
                if(i1 == Block.WOODEN_DOOR.id)
                {
                    boolean bottom = (world.getData(i, j, k) & 8) == 0;
                    ((EntityPlayer)entityhuman).netServerHandler.sendPacket(new Packet53BlockChange(i, j + (bottom ? 1 : -1), k, world));
                }
                result = event.useItemInHand() != org.bukkit.event.Event.Result.ALLOW;
            } else
            {
                result = Block.byId[i1].interact(world, i, j, k, entityhuman);
            }
            if(itemstack != null && !result)
                result = itemstack.placeItem(entityhuman, world, i, j, k, l);
            if(itemstack != null && (!result && event.useItemInHand() != org.bukkit.event.Event.Result.DENY || event.useItemInHand() == org.bukkit.event.Event.Result.ALLOW))
                useItem(entityhuman, world, itemstack);
        }
        return result;
    }

    private WorldServer world;
    public EntityHuman player;
    private float c;
    private int lastDigTick;
    private int e;
    private int f;
    private int g;
    private int currentTick;
    private boolean i;
    private int j;
    private int k;
    private int l;
    private int m;
}
