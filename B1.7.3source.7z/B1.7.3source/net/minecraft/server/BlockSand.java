// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, EntityFallingSand, 
//            BlockFire

public class BlockSand extends Block
{

    public BlockSand(int i, int j)
    {
        super(i, j, Material.SAND);
    }

    public void c(World world, int i, int j, int k)
    {
        world.c(i, j, k, id, c());
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        world.c(i, j, k, id, c());
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        g(world, i, j, k);
    }

    private void g(World world, int i, int j, int k)
    {
        int l = i;
        int i1 = j;
        int j1 = k;
        if(c_(world, l, i1 - 1, j1) && i1 >= 0)
        {
            byte byte0 = 32;
            if(instaFall || !world.a(i - byte0, j - byte0, k - byte0, i + byte0, j + byte0, k + byte0))
            {
                world.setTypeId(i, j, k, 0);
                for(; c_(world, i, j - 1, k) && j > 0; j--);
                if(j > 0)
                    world.setTypeId(i, j, k, id);
            } else
            {
                EntityFallingSand entityfallingsand = new EntityFallingSand(world, (float)i + 0.5F, (float)j + 0.5F, (float)k + 0.5F, id);
                world.addEntity(entityfallingsand);
            }
        }
    }

    public int c()
    {
        return 3;
    }

    public static boolean c_(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j, k);
        if(l == 0)
            return true;
        if(l == Block.FIRE.id)
            return true;
        Material material = Block.byId[l].material;
        if(material == Material.WATER)
            return true;
        return material == Material.LAVA;
    }

    public static boolean instaFall = false;

}
