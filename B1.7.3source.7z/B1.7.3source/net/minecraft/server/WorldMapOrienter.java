// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            WorldMap

public class WorldMapOrienter
{

    public WorldMapOrienter(WorldMap worldmap, byte byte0, byte byte1, byte byte2, byte byte3)
    {
        e = worldmap;
        super();
        a = byte0;
        b = byte1;
        c = byte2;
        d = byte3;
    }

    public byte a;
    public byte b;
    public byte c;
    public byte d;
    final WorldMap e;
}
