// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySquid.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Entity;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityWaterAnimal, World, AxisAlignedBB, Material, 
//            MathHelper, NBTTagCompound, EntityHuman

public class EntitySquid extends EntityWaterAnimal
{

    public EntitySquid(net.minecraft.server.World world)
    {
        super(world);
        a = 0.0F;
        b = 0.0F;
        c = 0.0F;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0.0F;
        j = 0.0F;
        k = 0.0F;
        l = 0.0F;
        m = 0.0F;
        n = 0.0F;
        o = 0.0F;
        p = 0.0F;
        texture = "/mob/squid.png";
        b(0.95F, 0.95F);
        l = (1.0F / (random.nextFloat() + 1.0F)) * 0.2F;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected String g()
    {
        return null;
    }

    protected String h()
    {
        return null;
    }

    protected String i()
    {
        return null;
    }

    protected float k()
    {
        return 0.4F;
    }

    protected int j()
    {
        return 0;
    }

    protected void q()
    {
        List loot = new ArrayList();
        int count = random.nextInt(3) + 1;
        if(count > 0)
            loot.add(new ItemStack(Material.INK_SACK, count));
        World bworld = world.getWorld();
        Entity entity = getBukkitEntity();
        EntityDeathEvent event = new EntityDeathEvent(entity, loot);
        world.getServer().getPluginManager().callEvent(event);
        ItemStack stack;
        for(Iterator i$ = event.getDrops().iterator(); i$.hasNext(); bworld.dropItemNaturally(entity.getLocation(), stack))
            stack = (ItemStack)i$.next();

    }

    public boolean a(EntityHuman entityhuman)
    {
        return false;
    }

    public boolean ad()
    {
        return world.a(boundingBox.b(0.0D, -0.60000002384185791D, 0.0D), Material.WATER, this);
    }

    public void v()
    {
        super.v();
        b = a;
        this.f = c;
        h = g;
        j = i;
        g += l;
        if(g > 6.283185F)
        {
            g -= 6.283185F;
            if(random.nextInt(10) == 0)
                l = (1.0F / (random.nextFloat() + 1.0F)) * 0.2F;
        }
        if(ad())
        {
            float f;
            if(g < 3.141593F)
            {
                f = g / 3.141593F;
                i = MathHelper.sin(f * f * 3.141593F) * 3.141593F * 0.25F;
                if((double)f > 0.75D)
                {
                    k = 1.0F;
                    m = 1.0F;
                } else
                {
                    m *= 0.8F;
                }
            } else
            {
                i = 0.0F;
                k *= 0.9F;
                m *= 0.99F;
            }
            if(!Y)
            {
                motX = n * k;
                motY = o * k;
                motZ = p * k;
            }
            f = MathHelper.a(motX * motX + motZ * motZ);
            K += ((-(float)Math.atan2(motX, motZ) * 180F) / 3.141593F - K) * 0.1F;
            yaw = K;
            c += 3.141593F * m * 1.5F;
            a += ((-(float)Math.atan2(f, motY) * 180F) / 3.141593F - a) * 0.1F;
        } else
        {
            i = MathHelper.abs(MathHelper.sin(g)) * 3.141593F * 0.25F;
            if(!Y)
            {
                motX = 0.0D;
                motY -= 0.080000000000000002D;
                motY *= 0.98000001907348633D;
                motZ = 0.0D;
            }
            a = (float)((double)a + (double)(-90F - a) * 0.02D);
        }
    }

    public void a(float f, float f1)
    {
        move(motX, motY, motZ);
    }

    protected void c_()
    {
        if(random.nextInt(50) == 0 || !bA || n == 0.0F && o == 0.0F && p == 0.0F)
        {
            float f = random.nextFloat() * 3.141593F * 2.0F;
            n = MathHelper.cos(f) * 0.2F;
            o = -0.1F + random.nextFloat() * 0.2F;
            p = MathHelper.sin(f) * 0.2F;
        }
        U();
    }

    public float a;
    public float b;
    public float c;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    private float k;
    private float l;
    private float m;
    private float n;
    private float o;
    private float p;
}
