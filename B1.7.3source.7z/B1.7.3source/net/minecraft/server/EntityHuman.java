// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityHuman.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.World;
import org.bukkit.craftbukkit.*;
import org.bukkit.craftbukkit.entity.CraftItem;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityLiving, InventoryPlayer, ContainerPlayer, Entity, 
//            ItemStack, EntityItem, ChunkCoordinates, NBTTagList, 
//            EntityMonster, EntityArrow, EntityCreeper, EntityGhast, 
//            EntityWolf, EntityMinecart, EntityBoat, EntityPig, 
//            World, DataWatcher, Container, StatisticList, 
//            MathHelper, AxisAlignedBB, Item, Material, 
//            NBTTagCompound, EnumBedError, WorldProvider, BlockBed, 
//            Block, IChunkProvider, WorldData, AchievementList, 
//            EntityFish, IInventory, TileEntityFurnace, TileEntityDispenser, 
//            TileEntitySign, Statistic

public abstract class EntityHuman extends EntityLiving
{

    public EntityHuman(net.minecraft.server.World world)
    {
        super(world);
        inventory = new InventoryPlayer(this);
        l = 0;
        m = 0;
        p = false;
        q = 0;
        spawnWorld = "";
        D = 20;
        E = false;
        d = 0;
        hookedFish = null;
        defaultContainer = new ContainerPlayer(inventory, !world.isStatic);
        activeContainer = defaultContainer;
        height = 1.62F;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        setPositionRotation((double)chunkcoordinates.x + 0.5D, chunkcoordinates.y + 1, (double)chunkcoordinates.z + 0.5D, 0.0F, 0.0F);
        health = 20;
        U = "humanoid";
        T = 180F;
        maxFireTicks = 20;
        texture = "/mob/char.png";
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
    }

    public void m_()
    {
        if(isSleeping())
        {
            sleepTicks++;
            if(sleepTicks > 100)
                sleepTicks = 100;
            if(!world.isStatic)
                if(!o())
                    a(true, true, false);
                else
                if(world.d())
                    a(false, true, true);
        } else
        if(sleepTicks > 0)
        {
            sleepTicks++;
            if(sleepTicks >= 110)
                sleepTicks = 0;
        }
        super.m_();
        if(!world.isStatic && activeContainer != null && !activeContainer.b(this))
        {
            y();
            activeContainer = defaultContainer;
        }
        t = w;
        u = x;
        v = y;
        double d0 = locX - w;
        double d1 = locY - x;
        double d2 = locZ - y;
        double d3 = 10D;
        if(d0 > d3)
            t = w = locX;
        if(d2 > d3)
            v = y = locZ;
        if(d1 > d3)
            u = x = locY;
        if(d0 < -d3)
            t = w = locX;
        if(d2 < -d3)
            v = y = locZ;
        if(d1 < -d3)
            u = x = locY;
        w += d0 * 0.25D;
        y += d2 * 0.25D;
        x += d1 * 0.25D;
        a(StatisticList.k, 1);
        if(vehicle == null)
            c = null;
    }

    protected boolean D()
    {
        return health <= 0 || isSleeping();
    }

    protected void y()
    {
        activeContainer = defaultContainer;
    }

    public void E()
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        super.E();
        n = o;
        o = 0.0F;
        i(locX - d0, locY - d1, locZ - d2);
    }

    protected void c_()
    {
        if(p)
        {
            q++;
            if(q >= 8)
            {
                q = 0;
                p = false;
            }
        } else
        {
            q = 0;
        }
        aa = (float)q / 8F;
    }

    public void v()
    {
        if(!world.allowMonsters && health < 20 && (ticksLived % 20) * 12 == 0)
            b(1, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.REGEN);
        inventory.f();
        n = o;
        super.v();
        float f = MathHelper.a(motX * motX + motZ * motZ);
        float f1 = (float)TrigMath.atan(-motY * 0.20000000298023224D) * 15F;
        if(f > 0.1F)
            f = 0.1F;
        if(!onGround || health <= 0)
            f = 0.0F;
        if(onGround || health <= 0)
            f1 = 0.0F;
        o += (f - o) * 0.4F;
        aj += (f1 - aj) * 0.8F;
        if(health > 0)
        {
            List list = world.b(this, boundingBox.b(1.0D, 0.0D, 1.0D));
            if(list != null)
            {
                for(int i = 0; i < list.size(); i++)
                {
                    Entity entity = (Entity)list.get(i);
                    if(!entity.dead)
                        i(entity);
                }

            }
        }
    }

    private void i(Entity entity)
    {
        entity.b(this);
    }

    public void die(Entity entity)
    {
        super.die(entity);
        b(0.2F, 0.2F);
        setPosition(locX, locY, locZ);
        motY = 0.10000000149011612D;
        if(name.equals("Notch"))
            a(new net.minecraft.server.ItemStack(Item.APPLE, 1), true);
        inventory.h();
        if(entity != null)
        {
            motX = -MathHelper.cos(((af + yaw) * 3.141593F) / 180F) * 0.1F;
            motZ = -MathHelper.sin(((af + yaw) * 3.141593F) / 180F) * 0.1F;
        } else
        {
            motX = motZ = 0.0D;
        }
        height = 0.1F;
        a(StatisticList.y, 1);
    }

    public void c(Entity entity, int i)
    {
        m += i;
        if(entity instanceof EntityHuman)
            a(StatisticList.A, 1);
        else
            a(StatisticList.z, 1);
    }

    public void F()
    {
        a(inventory.splitStack(inventory.itemInHandIndex, 1), false);
    }

    public void b(net.minecraft.server.ItemStack itemstack)
    {
        a(itemstack, false);
    }

    public void a(net.minecraft.server.ItemStack itemstack, boolean flag)
    {
        if(itemstack != null)
        {
            EntityItem entityitem = new EntityItem(world, locX, (locY - 0.30000001192092896D) + (double)t(), locZ, itemstack);
            entityitem.pickupDelay = 40;
            float f = 0.1F;
            if(flag)
            {
                float f1 = random.nextFloat() * 0.5F;
                float f2 = random.nextFloat() * 3.141593F * 2.0F;
                entityitem.motX = -MathHelper.sin(f2) * f1;
                entityitem.motZ = MathHelper.cos(f2) * f1;
                entityitem.motY = 0.20000000298023224D;
            } else
            {
                f = 0.3F;
                entityitem.motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
                entityitem.motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
                entityitem.motY = -MathHelper.sin((pitch / 180F) * 3.141593F) * f + 0.1F;
                f = 0.02F;
                float f1 = random.nextFloat() * 3.141593F * 2.0F;
                f *= random.nextFloat();
                entityitem.motX += Math.cos(f1) * (double)f;
                entityitem.motY += (random.nextFloat() - random.nextFloat()) * 0.1F;
                entityitem.motZ += Math.sin(f1) * (double)f;
            }
            Player player = (Player)getBukkitEntity();
            CraftItem drop = new CraftItem(world.getServer(), entityitem);
            PlayerDropItemEvent event = new PlayerDropItemEvent(player, drop);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
            {
                player.getInventory().addItem(new ItemStack[] {
                    drop.getItemStack()
                });
                return;
            }
            a(entityitem);
            a(StatisticList.v, 1);
        }
    }

    protected void a(EntityItem entityitem)
    {
        world.addEntity(entityitem);
    }

    public float a(Block block)
    {
        float f = inventory.a(block);
        if(a(Material.WATER))
            f /= 5F;
        if(!onGround)
            f /= 5F;
        return f;
    }

    public boolean b(Block block)
    {
        return inventory.b(block);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.l("Inventory");
        inventory.b(nbttaglist);
        dimension = nbttagcompound.e("Dimension");
        sleeping = nbttagcompound.m("Sleeping");
        sleepTicks = nbttagcompound.d("SleepTimer");
        if(sleeping)
        {
            A = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
            a(true, true, false);
        }
        spawnWorld = nbttagcompound.getString("SpawnWorld");
        if(spawnWorld == "")
            spawnWorld = ((World)world.getServer().getWorlds().get(0)).getName();
        if(nbttagcompound.hasKey("SpawnX") && nbttagcompound.hasKey("SpawnY") && nbttagcompound.hasKey("SpawnZ"))
            b = new ChunkCoordinates(nbttagcompound.e("SpawnX"), nbttagcompound.e("SpawnY"), nbttagcompound.e("SpawnZ"));
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Inventory", inventory.a(new NBTTagList()));
        nbttagcompound.a("Dimension", dimension);
        nbttagcompound.a("Sleeping", sleeping);
        nbttagcompound.a("SleepTimer", (short)sleepTicks);
        if(b != null)
        {
            nbttagcompound.a("SpawnX", b.x);
            nbttagcompound.a("SpawnY", b.y);
            nbttagcompound.a("SpawnZ", b.z);
            nbttagcompound.setString("SpawnWorld", spawnWorld);
        }
    }

    public void a(IInventory iinventory1)
    {
    }

    public void b(int i1, int j1, int k1)
    {
    }

    public void receive(Entity entity1, int j)
    {
    }

    public float t()
    {
        return 0.12F;
    }

    protected void s()
    {
        height = 1.62F;
    }

    public boolean damageEntity(Entity entity, int i)
    {
        ay = 0;
        if(health <= 0)
            return false;
        if(isSleeping() && !world.isStatic)
            a(true, true, false);
        if((entity instanceof EntityMonster) || (entity instanceof EntityArrow))
        {
            if(world.spawnMonsters == 0)
                i = 0;
            if(world.spawnMonsters == 1)
                i = i / 3 + 1;
            if(world.spawnMonsters == 3)
                i = (i * 3) / 2;
        }
        if(i == 0)
            return false;
        Object object = entity;
        if((entity instanceof EntityArrow) && ((EntityArrow)entity).shooter != null)
            object = ((EntityArrow)entity).shooter;
        if(object instanceof EntityLiving)
        {
            if(!(entity.getBukkitEntity() instanceof Projectile))
            {
                org.bukkit.entity.Entity damager = ((Entity)object).getBukkitEntity();
                org.bukkit.entity.Entity damagee = getBukkitEntity();
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK, i);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled() || event.getDamage() == 0)
                    return false;
                i = event.getDamage();
            }
            a((EntityLiving)object, false);
        }
        a(StatisticList.x, i);
        return super.damageEntity(entity, i);
    }

    protected boolean j_()
    {
        return false;
    }

    protected void a(EntityLiving entityliving, boolean flag)
    {
        if(!(entityliving instanceof EntityCreeper) && !(entityliving instanceof EntityGhast))
        {
            if(entityliving instanceof EntityWolf)
            {
                EntityWolf entitywolf = (EntityWolf)entityliving;
                if(entitywolf.isTamed() && name.equals(entitywolf.getOwnerName()))
                    return;
            }
            if(!(entityliving instanceof EntityHuman) || j_())
            {
                List list = world.a(net/minecraft/server/EntityWolf, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).b(16D, 4D, 16D));
                Iterator iterator = list.iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    Entity entity = (Entity)iterator.next();
                    EntityWolf entitywolf1 = (EntityWolf)entity;
                    if(entitywolf1.isTamed() && entitywolf1.F() == null && name.equals(entitywolf1.getOwnerName()) && (!flag || !entitywolf1.isSitting()))
                    {
                        org.bukkit.entity.Entity bukkitTarget = entity != null ? entityliving.getBukkitEntity() : null;
                        EntityTargetEvent event;
                        if(flag)
                            event = new EntityTargetEvent(entitywolf1.getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.OWNER_ATTACKED_TARGET);
                        else
                            event = new EntityTargetEvent(entitywolf1.getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_ATTACKED_OWNER);
                        world.getServer().getPluginManager().callEvent(event);
                        if(!event.isCancelled())
                        {
                            entitywolf1.setSitting(false);
                            entitywolf1.setTarget(entityliving);
                        }
                    }
                } while(true);
            }
        }
    }

    protected void c(int i)
    {
        int j = 25 - inventory.g();
        int k = i * j + d;
        inventory.c(i);
        i = k / 25;
        d = k % 25;
        super.c(i);
    }

    public void a(TileEntityFurnace tileentityfurnace1)
    {
    }

    public void a(TileEntityDispenser tileentitydispenser1)
    {
    }

    public void a(TileEntitySign tileentitysign1)
    {
    }

    public void c(Entity entity)
    {
        if(!entity.a(this))
        {
            net.minecraft.server.ItemStack itemstack = G();
            if(itemstack != null && (entity instanceof EntityLiving))
            {
                itemstack.a((EntityLiving)entity);
                if(itemstack.count == 0)
                {
                    itemstack.a(this);
                    H();
                }
            }
        }
    }

    public net.minecraft.server.ItemStack G()
    {
        return inventory.getItemInHand();
    }

    public void H()
    {
        inventory.setItem(inventory.itemInHandIndex, (net.minecraft.server.ItemStack)null);
    }

    public double I()
    {
        return (double)(height - 0.5F);
    }

    public void w()
    {
        q = -1;
        p = true;
    }

    public void d(Entity entity)
    {
        int i = inventory.a(entity);
        if(i > 0)
        {
            if(motY < 0.0D)
                i++;
            if((entity instanceof EntityLiving) && !(entity instanceof EntityHuman))
            {
                org.bukkit.entity.Entity damager = getBukkitEntity();
                org.bukkit.entity.Entity damagee = entity != null ? entity.getBukkitEntity() : null;
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK, i);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled() || event.getDamage() == 0)
                    return;
                i = event.getDamage();
            }
            if(!entity.damageEntity(this, i))
                return;
            net.minecraft.server.ItemStack itemstack = G();
            if(itemstack != null && (entity instanceof EntityLiving))
            {
                itemstack.a((EntityLiving)entity, this);
                if(itemstack.count == 0)
                {
                    itemstack.a(this);
                    H();
                }
            }
            if(entity instanceof EntityLiving)
            {
                if(entity.T())
                    a((EntityLiving)entity, true);
                a(StatisticList.w, i);
            }
        }
    }

    public void a(net.minecraft.server.ItemStack itemstack1)
    {
    }

    public void die()
    {
        super.die();
        defaultContainer.a(this);
        if(activeContainer != null)
            activeContainer.a(this);
    }

    public boolean K()
    {
        return !sleeping && super.K();
    }

    public EnumBedError a(int i, int j, int k)
    {
        if(!world.isStatic)
        {
            if(isSleeping() || !T())
                return EnumBedError.OTHER_PROBLEM;
            if(world.worldProvider.c)
                return EnumBedError.NOT_POSSIBLE_HERE;
            if(world.d())
                return EnumBedError.NOT_POSSIBLE_NOW;
            if(Math.abs(locX - (double)i) > 3D || Math.abs(locY - (double)j) > 2D || Math.abs(locZ - (double)k) > 3D)
                return EnumBedError.TOO_FAR_AWAY;
        }
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed = world.getWorld().getBlockAt(i, j, k);
            PlayerBedEnterEvent event = new PlayerBedEnterEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return EnumBedError.OTHER_PROBLEM;
        }
        b(0.2F, 0.2F);
        height = 0.2F;
        if(world.isLoaded(i, j, k))
        {
            int l = world.getData(i, j, k);
            int i1 = BlockBed.c(l);
            float f = 0.5F;
            float f1 = 0.5F;
            switch(i1)
            {
            case 0: // '\0'
                f1 = 0.9F;
                break;

            case 1: // '\001'
                f = 0.1F;
                break;

            case 2: // '\002'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f = 0.9F;
                break;
            }
            e(i1);
            setPosition((float)i + f, (float)j + 0.9375F, (float)k + f1);
        } else
        {
            setPosition((float)i + 0.5F, (float)j + 0.9375F, (float)k + 0.5F);
        }
        sleeping = true;
        sleepTicks = 0;
        A = new ChunkCoordinates(i, j, k);
        motX = motZ = motY = 0.0D;
        if(!world.isStatic)
            world.everyoneSleeping();
        return EnumBedError.OK;
    }

    private void e(int i)
    {
        B = 0.0F;
        C = 0.0F;
        switch(i)
        {
        case 0: // '\0'
            C = -1.8F;
            break;

        case 1: // '\001'
            B = 1.8F;
            break;

        case 2: // '\002'
            C = 1.8F;
            break;

        case 3: // '\003'
            B = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        b(0.6F, 1.8F);
        s();
        ChunkCoordinates chunkcoordinates = A;
        ChunkCoordinates chunkcoordinates1 = A;
        if(chunkcoordinates != null && world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) == Block.BED.id)
        {
            BlockBed.a(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, false);
            chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            if(chunkcoordinates1 == null)
                chunkcoordinates1 = new ChunkCoordinates(chunkcoordinates.x, chunkcoordinates.y + 1, chunkcoordinates.z);
            setPosition((float)chunkcoordinates1.x + 0.5F, (float)chunkcoordinates1.y + height + 0.1F, (float)chunkcoordinates1.z + 0.5F);
        }
        sleeping = false;
        if(!world.isStatic && flag1)
            world.everyoneSleeping();
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed;
            if(chunkcoordinates != null)
                bed = world.getWorld().getBlockAt(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z);
            else
                bed = world.getWorld().getBlockAt(player.getLocation());
            PlayerBedLeaveEvent event = new PlayerBedLeaveEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
        }
        if(flag)
            sleepTicks = 0;
        else
            sleepTicks = 100;
        if(flag2)
            a(A);
    }

    private boolean o()
    {
        return world.getTypeId(A.x, A.y, A.z) == Block.BED.id;
    }

    public static ChunkCoordinates getBed(net.minecraft.server.World world, ChunkCoordinates chunkcoordinates)
    {
        IChunkProvider ichunkprovider = world.o();
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z + 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z + 3 >> 4);
        if(world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) != Block.BED.id)
        {
            return null;
        } else
        {
            ChunkCoordinates chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            return chunkcoordinates1;
        }
    }

    public boolean isSleeping()
    {
        return sleeping;
    }

    public boolean isDeeplySleeping()
    {
        return sleeping && sleepTicks >= 100;
    }

    public void a(String s1)
    {
    }

    public ChunkCoordinates getBed()
    {
        return b;
    }

    public void a(ChunkCoordinates chunkcoordinates)
    {
        if(chunkcoordinates != null)
        {
            b = new ChunkCoordinates(chunkcoordinates);
            spawnWorld = world.worldData.name;
        } else
        {
            b = null;
        }
    }

    public void a(Statistic statistic)
    {
        a(statistic, 1);
    }

    public void a(Statistic statistic1, int j)
    {
    }

    protected void O()
    {
        super.O();
        a(StatisticList.u, 1);
    }

    public void a(float f, float f1)
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        super.a(f, f1);
        h(locX - d0, locY - d1, locZ - d2);
    }

    private void h(double d0, double d1, double d2)
    {
        if(vehicle == null)
            if(a(Material.WATER))
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
                if(i > 0)
                    a(StatisticList.q, i);
            } else
            if(ad())
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                    a(StatisticList.m, i);
            } else
            if(p())
            {
                if(d1 > 0.0D)
                    a(StatisticList.o, (int)Math.round(d1 * 100D));
            } else
            if(onGround)
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                    a(StatisticList.l, i);
            } else
            {
                int i = Math.round(MathHelper.a(d0 * d0 + d2 * d2) * 100F);
                if(i > 25)
                    a(StatisticList.p, i);
            }
    }

    private void i(double d0, double d1, double d2)
    {
        if(vehicle != null)
        {
            int i = Math.round(MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
            if(i > 0)
                if(vehicle instanceof EntityMinecart)
                {
                    a(StatisticList.r, i);
                    if(c == null)
                        c = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
                    else
                    if(c.a(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) >= 1000D)
                        a(AchievementList.q, 1);
                } else
                if(vehicle instanceof EntityBoat)
                    a(StatisticList.s, i);
                else
                if(vehicle instanceof EntityPig)
                    a(StatisticList.t, i);
        }
    }

    protected void a(float f)
    {
        if(f >= 2.0F)
            a(StatisticList.n, (int)Math.round((double)f * 100D));
        super.a(f);
    }

    public void a(EntityLiving entityliving)
    {
        if(entityliving instanceof EntityMonster)
            a(((Statistic) (AchievementList.s)));
    }

    public void P()
    {
        if(D > 0)
            D = 10;
        else
            E = true;
    }

    public InventoryPlayer inventory;
    public Container defaultContainer;
    public Container activeContainer;
    public byte l;
    public int m;
    public float n;
    public float o;
    public boolean p;
    public int q;
    public String name;
    public int dimension;
    public double t;
    public double u;
    public double v;
    public double w;
    public double x;
    public double y;
    public boolean sleeping;
    public boolean fauxSleeping;
    public String spawnWorld;
    public ChunkCoordinates A;
    public int sleepTicks;
    public float B;
    public float C;
    private ChunkCoordinates b;
    private ChunkCoordinates c;
    public int D;
    protected boolean E;
    public float F;
    private int d;
    public EntityFish hookedFish;
}
