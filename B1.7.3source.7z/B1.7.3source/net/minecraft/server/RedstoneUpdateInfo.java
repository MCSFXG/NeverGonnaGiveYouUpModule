// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


class RedstoneUpdateInfo
{

    public RedstoneUpdateInfo(int i, int j, int k, long l)
    {
        a = i;
        b = j;
        c = k;
        d = l;
    }

    int a;
    int b;
    int c;
    long d;
}
