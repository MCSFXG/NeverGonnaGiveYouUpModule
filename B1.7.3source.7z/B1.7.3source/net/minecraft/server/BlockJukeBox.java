// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockJukeBox.java

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockContainer, TileEntityRecordPlayer, EntityItem, ItemStack, 
//            Material, World, EntityHuman, TileEntity

public class BlockJukeBox extends BlockContainer
{

    protected BlockJukeBox(int i, int j)
    {
        super(i, j, Material.WOOD);
    }

    public int a(int i)
    {
        return textureId + (i != 1 ? 0 : 1);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(world.getData(i, j, k) == 0)
        {
            return false;
        } else
        {
            b_(world, i, j, k);
            return true;
        }
    }

    public void f(World world, int i, int j, int k, int l)
    {
        if(!world.isStatic)
        {
            TileEntityRecordPlayer tileentityrecordplayer = (TileEntityRecordPlayer)world.getTileEntity(i, j, k);
            tileentityrecordplayer.a = l;
            tileentityrecordplayer.update();
            world.setData(i, j, k, 1);
        }
    }

    public void b_(World world, int i, int j, int k)
    {
        if(!world.isStatic)
        {
            TileEntityRecordPlayer tileentityrecordplayer = (TileEntityRecordPlayer)world.getTileEntity(i, j, k);
            if(tileentityrecordplayer == null)
                return;
            int l = tileentityrecordplayer.a;
            if(l != 0)
            {
                world.e(1005, i, j, k, 0);
                world.a((String)null, i, j, k);
                tileentityrecordplayer.a = 0;
                tileentityrecordplayer.update();
                world.setData(i, j, k, 0);
                float f = 0.7F;
                double d0 = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                double d1 = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.20000000000000001D + 0.59999999999999998D;
                double d2 = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                EntityItem entityitem = new EntityItem(world, (double)i + d0, (double)j + d1, (double)k + d2, new ItemStack(l, 1, 0));
                entityitem.pickupDelay = 10;
                world.addEntity(entityitem);
            }
        }
    }

    public void remove(World world, int i, int j, int k)
    {
        b_(world, i, j, k);
        super.remove(world, i, j, k);
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f)
    {
        if(!world.isStatic)
            super.dropNaturally(world, i, j, k, l, f);
    }

    protected TileEntity a_()
    {
        return new TileEntityRecordPlayer();
    }
}
