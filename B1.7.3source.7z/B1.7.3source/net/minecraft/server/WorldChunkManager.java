// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldChunkManager.java

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            NoiseGeneratorOctaves2, BiomeBase, World, ChunkCoordIntPair

public class WorldChunkManager
{

    protected WorldChunkManager()
    {
    }

    public WorldChunkManager(World world)
    {
        e = new NoiseGeneratorOctaves2(new Random(world.getSeed() * 9871L), 4);
        f = new NoiseGeneratorOctaves2(new Random(world.getSeed() * 39811L), 4);
        g = new NoiseGeneratorOctaves2(new Random(world.getSeed() * 0x84a59L), 2);
    }

    public BiomeBase a(ChunkCoordIntPair chunkcoordintpair)
    {
        return getBiome(chunkcoordintpair.x << 4, chunkcoordintpair.z << 4);
    }

    public BiomeBase getBiome(int i, int j)
    {
        return getBiomeData(i, j, 1, 1)[0];
    }

    public BiomeBase[] getBiomeData(int i, int j, int k, int l)
    {
        d = a(d, i, j, k, l);
        return d;
    }

    public double[] a(double adouble[], int i, int j, int k, int l)
    {
        if(adouble == null || adouble.length < k * l)
            adouble = new double[k * l];
        adouble = e.a(adouble, i, j, k, l, 0.02500000037252903D, 0.02500000037252903D, 0.25D);
        c = g.a(c, i, j, k, l, 0.25D, 0.25D, 0.58823529411764708D);
        int i1 = 0;
        for(int j1 = 0; j1 < k; j1++)
        {
            for(int k1 = 0; k1 < l; k1++)
            {
                double d0 = c[i1] * 1.1000000000000001D + 0.5D;
                double d1 = 0.01D;
                double d2 = 1.0D - d1;
                double d3 = (adouble[i1] * 0.14999999999999999D + 0.69999999999999996D) * d2 + d0 * d1;
                d3 = 1.0D - (1.0D - d3) * (1.0D - d3);
                if(d3 < 0.0D)
                    d3 = 0.0D;
                if(d3 > 1.0D)
                    d3 = 1.0D;
                adouble[i1] = d3;
                i1++;
            }

        }

        return adouble;
    }

    public BiomeBase[] a(BiomeBase abiomebase[], int i, int j, int k, int l)
    {
        if(abiomebase == null || abiomebase.length < k * l)
            abiomebase = new BiomeBase[k * l];
        temperature = e.a(temperature, i, j, k, k, 0.02500000037252903D, 0.02500000037252903D, 0.25D);
        rain = f.a(rain, i, j, k, k, 0.05000000074505806D, 0.05000000074505806D, 0.33333333333333331D);
        c = g.a(c, i, j, k, k, 0.25D, 0.25D, 0.58823529411764708D);
        int i1 = 0;
        for(int j1 = 0; j1 < k; j1++)
        {
            for(int k1 = 0; k1 < l; k1++)
            {
                double d0 = c[i1] * 1.1000000000000001D + 0.5D;
                double d1 = 0.01D;
                double d2 = 1.0D - d1;
                double d3 = (temperature[i1] * 0.14999999999999999D + 0.69999999999999996D) * d2 + d0 * d1;
                d1 = 0.002D;
                d2 = 1.0D - d1;
                double d4 = (rain[i1] * 0.14999999999999999D + 0.5D) * d2 + d0 * d1;
                d3 = 1.0D - (1.0D - d3) * (1.0D - d3);
                if(d3 < 0.0D)
                    d3 = 0.0D;
                if(d4 < 0.0D)
                    d4 = 0.0D;
                if(d3 > 1.0D)
                    d3 = 1.0D;
                if(d4 > 1.0D)
                    d4 = 1.0D;
                temperature[i1] = d3;
                rain[i1] = d4;
                abiomebase[i1++] = BiomeBase.a(d3, d4);
            }

        }

        return abiomebase;
    }

    public double getHumidity(int x, int z)
    {
        return f.a(rain, x, z, 1, 1, 0.05000000074505806D, 0.05000000074505806D, 0.33333333333333331D)[0];
    }

    private NoiseGeneratorOctaves2 e;
    private NoiseGeneratorOctaves2 f;
    private NoiseGeneratorOctaves2 g;
    public double temperature[];
    public double rain[];
    public double c[];
    public BiomeBase d[];
}
