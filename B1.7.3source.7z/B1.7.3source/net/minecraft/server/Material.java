// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            MaterialTransparent, MaterialMapColor, MaterialLiquid, MaterialLogic, 
//            MaterialPortal

public class Material
{

    public Material(MaterialMapColor materialmapcolor)
    {
        G = true;
        C = materialmapcolor;
    }

    public boolean isLiquid()
    {
        return false;
    }

    public boolean isBuildable()
    {
        return true;
    }

    public boolean blocksLight()
    {
        return true;
    }

    public boolean isSolid()
    {
        return true;
    }

    private Material m()
    {
        F = true;
        return this;
    }

    private Material n()
    {
        G = false;
        return this;
    }

    private Material o()
    {
        canBurn = true;
        return this;
    }

    public boolean isBurnable()
    {
        return canBurn;
    }

    public Material f()
    {
        E = true;
        return this;
    }

    public boolean isReplacable()
    {
        return E;
    }

    public boolean h()
    {
        if(F)
            return false;
        else
            return isSolid();
    }

    public boolean i()
    {
        return G;
    }

    public int j()
    {
        return H;
    }

    protected Material k()
    {
        H = 1;
        return this;
    }

    protected Material l()
    {
        H = 2;
        return this;
    }

    public static final Material AIR;
    public static final Material GRASS;
    public static final Material EARTH;
    public static final Material WOOD;
    public static final Material STONE;
    public static final Material ORE;
    public static final Material WATER;
    public static final Material LAVA;
    public static final Material LEAVES;
    public static final Material PLANT;
    public static final Material SPONGE;
    public static final Material CLOTH;
    public static final Material FIRE;
    public static final Material SAND;
    public static final Material ORIENTABLE;
    public static final Material SHATTERABLE;
    public static final Material TNT;
    public static final Material CORAL;
    public static final Material ICE;
    public static final Material SNOW_LAYER;
    public static final Material SNOW_BLOCK;
    public static final Material CACTUS;
    public static final Material CLAY;
    public static final Material PUMPKIN;
    public static final Material PORTAL;
    public static final Material CAKE;
    public static final Material WEB;
    public static final Material PISTON;
    private boolean canBurn;
    private boolean E;
    private boolean F;
    public final MaterialMapColor C;
    private boolean G;
    private int H;

    static 
    {
        AIR = new MaterialTransparent(MaterialMapColor.b);
        GRASS = new Material(MaterialMapColor.c);
        EARTH = new Material(MaterialMapColor.l);
        WOOD = (new Material(MaterialMapColor.o)).o();
        STONE = (new Material(MaterialMapColor.m)).n();
        ORE = (new Material(MaterialMapColor.h)).n();
        WATER = (new MaterialLiquid(MaterialMapColor.n)).k();
        LAVA = (new MaterialLiquid(MaterialMapColor.f)).k();
        LEAVES = (new Material(MaterialMapColor.i)).o().m().k();
        PLANT = (new MaterialLogic(MaterialMapColor.i)).k();
        SPONGE = new Material(MaterialMapColor.e);
        CLOTH = (new Material(MaterialMapColor.e)).o();
        FIRE = (new MaterialTransparent(MaterialMapColor.b)).k();
        SAND = new Material(MaterialMapColor.d);
        ORIENTABLE = (new MaterialLogic(MaterialMapColor.b)).k();
        SHATTERABLE = (new Material(MaterialMapColor.b)).m();
        TNT = (new Material(MaterialMapColor.f)).o().m();
        CORAL = (new Material(MaterialMapColor.i)).k();
        ICE = (new Material(MaterialMapColor.g)).m();
        SNOW_LAYER = (new MaterialLogic(MaterialMapColor.j)).f().m().n().k();
        SNOW_BLOCK = (new Material(MaterialMapColor.j)).n();
        CACTUS = (new Material(MaterialMapColor.i)).m().k();
        CLAY = new Material(MaterialMapColor.k);
        PUMPKIN = (new Material(MaterialMapColor.i)).k();
        PORTAL = (new MaterialPortal(MaterialMapColor.b)).l();
        CAKE = (new Material(MaterialMapColor.b)).k();
        WEB = (new Material(MaterialMapColor.e)).n().k();
        PISTON = (new Material(MaterialMapColor.m)).l();
    }
}
