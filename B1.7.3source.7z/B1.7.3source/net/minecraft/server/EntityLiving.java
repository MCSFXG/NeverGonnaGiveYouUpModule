// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityLiving.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.World;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, AxisAlignedBB, Vec3D, World, 
//            Material, MathHelper, Block, StepSound, 
//            NBTTagCompound, EntityHuman

public abstract class EntityLiving extends Entity
{

    public EntityLiving(net.minecraft.server.World world)
    {
        super(world);
        maxNoDamageTicks = 20;
        K = 0.0F;
        L = 0.0F;
        Q = true;
        texture = "/mob/char.png";
        S = true;
        T = 0.0F;
        U = null;
        V = 1.0F;
        W = 0;
        X = 0.0F;
        Y = false;
        health = 10;
        af = 0.0F;
        deathTicks = 0;
        attackTicks = 0;
        ak = false;
        al = -1;
        am = (float)(Math.random() * 0.89999997615814209D + 0.10000000149011612D);
        aw = 0.0F;
        lastDamage = 0;
        ay = 0;
        aC = false;
        aD = 0.0F;
        aE = 0.7F;
        aF = 0;
        aI = true;
        J = (float)(Math.random() + 1.0D) * 0.01F;
        setPosition(locX, locY, locZ);
        I = (float)Math.random() * 12398F;
        yaw = (float)(Math.random() * 3.1415927410125732D * 2D);
        bs = 0.5F;
    }

    protected void b()
    {
    }

    public boolean e(Entity entity)
    {
        return world.a(Vec3D.create(locX, locY + (double)t(), locZ), Vec3D.create(entity.locX, entity.locY + (double)entity.t(), entity.locZ)) == null;
    }

    public boolean l_()
    {
        return !dead;
    }

    public boolean d_()
    {
        return !dead;
    }

    public float t()
    {
        return width * 0.85F;
    }

    public int e()
    {
        return 80;
    }

    public void Q()
    {
        String s = g();
        if(s != null)
            world.makeSound(this, s, k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
    }

    public void R()
    {
        Z = aa;
        super.R();
        if(random.nextInt(1000) < a++)
        {
            a = -e();
            Q();
        }
        if(T() && K())
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.SUFFOCATION, 1);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                damageEntity((Entity)null, event.getDamage());
        }
        if(fireProof || world.isStatic)
            fireTicks = 0;
        if(T() && a(Material.WATER) && !b_())
        {
            airTicks--;
            if(airTicks == -20)
            {
                airTicks = 0;
                for(int i = 0; i < 8; i++)
                {
                    float f = random.nextFloat() - random.nextFloat();
                    float f1 = random.nextFloat() - random.nextFloat();
                    float f2 = random.nextFloat() - random.nextFloat();
                    world.a("bubble", locX + (double)f, locY + (double)f1, locZ + (double)f2, motX, motY, motZ);
                }

                EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.DROWNING, 2);
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled() && event.getDamage() != 0)
                    damageEntity((Entity)null, event.getDamage());
            }
            fireTicks = 0;
        } else
        {
            airTicks = maxAirTicks;
        }
        ai = aj;
        if(attackTicks > 0)
            attackTicks--;
        if(hurtTicks > 0)
            hurtTicks--;
        if(noDamageTicks > 0)
            noDamageTicks--;
        if(health <= 0)
        {
            deathTicks++;
            if(deathTicks > 20)
            {
                X();
                die();
                for(int i = 0; i < 20; i++)
                {
                    double d0 = random.nextGaussian() * 0.02D;
                    double d1 = random.nextGaussian() * 0.02D;
                    double d2 = random.nextGaussian() * 0.02D;
                    world.a("explode", (locX + (double)(random.nextFloat() * length * 2.0F)) - (double)length, locY + (double)(random.nextFloat() * width), (locZ + (double)(random.nextFloat() * length * 2.0F)) - (double)length, d0, d1, d2);
                }

            }
        }
        P = O;
        L = K;
        lastYaw = yaw;
        lastPitch = pitch;
    }

    public void S()
    {
        for(int i = 0; i < 20; i++)
        {
            double d0 = random.nextGaussian() * 0.02D;
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            double d3 = 10D;
            world.a("explode", (locX + (double)(random.nextFloat() * length * 2.0F)) - (double)length - d0 * d3, (locY + (double)(random.nextFloat() * width)) - d1 * d3, (locZ + (double)(random.nextFloat() * length * 2.0F)) - (double)length - d2 * d3, d0, d1, d2);
        }

    }

    public void E()
    {
        super.E();
        M = N;
        N = 0.0F;
    }

    public void m_()
    {
        super.m_();
        v();
        double d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f = MathHelper.a(d0 * d0 + d1 * d1);
        float f1 = K;
        float f2 = 0.0F;
        M = N;
        float f3 = 0.0F;
        if(f > 0.05F)
        {
            f3 = 1.0F;
            f2 = f * 3F;
            f1 = ((float)TrigMath.atan2(d1, d0) * 180F) / 3.141593F - 90F;
        }
        if(aa > 0.0F)
            f1 = yaw;
        if(!onGround)
            f3 = 0.0F;
        N += (f3 - N) * 0.3F;
        float f4;
        for(f4 = f1 - K; f4 < -180F; f4 += 360F);
        for(; f4 >= 180F; f4 -= 360F);
        K += f4 * 0.3F;
        float f5;
        for(f5 = yaw - K; f5 < -180F; f5 += 360F);
        for(; f5 >= 180F; f5 -= 360F);
        boolean flag = f5 < -90F || f5 >= 90F;
        if(f5 < -75F)
            f5 = -75F;
        if(f5 >= 75F)
            f5 = 75F;
        K = yaw - f5;
        if(f5 * f5 > 2500F)
            K += f5 * 0.2F;
        if(flag)
            f2 *= -1F;
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        for(; K - L < -180F; L -= 360F);
        for(; K - L >= 180F; L += 360F);
        for(; pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        O += f2;
    }

    protected void b(float f, float f1)
    {
        super.b(f, f1);
    }

    public void b(int i)
    {
        b(i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.CUSTOM);
    }

    public void b(int i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason regainReason)
    {
        if(health > 0)
        {
            EntityRegainHealthEvent event = new EntityRegainHealthEvent(getBukkitEntity(), i, regainReason);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                health += event.getAmount();
            if(health > 20)
                health = 20;
            noDamageTicks = maxNoDamageTicks / 2;
        }
    }

    public boolean damageEntity(Entity entity, int i)
    {
        if(world.isStatic)
            return false;
        ay = 0;
        if(health <= 0)
            return false;
        ao = 1.5F;
        boolean flag = true;
        if((float)noDamageTicks > (float)maxNoDamageTicks / 2.0F)
        {
            if(i <= lastDamage)
                return false;
            c(i - lastDamage);
            lastDamage = i;
            flag = false;
        } else
        {
            lastDamage = i;
            ac = health;
            noDamageTicks = maxNoDamageTicks;
            c(i);
            hurtTicks = ae = 10;
        }
        af = 0.0F;
        if(flag)
        {
            world.a(this, (byte)2);
            af();
            if(entity != null)
            {
                double d0 = entity.locX - locX;
                double d1;
                for(d1 = entity.locZ - locZ; d0 * d0 + d1 * d1 < 0.0001D; d1 = (Math.random() - Math.random()) * 0.01D)
                    d0 = (Math.random() - Math.random()) * 0.01D;

                af = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - yaw;
                a(entity, i, d0, d1);
            } else
            {
                af = (int)(Math.random() * 2D) * 180;
            }
        }
        if(health <= 0)
        {
            if(flag)
                world.makeSound(this, i(), k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
            die(entity);
        } else
        if(flag)
            world.makeSound(this, h(), k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
        return true;
    }

    protected void c(int i)
    {
        health -= i;
    }

    protected float k()
    {
        return 1.0F;
    }

    protected String g()
    {
        return null;
    }

    protected String h()
    {
        return "random.hurt";
    }

    protected String i()
    {
        return "random.hurt";
    }

    public void a(Entity entity, int i, double d0, double d1)
    {
        float f = MathHelper.a(d0 * d0 + d1 * d1);
        float f1 = 0.4F;
        motX /= 2D;
        motY /= 2D;
        motZ /= 2D;
        motX -= (d0 / (double)f) * (double)f1;
        motY += 0.40000000596046448D;
        motZ -= (d1 / (double)f) * (double)f1;
        if(motY > 0.40000000596046448D)
            motY = 0.40000000596046448D;
    }

    public void die(Entity entity)
    {
        if(W >= 0 && entity != null)
            entity.c(this, W);
        if(entity != null)
            entity.a(this);
        ak = true;
        if(!world.isStatic)
            q();
        world.a(this, (byte)3);
    }

    protected void q()
    {
        int i = j();
        List loot = new ArrayList();
        int count = random.nextInt(3);
        if(i > 0 && count > 0)
            loot.add(new ItemStack(i, count));
        CraftEntity entity = (CraftEntity)getBukkitEntity();
        EntityDeathEvent event = new EntityDeathEvent(entity, loot);
        World bworld = world.getWorld();
        world.getServer().getPluginManager().callEvent(event);
        ItemStack stack;
        for(Iterator i$ = event.getDrops().iterator(); i$.hasNext(); bworld.dropItemNaturally(entity.getLocation(), stack))
            stack = (ItemStack)i$.next();

    }

    protected int j()
    {
        return 0;
    }

    protected void a(float f)
    {
        super.a(f);
        int i = (int)Math.ceil(f - 3F);
        if(i > 0)
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL, i);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled() && event.getDamage() != 0)
                damageEntity((Entity)null, event.getDamage());
            int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(locY - 0.20000000298023224D - (double)height), MathHelper.floor(locZ));
            if(j > 0)
            {
                StepSound stepsound = Block.byId[j].stepSound;
                world.makeSound(this, stepsound.getName(), stepsound.getVolume1() * 0.5F, stepsound.getVolume2() * 0.75F);
            }
        }
    }

    public void a(float f, float f1)
    {
        double d0;
        if(ad())
        {
            d0 = locY;
            a(f, f1, 0.02F);
            move(motX, motY, motZ);
            motX *= 0.80000001192092896D;
            motY *= 0.80000001192092896D;
            motZ *= 0.80000001192092896D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        if(ae())
        {
            d0 = locY;
            a(f, f1, 0.02F);
            move(motX, motY, motZ);
            motX *= 0.5D;
            motY *= 0.5D;
            motZ *= 0.5D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        {
            float f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int i = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(i > 0)
                    f2 = Block.byId[i].frictionFactor * 0.91F;
            }
            float f3 = 0.1627714F / (f2 * f2 * f2);
            a(f, f1, onGround ? 0.1F * f3 : 0.02F);
            f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(j > 0)
                    f2 = Block.byId[j].frictionFactor * 0.91F;
            }
            if(p())
            {
                float f4 = 0.15F;
                if(motX < (double)(-f4))
                    motX = -f4;
                if(motX > (double)f4)
                    motX = f4;
                if(motZ < (double)(-f4))
                    motZ = -f4;
                if(motZ > (double)f4)
                    motZ = f4;
                fallDistance = 0.0F;
                if(motY < -0.14999999999999999D)
                    motY = -0.14999999999999999D;
                if(isSneaking() && motY < 0.0D)
                    motY = 0.0D;
            }
            move(motX, motY, motZ);
            if(positionChanged && p())
                motY = 0.20000000000000001D;
            motY -= 0.080000000000000002D;
            motY *= 0.98000001907348633D;
            motX *= f2;
            motZ *= f2;
        }
        an = ao;
        d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f5 = MathHelper.a(d0 * d0 + d1 * d1) * 4F;
        if(f5 > 1.0F)
            f5 = 1.0F;
        ao += (f5 - ao) * 0.4F;
        ap += ao;
    }

    public boolean p()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        return world.getTypeId(i, j, k) == Block.LADDER.id;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("Health", (short)health);
        nbttagcompound.a("HurtTime", (short)hurtTicks);
        nbttagcompound.a("DeathTime", (short)deathTicks);
        nbttagcompound.a("AttackTime", (short)attackTicks);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        health = nbttagcompound.d("Health");
        if(!nbttagcompound.hasKey("Health"))
            health = 10;
        hurtTicks = nbttagcompound.d("HurtTime");
        deathTicks = nbttagcompound.d("DeathTime");
        attackTicks = nbttagcompound.d("AttackTime");
    }

    public boolean T()
    {
        return !dead && health > 0;
    }

    public boolean b_()
    {
        return false;
    }

    public void v()
    {
        if(aq > 0)
        {
            double d0 = locX + (ar - locX) / (double)aq;
            double d1 = locY + (as - locY) / (double)aq;
            double d2 = locZ + (at - locZ) / (double)aq;
            double d3;
            for(d3 = au - (double)yaw; d3 < -180D; d3 += 360D);
            for(; d3 >= 180D; d3 -= 360D);
            yaw = (float)((double)yaw + d3 / (double)aq);
            pitch = (float)((double)pitch + (av - (double)pitch) / (double)aq);
            aq--;
            setPosition(d0, d1, d2);
            c(yaw, pitch);
            List list = world.getEntities(this, boundingBox.shrink(0.03125D, 0.0D, 0.03125D));
            if(list.size() > 0)
            {
                double d4 = 0.0D;
                for(int i = 0; i < list.size(); i++)
                {
                    AxisAlignedBB axisalignedbb = (AxisAlignedBB)list.get(i);
                    if(axisalignedbb.e > d4)
                        d4 = axisalignedbb.e;
                }

                d1 += d4 - boundingBox.b;
                setPosition(d0, d1, d2);
            }
        }
        if(D())
        {
            aC = false;
            az = 0.0F;
            aA = 0.0F;
            aB = 0.0F;
        } else
        if(!Y)
            c_();
        boolean flag = ad();
        boolean flag1 = ae();
        if(aC)
            if(flag)
                motY += 0.039999999105930328D;
            else
            if(flag1)
                motY += 0.039999999105930328D;
            else
            if(onGround)
                O();
        az *= 0.98F;
        aA *= 0.98F;
        aB *= 0.9F;
        a(az, aA);
        List list1 = world.b(this, boundingBox.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
        if(list1 != null && list1.size() > 0)
        {
            for(int j = 0; j < list1.size(); j++)
            {
                Entity entity = (Entity)list1.get(j);
                if(entity.d_())
                    entity.collide(this);
            }

        }
    }

    protected boolean D()
    {
        return health <= 0;
    }

    protected void O()
    {
        motY = 0.41999998688697815D;
    }

    protected boolean h_()
    {
        return true;
    }

    protected void U()
    {
        EntityHuman entityhuman = world.findNearbyPlayer(this, -1D);
        if(h_() && entityhuman != null)
        {
            double d0 = entityhuman.locX - locX;
            double d1 = entityhuman.locY - locY;
            double d2 = entityhuman.locZ - locZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if(d3 > 16384D)
                die();
            if(ay > 600 && random.nextInt(800) == 0)
                if(d3 < 1024D)
                    ay = 0;
                else
                    die();
        }
    }

    protected void c_()
    {
        ay++;
        EntityHuman entityhuman = world.findNearbyPlayer(this, -1D);
        U();
        az = 0.0F;
        aA = 0.0F;
        float f = 8F;
        if(random.nextFloat() < 0.02F)
        {
            entityhuman = world.findNearbyPlayer(this, f);
            if(entityhuman != null)
            {
                b = entityhuman;
                aF = 10 + random.nextInt(20);
            } else
            {
                aB = (random.nextFloat() - 0.5F) * 20F;
            }
        }
        if(b != null)
        {
            a(b, 10F, u());
            if(aF-- <= 0 || b.dead || b.g(this) > (double)(f * f))
                b = null;
        } else
        {
            if(random.nextFloat() < 0.05F)
                aB = (random.nextFloat() - 0.5F) * 20F;
            yaw += aB;
            pitch = aD;
        }
        boolean flag = ad();
        boolean flag1 = ae();
        if(flag || flag1)
            aC = random.nextFloat() < 0.8F;
    }

    protected int u()
    {
        return 40;
    }

    public void a(Entity entity, float f, float f1)
    {
        double d0 = entity.locX - locX;
        double d1 = entity.locZ - locZ;
        double d2;
        if(entity instanceof EntityLiving)
        {
            EntityLiving entityliving = (EntityLiving)entity;
            d2 = (locY + (double)t()) - (entityliving.locY + (double)entityliving.t());
        } else
        {
            d2 = (entity.boundingBox.b + entity.boundingBox.e) / 2D - (locY + (double)t());
        }
        double d3 = MathHelper.a(d0 * d0 + d1 * d1);
        float f2 = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - 90F;
        float f3 = (float)(-((Math.atan2(d2, d3) * 180D) / 3.1415927410125732D));
        pitch = -b(pitch, f3, f1);
        yaw = b(yaw, f2, f);
    }

    public boolean V()
    {
        return b != null;
    }

    public Entity W()
    {
        return b;
    }

    private float b(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f1 - f; f3 < -180F; f3 += 360F);
        for(; f3 >= 180F; f3 -= 360F);
        if(f3 > f2)
            f3 = f2;
        if(f3 < -f2)
            f3 = -f2;
        return f + f3;
    }

    public void X()
    {
    }

    public boolean d()
    {
        return world.containsEntity(boundingBox) && world.getEntities(this, boundingBox).size() == 0 && !world.c(boundingBox);
    }

    protected void Y()
    {
        EntityDamageByBlockEvent event = new EntityDamageByBlockEvent(null, getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.VOID, 4);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled() || event.getDamage() == 0)
        {
            return;
        } else
        {
            damageEntity((Entity)null, event.getDamage());
            return;
        }
    }

    public Vec3D Z()
    {
        return b(1.0F);
    }

    public Vec3D b(float f)
    {
        if(f == 1.0F)
        {
            float f1 = MathHelper.cos(-yaw * 0.01745329F - 3.141593F);
            float f2 = MathHelper.sin(-yaw * 0.01745329F - 3.141593F);
            float f3 = -MathHelper.cos(-pitch * 0.01745329F);
            float f4 = MathHelper.sin(-pitch * 0.01745329F);
            return Vec3D.create(f2 * f3, f4, f1 * f3);
        } else
        {
            float f1 = lastPitch + (pitch - lastPitch) * f;
            float f2 = lastYaw + (yaw - lastYaw) * f;
            float f3 = MathHelper.cos(-f2 * 0.01745329F - 3.141593F);
            float f4 = MathHelper.sin(-f2 * 0.01745329F - 3.141593F);
            float f5 = -MathHelper.cos(-f1 * 0.01745329F);
            float f6 = MathHelper.sin(-f1 * 0.01745329F);
            return Vec3D.create(f4 * f5, f6, f3 * f5);
        }
    }

    public int l()
    {
        return 4;
    }

    public boolean isSleeping()
    {
        return false;
    }

    public int maxNoDamageTicks;
    public float I;
    public float J;
    public float K;
    public float L;
    protected float M;
    protected float N;
    protected float O;
    protected float P;
    protected boolean Q;
    protected String texture;
    protected boolean S;
    protected float T;
    protected String U;
    protected float V;
    protected int W;
    protected float X;
    public boolean Y;
    public float Z;
    public float aa;
    public int health;
    public int ac;
    private int a;
    public int hurtTicks;
    public int ae;
    public float af;
    public int deathTicks;
    public int attackTicks;
    public float ai;
    public float aj;
    protected boolean ak;
    public int al;
    public float am;
    public float an;
    public float ao;
    public float ap;
    protected int aq;
    protected double ar;
    protected double as;
    protected double at;
    protected double au;
    protected double av;
    float aw;
    public int lastDamage;
    protected int ay;
    protected float az;
    protected float aA;
    protected float aB;
    protected boolean aC;
    protected float aD;
    protected float aE;
    private Entity b;
    protected int aF;
}
