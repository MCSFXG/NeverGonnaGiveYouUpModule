package net.minecraft.block;

public class BlockHalfStoneSlab extends BlockStoneSlab
{
    private static final String __OBFID = "CL_00002108";

    public boolean isDouble()
    {
        return false;
    }
}
