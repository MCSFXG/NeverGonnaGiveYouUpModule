package net.minecraft.client.renderer;

import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.ItemStack;

public interface ItemMeshDefinition
{
    ModelResourceLocation getModelLocation(ItemStack p_178113_1_);
}
