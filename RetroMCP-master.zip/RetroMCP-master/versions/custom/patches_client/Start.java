//import net.minecraft.client.Minecraft;

public class Start
{

   public static void main(String[] args) {
		//Start main thread
		//Minecraft.main(args);
   }

}