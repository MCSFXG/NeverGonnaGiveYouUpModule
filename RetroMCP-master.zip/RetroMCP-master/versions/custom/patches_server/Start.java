//import net.minecraft.client.MinecraftServer;

public class Start
{

   public static void main(String[] args) {
		//Start main thread
		//MinecraftServer.main(args);
   }

}