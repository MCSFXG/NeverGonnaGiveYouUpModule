RetroMCP is using fixed fernflower; sources here: https://github.com/MCPHackers/RetroFernflower
Fernflower build commit: 2fd8290ffdbc9665802cee3300ab272a571091fc
License: http://www.apache.org/licenses/LICENSE-2.0
