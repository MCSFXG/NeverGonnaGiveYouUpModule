# Special Source 1.9.0
Special Source 1.9.0 allows for Java 8+ to decompile, recompile, and reobfuscate mods. Java 8 should still be used.
