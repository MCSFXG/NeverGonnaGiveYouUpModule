## [Please use RetroMCP-Java instead. This version is discontinued](https://github.com/MCPHackers/RetroMCP-Java)

# RetroMCP

RetroMCP is a modification of the Minecraft Coder Pack to create a "Long Term Service" patch for Minecraft

# Features

* Automatically download Minecraft .jar's from official download links
* Include an auto patching bat to create patched client and server jars
* A Start class for applet-only versions
* Reobfuscation for all available versions

# Licensing

MCP Version 4.3 __did not__ ship with a license, therefore it is allowed to be reuploaded and modified here.

With that in mind, all credit towards MCP goes to the original creators. Read docs/README-MCP.txt for credits.
