// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ServerConfigurationManager.java

package net.minecraft.server;

import java.io.*;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.command.ColouredConsoleSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            WorldServer, Packet3Chat, EntityPlayer, World, 
//            ItemInWorldManager, Packet70Bed, Packet9Respawn, EntityHuman, 
//            MinecraftServer, PropertyManager, IDataManager, PlayerFileData, 
//            ChunkProviderServer, PlayerManager, NetLoginHandler, NetworkManager, 
//            NetServerHandler, EntityTracker, ChunkCoordinates, Packet, 
//            TileEntity

public class ServerConfigurationManager
{

    public ServerConfigurationManager(MinecraftServer minecraftserver)
    {
        players = new ArrayList();
        banByName = new HashSet();
        banByIP = new HashSet();
        h = new HashSet();
        i = new HashSet();
        minecraftserver.server = new CraftServer(minecraftserver, this);
        minecraftserver.console = new ColouredConsoleSender(minecraftserver.server);
        cserver = minecraftserver.server;
        server = minecraftserver;
        j = minecraftserver.a("banned-players.txt");
        k = minecraftserver.a("banned-ips.txt");
        l = minecraftserver.a("ops.txt");
        m = minecraftserver.a("white-list.txt");
        maxPlayers = minecraftserver.propertyManager.getInt("max-players", 20);
        o = minecraftserver.propertyManager.getBoolean("white-list", false);
        g();
        i();
        k();
        m();
        h();
        j();
        l();
        n();
    }

    public void setPlayerFileData(WorldServer worldserver)
    {
        if(playerFileData != null)
        {
            return;
        } else
        {
            playerFileData = worldserver.p().d();
            return;
        }
    }

    public int a()
    {
        return 144;
    }

    public void a(EntityPlayer entityplayer)
    {
        players.add(entityplayer);
        playerFileData.b(entityplayer);
        ((WorldServer)entityplayer.world).chunkProviderServer.getChunkAt((int)entityplayer.locX >> 4, (int)entityplayer.locZ >> 4);
        for(; entityplayer.world.getEntities(entityplayer, entityplayer.boundingBox).size() != 0; entityplayer.setPosition(entityplayer.locX, entityplayer.locY + 1.0D, entityplayer.locZ));
        entityplayer.world.addEntity(entityplayer);
        PlayerJoinEvent playerJoinEvent = new PlayerJoinEvent(cserver.getPlayer(entityplayer), (new StringBuilder()).append("\247e").append(entityplayer.name).append(" joined the game.").toString());
        cserver.getPluginManager().callEvent(playerJoinEvent);
        String joinMessage = playerJoinEvent.getJoinMessage();
        if(joinMessage != null)
            server.serverConfigurationManager.sendAll(new Packet3Chat(joinMessage));
        ((WorldServer)entityplayer.world).manager.addPlayer(entityplayer);
    }

    public void b(EntityPlayer entityplayer)
    {
        ((WorldServer)entityplayer.world).manager.movePlayer(entityplayer);
    }

    public String disconnect(EntityPlayer entityplayer)
    {
        ((WorldServer)entityplayer.world).manager.removePlayer(entityplayer);
        PlayerQuitEvent playerQuitEvent = new PlayerQuitEvent(cserver.getPlayer(entityplayer), (new StringBuilder()).append("\247e").append(entityplayer.name).append(" left the game.").toString());
        cserver.getPluginManager().callEvent(playerQuitEvent);
        playerFileData.a(entityplayer);
        entityplayer.world.kill(entityplayer);
        players.remove(entityplayer);
        return playerQuitEvent.getQuitMessage();
    }

    public EntityPlayer a(NetLoginHandler netloginhandler, String s)
    {
        EntityPlayer entity = new EntityPlayer(server, (World)server.worlds.get(0), s, new ItemInWorldManager((World)server.worlds.get(0)));
        Player player = entity != null ? (Player)entity.getBukkitEntity() : null;
        PlayerLoginEvent event = new PlayerLoginEvent(player);
        String s2 = netloginhandler.networkManager.getSocketAddress().toString();
        s2 = s2.substring(s2.indexOf("/") + 1);
        s2 = s2.substring(0, s2.indexOf(":"));
        if(banByName.contains(s.trim().toLowerCase()))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_BANNED, "You are banned from this server!");
        else
        if(!isWhitelisted(s))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_WHITELIST, "You are not white-listed on this server!");
        else
        if(banByIP.contains(s2))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_BANNED, "Your IP address is banned from this server!");
        else
        if(players.size() >= maxPlayers)
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_FULL, "The server is full!");
        else
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED, s2);
        cserver.getPluginManager().callEvent(event);
        if(event.getResult() != org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED)
        {
            netloginhandler.disconnect(event.getKickMessage());
            return null;
        }
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(entityplayer.name.equalsIgnoreCase(s))
                entityplayer.netServerHandler.disconnect("You logged in from another location");
        }

        return new EntityPlayer(server, entity.world, s, new ItemInWorldManager(entity.world));
    }

    public EntityPlayer d(EntityPlayer entityplayer)
    {
        server.tracker.trackPlayer(entityplayer);
        server.tracker.untrackEntity(entityplayer);
        ((WorldServer)entityplayer.world).manager.removePlayer(entityplayer);
        players.remove(entityplayer);
        entityplayer.world.removeEntity(entityplayer);
        ChunkCoordinates chunkcoordinates = entityplayer.K();
        EntityPlayer entityplayer1 = new EntityPlayer(server, entityplayer.world, entityplayer.name, new ItemInWorldManager(entityplayer.world));
        entityplayer1.id = entityplayer.id;
        entityplayer1.netServerHandler = entityplayer.netServerHandler;
        entityplayer1.displayName = entityplayer.displayName;
        entityplayer1.compassTarget = entityplayer.compassTarget;
        entityplayer1.fauxSleeping = entityplayer.fauxSleeping;
        if(chunkcoordinates != null)
        {
            ChunkCoordinates chunkcoordinates1 = EntityHuman.getBed(entityplayer.world, chunkcoordinates);
            if(chunkcoordinates1 != null)
            {
                entityplayer1.setPositionRotation((float)chunkcoordinates1.x + 0.5F, (float)chunkcoordinates1.y + 0.1F, (float)chunkcoordinates1.z + 0.5F, 0.0F, 0.0F);
                entityplayer1.a(chunkcoordinates);
            } else
            {
                entityplayer1.netServerHandler.sendPacket(new Packet70Bed(0));
            }
        }
        ((WorldServer)entityplayer.world).chunkProviderServer.getChunkAt((int)entityplayer1.locX >> 4, (int)entityplayer1.locZ >> 4);
        for(; entityplayer.world.getEntities(entityplayer1, entityplayer1.boundingBox).size() != 0; entityplayer1.setPosition(entityplayer1.locX, entityplayer1.locY + 1.0D, entityplayer1.locZ));
        Player respawnPlayer = cserver.getPlayer(entityplayer);
        Location respawnLocation = new Location(respawnPlayer.getWorld(), entityplayer1.locX, entityplayer1.locY, entityplayer1.locZ, entityplayer1.yaw, entityplayer1.pitch);
        PlayerRespawnEvent respawnEvent = new PlayerRespawnEvent(respawnPlayer, respawnLocation);
        cserver.getPluginManager().callEvent(respawnEvent);
        entityplayer1.world = ((CraftWorld)respawnEvent.getRespawnLocation().getWorld()).getHandle();
        entityplayer1.locX = respawnEvent.getRespawnLocation().getX();
        entityplayer1.locY = respawnEvent.getRespawnLocation().getY();
        entityplayer1.locZ = respawnEvent.getRespawnLocation().getZ();
        entityplayer1.yaw = respawnEvent.getRespawnLocation().getYaw();
        entityplayer1.pitch = respawnEvent.getRespawnLocation().getPitch();
        entityplayer1.itemInWorldManager = new ItemInWorldManager(((CraftWorld)respawnEvent.getRespawnLocation().getWorld()).getHandle());
        entityplayer1.itemInWorldManager.player = entityplayer1;
        ((WorldServer)entityplayer1.world).chunkProviderServer.getChunkAt((int)entityplayer1.locX >> 4, (int)entityplayer1.locZ >> 4);
        entityplayer1.netServerHandler.sendPacket(new Packet9Respawn());
        entityplayer1.netServerHandler.a(entityplayer1.locX, entityplayer1.locY, entityplayer1.locZ, entityplayer1.yaw, entityplayer1.pitch);
        ((WorldServer)entityplayer1.world).manager.addPlayer(entityplayer1);
        entityplayer.world.addEntity(entityplayer1);
        players.add(entityplayer1);
        entityplayer1.syncInventory();
        entityplayer1.w();
        return entityplayer1;
    }

    public void b()
    {
        WorldServer world;
        for(Iterator i$ = server.worlds.iterator(); i$.hasNext(); world.manager.flush())
            world = (WorldServer)i$.next();

    }

    public void flagDirty(int i, int j, int k, WorldServer world)
    {
        world.manager.flagDirty(i, j, k);
    }

    public void sendAll(Packet packet)
    {
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public String c()
    {
        String s = "";
        for(int i = 0; i < players.size(); i++)
        {
            if(i > 0)
                s = (new StringBuilder()).append(s).append(", ").toString();
            s = (new StringBuilder()).append(s).append(((EntityPlayer)players.get(i)).name).toString();
        }

        return s;
    }

    public void a(String s)
    {
        banByName.add(s.toLowerCase());
        h();
    }

    public void b(String s)
    {
        banByName.remove(s.toLowerCase());
        h();
    }

    private void g()
    {
        try
        {
            banByName.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(j));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                banByName.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ban list: ").append(exception).toString());
        }
    }

    private void h()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(j, false));
            String s;
            for(Iterator iterator = banByName.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ban list: ").append(exception).toString());
        }
    }

    public void c(String s)
    {
        banByIP.add(s.toLowerCase());
        j();
    }

    public void d(String s)
    {
        banByIP.remove(s.toLowerCase());
        j();
    }

    private void i()
    {
        try
        {
            banByIP.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(k));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                banByIP.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ip ban list: ").append(exception).toString());
        }
    }

    private void j()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(k, false));
            String s;
            for(Iterator iterator = banByIP.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ip ban list: ").append(exception).toString());
        }
    }

    public void e(String s)
    {
        h.add(s.toLowerCase());
        l();
    }

    public void f(String s)
    {
        h.remove(s.toLowerCase());
        l();
    }

    private void k()
    {
        try
        {
            h.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(l));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                h.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ops: ").append(exception).toString());
        }
    }

    private void l()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(l, false));
            String s;
            for(Iterator iterator = h.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ops: ").append(exception).toString());
        }
    }

    private void m()
    {
        try
        {
            i.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(m));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                i.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load white-list: ").append(exception).toString());
        }
    }

    private void n()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(m, false));
            String s;
            for(Iterator iterator = i.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save white-list: ").append(exception).toString());
        }
    }

    public boolean isWhitelisted(String s)
    {
        s = s.trim().toLowerCase();
        return !o || h.contains(s) || i.contains(s);
    }

    public boolean isOp(String s)
    {
        return h.contains(s.trim().toLowerCase());
    }

    public EntityPlayer i(String s)
    {
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(entityplayer.name.equalsIgnoreCase(s))
                return entityplayer;
        }

        return null;
    }

    public void a(String s, String s1)
    {
        EntityPlayer entityplayer = i(s);
        if(entityplayer != null)
            entityplayer.netServerHandler.sendPacket(new Packet3Chat(s1));
    }

    public void a(double d0, double d1, double d2, double d3, Packet packet)
    {
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            double d4 = d0 - entityplayer.locX;
            double d5 = d1 - entityplayer.locY;
            double d6 = d2 - entityplayer.locZ;
            if(d4 * d4 + d5 * d5 + d6 * d6 < d3 * d3)
                entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public void j(String s)
    {
        Packet3Chat packet3chat = new Packet3Chat(s);
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(isOp(entityplayer.name))
                entityplayer.netServerHandler.sendPacket(packet3chat);
        }

    }

    public boolean a(String s, Packet packet)
    {
        EntityPlayer entityplayer = i(s);
        if(entityplayer != null)
        {
            entityplayer.netServerHandler.sendPacket(packet);
            return true;
        } else
        {
            return false;
        }
    }

    public void savePlayers()
    {
        for(int i = 0; i < players.size(); i++)
            playerFileData.a((EntityHuman)players.get(i));

    }

    public void a(int i1, int j1, int k1, TileEntity tileentity1)
    {
    }

    public void k(String s)
    {
        i.add(s);
        n();
    }

    public void l(String s)
    {
        i.remove(s);
        n();
    }

    public Set e()
    {
        return i;
    }

    public void f()
    {
        m();
    }

    public static Logger a = Logger.getLogger("Minecraft");
    public List players;
    public MinecraftServer server;
    public int maxPlayers;
    private Set banByName;
    private Set banByIP;
    private Set h;
    private Set i;
    private File j;
    private File k;
    private File l;
    private File m;
    public PlayerFileData playerFileData;
    private boolean o;
    private CraftServer cserver;

}
