// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.IOException;

// Referenced classes of package net.minecraft.server:
//            IChunkProvider, Chunk, EmptyChunk, World, 
//            IChunkLoader, IProgressUpdate

public class ChunkProviderLoadOrGenerate
    implements IChunkProvider
{

    public ChunkProviderLoadOrGenerate(World world, IChunkLoader ichunkloader, IChunkProvider ichunkprovider)
    {
        f = new Chunk[1024];
        a = 0xc4653601;
        b = 0xc4653601;
        c = new EmptyChunk(world, new byte[32768], 0, 0);
        g = world;
        e = ichunkloader;
        d = ichunkprovider;
    }

    public boolean d(int k, int l)
    {
        byte byte0 = 15;
        return k >= i - byte0 && l >= j - byte0 && k <= i + byte0 && l <= j + byte0;
    }

    public boolean isChunkLoaded(int k, int l)
    {
        if(!d(k, l))
            return false;
        if(k == a && l == b && h != null)
        {
            return true;
        } else
        {
            int i1 = k & 0x1f;
            int j1 = l & 0x1f;
            int k1 = i1 + j1 * 32;
            return f[k1] != null && (f[k1] == c || f[k1].a(k, l));
        }
    }

    public Chunk getChunkAt(int k, int l)
    {
        return getOrCreateChunk(k, l);
    }

    public Chunk getOrCreateChunk(int k, int l)
    {
        if(k == a && l == b && h != null)
            return h;
        if(!g.isLoading && !d(k, l))
            return c;
        int i1 = k & 0x1f;
        int j1 = l & 0x1f;
        int k1 = i1 + j1 * 32;
        if(!isChunkLoaded(k, l))
        {
            if(f[k1] != null)
            {
                f[k1].removeEntities();
                b(f[k1]);
                a(f[k1]);
            }
            Chunk chunk = e(k, l);
            if(chunk == null)
                if(d == null)
                {
                    chunk = c;
                } else
                {
                    chunk = d.getOrCreateChunk(k, l);
                    chunk.h();
                }
            f[k1] = chunk;
            chunk.loadNOP();
            if(f[k1] != null)
                f[k1].addEntities();
            if(!f[k1].done && isChunkLoaded(k + 1, l + 1) && isChunkLoaded(k, l + 1) && isChunkLoaded(k + 1, l))
                getChunkAt(this, k, l);
            if(isChunkLoaded(k - 1, l) && !getOrCreateChunk(k - 1, l).done && isChunkLoaded(k - 1, l + 1) && isChunkLoaded(k, l + 1) && isChunkLoaded(k - 1, l))
                getChunkAt(this, k - 1, l);
            if(isChunkLoaded(k, l - 1) && !getOrCreateChunk(k, l - 1).done && isChunkLoaded(k + 1, l - 1) && isChunkLoaded(k, l - 1) && isChunkLoaded(k + 1, l))
                getChunkAt(this, k, l - 1);
            if(isChunkLoaded(k - 1, l - 1) && !getOrCreateChunk(k - 1, l - 1).done && isChunkLoaded(k - 1, l - 1) && isChunkLoaded(k, l - 1) && isChunkLoaded(k - 1, l))
                getChunkAt(this, k - 1, l - 1);
        }
        a = k;
        b = l;
        h = f[k1];
        return f[k1];
    }

    private Chunk e(int k, int l)
    {
        if(e == null)
            return c;
        try
        {
            Chunk chunk = e.a(g, k, l);
            if(chunk != null)
                chunk.r = g.getTime();
            return chunk;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return c;
    }

    private void a(Chunk chunk)
    {
        if(e == null)
            return;
        try
        {
            e.b(g, chunk);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    private void b(Chunk chunk)
    {
        if(e == null)
            return;
        try
        {
            chunk.r = g.getTime();
            e.a(g, chunk);
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
    }

    public void getChunkAt(IChunkProvider ichunkprovider, int k, int l)
    {
        Chunk chunk = getOrCreateChunk(k, l);
        if(!chunk.done)
        {
            chunk.done = true;
            if(d != null)
            {
                d.getChunkAt(ichunkprovider, k, l);
                chunk.f();
            }
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        int k = 0;
        int l = 0;
        if(iprogressupdate != null)
        {
            for(int i1 = 0; i1 < f.length; i1++)
                if(f[i1] != null && f[i1].a(flag))
                    l++;

        }
        int j1 = 0;
        for(int k1 = 0; k1 < f.length; k1++)
        {
            if(f[k1] == null)
                continue;
            if(flag && !f[k1].p)
                a(f[k1]);
            if(!f[k1].a(flag))
                continue;
            b(f[k1]);
            f[k1].o = false;
            if(++k == 2 && !flag)
                return false;
            if(iprogressupdate != null && ++j1 % 10 == 0)
                iprogressupdate.a((j1 * 100) / l);
        }

        if(flag)
        {
            if(e == null)
                return true;
            e.b();
        }
        return true;
    }

    public boolean unloadChunks()
    {
        if(e != null)
            e.a();
        return d.unloadChunks();
    }

    public boolean b()
    {
        return true;
    }

    private Chunk c;
    private IChunkProvider d;
    private IChunkLoader e;
    private Chunk f[];
    private World g;
    int a;
    int b;
    private Chunk h;
    private int i;
    private int j;
}
