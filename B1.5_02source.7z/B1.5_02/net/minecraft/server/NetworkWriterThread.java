// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            NetworkManager

class NetworkWriterThread extends Thread
{

    NetworkWriterThread(NetworkManager networkmanager, String s)
    {
        a = networkmanager;
        super(s);
    }

    public void run()
    {
        synchronized(NetworkManager.a)
        {
            NetworkManager.c++;
        }
        for(; NetworkManager.a(a); NetworkManager.d(a));
        synchronized(NetworkManager.a)
        {
            NetworkManager.c--;
        }
        break MISSING_BLOCK_LABEL_105;
        Exception exception2;
        exception2;
        synchronized(NetworkManager.a)
        {
            NetworkManager.c--;
        }
        throw exception2;
    }

    final NetworkManager a;
}
