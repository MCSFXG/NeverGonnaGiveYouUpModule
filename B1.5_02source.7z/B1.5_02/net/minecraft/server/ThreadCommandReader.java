// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ThreadCommandReader.java

package net.minecraft.server;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jline.ConsoleReader;

// Referenced classes of package net.minecraft.server:
//            MinecraftServer

public class ThreadCommandReader extends Thread
{

    public ThreadCommandReader(MinecraftServer minecraftserver)
    {
        server = minecraftserver;
    }

    public void run()
    {
        try
        {
            ConsoleReader reader = server.reader;
            for(String line = null; !server.isStopped && MinecraftServer.isRunning(server) && (line = reader.readLine(">", null)) != null; server.issueCommand(line, server));
        }
        catch(IOException ioexception)
        {
            Logger.getLogger(net/minecraft/server/ThreadCommandReader.getName()).log(Level.SEVERE, null, ioexception);
        }
    }

    final MinecraftServer server;
}
