// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.lang.reflect.Constructor;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            World, ChunkPosition, EntityHuman, MathHelper, 
//            ChunkCoordIntPair, EnumCreatureType, WorldChunkManager, BiomeBase, 
//            BiomeMeta, ChunkCoordinates, EntityLiving, Material, 
//            EntitySpider, EntitySkeleton, EntitySheep, Pathfinder, 
//            PathEntity, PathPoint, BlockBed, EntityZombie

public final class SpawnerCreature
{

    public SpawnerCreature()
    {
    }

    protected static ChunkPosition a(World world, int i, int j)
    {
        int k = i + world.random.nextInt(16);
        int l = world.random.nextInt(128);
        int i1 = j + world.random.nextInt(16);
        return new ChunkPosition(k, l, i1);
    }

    public static final int spawnEntities(World world, boolean flag, boolean flag1)
    {
        int j;
        ChunkCoordinates chunkcoordinates;
        EnumCreatureType aenumcreaturetype[];
        int i1;
        int j1;
        if(!flag && !flag1)
            return 0;
        b.clear();
        for(int i = 0; i < world.players.size(); i++)
        {
            EntityHuman entityhuman = (EntityHuman)world.players.get(i);
            int k = MathHelper.floor(entityhuman.locX / 16D);
            int l = MathHelper.floor(entityhuman.locZ / 16D);
            byte byte0 = 8;
            for(int k1 = -byte0; k1 <= byte0; k1++)
            {
                for(int l1 = -byte0; l1 <= byte0; l1++)
                    b.add(new ChunkCoordIntPair(k1 + k, l1 + l));

            }

        }

        j = 0;
        chunkcoordinates = world.getSpawn();
        aenumcreaturetype = EnumCreatureType.values();
        i1 = aenumcreaturetype.length;
        j1 = 0;
_L10:
        if(j1 >= i1) goto _L2; else goto _L1
_L1:
        EnumCreatureType enumcreaturetype;
        Iterator iterator;
        enumcreaturetype = aenumcreaturetype[j1];
        if(enumcreaturetype.d() && !flag1 || !enumcreaturetype.d() && !flag || world.a(enumcreaturetype.a()) > (enumcreaturetype.b() * b.size()) / 256)
            continue; /* Loop/switch isn't completed */
        iterator = b.iterator();
_L4:
        BiomeMeta biomemeta1;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        do
        {
            ChunkCoordIntPair chunkcoordintpair;
            List list;
            do
            {
                if(!iterator.hasNext())
                    continue; /* Loop/switch isn't completed */
                chunkcoordintpair = (ChunkCoordIntPair)iterator.next();
                BiomeBase biomebase = world.getWorldChunkManager().a(chunkcoordintpair);
                list = biomebase.a(enumcreaturetype);
            } while(list == null || list.isEmpty());
            int i2 = 0;
            for(Iterator iterator1 = list.iterator(); iterator1.hasNext();)
            {
                BiomeMeta biomemeta = (BiomeMeta)iterator1.next();
                i2 += biomemeta.b;
            }

            int j2 = world.random.nextInt(i2);
            biomemeta1 = (BiomeMeta)list.get(0);
            Object obj = list.iterator();
            do
            {
                if(!((Iterator) (obj)).hasNext())
                    break;
                BiomeMeta biomemeta2 = (BiomeMeta)((Iterator) (obj)).next();
                j2 -= biomemeta2.b;
                if(j2 >= 0)
                    continue;
                biomemeta1 = biomemeta2;
                break;
            } while(true);
            obj = a(world, chunkcoordintpair.x * 16, chunkcoordintpair.z * 16);
            k2 = ((ChunkPosition) (obj)).x;
            l2 = ((ChunkPosition) (obj)).y;
            i3 = ((ChunkPosition) (obj)).z;
        } while(world.d(k2, l2, i3) || world.getMaterial(k2, l2, i3) != enumcreaturetype.c());
        j3 = 0;
        k3 = 0;
_L9:
        if(k3 >= 3) goto _L4; else goto _L3
_L3:
        int l3;
        int i4;
        int j4;
        byte byte1;
        int k4;
        l3 = k2;
        i4 = l2;
        j4 = i3;
        byte1 = 6;
        k4 = 0;
_L8:
        if(k4 >= 4) goto _L6; else goto _L5
_L5:
        EntityLiving entityliving;
        l3 += world.random.nextInt(byte1) - world.random.nextInt(byte1);
        i4 += world.random.nextInt(1) - world.random.nextInt(1);
        j4 += world.random.nextInt(byte1) - world.random.nextInt(byte1);
        if(!a(enumcreaturetype, world, l3, i4, j4))
            continue; /* Loop/switch isn't completed */
        float f = (float)l3 + 0.5F;
        float f1 = i4;
        float f2 = (float)j4 + 0.5F;
        if(world.a(f, f1, f2, 24D) != null)
            continue; /* Loop/switch isn't completed */
        float f3 = f - (float)chunkcoordinates.x;
        float f4 = f1 - (float)chunkcoordinates.y;
        float f5 = f2 - (float)chunkcoordinates.z;
        float f6 = f3 * f3 + f4 * f4 + f5 * f5;
        if(f6 < 576F)
            continue; /* Loop/switch isn't completed */
        try
        {
            entityliving = (EntityLiving)biomemeta1.a.getConstructor(new Class[] {
                net/minecraft/server/World
            }).newInstance(new Object[] {
                world
            });
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            return j;
        }
        entityliving.setPositionRotation(f, f1, f2, world.random.nextFloat() * 360F, 0.0F);
        if(!entityliving.d())
            break; /* Loop/switch isn't completed */
        j3++;
        world.addEntity(entityliving);
        a(entityliving, world, f, f1, f2);
        if(j3 < entityliving.l()) goto _L7; else goto _L4
_L7:
        j += j3;
        k4++;
          goto _L8
_L6:
        k3++;
          goto _L9
        j1++;
          goto _L10
_L2:
        return j;
    }

    private static boolean a(EnumCreatureType enumcreaturetype, World world, int i, int j, int k)
    {
        if(enumcreaturetype.c() == Material.WATER)
            return world.getMaterial(i, j, k).isLiquid() && !world.d(i, j + 1, k);
        else
            return world.d(i, j - 1, k) && !world.d(i, j, k) && !world.getMaterial(i, j, k).isLiquid() && !world.d(i, j + 1, k);
    }

    private static void a(EntityLiving entityliving, World world, float f, float f1, float f2)
    {
        if((entityliving instanceof EntitySpider) && world.random.nextInt(100) == 0)
        {
            EntitySkeleton entityskeleton = new EntitySkeleton(world);
            entityskeleton.setPositionRotation(f, f1, f2, entityliving.yaw, 0.0F);
            world.addEntity(entityskeleton);
            entityskeleton.mount(entityliving);
        } else
        if(entityliving instanceof EntitySheep)
            ((EntitySheep)entityliving).setColor(EntitySheep.a(world.random));
    }

    public static boolean a(World world, List list)
    {
        boolean flag = false;
        Pathfinder pathfinder = new Pathfinder(world);
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityHuman entityhuman = (EntityHuman)iterator.next();
            Class aclass[] = a;
            if(aclass != null && aclass.length != 0)
            {
                boolean flag1 = false;
                int i = 0;
                while(i < 20 && !flag1) 
                {
                    int j = (MathHelper.floor(entityhuman.locX) + world.random.nextInt(32)) - world.random.nextInt(32);
                    int k = (MathHelper.floor(entityhuman.locZ) + world.random.nextInt(32)) - world.random.nextInt(32);
                    int l = (MathHelper.floor(entityhuman.locY) + world.random.nextInt(16)) - world.random.nextInt(16);
                    if(l < 1)
                        l = 1;
                    else
                    if(l > 128)
                        l = 128;
                    int i1 = world.random.nextInt(aclass.length);
                    int j1;
                    for(j1 = l; j1 > 2 && !world.d(j, j1 - 1, k); j1--);
                    for(; !a(EnumCreatureType.MONSTER, world, j, j1, k) && j1 < l + 16 && j1 < 128; j1++);
                    if(j1 >= l + 16 || j1 >= 128)
                    {
                        j1 = l;
                    } else
                    {
                        float f = (float)j + 0.5F;
                        float f1 = j1;
                        float f2 = (float)k + 0.5F;
                        EntityLiving entityliving;
                        try
                        {
                            entityliving = (EntityLiving)aclass[i1].getConstructor(new Class[] {
                                net/minecraft/server/World
                            }).newInstance(new Object[] {
                                world
                            });
                        }
                        catch(Exception exception)
                        {
                            exception.printStackTrace();
                            return flag;
                        }
                        entityliving.setPositionRotation(f, f1, f2, world.random.nextFloat() * 360F, 0.0F);
                        if(entityliving.d())
                        {
                            PathEntity pathentity = pathfinder.a(entityliving, entityhuman, 32F);
                            if(pathentity != null && pathentity.a > 1)
                            {
                                PathPoint pathpoint = pathentity.c();
                                if(Math.abs((double)pathpoint.a - entityhuman.locX) < 1.5D && Math.abs((double)pathpoint.c - entityhuman.locZ) < 1.5D && Math.abs((double)pathpoint.b - entityhuman.locY) < 1.5D)
                                {
                                    ChunkCoordinates chunkcoordinates = BlockBed.f(world, MathHelper.floor(entityhuman.locX), MathHelper.floor(entityhuman.locY), MathHelper.floor(entityhuman.locZ), 1);
                                    if(chunkcoordinates == null)
                                        chunkcoordinates = new ChunkCoordinates(j, j1 + 1, k);
                                    entityliving.setPositionRotation((float)chunkcoordinates.x + 0.5F, chunkcoordinates.y, (float)chunkcoordinates.z + 0.5F, 0.0F, 0.0F);
                                    world.addEntity(entityliving);
                                    a(entityliving, world, (float)chunkcoordinates.x + 0.5F, chunkcoordinates.y, (float)chunkcoordinates.z + 0.5F);
                                    entityhuman.a(true, false, false);
                                    entityliving.M();
                                    flag = true;
                                    flag1 = true;
                                }
                            }
                        }
                    }
                    i++;
                }
            }
        } while(true);
        return flag;
    }

    private static Set b = new HashSet();
    protected static final Class a[] = {
        net/minecraft/server/EntitySpider, net/minecraft/server/EntityZombie, net/minecraft/server/EntitySkeleton
    };

}
