// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityFlying, IMonster, World, MathHelper, 
//            Entity, AxisAlignedBB, EntityFireball, Vec3D, 
//            Item

public class EntityGhast extends EntityFlying
    implements IMonster
{

    public EntityGhast(World world)
    {
        super(world);
        a = 0;
        g = null;
        h = 0;
        e = 0;
        f = 0;
        texture = "/mob/ghast.png";
        b(4F, 4F);
        bz = true;
    }

    protected void c_()
    {
        if(world.spawnMonsters == 0)
            die();
        Q();
        e = f;
        double d1 = b - locX;
        double d2 = c - locY;
        double d3 = d - locZ;
        double d4 = MathHelper.a(d1 * d1 + d2 * d2 + d3 * d3);
        if(d4 < 1.0D || d4 > 60D)
        {
            b = locX + (double)((random.nextFloat() * 2.0F - 1.0F) * 16F);
            c = locY + (double)((random.nextFloat() * 2.0F - 1.0F) * 16F);
            d = locZ + (double)((random.nextFloat() * 2.0F - 1.0F) * 16F);
        }
        if(a-- <= 0)
        {
            a += random.nextInt(5) + 2;
            if(a(b, c, d, d4))
            {
                motX += (d1 / d4) * 0.10000000000000001D;
                motY += (d2 / d4) * 0.10000000000000001D;
                motZ += (d3 / d4) * 0.10000000000000001D;
            } else
            {
                b = locX;
                c = locY;
                d = locZ;
            }
        }
        if(g != null && g.dead)
            g = null;
        if(g == null || h-- <= 0)
        {
            g = world.a(this, 100D);
            if(g != null)
                h = 20;
        }
        double d5 = 64D;
        if(g != null && g.g(this) < d5 * d5)
        {
            double d6 = g.locX - locX;
            double d7 = (g.boundingBox.b + (double)(g.width / 2.0F)) - (locY + (double)(width / 2.0F));
            double d8 = g.locZ - locZ;
            G = yaw = (-(float)Math.atan2(d6, d8) * 180F) / 3.141593F;
            if(e(g))
            {
                if(f == 10)
                    world.makeSound(this, "mob.ghast.charge", k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
                f++;
                if(f == 20)
                {
                    world.makeSound(this, "mob.ghast.fireball", k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
                    EntityFireball entityfireball = new EntityFireball(world, this, d6, d7, d8);
                    double d9 = 4D;
                    Vec3D vec3d = b(1.0F);
                    entityfireball.locX = locX + vec3d.a * d9;
                    entityfireball.locY = locY + (double)(width / 2.0F) + 0.5D;
                    entityfireball.locZ = locZ + vec3d.c * d9;
                    world.addEntity(entityfireball);
                    f = -40;
                }
            } else
            if(f > 0)
                f--;
        } else
        {
            G = yaw = (-(float)Math.atan2(motX, motZ) * 180F) / 3.141593F;
            if(f > 0)
                f--;
        }
        texture = f <= 10 ? "/mob/ghast.png" : "/mob/ghast_fire.png";
    }

    private boolean a(double d1, double d2, double d3, double d4)
    {
        double d5 = (b - locX) / d4;
        double d6 = (c - locY) / d4;
        double d7 = (d - locZ) / d4;
        AxisAlignedBB axisalignedbb = boundingBox.clone();
        for(int i1 = 1; (double)i1 < d4; i1++)
        {
            axisalignedbb.d(d5, d6, d7);
            if(world.getEntities(this, axisalignedbb).size() > 0)
                return false;
        }

        return true;
    }

    protected String g()
    {
        return "mob.ghast.moan";
    }

    protected String h()
    {
        return "mob.ghast.scream";
    }

    protected String i()
    {
        return "mob.ghast.death";
    }

    protected int j()
    {
        return Item.SULPHUR.id;
    }

    protected float k()
    {
        return 10F;
    }

    public boolean d()
    {
        return random.nextInt(20) == 0 && super.d() && world.spawnMonsters > 0;
    }

    public int l()
    {
        return 1;
    }

    public int a;
    public double b;
    public double c;
    public double d;
    private Entity g;
    private int h;
    public int e;
    public int f;
}
