// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockFlower, World, WorldGenTaiga2, WorldGenForest, 
//            WorldGenTrees, WorldGenBigTree, WorldGenerator

public class BlockSapling extends BlockFlower
{

    protected BlockSapling(int i, int j)
    {
        super(i, j);
        float f = 0.4F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        super.a(world, i, j, k, random);
        if(world.getLightLevel(i, j + 1, k) >= 9 && random.nextInt(30) == 0)
        {
            int l = world.getData(i, j, k);
            if((l & 8) == 0)
                world.setData(i, j, k, l | 8);
            else
                b(world, i, j, k, random);
        }
    }

    public int a(int i, int j)
    {
        j &= 3;
        if(j == 1)
            return 63;
        if(j == 2)
            return 79;
        else
            return super.a(i, j);
    }

    public void b(World world, int i, int j, int k, Random random)
    {
        int l = world.getData(i, j, k) & 3;
        world.setRawTypeId(i, j, k, 0);
        Object obj = null;
        if(l == 1)
            obj = new WorldGenTaiga2();
        else
        if(l == 2)
        {
            obj = new WorldGenForest();
        } else
        {
            obj = new WorldGenTrees();
            if(random.nextInt(10) == 0)
                obj = new WorldGenBigTree();
        }
        if(!((WorldGenerator) (obj)).a(world, random, i, j, k))
            world.setRawTypeIdAndData(i, j, k, id, l);
    }

    protected int b(int i)
    {
        return i & 3;
    }
}
