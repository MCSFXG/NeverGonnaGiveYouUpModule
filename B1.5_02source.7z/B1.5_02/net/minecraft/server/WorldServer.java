// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldServer.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.BlockChangeDelegate;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.weather.LightningStrikeEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            World, EntityList, PlayerManager, EntityHuman, 
//            ChunkProviderServer, TileEntity, Entity, Packet71Weather, 
//            Packet38EntityStatus, Packet60Explosion, Packet54PlayNoteBlock, Packet70Bed, 
//            WorldProvider, MinecraftServer, IDataManager, WorldData, 
//            MathHelper, ServerConfigurationManager, EntityTracker, Explosion, 
//            IChunkProvider

public class WorldServer extends World
    implements BlockChangeDelegate
{

    public WorldServer(MinecraftServer minecraftserver, IDataManager idatamanager, String s, int i, long j)
    {
        super(idatamanager, s, j, WorldProvider.a(i));
        weirdIsOpCache = false;
        A = new EntityList();
        server = minecraftserver;
        cserver = minecraftserver.server;
        manager = new PlayerManager(minecraftserver, this);
    }

    public CraftWorld getWorld()
    {
        return world;
    }

    public CraftServer getServer()
    {
        return cserver;
    }

    public void entityJoinedWorld(Entity entity, boolean flag)
    {
        if(entity.passenger == null || !(entity.passenger instanceof EntityHuman))
            super.entityJoinedWorld(entity, flag);
    }

    public void vehicleEnteredWorld(Entity entity, boolean flag)
    {
        super.entityJoinedWorld(entity, flag);
    }

    protected IChunkProvider b()
    {
        IChunkLoader ichunkloader = r.a(worldProvider);
        chunkProviderServer = new ChunkProviderServer(this, ichunkloader, worldProvider.c());
        return chunkProviderServer;
    }

    public List getTileEntities(int i, int j, int k, int l, int i1, int j1)
    {
        ArrayList arraylist = new ArrayList();
        for(int k1 = 0; k1 < c.size(); k1++)
        {
            TileEntity tileentity = (TileEntity)c.get(k1);
            if(tileentity.e >= i && tileentity.f >= j && tileentity.g >= k && tileentity.e < l && tileentity.f < i1 && tileentity.g < j1)
                arraylist.add(tileentity);
        }

        return arraylist;
    }

    public boolean a(EntityHuman entityhuman, int i, int j, int k)
    {
        int l = (int)MathHelper.abs(i - worldData.c());
        int i1 = (int)MathHelper.abs(k - worldData.e());
        if(l > i1)
            i1 = l;
        return i1 > server.spawnProtection || server.serverConfigurationManager.isOp(entityhuman.name);
    }

    protected void c(Entity entity)
    {
        super.c(entity);
        A.a(entity.id, entity);
    }

    protected void d(Entity entity)
    {
        super.d(entity);
        A.d(entity.id);
    }

    public Entity getEntity(int i)
    {
        return (Entity)A.a(i);
    }

    public boolean a(Entity entity)
    {
        if(super.a(entity))
        {
            CraftServer server = cserver;
            LightningStrikeEvent lightning = new LightningStrikeEvent(world, entity.getBukkitEntity());
            server.getPluginManager().callEvent(lightning);
            if(!lightning.isCancelled())
            {
                this.server.serverConfigurationManager.a(entity.locX, entity.locY, entity.locZ, 512D, new Packet71Weather(entity));
                return true;
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
    }

    public void a(Entity entity, byte b0)
    {
        Packet38EntityStatus packet38entitystatus = new Packet38EntityStatus(entity.id, b0);
        server.tracker.b(entity, packet38entitystatus);
    }

    public Explosion createExplosion(Entity entity, double d0, double d1, double d2, 
            float f, boolean flag)
    {
        Explosion explosion = super.createExplosion(entity, d0, d1, d2, f, flag);
        if(explosion.wasCanceled)
        {
            return explosion;
        } else
        {
            server.serverConfigurationManager.a(d0, d1, d2, 64D, new Packet60Explosion(d0, d1, d2, f, explosion.g));
            return explosion;
        }
    }

    public void d(int i, int j, int k, int l, int i1)
    {
        super.d(i, j, k, l, i1);
        server.serverConfigurationManager.a(i, j, k, 64D, new Packet54PlayNoteBlock(i, j, k, l, i1));
    }

    public void saveLevel()
    {
        r.e();
    }

    protected void i()
    {
        boolean flag = v();
        super.i();
        if(flag != v())
            if(flag)
                server.serverConfigurationManager.sendAll(new Packet70Bed(2));
            else
                server.serverConfigurationManager.sendAll(new Packet70Bed(1));
    }

    public ChunkProviderServer chunkProviderServer;
    public boolean weirdIsOpCache;
    public boolean y;
    public final MinecraftServer server;
    private EntityList A;
    public PlayerManager manager;
    private final CraftWorld world = new CraftWorld(this);
    private final CraftServer cserver;
}
