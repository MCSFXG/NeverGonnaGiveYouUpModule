// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityWeatherStorm.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityWeather, WorldServer, Entity, World, 
//            MathHelper, Block, BlockFire, AxisAlignedBB, 
//            NBTTagCompound

public class EntityWeatherStorm extends EntityWeather
{

    public EntityWeatherStorm(World world, double d0, double d1, double d2)
    {
        super(world);
        a = 0L;
        cworld = ((WorldServer)world).getWorld();
        server = ((WorldServer)world).getServer();
        setPositionRotation(d0, d1, d2, 0.0F, 0.0F);
        b = 2;
        a = random.nextLong();
        c = random.nextInt(3) + 1;
        if(world.spawnMonsters >= 2 && world.a(MathHelper.floor(d0), MathHelper.floor(d1), MathHelper.floor(d2), 10))
        {
            int i = MathHelper.floor(d0);
            int j = MathHelper.floor(d1);
            int k = MathHelper.floor(d2);
            if(world.getTypeId(i, j, k) == 0 && Block.FIRE.canPlace(world, i, j, k))
            {
                org.bukkit.block.Block theBlock = cworld.getBlockAt(i, j, k);
                BlockIgniteEvent event = new BlockIgniteEvent(theBlock, org.bukkit.event.block.BlockIgniteEvent.IgniteCause.LIGHTNING, null);
                ((WorldServer)world).getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    world.setTypeId(i, j, k, Block.FIRE.id);
            }
            for(i = 0; i < 4; i++)
            {
                j = (MathHelper.floor(d0) + random.nextInt(3)) - 1;
                k = (MathHelper.floor(d1) + random.nextInt(3)) - 1;
                int l = (MathHelper.floor(d2) + random.nextInt(3)) - 1;
                if(world.getTypeId(j, k, l) != 0 || !Block.FIRE.canPlace(world, j, k, l))
                    continue;
                org.bukkit.block.Block theBlock = cworld.getBlockAt(j, k, l);
                BlockIgniteEvent event = new BlockIgniteEvent(theBlock, org.bukkit.event.block.BlockIgniteEvent.IgniteCause.LIGHTNING, null);
                ((WorldServer)world).getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    world.setTypeId(j, k, l, Block.FIRE.id);
            }

        }
    }

    public void p_()
    {
        super.p_();
        if(b == 2)
        {
            world.makeSound(locX, locY, locZ, "ambient.weather.thunder", 10000F, 0.8F + random.nextFloat() * 0.2F);
            world.makeSound(locX, locY, locZ, "random.explode", 2.0F, 0.5F + random.nextFloat() * 0.2F);
        }
        b--;
        if(b < 0)
            if(c == 0)
                die();
            else
            if(b < -random.nextInt(10))
            {
                c--;
                b = 1;
                a = random.nextLong();
                if(world.a(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ), 10))
                {
                    int i = MathHelper.floor(locX);
                    int j = MathHelper.floor(locY);
                    int k = MathHelper.floor(locZ);
                    if(world.getTypeId(i, j, k) == 0 && Block.FIRE.canPlace(world, i, j, k))
                    {
                        org.bukkit.block.Block theBlock = cworld.getBlockAt(i, j, k);
                        BlockIgniteEvent event = new BlockIgniteEvent(theBlock, org.bukkit.event.block.BlockIgniteEvent.IgniteCause.LIGHTNING, null);
                        ((WorldServer)world).getServer().getPluginManager().callEvent(event);
                        if(!event.isCancelled())
                            world.setTypeId(i, j, k, Block.FIRE.id);
                    }
                }
            }
        if(b >= 0)
        {
            double d0 = 3D;
            List list = world.b(this, AxisAlignedBB.b(locX - d0, locY - d0, locZ - d0, locX + d0, locY + 6D + d0, locZ + d0));
            for(int l = 0; l < list.size(); l++)
            {
                Entity entity = (Entity)list.get(l);
                entity.a(this);
            }

            world.i = 2;
        }
    }

    protected void b()
    {
    }

    protected void a(NBTTagCompound nbttagcompound1)
    {
    }

    protected void b(NBTTagCompound nbttagcompound1)
    {
    }

    private int b;
    public long a;
    private int c;
    private CraftWorld cworld;
    private CraftServer server;
}
