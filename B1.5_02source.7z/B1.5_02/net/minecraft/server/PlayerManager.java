// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PlayerManager.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package net.minecraft.server:
//            PlayerList, PlayerInstance, EntityPlayer, MinecraftServer, 
//            WorldServer

public class PlayerManager
{

    public PlayerManager(MinecraftServer minecraftserver, WorldServer world)
    {
        a = new ArrayList();
        b = new PlayerList();
        c = new ArrayList();
        this.world = world;
        server = minecraftserver;
    }

    public void flush()
    {
        for(int i = 0; i < c.size(); i++)
            ((PlayerInstance)c.get(i)).a();

        c.clear();
    }

    private PlayerInstance a(int i, int j, boolean flag)
    {
        long k = (long)i + 0x7fffffffL | (long)j + 0x7fffffffL << 32;
        PlayerInstance playerinstance = (PlayerInstance)b.a(k);
        if(playerinstance == null && flag)
        {
            playerinstance = new PlayerInstance(this, i, j);
            b.a(k, playerinstance);
        }
        return playerinstance;
    }

    public void flagDirty(int i, int j, int k)
    {
        int l = i >> 4;
        int i1 = k >> 4;
        PlayerInstance playerinstance = a(l, i1, false);
        if(playerinstance != null)
            playerinstance.a(i & 0xf, j, k & 0xf);
    }

    public void addPlayer(EntityPlayer entityplayer)
    {
        int i = (int)entityplayer.locX >> 4;
        int j = (int)entityplayer.locZ >> 4;
        entityplayer.d = entityplayer.locX;
        entityplayer.e = entityplayer.locZ;
        int k = 0;
        byte b0 = 10;
        int l = 0;
        int i1 = 0;
        a(i, j, true).a(entityplayer);
        for(int j1 = 1; j1 <= b0 * 2; j1++)
        {
            for(int k1 = 0; k1 < 2; k1++)
            {
                int aint[] = e[k++ % 4];
                for(int l1 = 0; l1 < j1; l1++)
                {
                    l += aint[0];
                    i1 += aint[1];
                    a(i + l, j + i1, true).a(entityplayer);
                }

            }

        }

        k %= 4;
        for(int j1 = 0; j1 < b0 * 2; j1++)
        {
            l += e[k][0];
            i1 += e[k][1];
            a(i + l, j + i1, true).a(entityplayer);
        }

        a.add(entityplayer);
    }

    public void removePlayer(EntityPlayer entityplayer)
    {
        int i = (int)entityplayer.d >> 4;
        int j = (int)entityplayer.e >> 4;
        for(int k = i - 10; k <= i + 10; k++)
        {
            for(int l = j - 10; l <= j + 10; l++)
            {
                PlayerInstance playerinstance = a(k, l, false);
                if(playerinstance != null)
                    playerinstance.b(entityplayer);
            }

        }

        a.remove(entityplayer);
    }

    private boolean a(int i, int j, int k, int l)
    {
        int i1 = i - k;
        int j1 = j - l;
        return i1 < -10 || i1 > 10 ? false : j1 >= -10 && j1 <= 10;
    }

    public void movePlayer(EntityPlayer entityplayer)
    {
        int i = (int)entityplayer.locX >> 4;
        int j = (int)entityplayer.locZ >> 4;
        double d0 = entityplayer.d - entityplayer.locX;
        double d1 = entityplayer.e - entityplayer.locZ;
        double d2 = d0 * d0 + d1 * d1;
        if(d2 >= 64D)
        {
            int k = (int)entityplayer.d >> 4;
            int l = (int)entityplayer.e >> 4;
            int i1 = i - k;
            int j1 = j - l;
            if(i1 > 10 || i1 < -10 || j1 > 10 || j1 < -10)
            {
                removePlayer(entityplayer);
                addPlayer(entityplayer);
                return;
            }
            if(i1 != 0 || j1 != 0)
            {
                for(int k1 = i - 10; k1 <= i + 10; k1++)
                {
                    for(int l1 = j - 10; l1 <= j + 10; l1++)
                    {
                        if(!a(k1, l1, k, l))
                            a(k1, l1, true).a(entityplayer);
                        if(a(k1 - i1, l1 - j1, i, j))
                            continue;
                        PlayerInstance playerinstance = a(k1 - i1, l1 - j1, false);
                        if(playerinstance != null)
                            playerinstance.b(entityplayer);
                    }

                }

                entityplayer.d = entityplayer.locX;
                entityplayer.e = entityplayer.locZ;
            }
        }
    }

    public int b()
    {
        return 144;
    }

    static MinecraftServer a(PlayerManager playermanager)
    {
        return playermanager.server;
    }

    static PlayerList b(PlayerManager playermanager)
    {
        return playermanager.b;
    }

    static List c(PlayerManager playermanager)
    {
        return playermanager.c;
    }

    private List a;
    private PlayerList b;
    private List c;
    private MinecraftServer server;
    private final int e[][] = {
        {
            1, 0
        }, {
            0, 1
        }, {
            -1, 0
        }, {
            0, -1
        }
    };
    public WorldServer world;
}
