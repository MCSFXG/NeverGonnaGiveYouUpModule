// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TileEntityFurnace.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            TileEntity, ItemStack, NBTTagCompound, NBTTagList, 
//            IInventory, World, BlockFurnace, FurnaceRecipes, 
//            Item, Block, Material, EntityHuman

public class TileEntityFurnace extends TileEntity
    implements IInventory
{

    public ItemStack[] getContents()
    {
        return items;
    }

    public TileEntityFurnace()
    {
        items = new ItemStack[3];
        burnTime = 0;
        b = 0;
        cookTime = 0;
    }

    public int getSize()
    {
        return items.length;
    }

    public ItemStack getItem(int i)
    {
        return items[i];
    }

    public ItemStack a(int i, int j)
    {
        if(items[i] != null)
        {
            ItemStack itemstack;
            if(items[i].count <= j)
            {
                itemstack = items[i];
                items[i] = null;
                return itemstack;
            }
            itemstack = items[i].a(j);
            if(items[i].count == 0)
                items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        items[i] = itemstack;
        if(itemstack != null && itemstack.count > getMaxStackSize())
            itemstack.count = getMaxStackSize();
    }

    public String getName()
    {
        return "Furnace";
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.l("Items");
        items = new ItemStack[getSize()];
        for(int i = 0; i < nbttaglist.c(); i++)
        {
            NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.a(i);
            byte b0 = nbttagcompound1.c("Slot");
            if(b0 >= 0 && b0 < items.length)
                items[b0] = new ItemStack(nbttagcompound1);
        }

        burnTime = nbttagcompound.d("BurnTime");
        cookTime = nbttagcompound.d("CookTime");
        b = a(items[1]);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("BurnTime", (short)burnTime);
        nbttagcompound.a("CookTime", (short)cookTime);
        NBTTagList nbttaglist = new NBTTagList();
        for(int i = 0; i < items.length; i++)
            if(items[i] != null)
            {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.a("Slot", (byte)i);
                items[i].a(nbttagcompound1);
                nbttaglist.a(nbttagcompound1);
            }

        nbttagcompound.a("Items", nbttaglist);
    }

    public int getMaxStackSize()
    {
        return 64;
    }

    public boolean f()
    {
        return burnTime > 0;
    }

    public void g_()
    {
        boolean flag = burnTime > 0;
        boolean flag1 = false;
        if(burnTime > 0)
            burnTime--;
        if(!world.isStatic)
        {
            if(burnTime == 0 && h())
            {
                b = burnTime = a(items[1]);
                if(burnTime > 0)
                {
                    flag1 = true;
                    if(items[1] != null)
                    {
                        items[1].count--;
                        if(items[1].count == 0)
                            items[1] = null;
                    }
                }
            }
            if(f() && h())
            {
                cookTime++;
                if(cookTime == 200)
                {
                    cookTime = 0;
                    g();
                    flag1 = true;
                }
            } else
            {
                cookTime = 0;
            }
            if(flag != (burnTime > 0))
            {
                flag1 = true;
                BlockFurnace.a(burnTime > 0, world, e, f, g);
            }
        }
        if(flag1)
            update();
    }

    private boolean h()
    {
        if(items[0] == null)
        {
            return false;
        } else
        {
            ItemStack itemstack = FurnaceRecipes.a().a(items[0].getItem().id);
            return itemstack != null ? items[2] != null ? items[2].a(itemstack) ? items[2].count >= getMaxStackSize() || items[2].count >= items[2].b() ? items[2].count < itemstack.b() : true : false : true : false;
        }
    }

    public void g()
    {
        if(h())
        {
            ItemStack itemstack = FurnaceRecipes.a().a(items[0].getItem().id);
            if(items[2] == null)
                items[2] = itemstack.j();
            else
            if(items[2].id == itemstack.id)
                items[2].count++;
            items[0].count--;
            if(items[0].count <= 0)
                items[0] = null;
        }
    }

    private int a(ItemStack itemstack)
    {
        if(itemstack == null)
        {
            return 0;
        } else
        {
            int i = itemstack.getItem().id;
            return i >= 256 || Block.byId[i].material != Material.WOOD ? i != Item.STICK.id ? i != Item.COAL.id ? i != Item.LAVA_BUCKET.id ? ((char) (i != Block.SAPLING.id ? '\0' : 'd')) : '\u4E20' : '\u0640' : 100 : 300;
        }
    }

    public boolean a_(EntityHuman entityhuman)
    {
        return world.getTileEntity(e, f, g) == this ? entityhuman.d((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D : false;
    }

    private ItemStack items[];
    public int burnTime;
    public int b;
    public int cookTime;
}
