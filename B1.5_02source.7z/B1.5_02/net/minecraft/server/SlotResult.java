// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Slot, ItemStack, Block, AchievementList, 
//            EntityHuman, Item, IInventory

public class SlotResult extends Slot
{

    public SlotResult(EntityHuman entityhuman, IInventory iinventory, IInventory iinventory1, int i, int j, int k)
    {
        super(iinventory1, i, j, k);
        e = entityhuman;
        d = iinventory;
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        return false;
    }

    public void a(ItemStack itemstack)
    {
        if(itemstack.id == Block.WORKBENCH.id)
            e.a(AchievementList.h, 1);
        else
        if(itemstack.id == Item.WOOD_PICKAXE.id)
            e.a(AchievementList.i, 1);
        else
        if(itemstack.id == Block.FURNACE.id)
            e.a(AchievementList.j, 1);
        else
        if(itemstack.id == Item.WOOD_HOE.id)
            e.a(AchievementList.l, 1);
        else
        if(itemstack.id == Item.BREAD.id)
            e.a(AchievementList.m, 1);
        else
        if(itemstack.id == Item.CAKE.id)
            e.a(AchievementList.n, 1);
        else
        if(itemstack.id == Item.STONE_PICKAXE.id)
            e.a(AchievementList.o, 1);
        else
        if(itemstack.id == Item.WOOD_SWORD.id)
            e.a(AchievementList.r, 1);
        for(int i = 0; i < d.getSize(); i++)
        {
            ItemStack itemstack1 = d.getItem(i);
            if(itemstack1 == null)
                continue;
            d.a(i, 1);
            if(itemstack1.getItem().h())
                d.setItem(i, new ItemStack(itemstack1.getItem().g()));
        }

    }

    public boolean e()
    {
        return true;
    }

    private final IInventory d;
    private EntityHuman e;
}
