// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsoleCommandHandler.java

package net.minecraft.server;

import java.util.*;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.server:
//            WorldServer, EntityPlayer, ItemStack, Packet3Chat, 
//            ServerCommand, ICommandListener, MinecraftServer, ServerConfigurationManager, 
//            NetServerHandler, Item, PropertyManager

public class ConsoleCommandHandler
{

    public ConsoleCommandHandler(MinecraftServer minecraftserver)
    {
        server = minecraftserver;
    }

    public boolean handle(ServerCommand servercommand)
    {
        String s = servercommand.command;
        ICommandListener icommandlistener = servercommand.b;
        String s1 = icommandlistener.getName();
        WorldServer worldserver = (WorldServer)server.worlds.get(0);
        listener = icommandlistener;
        ServerConfigurationManager serverconfigurationmanager = server.serverConfigurationManager;
        if(!s.toLowerCase().startsWith("help") && !s.toLowerCase().startsWith("?"))
        {
            if(s.toLowerCase().startsWith("list"))
                icommandlistener.sendMessage((new StringBuilder()).append("Connected players: ").append(serverconfigurationmanager.c()).toString());
            else
            if(s.toLowerCase().startsWith("stop"))
            {
                print(s1, "Stopping the server..");
                server.a();
            } else
            if(s.toLowerCase().startsWith("save-all"))
            {
                print(s1, "Forcing save..");
                server.saveChunks();
                print(s1, "Save complete.");
            } else
            if(s.toLowerCase().startsWith("save-off"))
            {
                print(s1, "Disabling level saving..");
                worldserver.y = true;
            } else
            if(s.toLowerCase().startsWith("save-on"))
            {
                print(s1, "Enabling level saving..");
                worldserver.y = false;
            } else
            if(s.toLowerCase().startsWith("op "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.e(s2);
                print(s1, (new StringBuilder()).append("Opping ").append(s2).toString());
                serverconfigurationmanager.a(s2, "\247eYou are now op!");
            } else
            if(s.toLowerCase().startsWith("deop "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.f(s2);
                serverconfigurationmanager.a(s2, "\247eYou are no longer op!");
                print(s1, (new StringBuilder()).append("De-opping ").append(s2).toString());
            } else
            if(s.toLowerCase().startsWith("ban-ip "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.c(s2);
                print(s1, (new StringBuilder()).append("Banning ip ").append(s2).toString());
            } else
            if(s.toLowerCase().startsWith("pardon-ip "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.d(s2);
                print(s1, (new StringBuilder()).append("Pardoning ip ").append(s2).toString());
            } else
            if(s.toLowerCase().startsWith("ban "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.a(s2);
                print(s1, (new StringBuilder()).append("Banning ").append(s2).toString());
                EntityPlayer entityplayer = serverconfigurationmanager.i(s2);
                if(entityplayer != null)
                    entityplayer.netServerHandler.disconnect("Banned by admin");
            } else
            if(s.toLowerCase().startsWith("pardon "))
            {
                String s2 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.b(s2);
                print(s1, (new StringBuilder()).append("Pardoning ").append(s2).toString());
            } else
            if(s.toLowerCase().startsWith("kick "))
            {
                String parts[] = s.split(" ");
                String s2 = parts.length < 2 ? "" : parts[1];
                EntityPlayer entityplayer = null;
                for(int i = 0; i < serverconfigurationmanager.players.size(); i++)
                {
                    EntityPlayer entityplayer1 = (EntityPlayer)serverconfigurationmanager.players.get(i);
                    if(entityplayer1.name.equalsIgnoreCase(s2))
                        entityplayer = entityplayer1;
                }

                if(entityplayer != null)
                {
                    entityplayer.netServerHandler.disconnect("Kicked by admin");
                    print(s1, (new StringBuilder()).append("Kicking ").append(entityplayer.name).toString());
                } else
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s2).append(". No kick.").toString());
                }
            } else
            if(s.toLowerCase().startsWith("tp "))
            {
                String astring[] = s.split(" ");
                if(astring.length == 3)
                {
                    EntityPlayer entityplayer = serverconfigurationmanager.i(astring[1]);
                    EntityPlayer entityplayer2 = serverconfigurationmanager.i(astring[2]);
                    if(entityplayer == null)
                        icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(astring[1]).append(". No tp.").toString());
                    else
                    if(entityplayer2 == null)
                    {
                        icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(astring[2]).append(". No tp.").toString());
                    } else
                    {
                        entityplayer.netServerHandler.a(entityplayer2.locX, entityplayer2.locY, entityplayer2.locZ, entityplayer2.yaw, entityplayer2.pitch);
                        print(s1, (new StringBuilder()).append("Teleporting ").append(astring[1]).append(" to ").append(astring[2]).append(".").toString());
                    }
                } else
                {
                    icommandlistener.sendMessage("Syntax error, please provice a source and a target.");
                }
            } else
            if(s.toLowerCase().startsWith("give "))
            {
                String astring[] = s.split(" ");
                if(astring.length != 3 && astring.length != 4)
                    return true;
                String s3 = astring[1];
                EntityPlayer entityplayer2 = serverconfigurationmanager.i(s3);
                if(entityplayer2 != null)
                    try
                    {
                        int j = Integer.parseInt(astring[2]);
                        if(Item.byId[j] != null)
                        {
                            print(s1, (new StringBuilder()).append("Giving ").append(entityplayer2.name).append(" some ").append(j).toString());
                            int k = 1;
                            if(astring.length > 3)
                                k = a(astring[3], 1);
                            if(k < 1)
                                k = 1;
                            if(k > 64)
                                k = 64;
                            entityplayer2.b(new ItemStack(j, k, 0));
                        } else
                        {
                            icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(j).toString());
                        }
                    }
                    catch(NumberFormatException numberformatexception)
                    {
                        icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(astring[2]).toString());
                    }
                else
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s3).toString());
            } else
            if(s.toLowerCase().startsWith("time "))
            {
                String astring[] = s.split(" ");
                if(astring.length != 3)
                    return true;
                String s3 = astring[1];
                try
                {
                    int i = Integer.parseInt(astring[2]);
                    if("add".equalsIgnoreCase(s3))
                    {
                        worldserver.setTime(worldserver.getTime() + (long)i);
                        print(s1, (new StringBuilder()).append("Added ").append(i).append(" to time").toString());
                    } else
                    if("set".equalsIgnoreCase(s3))
                    {
                        worldserver.setTime(i);
                        print(s1, (new StringBuilder()).append("Set time to ").append(i).toString());
                    } else
                    {
                        icommandlistener.sendMessage("Unknown method, use either \"add\" or \"set\"");
                    }
                }
                catch(NumberFormatException numberformatexception1)
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("Unable to convert time value, ").append(astring[2]).toString());
                }
            } else
            if(s.toLowerCase().startsWith("say "))
            {
                s = s.substring(s.indexOf(" ")).trim();
                a.info((new StringBuilder()).append("[").append(s1).append("] ").append(s).toString());
                serverconfigurationmanager.sendAll(new Packet3Chat((new StringBuilder()).append("\247d[Server] ").append(s).toString()));
            } else
            if(s.toLowerCase().startsWith("tell "))
            {
                String astring[] = s.split(" ");
                if(astring.length >= 3)
                {
                    s = s.substring(s.indexOf(" ")).trim();
                    s = s.substring(s.indexOf(" ")).trim();
                    a.info((new StringBuilder()).append("[").append(s1).append("->").append(astring[1]).append("] ").append(s).toString());
                    s = (new StringBuilder()).append("\2477").append(s1).append(" whispers ").append(s).toString();
                    a.info(s);
                    if(!serverconfigurationmanager.a(astring[1], new Packet3Chat(s)))
                        icommandlistener.sendMessage("There's no player by that name online.");
                }
            } else
            if(s.toLowerCase().startsWith("whitelist "))
            {
                a(s1, s, icommandlistener);
            } else
            {
                icommandlistener.sendMessage("Unknown console command. Type \"help\" for help.");
                return false;
            }
        } else
        {
            a(icommandlistener);
        }
        return true;
    }

    private void a(String s, String s1, ICommandListener icommandlistener)
    {
        String astring[] = s1.split(" ");
        listener = icommandlistener;
        if(astring.length >= 2)
        {
            String s2 = astring[1].toLowerCase();
            if("on".equals(s2))
            {
                print(s, "Turned on white-listing");
                server.propertyManager.b("white-list", true);
            } else
            if("off".equals(s2))
            {
                print(s, "Turned off white-listing");
                server.propertyManager.b("white-list", false);
            } else
            if("list".equals(s2))
            {
                Set set = server.serverConfigurationManager.e();
                String s3 = "";
                for(Iterator iterator = set.iterator(); iterator.hasNext();)
                {
                    String s4 = (String)iterator.next();
                    s3 = (new StringBuilder()).append(s3).append(s4).append(" ").toString();
                }

                icommandlistener.sendMessage((new StringBuilder()).append("White-listed players: ").append(s3).toString());
            } else
            if("add".equals(s2) && astring.length == 3)
            {
                String s5 = astring[2].toLowerCase();
                server.serverConfigurationManager.k(s5);
                print(s, (new StringBuilder()).append("Added ").append(s5).append(" to white-list").toString());
            } else
            if("remove".equals(s2) && astring.length == 3)
            {
                String s5 = astring[2].toLowerCase();
                server.serverConfigurationManager.l(s5);
                print(s, (new StringBuilder()).append("Removed ").append(s5).append(" from white-list").toString());
            } else
            if("reload".equals(s2))
            {
                server.serverConfigurationManager.f();
                print(s, "Reloaded white-list from file");
            }
        }
    }

    private void a(ICommandListener icommandlistener)
    {
        icommandlistener.sendMessage("To run the server without a gui, start it like this:");
        icommandlistener.sendMessage("   java -Xmx1024M -Xms1024M -jar minecraft_server.jar nogui");
        icommandlistener.sendMessage("Console commands:");
        icommandlistener.sendMessage("   help  or  ?               shows this message");
        icommandlistener.sendMessage("   kick <player>             removes a player from the server");
        icommandlistener.sendMessage("   ban <player>              bans a player from the server");
        icommandlistener.sendMessage("   pardon <player>           pardons a banned player so that they can connect again");
        icommandlistener.sendMessage("   ban-ip <ip>               bans an IP address from the server");
        icommandlistener.sendMessage("   pardon-ip <ip>            pardons a banned IP address so that they can connect again");
        icommandlistener.sendMessage("   op <player>               turns a player into an op");
        icommandlistener.sendMessage("   deop <player>             removes op status from a player");
        icommandlistener.sendMessage("   tp <player1> <player2>    moves one player to the same location as another player");
        icommandlistener.sendMessage("   give <player> <id> [num]  gives a player a resource");
        icommandlistener.sendMessage("   tell <player> <message>   sends a private message to a player");
        icommandlistener.sendMessage("   stop                      gracefully stops the server");
        icommandlistener.sendMessage("   save-all                  forces a server-wide level save");
        icommandlistener.sendMessage("   save-off                  disables terrain saving (useful for backup scripts)");
        icommandlistener.sendMessage("   save-on                   re-enables terrain saving");
        icommandlistener.sendMessage("   list                      lists all currently connected players");
        icommandlistener.sendMessage("   say <message>             broadcasts a message to all players");
        icommandlistener.sendMessage("   time <add|set> <amount>   adds to or sets the world time (0-24000)");
    }

    private void print(String s, String s1)
    {
        listener.sendMessage(s1);
        String s2 = (new StringBuilder()).append(s).append(": ").append(s1).toString();
        server.serverConfigurationManager.j((new StringBuilder()).append("\2477(").append(s2).append(")").toString());
        a.info(s2);
    }

    private int a(String s, int i)
    {
        try
        {
            return Integer.parseInt(s);
        }
        catch(NumberFormatException numberformatexception)
        {
            return i;
        }
    }

    private static Logger a = Logger.getLogger("Minecraft");
    private MinecraftServer server;
    private ICommandListener listener;

}
