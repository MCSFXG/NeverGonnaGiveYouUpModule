// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NetworkManager.java

package net.minecraft.server;

import java.io.*;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            NetworkReaderThread, NetworkWriterThread, Packet, NetworkMasterThread, 
//            ThreadMonitorConnection, NetHandler

public class NetworkManager
{

    public NetworkManager(Socket socket, String s, NetHandler nethandler)
    {
        e = new Object();
        j = true;
        k = Collections.synchronizedList(new ArrayList());
        l = Collections.synchronizedList(new ArrayList());
        m = Collections.synchronizedList(new ArrayList());
        o = false;
        r = false;
        this.s = "";
        u = 0;
        v = 0;
        d = 0;
        w = 50;
        this.socket = socket;
        g = socket.getRemoteSocketAddress();
        n = nethandler;
        try
        {
            socket.setSoTimeout(30000);
            socket.setTrafficClass(24);
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());
        }
        catch(IOException socketexception)
        {
            System.err.println(socketexception.getMessage());
        }
        q = new NetworkReaderThread(this, (new StringBuilder()).append(s).append(" read thread").toString());
        p = new NetworkWriterThread(this, (new StringBuilder()).append(s).append(" write thread").toString());
        q.start();
        p.start();
    }

    public void a(NetHandler nethandler)
    {
        n = nethandler;
    }

    public void a(Packet packet)
    {
        if(!o)
        {
            Object object = e;
            synchronized(e)
            {
                v += packet.a() + 1;
                if(packet.k)
                    m.add(packet);
                else
                    l.add(packet);
            }
        }
    }

    private void e()
    {
        try
        {
            boolean flag = true;
            if(!l.isEmpty() && (d == 0 || System.currentTimeMillis() - ((Packet)l.get(0)).timestamp >= (long)d))
            {
                flag = false;
                Object object = e;
                Packet packet;
                synchronized(e)
                {
                    packet = (Packet)l.remove(0);
                    v -= packet.a() + 1;
                }
                Packet.a(packet, output);
            }
            if((flag || w-- <= 0) && !m.isEmpty() && (d == 0 || System.currentTimeMillis() - ((Packet)m.get(0)).timestamp >= (long)d))
            {
                flag = false;
                Object object = e;
                Packet packet;
                synchronized(e)
                {
                    packet = (Packet)m.remove(0);
                    v -= packet.a() + 1;
                }
                Packet.a(packet, output);
                w = 50;
            }
            if(flag)
                Thread.sleep(10L);
            else
                output.flush();
        }
        catch(InterruptedException interruptedexception) { }
        catch(Exception exception)
        {
            if(!r)
                a(exception);
        }
    }

    private void f()
    {
        try
        {
            Packet packet = Packet.a(input, n.c());
            if(packet != null)
                k.add(packet);
            else
                a("disconnect.endOfStream", new Object[0]);
        }
        catch(Exception exception)
        {
            if(!r)
                a(exception);
        }
    }

    private void a(Exception exception)
    {
        exception.printStackTrace();
        a("disconnect.genericReason", new Object[] {
            (new StringBuilder()).append("Internal exception: ").append(exception.toString()).toString()
        });
    }

    public transient void a(String s, Object aobject[])
    {
        if(j)
        {
            r = true;
            this.s = s;
            t = aobject;
            (new NetworkMasterThread(this)).start();
            j = false;
            try
            {
                input.close();
                input = null;
            }
            catch(Throwable throwable) { }
            try
            {
                output.close();
                output = null;
            }
            catch(Throwable throwable1) { }
            try
            {
                socket.close();
                socket = null;
            }
            catch(Throwable throwable2) { }
        }
    }

    public void a()
    {
        if(v > 0x100000)
            a("disconnect.overflow", new Object[0]);
        if(k.isEmpty())
        {
            if(u++ == 1200)
                a("disconnect.timeout", new Object[0]);
        } else
        {
            u = 0;
        }
        Packet packet;
        for(int i = 100; !k.isEmpty() && i-- >= 0; packet.a(n))
            packet = (Packet)k.remove(0);

        if(r && k.isEmpty())
            n.a(s, t);
    }

    public SocketAddress getSocketAddress()
    {
        return g;
    }

    public void c()
    {
        o = true;
        q.interrupt();
        (new ThreadMonitorConnection(this)).start();
    }

    public int d()
    {
        return m.size();
    }

    static boolean a(NetworkManager networkmanager)
    {
        return networkmanager.j;
    }

    static boolean b(NetworkManager networkmanager)
    {
        return networkmanager.o;
    }

    static void c(NetworkManager networkmanager)
    {
        networkmanager.f();
    }

    static void d(NetworkManager networkmanager)
    {
        networkmanager.e();
    }

    static Thread e(NetworkManager networkmanager)
    {
        return networkmanager.q;
    }

    static Thread f(NetworkManager networkmanager)
    {
        return networkmanager.p;
    }

    public static final Object a = new Object();
    public static int b;
    public static int c;
    private Object e;
    public Socket socket;
    private final SocketAddress g;
    private DataInputStream input;
    private DataOutputStream output;
    private boolean j;
    private List k;
    private List l;
    private List m;
    private NetHandler n;
    private boolean o;
    private Thread p;
    private Thread q;
    private boolean r;
    private String s;
    private Object t[];
    private int u;
    private int v;
    public int d;
    private int w;

}
