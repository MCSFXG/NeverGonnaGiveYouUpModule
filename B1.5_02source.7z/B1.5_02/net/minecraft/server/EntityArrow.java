// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityArrow.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityDamageByProjectileEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, MovingObjectPosition, EntityLiving, WorldServer, 
//            ItemStack, MathHelper, World, Vec3D, 
//            AxisAlignedBB, NBTTagCompound, EntityHuman, Item, 
//            InventoryPlayer

public class EntityArrow extends Entity
{

    public EntityArrow(World world)
    {
        super(world);
        c = -1;
        d = -1;
        e = -1;
        f = 0;
        g = false;
        a = 0;
        i = 0;
        b(0.5F, 0.5F);
    }

    public EntityArrow(World world, double d0, double d1, double d2)
    {
        super(world);
        c = -1;
        d = -1;
        e = -1;
        f = 0;
        g = false;
        a = 0;
        i = 0;
        b(0.5F, 0.5F);
        setPosition(d0, d1, d2);
        height = 0.0F;
    }

    public EntityArrow(World world, EntityLiving entityliving)
    {
        super(world);
        c = -1;
        d = -1;
        e = -1;
        f = 0;
        g = false;
        a = 0;
        i = 0;
        shooter = entityliving;
        b(0.5F, 0.5F);
        setPositionRotation(entityliving.locX, entityliving.locY + (double)entityliving.s(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        locX -= MathHelper.cos((yaw / 180F) * 3.141593F) * 0.16F;
        locY -= 0.10000000149011612D;
        locZ -= MathHelper.sin((yaw / 180F) * 3.141593F) * 0.16F;
        setPosition(locX, locY, locZ);
        height = 0.0F;
        motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F);
        motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F);
        motY = -MathHelper.sin((pitch / 180F) * 3.141593F);
        a(motX, motY, motZ, 1.5F, 1.0F);
    }

    protected void b()
    {
    }

    public void a(double d0, double d1, double d2, float f, 
            float f1)
    {
        float f2 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= f2;
        d1 /= f2;
        d2 /= f2;
        d0 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d1 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d2 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d0 *= f;
        d1 *= f;
        d2 *= f;
        motX = d0;
        motY = d1;
        motZ = d2;
        float f3 = MathHelper.a(d0 * d0 + d2 * d2);
        lastYaw = yaw = (float)((Math.atan2(d0, d2) * 180D) / 3.1415927410125732D);
        lastPitch = pitch = (float)((Math.atan2(d1, f3) * 180D) / 3.1415927410125732D);
        h = 0;
    }

    public void p_()
    {
        super.p_();
        if(lastPitch == 0.0F && lastYaw == 0.0F)
        {
            float f = MathHelper.a(motX * motX + motZ * motZ);
            lastYaw = yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
            lastPitch = pitch = (float)((Math.atan2(motY, f) * 180D) / 3.1415927410125732D);
        }
        if(a > 0)
            a--;
        if(g)
        {
            int i = world.getTypeId(c, d, e);
            if(i == this.f)
            {
                h++;
                if(h == 1200)
                    die();
                return;
            }
            g = false;
            motX *= random.nextFloat() * 0.2F;
            motY *= random.nextFloat() * 0.2F;
            motZ *= random.nextFloat() * 0.2F;
            h = 0;
            this.i = 0;
        } else
        {
            this.i++;
        }
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if(movingobjectposition != null)
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        Entity entity = null;
        List list = world.b(this, boundingBox.a(motX, motY, motZ).b(1.0D, 1.0D, 1.0D));
        double d0 = 0.0D;
        float f1;
        for(int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);
            if(!entity1.o_() || entity1 == this.shooter && this.i < 5)
                continue;
            f1 = 0.3F;
            AxisAlignedBB axisalignedbb = entity1.boundingBox.b(f1, f1, f1);
            MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
            if(movingobjectposition1 == null)
                continue;
            double d1 = vec3d.a(movingobjectposition1.f);
            if(d1 < d0 || d0 == 0.0D)
            {
                entity = entity1;
                d0 = d1;
            }
        }

        if(entity != null)
            movingobjectposition = new MovingObjectPosition(entity);
        float f2;
        if(movingobjectposition != null)
            if(movingobjectposition.entity != null)
            {
                boolean stick;
                if(entity instanceof EntityLiving)
                {
                    CraftServer server = ((WorldServer)world).getServer();
                    org.bukkit.entity.Entity shooter = this.shooter != null ? this.shooter.getBukkitEntity() : null;
                    org.bukkit.entity.Entity damagee = movingobjectposition.entity.getBukkitEntity();
                    org.bukkit.entity.Entity projectile = getBukkitEntity();
                    org.bukkit.event.entity.EntityDamageEvent.DamageCause damageCause = org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                    int damage = 4;
                    EntityDamageByProjectileEvent event = new EntityDamageByProjectileEvent(shooter, damagee, projectile, damageCause, damage);
                    server.getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                        stick = movingobjectposition.entity.damageEntity(this.shooter, event.getDamage());
                    else
                        stick = !event.getBounce();
                } else
                {
                    stick = movingobjectposition.entity.damageEntity(this.shooter, 4);
                }
                if(stick)
                {
                    world.makeSound(this, "random.drr", 1.0F, 1.2F / (random.nextFloat() * 0.2F + 0.9F));
                    die();
                } else
                {
                    motX *= -0.10000000149011612D;
                    motY *= -0.10000000149011612D;
                    motZ *= -0.10000000149011612D;
                    yaw += 180F;
                    lastYaw += 180F;
                    this.i = 0;
                }
            } else
            {
                c = movingobjectposition.b;
                d = movingobjectposition.c;
                e = movingobjectposition.d;
                this.f = world.getTypeId(c, d, e);
                motX = (float)(movingobjectposition.f.a - locX);
                motY = (float)(movingobjectposition.f.b - locY);
                motZ = (float)(movingobjectposition.f.c - locZ);
                f2 = MathHelper.a(motX * motX + motY * motY + motZ * motZ);
                locX -= (motX / (double)f2) * 0.05000000074505806D;
                locY -= (motY / (double)f2) * 0.05000000074505806D;
                locZ -= (motZ / (double)f2) * 0.05000000074505806D;
                world.makeSound(this, "random.drr", 1.0F, 1.2F / (random.nextFloat() * 0.2F + 0.9F));
                g = true;
                a = 7;
            }
        locX += motX;
        locY += motY;
        locZ += motZ;
        f2 = MathHelper.a(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for(pitch = (float)((Math.atan2(motY, f2) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        float f3 = 0.99F;
        f1 = 0.03F;
        if(Z())
        {
            for(int k = 0; k < 4; k++)
            {
                float f4 = 0.25F;
                world.a("bubble", locX - motX * (double)f4, locY - motY * (double)f4, locZ - motZ * (double)f4, motX, motY, motZ);
            }

            f3 = 0.8F;
        }
        motX *= f3;
        motY *= f3;
        motZ *= f3;
        motY -= f1;
        setPosition(locX, locY, locZ);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("xTile", (short)c);
        nbttagcompound.a("yTile", (short)d);
        nbttagcompound.a("zTile", (short)e);
        nbttagcompound.a("inTile", (byte)f);
        nbttagcompound.a("shake", (byte)a);
        nbttagcompound.a("inGround", (byte)(g ? 1 : 0));
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        c = nbttagcompound.d("xTile");
        d = nbttagcompound.d("yTile");
        e = nbttagcompound.d("zTile");
        f = nbttagcompound.c("inTile") & 0xff;
        a = nbttagcompound.c("shake") & 0xff;
        g = nbttagcompound.c("inGround") == 1;
    }

    public void b(EntityHuman entityhuman)
    {
        if(!world.isStatic && g && shooter == entityhuman && a <= 0 && entityhuman.inventory.canHold(new ItemStack(Item.ARROW, 1)))
        {
            world.makeSound(this, "random.pop", 0.2F, ((random.nextFloat() - random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            entityhuman.receive(this, 1);
            die();
        }
    }

    private int c;
    private int d;
    private int e;
    private int f;
    private boolean g;
    public int a;
    public EntityLiving shooter;
    private int h;
    private int i;
}
