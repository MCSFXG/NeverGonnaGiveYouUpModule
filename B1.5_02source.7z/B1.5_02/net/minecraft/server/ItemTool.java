// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, EnumToolMaterial, ItemStack, Block, 
//            EntityLiving, Entity

public class ItemTool extends Item
{

    protected ItemTool(int i, int j, EnumToolMaterial enumtoolmaterial, Block ablock[])
    {
        super(i);
        bj = 4F;
        a = enumtoolmaterial;
        bi = ablock;
        maxStackSize = 1;
        d(enumtoolmaterial.a());
        bj = enumtoolmaterial.b();
        bk = j + enumtoolmaterial.c();
    }

    public float a(ItemStack itemstack, Block block)
    {
        for(int i = 0; i < bi.length; i++)
            if(bi[i] == block)
                return bj;

        return 1.0F;
    }

    public boolean a(ItemStack itemstack, EntityLiving entityliving, EntityLiving entityliving1)
    {
        itemstack.damage(2, entityliving1);
        return true;
    }

    public boolean a(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
    {
        itemstack.damage(1, entityliving);
        return true;
    }

    public int a(Entity entity)
    {
        return bk;
    }

    private Block bi[];
    private float bj;
    private int bk;
    protected EnumToolMaterial a;
}
