// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityFireball.java

package net.minecraft.server;

import java.util.List;
import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.entity.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, MovingObjectPosition, EntityLiving, WorldServer, 
//            MathHelper, World, Vec3D, AxisAlignedBB, 
//            NBTTagCompound

public class EntityFireball extends Entity
{

    public EntityFireball(World world)
    {
        super(world);
        e = -1;
        f = -1;
        g = -1;
        h = 0;
        i = false;
        a = 0;
        l = 0;
        b(1.0F, 1.0F);
    }

    protected void b()
    {
    }

    public EntityFireball(World world, EntityLiving entityliving, double d0, double d1, double d2)
    {
        super(world);
        e = -1;
        f = -1;
        g = -1;
        h = 0;
        i = false;
        a = 0;
        l = 0;
        shooter = entityliving;
        b(1.0F, 1.0F);
        setPositionRotation(entityliving.locX, entityliving.locY, entityliving.locZ, entityliving.yaw, entityliving.pitch);
        setPosition(locX, locY, locZ);
        height = 0.0F;
        motX = motY = motZ = 0.0D;
        d0 += random.nextGaussian() * 0.40000000000000002D;
        d1 += random.nextGaussian() * 0.40000000000000002D;
        d2 += random.nextGaussian() * 0.40000000000000002D;
        double d3 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        b = (d0 / d3) * 0.10000000000000001D;
        c = (d1 / d3) * 0.10000000000000001D;
        d = (d2 / d3) * 0.10000000000000001D;
    }

    public void p_()
    {
        super.p_();
        fireTicks = 10;
        if(a > 0)
            a--;
        if(this.i)
        {
            int i = world.getTypeId(e, this.f, g);
            if(i == h)
            {
                this.k++;
                if(this.k == 1200)
                    die();
                return;
            }
            this.i = false;
            motX *= random.nextFloat() * 0.2F;
            motY *= random.nextFloat() * 0.2F;
            motZ *= random.nextFloat() * 0.2F;
            this.k = 0;
            l = 0;
        } else
        {
            l++;
        }
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if(movingobjectposition != null)
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        Entity entity = null;
        List list = world.b(this, boundingBox.a(motX, motY, motZ).b(1.0D, 1.0D, 1.0D));
        double d0 = 0.0D;
        for(int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);
            if(!entity1.o_() || entity1 == this.shooter && l < 25)
                continue;
            float f = 0.3F;
            AxisAlignedBB axisalignedbb = entity1.boundingBox.b(f, f, f);
            MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
            if(movingobjectposition1 == null)
                continue;
            double d1 = vec3d.a(movingobjectposition1.f);
            if(d1 < d0 || d0 == 0.0D)
            {
                entity = entity1;
                d0 = d1;
            }
        }

        if(entity != null)
            movingobjectposition = new MovingObjectPosition(entity);
        if(movingobjectposition != null)
        {
            if(movingobjectposition.entity != null)
            {
                boolean stick;
                if(movingobjectposition.entity instanceof EntityLiving)
                {
                    CraftServer server = ((WorldServer)world).getServer();
                    org.bukkit.entity.Entity shooter = this.shooter != null ? this.shooter.getBukkitEntity() : null;
                    org.bukkit.entity.Entity damagee = movingobjectposition.entity.getBukkitEntity();
                    org.bukkit.entity.Entity projectile = getBukkitEntity();
                    org.bukkit.event.entity.EntityDamageEvent.DamageCause damageCause = org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                    int damage = 0;
                    EntityDamageByProjectileEvent event = new EntityDamageByProjectileEvent(shooter, damagee, projectile, damageCause, damage);
                    server.getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                        stick = movingobjectposition.entity.damageEntity(this.shooter, event.getDamage());
                    else
                        stick = !event.getBounce();
                } else
                {
                    stick = movingobjectposition.entity.damageEntity(this.shooter, 0);
                }
                if(!stick);
            }
            CraftServer server = ((WorldServer)world).getServer();
            ExplosionPrimeEvent event = new ExplosionPrimeEvent(CraftEntity.getEntity(server, this), 1.0F, false);
            server.getPluginManager().callEvent(event);
            if(!event.isCancelled())
            {
                world.createExplosion(this, locX, locY, locZ, event.getRadius(), event.getFire());
                die();
            }
        }
        locX += motX;
        locY += motY;
        locZ += motZ;
        float f1 = MathHelper.a(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for(pitch = (float)((Math.atan2(motY, f1) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        float f2 = 0.95F;
        if(Z())
        {
            for(int k = 0; k < 4; k++)
            {
                float f3 = 0.25F;
                world.a("bubble", locX - motX * (double)f3, locY - motY * (double)f3, locZ - motZ * (double)f3, motX, motY, motZ);
            }

            f2 = 0.8F;
        }
        motX += b;
        motY += c;
        motZ += d;
        motX *= f2;
        motY *= f2;
        motZ *= f2;
        world.a("smoke", locX, locY + 0.5D, locZ, 0.0D, 0.0D, 0.0D);
        setPosition(locX, locY, locZ);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.a("xTile", (short)e);
        nbttagcompound.a("yTile", (short)f);
        nbttagcompound.a("zTile", (short)g);
        nbttagcompound.a("inTile", (byte)h);
        nbttagcompound.a("shake", (byte)a);
        nbttagcompound.a("inGround", (byte)(i ? 1 : 0));
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        e = nbttagcompound.d("xTile");
        f = nbttagcompound.d("yTile");
        g = nbttagcompound.d("zTile");
        h = nbttagcompound.c("inTile") & 0xff;
        a = nbttagcompound.c("shake") & 0xff;
        i = nbttagcompound.c("inGround") == 1;
    }

    public boolean o_()
    {
        return true;
    }

    public boolean damageEntity(Entity entity, int i)
    {
        ab();
        if(entity != null)
        {
            Vec3D vec3d = entity.V();
            if(vec3d != null)
            {
                motX = vec3d.a;
                motY = vec3d.b;
                motZ = vec3d.c;
                b = motX * 0.10000000000000001D;
                c = motY * 0.10000000000000001D;
                d = motZ * 0.10000000000000001D;
            }
            return true;
        } else
        {
            return false;
        }
    }

    private int e;
    private int f;
    private int g;
    private int h;
    private boolean i;
    public int a;
    private EntityLiving shooter;
    private int k;
    private int l;
    public double b;
    public double c;
    public double d;
}
