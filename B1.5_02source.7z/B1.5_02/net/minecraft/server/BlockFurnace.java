// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockContainer, Material, Block, World, 
//            TileEntityFurnace, EntityHuman, EntityLiving, MathHelper, 
//            TileEntity

public class BlockFurnace extends BlockContainer
{

    protected BlockFurnace(int i, boolean flag)
    {
        super(i, Material.STONE);
        a = flag;
        textureId = 45;
    }

    public int a(int i, Random random)
    {
        return Block.FURNACE.id;
    }

    public void e(World world, int i, int j, int k)
    {
        super.e(world, i, j, k);
        g(world, i, j, k);
    }

    private void g(World world, int i, int j, int k)
    {
        if(world.isStatic)
            return;
        int l = world.getTypeId(i, j, k - 1);
        int i1 = world.getTypeId(i, j, k + 1);
        int j1 = world.getTypeId(i - 1, j, k);
        int k1 = world.getTypeId(i + 1, j, k);
        byte byte0 = 3;
        if(Block.o[l] && !Block.o[i1])
            byte0 = 3;
        if(Block.o[i1] && !Block.o[l])
            byte0 = 2;
        if(Block.o[j1] && !Block.o[k1])
            byte0 = 5;
        if(Block.o[k1] && !Block.o[j1])
            byte0 = 4;
        world.setData(i, j, k, byte0);
    }

    public int a(int i)
    {
        if(i == 1)
            return textureId + 17;
        if(i == 0)
            return textureId + 17;
        if(i == 3)
            return textureId - 1;
        else
            return textureId;
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(world.isStatic)
        {
            return true;
        } else
        {
            TileEntityFurnace tileentityfurnace = (TileEntityFurnace)world.getTileEntity(i, j, k);
            entityhuman.a(tileentityfurnace);
            return true;
        }
    }

    public static void a(boolean flag, World world, int i, int j, int k)
    {
        int l = world.getData(i, j, k);
        TileEntity tileentity = world.getTileEntity(i, j, k);
        if(flag)
            world.setTypeId(i, j, k, Block.BURNING_FURNACE.id);
        else
            world.setTypeId(i, j, k, Block.FURNACE.id);
        world.setData(i, j, k, l);
        world.setTileEntity(i, j, k, tileentity);
    }

    protected TileEntity a_()
    {
        return new TileEntityFurnace();
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving)
    {
        int l = MathHelper.floor((double)((entityliving.yaw * 4F) / 360F) + 0.5D) & 3;
        if(l == 0)
            world.setData(i, j, k, 2);
        if(l == 1)
            world.setData(i, j, k, 5);
        if(l == 2)
            world.setData(i, j, k, 3);
        if(l == 3)
            world.setData(i, j, k, 4);
    }

    private final boolean a;
}
