// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Container, InventoryCrafting, InventoryCraftResult, SlotResult, 
//            InventoryPlayer, Slot, SlotArmor, CraftingManager, 
//            IInventory, EntityHuman

public class ContainerPlayer extends Container
{

    public ContainerPlayer(InventoryPlayer inventoryplayer)
    {
        this(inventoryplayer, true);
    }

    public ContainerPlayer(InventoryPlayer inventoryplayer, boolean flag)
    {
        a = new InventoryCrafting(this, 2, 2);
        b = new InventoryCraftResult();
        c = false;
        c = flag;
        a(new SlotResult(inventoryplayer.d, a, b, 0, 144, 36));
        for(int i = 0; i < 2; i++)
        {
            for(int i1 = 0; i1 < 2; i1++)
                a(new Slot(a, i1 + i * 2, 88 + i1 * 18, 26 + i * 18));

        }

        for(int j = 0; j < 4; j++)
        {
            int j1 = j;
            a(new SlotArmor(this, inventoryplayer, inventoryplayer.getSize() - 1 - j, 8, 8 + j * 18, j1));
        }

        for(int k = 0; k < 3; k++)
        {
            for(int k1 = 0; k1 < 9; k1++)
                a(new Slot(inventoryplayer, k1 + (k + 1) * 9, 8 + k1 * 18, 84 + k * 18));

        }

        for(int l = 0; l < 9; l++)
            a(new Slot(inventoryplayer, l, 8 + l * 18, 142));

        a(a);
    }

    public void a(IInventory iinventory)
    {
        b.setItem(0, CraftingManager.a().a(a));
    }

    public void a(EntityHuman entityhuman)
    {
        super.a(entityhuman);
        for(int i = 0; i < 4; i++)
        {
            ItemStack itemstack = a.getItem(i);
            if(itemstack != null)
            {
                entityhuman.b(itemstack);
                a.setItem(i, null);
            }
        }

    }

    public boolean b(EntityHuman entityhuman)
    {
        return true;
    }

    public InventoryCrafting a;
    public IInventory b;
    public boolean c;
}
