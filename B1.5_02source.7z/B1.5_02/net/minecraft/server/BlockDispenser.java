// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockDispenser.java

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockContainer, TileEntityDispenser, EntityArrow, EntityEgg, 
//            EntitySnowball, EntityItem, Material, Block, 
//            World, EntityHuman, ItemStack, Item, 
//            EntityLiving, MathHelper, TileEntity

public class BlockDispenser extends BlockContainer
{

    protected BlockDispenser(int i)
    {
        super(i, Material.STONE);
        textureId = 45;
    }

    public int b()
    {
        return 4;
    }

    public int a(int i, Random random)
    {
        return Block.DISPENSER.id;
    }

    public void e(World world, int i, int j, int k)
    {
        super.e(world, i, j, k);
        g(world, i, j, k);
    }

    private void g(World world, int i, int j, int k)
    {
        if(!world.isStatic)
        {
            int l = world.getTypeId(i, j, k - 1);
            int i1 = world.getTypeId(i, j, k + 1);
            int j1 = world.getTypeId(i - 1, j, k);
            int k1 = world.getTypeId(i + 1, j, k);
            byte b0 = 3;
            if(Block.o[l] && !Block.o[i1])
                b0 = 3;
            if(Block.o[i1] && !Block.o[l])
                b0 = 2;
            if(Block.o[j1] && !Block.o[k1])
                b0 = 5;
            if(Block.o[k1] && !Block.o[j1])
                b0 = 4;
            world.setData(i, j, k, b0);
        }
    }

    public int a(int i)
    {
        return i != 1 ? i != 0 ? i != 3 ? textureId : textureId + 1 : textureId + 17 : textureId + 17;
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(world.isStatic)
        {
            return true;
        } else
        {
            TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);
            entityhuman.a(tileentitydispenser);
            return true;
        }
    }

    public void dispense(World world, int i, int j, int k, Random random)
    {
        int l = world.getData(i, j, k);
        float f = 0.0F;
        float f1 = 0.0F;
        if(l == 3)
            f1 = 1.0F;
        else
        if(l == 2)
            f1 = -1F;
        else
        if(l == 5)
            f = 1.0F;
        else
            f = -1F;
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);
        ItemStack itemstack = tileentitydispenser.b();
        double d0 = (double)i + (double)f * 0.5D + 0.5D;
        double d1 = (double)j + 0.5D;
        double d2 = (double)k + (double)f1 * 0.5D + 0.5D;
        if(itemstack == null)
        {
            world.makeSound(i, j, k, "random.click", 1.0F, 1.2F);
        } else
        {
            if(itemstack.id == Item.ARROW.id)
            {
                EntityArrow entityarrow = new EntityArrow(world, d0, d1, d2);
                entityarrow.a(f, 0.10000000149011612D, f1, 1.1F, 6F);
                world.addEntity(entityarrow);
                world.makeSound(i, j, k, "random.bow", 1.0F, 1.2F);
            } else
            if(itemstack.id == Item.EGG.id)
            {
                EntityEgg entityegg = new EntityEgg(world, d0, d1, d2);
                entityegg.a(f, 0.10000000149011612D, f1, 1.1F, 6F);
                world.addEntity(entityegg);
                world.makeSound(i, j, k, "random.bow", 1.0F, 1.2F);
            } else
            if(itemstack.id == Item.SNOW_BALL.id)
            {
                EntitySnowball entitysnowball = new EntitySnowball(world, d0, d1, d2);
                entitysnowball.a(f, 0.10000000149011612D, f1, 1.1F, 6F);
                world.addEntity(entitysnowball);
                world.makeSound(i, j, k, "random.bow", 1.0F, 1.2F);
            } else
            {
                EntityItem entityitem = new EntityItem(world, d0, d1 - 0.29999999999999999D, d2, itemstack);
                double d3 = random.nextDouble() * 0.10000000000000001D + 0.20000000000000001D;
                entityitem.motX = (double)f * d3;
                entityitem.motY = 0.20000000298023224D;
                entityitem.motZ = (double)f1 * d3;
                entityitem.motX += random.nextGaussian() * 0.0074999998323619366D * 6D;
                entityitem.motY += random.nextGaussian() * 0.0074999998323619366D * 6D;
                entityitem.motZ += random.nextGaussian() * 0.0074999998323619366D * 6D;
                world.addEntity(entityitem);
                world.makeSound(i, j, k, "random.click", 1.0F, 1.0F);
            }
            for(int i1 = 0; i1 < 10; i1++)
            {
                double d3 = random.nextDouble() * 0.20000000000000001D + 0.01D;
                double d4 = d0 + (double)f * 0.01D + (random.nextDouble() - 0.5D) * (double)f1 * 0.5D;
                double d5 = d1 + (random.nextDouble() - 0.5D) * 0.5D;
                double d6 = d2 + (double)f1 * 0.01D + (random.nextDouble() - 0.5D) * (double)f * 0.5D;
                double d7 = (double)f * d3 + random.nextGaussian() * 0.01D;
                double d8 = -0.029999999999999999D + random.nextGaussian() * 0.01D;
                double d9 = (double)f1 * d3 + random.nextGaussian() * 0.01D;
                world.a("smoke", d4, d5, d6, d7, d8, d9);
            }

        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if(l > 0 && Block.byId[l].isPowerSource())
        {
            boolean flag = world.isBlockIndirectlyPowered(i, j, k) || world.isBlockIndirectlyPowered(i, j + 1, k);
            if(flag)
                world.c(i, j, k, id, b());
        }
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        if(world.isBlockIndirectlyPowered(i, j, k) || world.isBlockIndirectlyPowered(i, j + 1, k))
            dispense(world, i, j, k, random);
    }

    protected TileEntity a_()
    {
        return new TileEntityDispenser();
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving)
    {
        int l = MathHelper.floor((double)((entityliving.yaw * 4F) / 360F) + 0.5D) & 3;
        if(l == 0)
            world.setData(i, j, k, 2);
        if(l == 1)
            world.setData(i, j, k, 5);
        if(l == 2)
            world.setData(i, j, k, 3);
        if(l == 3)
            world.setData(i, j, k, 4);
    }
}
