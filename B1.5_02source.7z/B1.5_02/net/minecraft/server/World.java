// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   World.java

package net.minecraft.server;

import java.io.PrintStream;
import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.block.BlockCanBuildEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            WorldProviderHell, WorldProvider, WorldData, ChunkProviderLoadOrGenerate, 
//            IWorldAccess, WorldServer, EntityHuman, EntityLiving, 
//            EntityPlayer, Entity, NextTickListEntry, TileEntity, 
//            Explosion, MetadataChunkBlock, IProgressUpdate, ChunkCoordIntPair, 
//            EntityWeatherStorm, ChunkCache, Pathfinder, ChunkCoordinates, 
//            IBlockAccess, IDataManager, IChunkProvider, Chunk, 
//            Material, Block, EnumSkyBlock, Vec3D, 
//            MathHelper, AxisAlignedBB, BlockFire, BlockFluids, 
//            SpawnerCreature, ServerConfigurationManager, WorldChunkManager, BiomeBase, 
//            MovingObjectPosition, PathEntity

public class World
    implements IBlockAccess
{

    public WorldChunkManager getWorldChunkManager()
    {
        return worldProvider.b;
    }

    public World(IDataManager idatamanager, String s, long i, WorldProvider worldprovider)
    {
        a = false;
        w = new ArrayList();
        entityList = new ArrayList();
        x = new ArrayList();
        y = new TreeSet();
        z = new HashSet();
        c = new ArrayList();
        players = new ArrayList();
        e = new ArrayList();
        A = 0xffffffL;
        f = 0;
        g = (new Random()).nextInt();
        h = 0x3c6ef35f;
        F = 0;
        this.i = 0;
        j = false;
        G = System.currentTimeMillis();
        k = 40;
        random = new Random();
        n = false;
        p = new ArrayList();
        I = new ArrayList();
        J = 0;
        allowMonsters = true;
        allowAnimals = true;
        M = new HashSet();
        lastXAccessed = 0x80000000;
        lastZAccessed = 0x80000000;
        N = random.nextInt(12000);
        O = new ArrayList();
        isStatic = false;
        r = idatamanager;
        worldData = idatamanager.c();
        n = worldData == null;
        if(worldprovider != null)
            worldProvider = worldprovider;
        else
        if(worldData != null && worldData.h() == -1)
            worldProvider = new WorldProviderHell();
        else
            worldProvider = new WorldProvider();
        boolean flag = false;
        if(worldData == null)
        {
            worldData = new WorldData(i, s);
            flag = true;
        } else
        {
            worldData.a(s);
        }
        worldProvider.a(this);
        chunkProvider = b();
        if(flag)
            c();
        g();
        x();
    }

    protected IChunkProvider b()
    {
        IChunkLoader ichunkloader = r.a(worldProvider);
        return new ChunkProviderLoadOrGenerate(this, ichunkloader, worldProvider.c());
    }

    protected void c()
    {
        isLoading = true;
        int i = 0;
        byte b0 = 64;
        int j;
        for(j = 0; !worldProvider.a(i, j); j += random.nextInt(64) - random.nextInt(64))
            i += random.nextInt(64) - random.nextInt(64);

        worldData.setSpawn(i, b0, j);
        isLoading = false;
    }

    public int a(int i, int j)
    {
        int k;
        for(k = 63; !isEmpty(i, k + 1, j); k++);
        return getTypeId(i, k, j);
    }

    public void save(boolean flag, IProgressUpdate iprogressupdate)
    {
        if(chunkProvider.b())
        {
            if(iprogressupdate != null)
                iprogressupdate.a("Saving level");
            w();
            if(iprogressupdate != null)
                iprogressupdate.b("Saving chunks");
            chunkProvider.saveChunks(flag, iprogressupdate);
        }
    }

    private void w()
    {
        k();
        r.a(worldData, players);
    }

    public int getTypeId(int i, int j, int k)
    {
        return i < 0xfe17b800 || k < 0xfe17b800 || i >= 0x1e84800 || k > 0x1e84800 ? 0 : j >= 0 ? j < 128 ? getChunkAt(i >> 4, k >> 4).getTypeId(i & 0xf, j, k & 0xf) : 0 : 0;
    }

    public boolean isEmpty(int i, int j, int k)
    {
        return getTypeId(i, j, k) == 0;
    }

    public boolean isLoaded(int i, int j, int k)
    {
        return j < 0 || j >= 128 ? false : isChunkLoaded(i >> 4, k >> 4);
    }

    public boolean a(int i, int j, int k, int l)
    {
        return a(i - l, j - l, k - l, i + l, j + l, k + l);
    }

    public boolean a(int i, int j, int k, int l, int i1, int j1)
    {
        if(i1 >= 0 && j < 128)
        {
            i >>= 4;
            j >>= 4;
            k >>= 4;
            l >>= 4;
            i1 >>= 4;
            j1 >>= 4;
            for(int k1 = i; k1 <= l; k1++)
            {
                for(int l1 = k; l1 <= j1; l1++)
                    if(!isChunkLoaded(k1, l1))
                        return false;

            }

            return true;
        } else
        {
            return false;
        }
    }

    private boolean isChunkLoaded(int i, int j)
    {
        return chunkProvider.isChunkLoaded(i, j);
    }

    public Chunk b(int i, int j)
    {
        return getChunkAt(i >> 4, j >> 4);
    }

    public Chunk getChunkAt(int i, int j)
    {
        Chunk result = null;
        synchronized(chunkLock)
        {
            if(lastChunkAccessed == null || lastXAccessed != i || lastZAccessed != j)
            {
                lastXAccessed = i;
                lastZAccessed = j;
                lastChunkAccessed = chunkProvider.getOrCreateChunk(i, j);
            }
            result = lastChunkAccessed;
        }
        return result;
    }

    public boolean setRawTypeIdAndData(int i, int j, int k, int l, int i1)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(j < 0)
                return false;
            if(j >= 128)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                return chunk.a(i & 0xf, j, k & 0xf, l, i1);
            }
        } else
        {
            return false;
        }
    }

    public boolean setRawTypeId(int i, int j, int k, int l)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(j < 0)
                return false;
            if(j >= 128)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                return chunk.a(i & 0xf, j, k & 0xf, l);
            }
        } else
        {
            return false;
        }
    }

    public Material getMaterial(int i, int j, int k)
    {
        int l = getTypeId(i, j, k);
        return l != 0 ? Block.byId[l].material : Material.AIR;
    }

    public int getData(int i, int j, int k)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(j < 0)
                return 0;
            if(j >= 128)
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                return chunk.getData(i, j, k);
            }
        } else
        {
            return 0;
        }
    }

    public void setData(int i, int j, int k, int l)
    {
        if(setRawData(i, j, k, l))
            update(i, j, k, getTypeId(i, j, k));
    }

    public boolean setRawData(int i, int j, int k, int l)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(j < 0)
                return false;
            if(j >= 128)
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                chunk.b(i, j, k, l);
                return true;
            }
        } else
        {
            return false;
        }
    }

    public boolean setTypeId(int i, int j, int k, int l)
    {
        int old = getTypeId(i, j, k);
        if(setRawTypeId(i, j, k, l))
        {
            update(i, j, k, l != 0 ? l : old);
            return true;
        } else
        {
            return false;
        }
    }

    public boolean setTypeIdAndData(int i, int j, int k, int l, int i1)
    {
        int old = getTypeId(i, j, k);
        if(setRawTypeIdAndData(i, j, k, l, i1))
        {
            update(i, j, k, l != 0 ? l : old);
            return true;
        } else
        {
            return false;
        }
    }

    public void notify(int i, int j, int k)
    {
        for(int l = 0; l < p.size(); l++)
            ((IWorldAccess)p.get(l)).a(i, j, k);

    }

    protected void update(int i, int j, int k, int l)
    {
        notify(i, j, k);
        applyPhysics(i, j, k, l);
    }

    public void g(int i, int j, int k, int l)
    {
        if(k > l)
        {
            int i1 = l;
            l = k;
            k = i1;
        }
        b(i, k, j, i, l, j);
    }

    public void h(int i, int j, int k)
    {
        for(int l = 0; l < p.size(); l++)
            ((IWorldAccess)p.get(l)).a(i, j, k, i, j, k);

    }

    public void b(int i, int j, int k, int l, int i1, int j1)
    {
        for(int k1 = 0; k1 < p.size(); k1++)
            ((IWorldAccess)p.get(k1)).a(i, j, k, l, i1, j1);

    }

    public void applyPhysics(int i, int j, int k, int l)
    {
        k(i - 1, j, k, l);
        k(i + 1, j, k, l);
        k(i, j - 1, k, l);
        k(i, j + 1, k, l);
        k(i, j, k - 1, l);
        k(i, j, k + 1, l);
    }

    private void k(int i, int j, int k, int l)
    {
        if(!this.j && !isStatic)
        {
            Block block = Block.byId[getTypeId(i, j, k)];
            if(block != null)
            {
                CraftWorld world = ((WorldServer)this).getWorld();
                if(world != null)
                {
                    BlockPhysicsEvent event = new BlockPhysicsEvent(world.getBlockAt(i, j, k), l);
                    ((WorldServer)this).getServer().getPluginManager().callEvent(event);
                    if(event.isCancelled())
                        return;
                }
                block.doPhysics(this, i, j, k, l);
            }
        }
    }

    public boolean isChunkLoaded(int i, int j, int k)
    {
        return getChunkAt(i >> 4, k >> 4).c(i & 0xf, j, k & 0xf);
    }

    public int getLightLevel(int i, int j, int k)
    {
        return a(i, j, k, true);
    }

    public int a(int i, int j, int k, boolean flag)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(flag)
            {
                int l = getTypeId(i, j, k);
                if(l == Block.STEP.id || l == Block.SOIL.id)
                {
                    int i1 = a(i, j + 1, k, false);
                    int j1 = a(i + 1, j, k, false);
                    int k1 = a(i - 1, j, k, false);
                    int l1 = a(i, j, k + 1, false);
                    int i2 = a(i, j, k - 1, false);
                    if(j1 > i1)
                        i1 = j1;
                    if(k1 > i1)
                        i1 = k1;
                    if(l1 > i1)
                        i1 = l1;
                    if(i2 > i1)
                        i1 = i2;
                    return i1;
                }
            }
            if(j < 0)
                return 0;
            if(j >= 128)
            {
                int l = 15 - f;
                if(l < 0)
                    l = 0;
                return l;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                return chunk.c(i, j, k, f);
            }
        } else
        {
            return 15;
        }
    }

    public boolean k(int i, int j, int k)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            if(j < 0)
                return false;
            if(j >= 128)
                return true;
            if(!isChunkLoaded(i >> 4, k >> 4))
            {
                return false;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, k >> 4);
                i &= 0xf;
                k &= 0xf;
                return chunk.c(i, j, k);
            }
        } else
        {
            return false;
        }
    }

    public int getHighestBlockYAt(int i, int j)
    {
        if(i >= 0xfe17b800 && j >= 0xfe17b800 && i < 0x1e84800 && j <= 0x1e84800)
        {
            if(!isChunkLoaded(i >> 4, j >> 4))
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(i >> 4, j >> 4);
                return chunk.b(i & 0xf, j & 0xf);
            }
        } else
        {
            return 0;
        }
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
    {
        if((!worldProvider.e || enumskyblock != EnumSkyBlock.SKY) && isLoaded(i, j, k))
        {
            if(enumskyblock == EnumSkyBlock.SKY)
            {
                if(k(i, j, k))
                    l = 15;
            } else
            if(enumskyblock == EnumSkyBlock.BLOCK)
            {
                int i1 = getTypeId(i, j, k);
                if(Block.s[i1] > l)
                    l = Block.s[i1];
            }
            if(a(enumskyblock, i, j, k) != l)
                a(enumskyblock, i, j, k, i, j, k);
        }
    }

    public int a(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        if(j >= 0 && j < 128 && i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800)
        {
            int l = i >> 4;
            int i1 = k >> 4;
            if(!isChunkLoaded(l, i1))
            {
                return 0;
            } else
            {
                Chunk chunk = getChunkAt(l, i1);
                return chunk.a(enumskyblock, i & 0xf, j, k & 0xf);
            }
        } else
        {
            return enumskyblock.c;
        }
    }

    public void b(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
    {
        if(i >= 0xfe17b800 && k >= 0xfe17b800 && i < 0x1e84800 && k <= 0x1e84800 && j >= 0 && j < 128 && isChunkLoaded(i >> 4, k >> 4))
        {
            Chunk chunk = getChunkAt(i >> 4, k >> 4);
            chunk.a(enumskyblock, i & 0xf, j, k & 0xf, l);
            for(int i1 = 0; i1 < p.size(); i1++)
                ((IWorldAccess)p.get(i1)).a(i, j, k);

        }
    }

    public float l(int i, int j, int k)
    {
        return worldProvider.f[getLightLevel(i, j, k)];
    }

    public boolean d()
    {
        return f < 4;
    }

    public MovingObjectPosition a(Vec3D vec3d, Vec3D vec3d1)
    {
        return rayTrace(vec3d, vec3d1, false);
    }

    public MovingObjectPosition rayTrace(Vec3D vec3d, Vec3D vec3d1, boolean flag)
    {
        if(!Double.isNaN(vec3d.a) && !Double.isNaN(vec3d.b) && !Double.isNaN(vec3d.c))
        {
            if(!Double.isNaN(vec3d1.a) && !Double.isNaN(vec3d1.b) && !Double.isNaN(vec3d1.c))
            {
                int i = MathHelper.floor(vec3d1.a);
                int j = MathHelper.floor(vec3d1.b);
                int k = MathHelper.floor(vec3d1.c);
                int l = MathHelper.floor(vec3d.a);
                int i1 = MathHelper.floor(vec3d.b);
                int j1 = MathHelper.floor(vec3d.c);
                for(int k1 = 200; k1-- >= 0;)
                {
                    if(Double.isNaN(vec3d.a) || Double.isNaN(vec3d.b) || Double.isNaN(vec3d.c))
                        return null;
                    if(l == i && i1 == j && j1 == k)
                        return null;
                    double d0 = 999D;
                    double d1 = 999D;
                    double d2 = 999D;
                    if(i > l)
                        d0 = (double)l + 1.0D;
                    if(i < l)
                        d0 = (double)l + 0.0D;
                    if(j > i1)
                        d1 = (double)i1 + 1.0D;
                    if(j < i1)
                        d1 = (double)i1 + 0.0D;
                    if(k > j1)
                        d2 = (double)j1 + 1.0D;
                    if(k < j1)
                        d2 = (double)j1 + 0.0D;
                    double d3 = 999D;
                    double d4 = 999D;
                    double d5 = 999D;
                    double d6 = vec3d1.a - vec3d.a;
                    double d7 = vec3d1.b - vec3d.b;
                    double d8 = vec3d1.c - vec3d.c;
                    if(d0 != 999D)
                        d3 = (d0 - vec3d.a) / d6;
                    if(d1 != 999D)
                        d4 = (d1 - vec3d.b) / d7;
                    if(d2 != 999D)
                        d5 = (d2 - vec3d.c) / d8;
                    boolean flag1 = false;
                    byte b0;
                    if(d3 < d4 && d3 < d5)
                    {
                        if(i > l)
                            b0 = 4;
                        else
                            b0 = 5;
                        vec3d.a = d0;
                        vec3d.b += d7 * d3;
                        vec3d.c += d8 * d3;
                    } else
                    if(d4 < d5)
                    {
                        if(j > i1)
                            b0 = 0;
                        else
                            b0 = 1;
                        vec3d.a += d6 * d4;
                        vec3d.b = d1;
                        vec3d.c += d8 * d4;
                    } else
                    {
                        if(k > j1)
                            b0 = 2;
                        else
                            b0 = 3;
                        vec3d.a += d6 * d5;
                        vec3d.b += d7 * d5;
                        vec3d.c = d2;
                    }
                    Vec3D vec3d2 = Vec3D.create(vec3d.a, vec3d.b, vec3d.c);
                    l = (int)(vec3d2.a = MathHelper.floor(vec3d.a));
                    if(b0 == 5)
                    {
                        l--;
                        vec3d2.a++;
                    }
                    i1 = (int)(vec3d2.b = MathHelper.floor(vec3d.b));
                    if(b0 == 1)
                    {
                        i1--;
                        vec3d2.b++;
                    }
                    j1 = (int)(vec3d2.c = MathHelper.floor(vec3d.c));
                    if(b0 == 3)
                    {
                        j1--;
                        vec3d2.c++;
                    }
                    int l1 = getTypeId(l, i1, j1);
                    int i2 = getData(l, i1, j1);
                    Block block = Block.byId[l1];
                    if(l1 > 0 && block.a(i2, flag))
                    {
                        MovingObjectPosition movingobjectposition = block.a(this, l, i1, j1, vec3d, vec3d1);
                        if(movingobjectposition != null)
                            return movingobjectposition;
                    }
                }

                return null;
            } else
            {
                return null;
            }
        } else
        {
            return null;
        }
    }

    public void makeSound(Entity entity, String s, float f, float f1)
    {
        for(int i = 0; i < p.size(); i++)
            ((IWorldAccess)p.get(i)).a(s, entity.locX, entity.locY - (double)entity.height, entity.locZ, f, f1);

    }

    public void makeSound(double d0, double d1, double d2, String s, 
            float f, float f1)
    {
        for(int i = 0; i < p.size(); i++)
            ((IWorldAccess)p.get(i)).a(s, d0, d1, d2, f, f1);

    }

    public void a(String s, int i, int j, int k)
    {
        for(int l = 0; l < p.size(); l++)
            ((IWorldAccess)p.get(l)).a(s, i, j, k);

    }

    public void a(String s, double d0, double d1, double d2, 
            double d3, double d4, double d5)
    {
        for(int i = 0; i < p.size(); i++)
            ((IWorldAccess)p.get(i)).a(s, d0, d1, d2, d3, d4, d5);

    }

    public boolean a(Entity entity)
    {
        e.add(entity);
        return true;
    }

    public boolean addEntity(Entity entity)
    {
        int i = MathHelper.floor(entity.locX / 16D);
        int j = MathHelper.floor(entity.locZ / 16D);
        boolean flag = false;
        if(entity instanceof EntityHuman)
            flag = true;
        if((entity instanceof EntityLiving) && !(entity instanceof EntityPlayer))
        {
            CreatureSpawnEvent event = CraftEventFactory.callCreatureSpawnEvent((EntityLiving)entity);
            if(event.isCancelled())
                return false;
        }
        if(!flag && !isChunkLoaded(i, j))
            return false;
        if(entity instanceof EntityHuman)
        {
            EntityHuman entityhuman = (EntityHuman)entity;
            players.add(entityhuman);
            everyoneSleeping();
        }
        getChunkAt(i, j).a(entity);
        entityList.add(entity);
        c(entity);
        return true;
    }

    protected void c(Entity entity)
    {
        for(int i = 0; i < p.size(); i++)
            ((IWorldAccess)p.get(i)).a(entity);

    }

    protected void d(Entity entity)
    {
        for(int i = 0; i < p.size(); i++)
            ((IWorldAccess)p.get(i)).b(entity);

    }

    public void kill(Entity entity)
    {
        if(entity.passenger != null)
            entity.passenger.mount((Entity)null);
        if(entity.vehicle != null)
            entity.mount((Entity)null);
        entity.die();
        if(entity instanceof EntityHuman)
        {
            players.remove((EntityHuman)entity);
            everyoneSleeping();
        }
    }

    public void removeEntity(Entity entity)
    {
        entity.die();
        if(entity instanceof EntityHuman)
        {
            players.remove((EntityHuman)entity);
            everyoneSleeping();
        }
        int i = entity.chunkX;
        int j = entity.chunkZ;
        if(entity.bB && isChunkLoaded(i, j))
            getChunkAt(i, j).b(entity);
        entityList.remove(entity);
        d(entity);
    }

    public void addIWorldAccess(IWorldAccess iworldaccess)
    {
        p.add(iworldaccess);
    }

    public List getEntities(Entity entity, AxisAlignedBB axisalignedbb)
    {
        I.clear();
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = i1; l1 < j1; l1++)
            {
                if(!isLoaded(k1, 64, l1))
                    continue;
                for(int i2 = k - 1; i2 < l; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, i2, l1)];
                    if(block != null)
                        block.a(this, k1, i2, l1, axisalignedbb, I);
                }

            }

        }

        double d0 = 0.25D;
        List list = b(entity, axisalignedbb.b(d0, d0, d0));
        for(int j2 = 0; j2 < list.size(); j2++)
        {
            AxisAlignedBB axisalignedbb1 = ((Entity)list.get(j2)).e_();
            if(axisalignedbb1 != null && axisalignedbb1.a(axisalignedbb))
                I.add(axisalignedbb1);
            axisalignedbb1 = entity.a_((Entity)list.get(j2));
            if(axisalignedbb1 != null && axisalignedbb1.a(axisalignedbb))
                I.add(axisalignedbb1);
        }

        return I;
    }

    public int a(float f)
    {
        float f1 = b(f);
        float f2 = 1.0F - (MathHelper.cos(f1 * 3.141593F * 2.0F) * 2.0F + 0.5F);
        if(f2 < 0.0F)
            f2 = 0.0F;
        if(f2 > 1.0F)
            f2 = 1.0F;
        f2 = 1.0F - f2;
        f2 = (float)((double)f2 * (1.0D - (double)(d(f) * 5F) / 16D));
        f2 = (float)((double)f2 * (1.0D - (double)(c(f) * 5F) / 16D));
        f2 = 1.0F - f2;
        return (int)(f2 * 11F);
    }

    public float b(float f)
    {
        return worldProvider.a(worldData.f(), f);
    }

    public int e(int i, int j)
    {
        Chunk chunk = b(i, j);
        int k = 127;
        i &= 0xf;
        j &= 0xf;
        for(; k > 0; k--)
        {
            int l = chunk.getTypeId(i, k, j);
            if(l != 0 && Block.byId[l].material.isSolid())
                return k + 1;
        }

        return -1;
    }

    public void c(int i, int j, int k, int l, int i1)
    {
        NextTickListEntry nextticklistentry = new NextTickListEntry(i, j, k, l);
        byte b0 = 8;
        if(a)
        {
            if(a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0))
            {
                int j1 = getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
                if(j1 == nextticklistentry.d && j1 > 0)
                    Block.byId[j1].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, random);
            }
        } else
        if(a(i - b0, j - b0, k - b0, i + b0, j + b0, k + b0))
        {
            if(l > 0)
                nextticklistentry.a((long)i1 + worldData.f());
            if(!z.contains(nextticklistentry))
            {
                z.add(nextticklistentry);
                y.add(nextticklistentry);
            }
        }
    }

    public void cleanUp()
    {
        for(int i = 0; i < e.size(); i++)
        {
            Entity entity = (Entity)e.get(i);
            entity.p_();
            if(entity.dead)
                e.remove(i--);
        }

        entityList.removeAll(x);
        for(int i = 0; i < x.size(); i++)
        {
            Entity entity = (Entity)x.get(i);
            int j = entity.chunkX;
            int k = entity.chunkZ;
            if(entity.bB && isChunkLoaded(j, k))
                getChunkAt(j, k).b(entity);
        }

        for(int i = 0; i < x.size(); i++)
            d((Entity)x.get(i));

        x.clear();
        for(int i = 0; i < entityList.size(); i++)
        {
            Entity entity = (Entity)entityList.get(i);
            if(entity.vehicle != null)
            {
                if(!entity.vehicle.dead && entity.vehicle.passenger == entity)
                    continue;
                entity.vehicle.passenger = null;
                entity.vehicle = null;
            }
            if(!entity.dead)
                playerJoinedWorld(entity);
            if(!entity.dead)
                continue;
            int j = entity.chunkX;
            int k = entity.chunkZ;
            if(entity.bB && isChunkLoaded(j, k))
                getChunkAt(j, k).b(entity);
            entityList.remove(i--);
            d(entity);
        }

        for(int i = 0; i < c.size(); i++)
        {
            TileEntity tileentity = (TileEntity)c.get(i);
            tileentity.g_();
        }

    }

    public void playerJoinedWorld(Entity entity)
    {
        entityJoinedWorld(entity, true);
    }

    public void entityJoinedWorld(Entity entity, boolean flag)
    {
        int i = MathHelper.floor(entity.locX);
        int j = MathHelper.floor(entity.locZ);
        byte b0 = 32;
        if(!flag || a(i - b0, 0, j - b0, i + b0, 128, j + b0))
        {
            entity.bk = entity.locX;
            entity.bl = entity.locY;
            entity.bm = entity.locZ;
            entity.lastYaw = entity.yaw;
            entity.lastPitch = entity.pitch;
            if(flag && entity.bB)
                if(entity.vehicle != null)
                    entity.B();
                else
                    entity.p_();
            if(Double.isNaN(entity.locX) || Double.isInfinite(entity.locX))
                entity.locX = entity.bk;
            if(Double.isNaN(entity.locY) || Double.isInfinite(entity.locY))
                entity.locY = entity.bl;
            if(Double.isNaN(entity.locZ) || Double.isInfinite(entity.locZ))
                entity.locZ = entity.bm;
            if(Double.isNaN(entity.pitch) || Double.isInfinite(entity.pitch))
                entity.pitch = entity.lastPitch;
            if(Double.isNaN(entity.yaw) || Double.isInfinite(entity.yaw))
                entity.yaw = entity.lastYaw;
            int k = MathHelper.floor(entity.locX / 16D);
            int l = MathHelper.floor(entity.locY / 16D);
            int i1 = MathHelper.floor(entity.locZ / 16D);
            if(!entity.bB || entity.chunkX != k || entity.bD != l || entity.chunkZ != i1)
            {
                if(entity.bB && isChunkLoaded(entity.chunkX, entity.chunkZ))
                    getChunkAt(entity.chunkX, entity.chunkZ).a(entity, entity.bD);
                if(isChunkLoaded(k, i1))
                {
                    entity.bB = true;
                    getChunkAt(k, i1).a(entity);
                } else
                {
                    entity.bB = false;
                }
            }
            if(flag && entity.bB && entity.passenger != null)
                if(!entity.passenger.dead && entity.passenger.vehicle == entity)
                {
                    playerJoinedWorld(entity.passenger);
                } else
                {
                    entity.passenger.vehicle = null;
                    entity.passenger = null;
                }
        }
    }

    public boolean containsEntity(AxisAlignedBB axisalignedbb)
    {
        List list = b((Entity)null, axisalignedbb);
        for(int i = 0; i < list.size(); i++)
        {
            Entity entity = (Entity)list.get(i);
            if(!entity.dead && entity.aE)
                return false;
        }

        return true;
    }

    public boolean b(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(axisalignedbb.a < 0.0D)
            i--;
        if(axisalignedbb.b < 0.0D)
            k--;
        if(axisalignedbb.c < 0.0D)
            i1--;
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null)
                        return true;
                }

            }

        }

        return false;
    }

    public boolean c(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(axisalignedbb.a < 0.0D)
            i--;
        if(axisalignedbb.b < 0.0D)
            k--;
        if(axisalignedbb.c < 0.0D)
            i1--;
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null && block.material.isLiquid())
                        return true;
                }

            }

        }

        return false;
    }

    public boolean d(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(a(i, k, i1, j, l, j1))
        {
            for(int k1 = i; k1 < j; k1++)
            {
                for(int l1 = k; l1 < l; l1++)
                {
                    for(int i2 = i1; i2 < j1; i2++)
                    {
                        int j2 = getTypeId(k1, l1, i2);
                        if(j2 == Block.FIRE.id || j2 == Block.LAVA.id || j2 == Block.STATIONARY_LAVA.id)
                            return true;
                    }

                }

            }

        }
        return false;
    }

    public boolean a(AxisAlignedBB axisalignedbb, Material material, Entity entity)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        if(!a(i, k, i1, j, l, j1))
            return false;
        boolean flag = false;
        Vec3D vec3d = Vec3D.create(0.0D, 0.0D, 0.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block == null || block.material != material)
                        continue;
                    double d0 = (float)(l1 + 1) - BlockFluids.c(getData(k1, l1, i2));
                    if((double)l >= d0)
                    {
                        flag = true;
                        block.a(this, k1, l1, i2, entity, vec3d);
                    }
                }

            }

        }

        if(vec3d.c() > 0.0D)
        {
            vec3d = vec3d.b();
            double d1 = 0.014D;
            entity.motX += vec3d.a * d1;
            entity.motY += vec3d.b * d1;
            entity.motZ += vec3d.c * d1;
        }
        return flag;
    }

    public boolean a(AxisAlignedBB axisalignedbb, Material material)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block != null && block.material == material)
                        return true;
                }

            }

        }

        return false;
    }

    public boolean b(AxisAlignedBB axisalignedbb, Material material)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.d + 1.0D);
        int k = MathHelper.floor(axisalignedbb.b);
        int l = MathHelper.floor(axisalignedbb.e + 1.0D);
        int i1 = MathHelper.floor(axisalignedbb.c);
        int j1 = MathHelper.floor(axisalignedbb.f + 1.0D);
        for(int k1 = i; k1 < j; k1++)
        {
            for(int l1 = k; l1 < l; l1++)
            {
                for(int i2 = i1; i2 < j1; i2++)
                {
                    Block block = Block.byId[getTypeId(k1, l1, i2)];
                    if(block == null || block.material != material)
                        continue;
                    int j2 = getData(k1, l1, i2);
                    double d0 = l1 + 1;
                    if(j2 < 8)
                        d0 = (double)(l1 + 1) - (double)j2 / 8D;
                    if(d0 >= axisalignedbb.b)
                        return true;
                }

            }

        }

        return false;
    }

    public Explosion a(Entity entity, double d0, double d1, double d2, 
            float f)
    {
        return createExplosion(entity, d0, d1, d2, f, false);
    }

    public Explosion createExplosion(Entity entity, double d0, double d1, double d2, 
            float f, boolean flag)
    {
        Explosion explosion = new Explosion(this, entity, d0, d1, d2, f);
        explosion.a = flag;
        explosion.a();
        explosion.a(true);
        return explosion;
    }

    public float a(Vec3D vec3d, AxisAlignedBB axisalignedbb)
    {
        double d0 = 1.0D / ((axisalignedbb.d - axisalignedbb.a) * 2D + 1.0D);
        double d1 = 1.0D / ((axisalignedbb.e - axisalignedbb.b) * 2D + 1.0D);
        double d2 = 1.0D / ((axisalignedbb.f - axisalignedbb.c) * 2D + 1.0D);
        int i = 0;
        int j = 0;
        for(float f = 0.0F; f <= 1.0F; f = (float)((double)f + d0))
        {
            for(float f1 = 0.0F; f1 <= 1.0F; f1 = (float)((double)f1 + d1))
            {
                for(float f2 = 0.0F; f2 <= 1.0F; f2 = (float)((double)f2 + d2))
                {
                    double d3 = axisalignedbb.a + (axisalignedbb.d - axisalignedbb.a) * (double)f;
                    double d4 = axisalignedbb.b + (axisalignedbb.e - axisalignedbb.b) * (double)f1;
                    double d5 = axisalignedbb.c + (axisalignedbb.f - axisalignedbb.c) * (double)f2;
                    if(a(Vec3D.create(d3, d4, d5), vec3d) == null)
                        i++;
                    j++;
                }

            }

        }

        return (float)i / (float)j;
    }

    public TileEntity getTileEntity(int i, int j, int k)
    {
        Chunk chunk = getChunkAt(i >> 4, k >> 4);
        return chunk == null ? null : chunk.d(i & 0xf, j, k & 0xf);
    }

    public void setTileEntity(int i, int j, int k, TileEntity tileentity)
    {
        Chunk chunk = getChunkAt(i >> 4, k >> 4);
        if(chunk != null)
            chunk.a(i & 0xf, j, k & 0xf, tileentity);
    }

    public void n(int i, int j, int k)
    {
        Chunk chunk = getChunkAt(i >> 4, k >> 4);
        if(chunk != null)
            chunk.e(i & 0xf, j, k & 0xf);
    }

    public boolean d(int i, int j, int k)
    {
        Block block = Block.byId[getTypeId(i, j, k)];
        return block != null ? block.a() : false;
    }

    public boolean doLighting()
    {
        if(J >= 50)
            return false;
        J++;
        int i = 500;
_L1:
        boolean flag1;
        if(w.size() <= 0)
            break MISSING_BLOCK_LABEL_90;
        if(--i > 0)
            break MISSING_BLOCK_LABEL_60;
        boolean flag = true;
        flag1 = flag;
        J--;
        return flag1;
        ((MetadataChunkBlock)w.remove(w.size() - 1)).a(this);
          goto _L1
        boolean flag = false;
        flag1 = flag;
        J--;
        return flag1;
        Exception exception;
        exception;
        J--;
        throw exception;
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l, int i1, int j1)
    {
        a(enumskyblock, i, j, k, l, i1, j1, true);
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l, int i1, int j1, 
            boolean flag)
    {
        if(!worldProvider.e || enumskyblock != EnumSkyBlock.SKY)
        {
            u++;
            if(u == 50)
            {
                u--;
            } else
            {
                int k1 = (l + i) / 2;
                int l1 = (j1 + k) / 2;
                if(!isLoaded(k1, 64, l1))
                    u--;
                else
                if(!b(k1, l1).g())
                {
                    int i2 = w.size();
                    int j2;
                    if(flag)
                    {
                        j2 = 5;
                        if(j2 > i2)
                            j2 = i2;
                        for(int k2 = 0; k2 < j2; k2++)
                        {
                            MetadataChunkBlock metadatachunkblock = (MetadataChunkBlock)w.get(w.size() - k2 - 1);
                            if(metadatachunkblock.a == enumskyblock && metadatachunkblock.a(i, j, k, l, i1, j1))
                            {
                                u--;
                                return;
                            }
                        }

                    }
                    w.add(new MetadataChunkBlock(enumskyblock, i, j, k, l, i1, j1));
                    j2 = 0xf4240;
                    if(w.size() > 0xf4240)
                    {
                        System.out.println((new StringBuilder()).append("More than ").append(j2).append(" updates, aborting lighting updates").toString());
                        w.clear();
                    }
                    u--;
                }
            }
        }
    }

    public void g()
    {
        int i = a(1.0F);
        if(i != f)
            f = i;
    }

    public void setSpawnFlags(boolean flag, boolean flag1)
    {
        allowMonsters = flag;
        allowAnimals = flag1;
    }

    public void doTick()
    {
        i();
        long i;
        if(everyoneDeeplySleeping())
        {
            boolean flag = false;
            if(allowMonsters && spawnMonsters >= 1)
                flag = SpawnerCreature.a(this, players);
            if(!flag)
            {
                i = worldData.f() + 24000L;
                worldData.a(i - i % 24000L);
                s();
            }
        }
        if((allowMonsters || allowAnimals) && (this instanceof WorldServer) && ((WorldServer)this).getServer().getHandle().players.size() > 0)
            SpawnerCreature.spawnEntities(this, allowMonsters, allowAnimals);
        chunkProvider.unloadChunks();
        int j = a(1.0F);
        if(j != f)
        {
            f = j;
            for(int k = 0; k < p.size(); k++)
                ((IWorldAccess)p.get(k)).a();

        }
        i = worldData.f() + 1L;
        if(i % (long)this.k == 0L)
            save(false, (IProgressUpdate)null);
        worldData.a(i);
        a(false);
        j();
    }

    private void x()
    {
        if(worldData.l())
        {
            C = 1.0F;
            if(worldData.j())
                E = 1.0F;
        }
    }

    protected void i()
    {
        if(!worldProvider.e)
        {
            if(F > 0)
                F--;
            int i = worldData.k();
            if(i <= 0)
            {
                if(worldData.j())
                    worldData.b(random.nextInt(12000) + 3600);
                else
                    worldData.b(random.nextInt(0x29040) + 12000);
            } else
            {
                i--;
                worldData.b(i);
                if(i <= 0)
                {
                    CraftServer server = ((WorldServer)this).getServer();
                    ThunderChangeEvent thunder = new ThunderChangeEvent(((WorldServer)this).getWorld(), !worldData.j());
                    server.getPluginManager().callEvent(thunder);
                    if(!thunder.isCancelled())
                        worldData.a(!worldData.j());
                }
            }
            int j = worldData.m();
            if(j <= 0)
            {
                if(worldData.l())
                    worldData.c(random.nextInt(12000) + 12000);
                else
                    worldData.c(random.nextInt(0x29040) + 12000);
            } else
            {
                j--;
                worldData.c(j);
                if(j <= 0)
                {
                    CraftServer server = ((WorldServer)this).getServer();
                    WeatherChangeEvent weather = new WeatherChangeEvent(((WorldServer)this).getWorld(), !worldData.l());
                    server.getPluginManager().callEvent(weather);
                    if(!weather.isCancelled())
                        worldData.b(!worldData.l());
                }
            }
            B = C;
            if(worldData.l())
                C = (float)((double)C + 0.01D);
            else
                C = (float)((double)C - 0.01D);
            if(C < 0.0F)
                C = 0.0F;
            if(C > 1.0F)
                C = 1.0F;
            D = E;
            if(worldData.j())
                E = (float)((double)E + 0.01D);
            else
                E = (float)((double)E - 0.01D);
            if(E < 0.0F)
                E = 0.0F;
            if(E > 1.0F)
                E = 1.0F;
        }
    }

    private void y()
    {
        CraftServer server = ((WorldServer)this).getServer();
        WeatherChangeEvent weather = new WeatherChangeEvent(((WorldServer)this).getWorld(), false);
        server.getPluginManager().callEvent(weather);
        ThunderChangeEvent thunder = new ThunderChangeEvent(((WorldServer)this).getWorld(), false);
        server.getPluginManager().callEvent(thunder);
        if(!weather.isCancelled())
        {
            worldData.c(0);
            worldData.b(false);
        }
        if(!thunder.isCancelled())
        {
            worldData.b(0);
            worldData.a(false);
        }
    }

    protected void j()
    {
        M.clear();
        for(int i1 = 0; i1 < players.size(); i1++)
        {
            EntityHuman entityhuman = (EntityHuman)players.get(i1);
            int i = MathHelper.floor(entityhuman.locX / 16D);
            int j = MathHelper.floor(entityhuman.locZ / 16D);
            byte b0 = 9;
            for(int k = -b0; k <= b0; k++)
            {
                for(int l = -b0; l <= b0; l++)
                    M.add(new ChunkCoordIntPair(k + i, l + j));

            }

        }

        if(N > 0)
            N--;
        for(Iterator iterator = M.iterator(); iterator.hasNext();)
        {
            ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)iterator.next();
            int i = chunkcoordintpair.x * 16;
            int j = chunkcoordintpair.z * 16;
            Chunk chunk = getChunkAt(chunkcoordintpair.x, chunkcoordintpair.z);
            int k;
            if(N == 0)
            {
                g = g * 3 + h;
                k = g >> 2;
                int l = k & 0xf;
                int j1 = k >> 8 & 0xf;
                int k1 = k >> 16 & 0x7f;
                int l1 = chunk.getTypeId(l, k1, j1);
                l += i;
                j1 += j;
                if(l1 == 0 && getLightLevel(l, k1, j1) <= random.nextInt(8) && a(EnumSkyBlock.SKY, l, k1, j1) <= 0)
                {
                    EntityHuman entityhuman1 = a((double)l + 0.5D, (double)k1 + 0.5D, (double)j1 + 0.5D, 8D);
                    if(entityhuman1 != null && entityhuman1.d((double)l + 0.5D, (double)k1 + 0.5D, (double)j1 + 0.5D) > 4D)
                    {
                        makeSound((double)l + 0.5D, (double)k1 + 0.5D, (double)j1 + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + random.nextFloat() * 0.2F);
                        N = random.nextInt(12000) + 6000;
                    }
                }
            }
            if(random.nextInt(0x186a0) == 0 && v() && u())
            {
                g = g * 3 + h;
                k = g >> 2;
                int l = i + (k & 0xf);
                int j1 = j + (k >> 8 & 0xf);
                int k1 = e(l, j1);
                if(q(l, k1, j1))
                {
                    a(new EntityWeatherStorm(this, l, k1, j1));
                    F = 2;
                }
            }
            if(random.nextInt(16) == 0 && v())
            {
                g = g * 3 + h;
                k = g >> 2;
                int l = k & 0xf;
                int j1 = k >> 8 & 0xf;
                int k1 = e(l + i, j1 + j);
                if(getWorldChunkManager().getBiome(l + i, j1 + j).c() && k1 >= 0 && k1 < 128 && chunk.a(EnumSkyBlock.BLOCK, l, k1, j1) < 10)
                {
                    int l1 = chunk.getTypeId(l, k1 - 1, j1);
                    int i2 = chunk.getTypeId(l, k1, j1);
                    if(i2 == 0 && Block.SNOW.canPlace(this, l + i, k1, j1 + j) && l1 != 0 && l1 != Block.ICE.id && Block.byId[l1].material.isSolid())
                        setTypeId(l + i, k1, j1 + j, Block.SNOW.id);
                    if(l1 == Block.STATIONARY_WATER.id && chunk.getData(l, k1 - 1, j1) == 0)
                        setTypeId(l + i, k1 - 1, j1 + j, Block.ICE.id);
                }
            }
            k = 0;
            while(k < 80) 
            {
                g = g * 3 + h;
                int l = g >> 2;
                int j1 = l & 0xf;
                int k1 = l >> 8 & 0xf;
                int l1 = l >> 16 & 0x7f;
                int i2 = chunk.b[j1 << 11 | k1 << 7 | l1] & 0xff;
                if(Block.n[i2])
                    Block.byId[i2].a(this, j1 + i, l1, k1 + j, random);
                k++;
            }
        }

    }

    public boolean a(boolean flag)
    {
        int i = y.size();
        if(i != z.size())
            throw new IllegalStateException("TickNextTick list out of synch");
        if(i > 1000)
            i = 1000;
        for(int j = 0; j < i; j++)
        {
            NextTickListEntry nextticklistentry = (NextTickListEntry)y.first();
            if(!flag && nextticklistentry.e > worldData.f())
                break;
            y.remove(nextticklistentry);
            z.remove(nextticklistentry);
            byte b0 = 8;
            if(!a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0))
                continue;
            int k = getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
            if(k == nextticklistentry.d && k > 0)
                Block.byId[k].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, random);
        }

        return y.size() != 0;
    }

    public List b(Entity entity, AxisAlignedBB axisalignedbb)
    {
        O.clear();
        int i = MathHelper.floor((axisalignedbb.a - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.d + 2D) / 16D);
        int k = MathHelper.floor((axisalignedbb.c - 2D) / 16D);
        int l = MathHelper.floor((axisalignedbb.f + 2D) / 16D);
        for(int i1 = i; i1 <= j; i1++)
        {
            for(int j1 = k; j1 <= l; j1++)
                if(isChunkLoaded(i1, j1))
                    getChunkAt(i1, j1).a(entity, axisalignedbb, O);

        }

        return O;
    }

    public List a(Class oclass, AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor((axisalignedbb.a - 2D) / 16D);
        int j = MathHelper.floor((axisalignedbb.d + 2D) / 16D);
        int k = MathHelper.floor((axisalignedbb.c - 2D) / 16D);
        int l = MathHelper.floor((axisalignedbb.f + 2D) / 16D);
        ArrayList arraylist = new ArrayList();
        for(int i1 = i; i1 <= j; i1++)
        {
            for(int j1 = k; j1 <= l; j1++)
                if(isChunkLoaded(i1, j1))
                    getChunkAt(i1, j1).a(oclass, axisalignedbb, arraylist);

        }

        return arraylist;
    }

    public void b(int i, int j, int k, TileEntity tileentity)
    {
        if(isLoaded(i, j, k))
            b(i, k).f();
        for(int l = 0; l < p.size(); l++)
            ((IWorldAccess)p.get(l)).a(i, j, k, tileentity);

    }

    public int a(Class oclass)
    {
        int i = 0;
        for(int j = 0; j < entityList.size(); j++)
        {
            Entity entity = (Entity)entityList.get(j);
            if(oclass.isAssignableFrom(entity.getClass()))
                i++;
        }

        return i;
    }

    public void a(List list)
    {
        Entity entity = null;
        for(int i = 0; i < list.size(); i++)
        {
            entity = (Entity)list.get(i);
            if((entity instanceof EntityLiving) && !(entity instanceof EntityPlayer))
            {
                CreatureSpawnEvent event = CraftEventFactory.callCreatureSpawnEvent((EntityLiving)entity);
                if(event.isCancelled())
                    continue;
            }
            entityList.add(entity);
            c((Entity)list.get(i));
        }

    }

    public void b(List list)
    {
        x.addAll(list);
    }

    public boolean a(int i, int j, int k, int l, boolean flag)
    {
        int i1 = getTypeId(j, k, l);
        Block block = Block.byId[i1];
        Block block1 = Block.byId[i];
        AxisAlignedBB axisalignedbb = block1.d(this, j, k, l);
        if(flag)
            axisalignedbb = null;
        boolean defaultReturn = axisalignedbb == null || containsEntity(axisalignedbb) ? block == Block.WATER || block == Block.STATIONARY_WATER || block == Block.LAVA || block == Block.STATIONARY_LAVA || block == Block.FIRE || block == Block.SNOW ? true : i > 0 && block == null && block1.canPlace(this, j, k, l) : false;
        if(axisalignedbb != null && !containsEntity(axisalignedbb))
        {
            return false;
        } else
        {
            BlockCanBuildEvent event = new BlockCanBuildEvent(((WorldServer)this).getWorld().getBlockAt(j, k, l), i, defaultReturn);
            ((WorldServer)this).getServer().getPluginManager().callEvent(event);
            return event.isBuildable();
        }
    }

    public PathEntity findPath(Entity entity, Entity entity1, float f)
    {
        int i = MathHelper.floor(entity.locX);
        int j = MathHelper.floor(entity.locY);
        int k = MathHelper.floor(entity.locZ);
        int l = (int)(f + 16F);
        int i1 = i - l;
        int j1 = j - l;
        int k1 = k - l;
        int l1 = i + l;
        int i2 = j + l;
        int j2 = k + l;
        ChunkCache chunkcache = new ChunkCache(this, i1, j1, k1, l1, i2, j2);
        return (new Pathfinder(chunkcache)).a(entity, entity1, f);
    }

    public PathEntity a(Entity entity, int i, int j, int k, float f)
    {
        int l = MathHelper.floor(entity.locX);
        int i1 = MathHelper.floor(entity.locY);
        int j1 = MathHelper.floor(entity.locZ);
        int k1 = (int)(f + 8F);
        int l1 = l - k1;
        int i2 = i1 - k1;
        int j2 = j1 - k1;
        int k2 = l + k1;
        int l2 = i1 + k1;
        int i3 = j1 + k1;
        ChunkCache chunkcache = new ChunkCache(this, l1, i2, j2, k2, l2, i3);
        return (new Pathfinder(chunkcache)).a(entity, i, j, k, f);
    }

    public boolean isBlockFacePowered(int i, int j, int k, int l)
    {
        int i1 = getTypeId(i, j, k);
        return i1 != 0 ? Block.byId[i1].c(this, i, j, k, l) : false;
    }

    public boolean isBlockPowered(int i, int j, int k)
    {
        return isBlockFacePowered(i, j - 1, k, 0) ? true : isBlockFacePowered(i, j + 1, k, 1) ? true : isBlockFacePowered(i, j, k - 1, 2) ? true : isBlockFacePowered(i, j, k + 1, 3) ? true : isBlockFacePowered(i - 1, j, k, 4) ? true : isBlockFacePowered(i + 1, j, k, 5);
    }

    public boolean isBlockFaceIndirectlyPowered(int i, int j, int k, int l)
    {
        if(d(i, j, k))
        {
            return isBlockPowered(i, j, k);
        } else
        {
            int i1 = getTypeId(i, j, k);
            return i1 != 0 ? Block.byId[i1].b(this, i, j, k, l) : false;
        }
    }

    public boolean isBlockIndirectlyPowered(int i, int j, int k)
    {
        return isBlockFaceIndirectlyPowered(i, j - 1, k, 0) ? true : isBlockFaceIndirectlyPowered(i, j + 1, k, 1) ? true : isBlockFaceIndirectlyPowered(i, j, k - 1, 2) ? true : isBlockFaceIndirectlyPowered(i, j, k + 1, 3) ? true : isBlockFaceIndirectlyPowered(i - 1, j, k, 4) ? true : isBlockFaceIndirectlyPowered(i + 1, j, k, 5);
    }

    public EntityHuman a(Entity entity, double d0)
    {
        return a(entity.locX, entity.locY, entity.locZ, d0);
    }

    public EntityHuman a(double d0, double d1, double d2, double d3)
    {
        double d4 = -1D;
        EntityHuman entityhuman = null;
        for(int i = 0; i < players.size(); i++)
        {
            EntityHuman entityhuman1 = (EntityHuman)players.get(i);
            double d5 = entityhuman1.d(d0, d1, d2);
            if((d3 < 0.0D || d5 < d3 * d3) && (d4 == -1D || d5 < d4))
            {
                d4 = d5;
                entityhuman = entityhuman1;
            }
        }

        return entityhuman;
    }

    public EntityHuman a(String s)
    {
        for(int i = 0; i < players.size(); i++)
            if(s.equals(((EntityHuman)players.get(i)).name))
                return (EntityHuman)players.get(i);

        return null;
    }

    public byte[] c(int i, int j, int k, int l, int i1, int j1)
    {
        byte abyte[] = new byte[(l * i1 * j1 * 5) / 2];
        int k1 = i >> 4;
        int l1 = k >> 4;
        int i2 = (i + l) - 1 >> 4;
        int j2 = (k + j1) - 1 >> 4;
        int k2 = 0;
        int l2 = j;
        int i3 = j + i1;
        if(j < 0)
            l2 = 0;
        if(i3 > 128)
            i3 = 128;
        for(int j3 = k1; j3 <= i2; j3++)
        {
            int k3 = i - j3 * 16;
            int l3 = (i + l) - j3 * 16;
            if(k3 < 0)
                k3 = 0;
            if(l3 > 16)
                l3 = 16;
            for(int i4 = l1; i4 <= j2; i4++)
            {
                int j4 = k - i4 * 16;
                int k4 = (k + j1) - i4 * 16;
                if(j4 < 0)
                    j4 = 0;
                if(k4 > 16)
                    k4 = 16;
                k2 = getChunkAt(j3, i4).a(abyte, k3, l2, j4, l3, i3, k4, k2);
            }

        }

        return abyte;
    }

    public void k()
    {
        r.b();
    }

    public void setTime(long i)
    {
        worldData.a(i);
    }

    public long getSeed()
    {
        return worldData.b();
    }

    public long getTime()
    {
        return worldData.f();
    }

    public ChunkCoordinates getSpawn()
    {
        return new ChunkCoordinates(worldData.c(), worldData.d(), worldData.e());
    }

    public boolean a(EntityHuman entityhuman, int i, int j, int i1)
    {
        return true;
    }

    public void a(Entity entity1, byte byte0)
    {
    }

    public IChunkProvider o()
    {
        return chunkProvider;
    }

    public void d(int i, int j, int k, int l, int i1)
    {
        int j1 = getTypeId(i, j, k);
        if(j1 > 0)
            Block.byId[j1].a(this, i, j, k, l, i1);
    }

    public IDataManager p()
    {
        return r;
    }

    public WorldData q()
    {
        return worldData;
    }

    public void everyoneSleeping()
    {
        H = !players.isEmpty();
        Iterator iterator = players.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityHuman entityhuman = (EntityHuman)iterator.next();
            if(entityhuman.isSleeping() || entityhuman.fauxSleeping)
                continue;
            H = false;
            break;
        } while(true);
    }

    public void checkSleepStatus()
    {
        if(!isStatic)
            everyoneSleeping();
    }

    protected void s()
    {
        H = false;
        Iterator iterator = players.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityHuman entityhuman = (EntityHuman)iterator.next();
            if(entityhuman.isSleeping())
                entityhuman.a(false, false, true);
        } while(true);
        y();
    }

    public boolean everyoneDeeplySleeping()
    {
        if(H && !isStatic)
        {
            Iterator iterator = players.iterator();
            boolean foundActualSleepers = false;
            EntityHuman entityhuman;
            do
            {
                if(!iterator.hasNext())
                    return foundActualSleepers;
                entityhuman = (EntityHuman)iterator.next();
                if(entityhuman.isDeeplySleeping())
                    foundActualSleepers = true;
            } while(entityhuman.isDeeplySleeping() || entityhuman.fauxSleeping);
            return false;
        } else
        {
            return false;
        }
    }

    public float c(float f)
    {
        return (D + (E - D) * f) * d(f);
    }

    public float d(float f)
    {
        return B + (C - B) * f;
    }

    public boolean u()
    {
        return (double)c(1.0F) > 0.90000000000000002D;
    }

    public boolean v()
    {
        return (double)d(1.0F) > 0.20000000000000001D;
    }

    public boolean q(int i, int j, int k)
    {
        if(!v())
            return false;
        if(!isChunkLoaded(i, j, k))
            return false;
        if(e(i, k) > j)
        {
            return false;
        } else
        {
            BiomeBase biomebase = getWorldChunkManager().getBiome(i, k);
            return biomebase.c() ? false : biomebase.d();
        }
    }

    public boolean a;
    private List w;
    public List entityList;
    private List x;
    private TreeSet y;
    private Set z;
    public List c;
    public List players;
    public List e;
    private long A;
    public int f;
    protected int g;
    protected int h;
    private float B;
    private float C;
    private float D;
    private float E;
    private int F;
    public int i;
    public boolean j;
    private long G;
    protected int k;
    public int spawnMonsters;
    public Random random;
    public boolean n;
    public final WorldProvider worldProvider;
    protected List p;
    public IChunkProvider chunkProvider;
    protected final IDataManager r;
    public WorldData worldData;
    public boolean isLoading;
    private boolean H;
    private ArrayList I;
    private int J;
    public boolean allowMonsters;
    public boolean allowAnimals;
    static int u = 0;
    private Set M;
    private int N;
    private List O;
    public boolean isStatic;
    Chunk lastChunkAccessed;
    int lastXAccessed;
    int lastZAccessed;
    final Object chunkLock = new Object();

}
