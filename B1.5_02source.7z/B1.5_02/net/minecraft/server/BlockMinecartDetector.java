// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockMinecartTrack, World, IBlockAccess, EntityMinecart, 
//            AxisAlignedBB, Entity

public class BlockMinecartDetector extends BlockMinecartTrack
{

    public BlockMinecartDetector(int i, int j)
    {
        super(i, j, true);
        a(true);
    }

    public int b()
    {
        return 20;
    }

    public boolean isPowerSource()
    {
        return true;
    }

    public void a(World world, int i, int j, int k, Entity entity)
    {
        if(world.isStatic)
            return;
        int l = world.getData(i, j, k);
        if((l & 8) != 0)
        {
            return;
        } else
        {
            f(world, i, j, k, l);
            return;
        }
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        if(world.isStatic)
            return;
        int l = world.getData(i, j, k);
        if((l & 8) == 0)
        {
            return;
        } else
        {
            f(world, i, j, k, l);
            return;
        }
    }

    public boolean b(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return (iblockaccess.getData(i, j, k) & 8) != 0;
    }

    public boolean c(World world, int i, int j, int k, int l)
    {
        if((world.getData(i, j, k) & 8) == 0)
            return false;
        else
            return l == 1;
    }

    private void f(World world, int i, int j, int k, int l)
    {
        boolean flag = (l & 8) != 0;
        boolean flag1 = false;
        float f1 = 0.125F;
        List list = world.a(net/minecraft/server/EntityMinecart, AxisAlignedBB.b((float)i + f1, j, (float)k + f1, (float)(i + 1) - f1, (double)j + 0.25D, (float)(k + 1) - f1));
        if(list.size() > 0)
            flag1 = true;
        if(flag1 && !flag)
        {
            world.setData(i, j, k, l | 8);
            world.applyPhysics(i, j, k, id);
            world.applyPhysics(i, j - 1, k, id);
            world.b(i, j, k, i, j, k);
        }
        if(!flag1 && flag)
        {
            world.setData(i, j, k, l & 7);
            world.applyPhysics(i, j, k, id);
            world.applyPhysics(i, j - 1, k, id);
            world.b(i, j, k, i, j, k);
        }
        if(flag1)
            world.c(i, j, k, id, b());
    }
}
