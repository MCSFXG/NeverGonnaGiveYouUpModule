// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            BlockFlower, Block, World

public class BlockMushroom extends BlockFlower
{

    protected BlockMushroom(int i, int j)
    {
        super(i, j);
        float f1 = 0.2F;
        a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f1 * 2.0F, 0.5F + f1);
    }

    protected boolean c(int i)
    {
        return Block.o[i];
    }

    public boolean f(World world, int i, int j, int k)
    {
        return world.getLightLevel(i, j, k) <= 13 && c(world.getTypeId(i, j - 1, k));
    }
}
