// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPlayer.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityHuman, ItemStack, Packet5EntityEquipment, WorldServer, 
//            EntityArrow, ChunkCoordIntPair, Packet51MapChunk, TileEntity, 
//            Packet8UpdateHealth, EntityItem, Packet22Collect, Packet18ArmAnimation, 
//            Packet17, Packet39AttachEntity, Packet100OpenWindow, ContainerWorkbench, 
//            ContainerChest, ContainerFurnace, ContainerDispenser, SlotResult, 
//            Packet103SetSlot, Packet104WindowItems, Packet105CraftProgressBar, Packet101CloseWindow, 
//            Packet200Statistic, ICrafting, World, ChunkCoordinates, 
//            WorldProvider, ItemInWorldManager, Container, MinecraftServer, 
//            EntityTracker, InventoryPlayer, NetServerHandler, Entity, 
//            EnumBedError, IInventory, TileEntityFurnace, TileEntityDispenser, 
//            Statistic

public class EntityPlayer extends EntityHuman
    implements ICrafting
{

    public EntityPlayer(MinecraftServer minecraftserver, World world, String s, ItemInWorldManager iteminworldmanager)
    {
        super(world);
        f = new LinkedList();
        g = new HashSet();
        bF = 0xfa0a1f01;
        bG = 60;
        bI = 0;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        int i = chunkcoordinates.x;
        int j = chunkcoordinates.z;
        int k = chunkcoordinates.y;
        if(!world.worldProvider.e)
        {
            i += random.nextInt(20) - 10;
            k = world.e(i, j);
            j += random.nextInt(20) - 10;
        }
        setPositionRotation((double)i + 0.5D, k, (double)j + 0.5D, 0.0F, 0.0F);
        b = minecraftserver;
        bo = 0.0F;
        iteminworldmanager.player = this;
        name = s;
        itemInWorldManager = iteminworldmanager;
        height = 0.0F;
        displayName = name;
    }

    public void syncInventory()
    {
        activeContainer.a(this);
    }

    public net.minecraft.server.ItemStack[] getEquipment()
    {
        return bH;
    }

    protected void j_()
    {
        height = 0.0F;
    }

    public float s()
    {
        return 1.62F;
    }

    public void p_()
    {
        itemInWorldManager.a();
        bG--;
        activeContainer.a();
        for(int i = 0; i < 5; i++)
        {
            net.minecraft.server.ItemStack itemstack = b_(i);
            if(itemstack != bH[i])
            {
                b.tracker.a(this, new Packet5EntityEquipment(id, i, itemstack));
                bH[i] = itemstack;
            }
        }

    }

    public net.minecraft.server.ItemStack b_(int i)
    {
        return i != 0 ? inventory.armor[i - 1] : inventory.getItemInHand();
    }

    public void a(Entity entity)
    {
        List loot = new ArrayList();
        for(int i = 0; i < inventory.items.length; i++)
            if(inventory.items[i] != null)
            {
                loot.add(new CraftItemStack(inventory.items[i]));
                inventory.items[i] = null;
            }

        for(int i = 0; i < inventory.armor.length; i++)
            if(inventory.armor[i] != null)
            {
                loot.add(new CraftItemStack(inventory.armor[i]));
                inventory.armor[i] = null;
            }

        CraftEntity craftEntity = (CraftEntity)getBukkitEntity();
        CraftWorld cworld = ((WorldServer)world).getWorld();
        Server server = ((WorldServer)world).getServer();
        EntityDeathEvent event = new EntityDeathEvent(craftEntity, loot);
        server.getPluginManager().callEvent(event);
        ItemStack stack;
        for(Iterator i$ = event.getDrops().iterator(); i$.hasNext(); cworld.dropItemNaturally(craftEntity.getLocation(), stack))
            stack = (ItemStack)i$.next();

    }

    public boolean damageEntity(Entity entity, int i)
    {
        if(bG > 0)
            return false;
        if(!b.pvpMode)
        {
            if(entity instanceof EntityHuman)
                return false;
            if(entity instanceof EntityArrow)
            {
                EntityArrow entityarrow = (EntityArrow)entity;
                if(entityarrow.shooter instanceof EntityHuman)
                    return false;
            }
        }
        return super.damageEntity(entity, i);
    }

    protected boolean t()
    {
        return b.pvpMode;
    }

    public void b(int i)
    {
        super.b(i);
    }

    public void a(boolean flag)
    {
        super.p_();
        if(flag && !f.isEmpty())
        {
            ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)f.get(0);
            if(chunkcoordintpair != null)
            {
                boolean flag1 = false;
                if(netServerHandler.b() < 2)
                    flag1 = true;
                if(flag1)
                {
                    f.remove(chunkcoordintpair);
                    netServerHandler.sendPacket(new Packet51MapChunk(chunkcoordintpair.x * 16, 0, chunkcoordintpair.z * 16, 16, 128, 16, world));
                    List list = ((WorldServer)world).getTileEntities(chunkcoordintpair.x * 16, 0, chunkcoordintpair.z * 16, chunkcoordintpair.x * 16 + 16, 128, chunkcoordintpair.z * 16 + 16);
                    for(int i = 0; i < list.size(); i++)
                        a((TileEntity)list.get(i));

                }
            }
        }
        if(health != bF)
        {
            netServerHandler.sendPacket(new Packet8UpdateHealth(health));
            bF = health;
        }
    }

    private void a(TileEntity tileentity)
    {
        if(tileentity != null)
        {
            Packet packet = tileentity.e();
            if(packet != null)
                netServerHandler.sendPacket(packet);
        }
    }

    public void u()
    {
        super.u();
    }

    public void receive(Entity entity, int i)
    {
        if(!entity.dead)
        {
            if(entity instanceof EntityItem)
                b.tracker.a(entity, new Packet22Collect(entity.id, id));
            if(entity instanceof EntityArrow)
                b.tracker.a(entity, new Packet22Collect(entity.id, id));
        }
        super.receive(entity, i);
        activeContainer.a();
    }

    public void k_()
    {
        if(!p)
        {
            q = -1;
            p = true;
            b.tracker.a(this, new Packet18ArmAnimation(this, 1));
        }
    }

    public void w()
    {
    }

    public EnumBedError a(int i, int j, int k)
    {
        EnumBedError enumbederror = super.a(i, j, k);
        if(enumbederror == EnumBedError.OK)
            b.tracker.a(this, new Packet17(this, 0, i, j, k));
        return enumbederror;
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        if(isSleeping())
            b.tracker.b(this, new Packet18ArmAnimation(this, 3));
        super.a(flag, flag1, flag2);
        netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    public void mount(Entity entity)
    {
        setPassengerOf(entity);
    }

    public void setPassengerOf(Entity entity)
    {
        super.setPassengerOf(entity);
        netServerHandler.sendPacket(new Packet39AttachEntity(this, vehicle));
        netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    protected void a(double d1, boolean flag1)
    {
    }

    public void b(double d0, boolean flag)
    {
        super.a(d0, flag);
    }

    private void af()
    {
        bI = bI % 100 + 1;
    }

    public void b(int i, int j, int k)
    {
        af();
        netServerHandler.sendPacket(new Packet100OpenWindow(bI, 1, "Crafting", 9));
        activeContainer = new ContainerWorkbench(inventory, world, i, j, k);
        activeContainer.f = bI;
        activeContainer.a(this);
    }

    public void a(IInventory iinventory)
    {
        af();
        netServerHandler.sendPacket(new Packet100OpenWindow(bI, 0, iinventory.getName(), iinventory.getSize()));
        activeContainer = new ContainerChest(inventory, iinventory);
        activeContainer.f = bI;
        activeContainer.a(this);
    }

    public void a(TileEntityFurnace tileentityfurnace)
    {
        af();
        netServerHandler.sendPacket(new Packet100OpenWindow(bI, 2, tileentityfurnace.getName(), tileentityfurnace.getSize()));
        activeContainer = new ContainerFurnace(inventory, tileentityfurnace);
        activeContainer.f = bI;
        activeContainer.a(this);
    }

    public void a(TileEntityDispenser tileentitydispenser)
    {
        af();
        netServerHandler.sendPacket(new Packet100OpenWindow(bI, 3, tileentitydispenser.getName(), tileentitydispenser.getSize()));
        activeContainer = new ContainerDispenser(inventory, tileentitydispenser);
        activeContainer.f = bI;
        activeContainer.a(this);
    }

    public void a(Container container, int i, net.minecraft.server.ItemStack itemstack)
    {
        if(!(container.b(i) instanceof SlotResult) && !h)
            netServerHandler.sendPacket(new Packet103SetSlot(container.f, i, itemstack));
    }

    public void a(Container container, List list)
    {
        netServerHandler.sendPacket(new Packet104WindowItems(container.f, list));
        netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.j()));
    }

    public void a(Container container, int i, int j)
    {
        netServerHandler.sendPacket(new Packet105CraftProgressBar(container.f, i, j));
    }

    public void a(net.minecraft.server.ItemStack itemstack1)
    {
    }

    public void x()
    {
        netServerHandler.sendPacket(new Packet101CloseWindow(activeContainer.f));
        z();
    }

    public void y()
    {
        if(!h)
            netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.j()));
    }

    public void z()
    {
        activeContainer.a(this);
        activeContainer = defaultContainer;
    }

    public void a(float f, float f1, boolean flag, boolean flag1, float f2, float f3)
    {
        av = f;
        aw = f1;
        ay = flag;
        setSneak(flag1);
        pitch = f2;
        yaw = f3;
    }

    public void a(Statistic statistic, int i)
    {
        if(statistic != null && !statistic.g)
        {
            for(; i > 100; i -= 100)
                netServerHandler.sendPacket(new Packet200Statistic(statistic.e, 100));

            netServerHandler.sendPacket(new Packet200Statistic(statistic.e, i));
        }
    }

    public String toString()
    {
        return (new StringBuilder()).append(super.toString()).append("(").append(name).append(" at ").append(locX).append(",").append(locY).append(",").append(locZ).append(")").toString();
    }

    public NetServerHandler netServerHandler;
    public MinecraftServer b;
    public ItemInWorldManager itemInWorldManager;
    public double d;
    public double e;
    public List f;
    public Set g;
    private int bF;
    private int bG;
    private net.minecraft.server.ItemStack bH[] = {
        null, null, null, null, null
    };
    private int bI;
    public boolean h;
    public String displayName;
    public Location compassTarget;
}
