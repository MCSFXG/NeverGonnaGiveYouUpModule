// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, ItemStack, World, Block, 
//            BlockSapling, BlockCrops, EntitySheep, BlockCloth, 
//            EntityHuman, EntityLiving

public class ItemDye extends Item
{

    public ItemDye(int i)
    {
        super(i);
        a(true);
        d(0);
    }

    public boolean a(ItemStack itemstack, EntityHuman entityhuman, World world, int i, int j, int k, int l)
    {
        if(itemstack.getData() == 15)
        {
            int i1 = world.getTypeId(i, j, k);
            if(i1 == Block.SAPLING.id)
            {
                ((BlockSapling)Block.SAPLING).b(world, i, j, k, world.random);
                itemstack.count--;
                return true;
            }
            if(i1 == Block.CROPS.id)
            {
                ((BlockCrops)Block.CROPS).c_(world, i, j, k);
                itemstack.count--;
                return true;
            }
        }
        return false;
    }

    public void a(ItemStack itemstack, EntityLiving entityliving)
    {
        if(entityliving instanceof EntitySheep)
        {
            EntitySheep entitysheep = (EntitySheep)entityliving;
            int i = BlockCloth.c(itemstack.getData());
            if(!entitysheep.isSheared() && entitysheep.getColor() != i)
            {
                entitysheep.setColor(i);
                itemstack.count--;
            }
        }
    }

    public static final String a[] = {
        "black", "red", "green", "brown", "blue", "purple", "cyan", "silver", "gray", "pink", 
        "lime", "yellow", "lightBlue", "magenta", "orange", "white"
    };

}
