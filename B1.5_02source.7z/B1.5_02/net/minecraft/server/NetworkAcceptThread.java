// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.IOException;
import java.net.*;
import java.util.HashMap;

// Referenced classes of package net.minecraft.server:
//            NetworkListenThread, NetLoginHandler, MinecraftServer

class NetworkAcceptThread extends Thread
{

    NetworkAcceptThread(NetworkListenThread networklistenthread, String s, MinecraftServer minecraftserver)
    {
        b = networklistenthread;
        a = minecraftserver;
        super(s);
    }

    public void run()
    {
        HashMap hashmap = new HashMap();
_L2:
        if(!b.b)
            break; /* Loop/switch isn't completed */
        Socket socket = NetworkListenThread.a(b).accept();
        if(socket == null)
            continue; /* Loop/switch isn't completed */
        InetAddress inetaddress = socket.getInetAddress();
        if(hashmap.containsKey(inetaddress) && !"127.0.0.1".equals(inetaddress.getHostAddress()) && System.currentTimeMillis() - ((Long)hashmap.get(inetaddress)).longValue() < 5000L)
        {
            hashmap.put(inetaddress, Long.valueOf(System.currentTimeMillis()));
            socket.close();
            continue; /* Loop/switch isn't completed */
        }
        try
        {
            hashmap.put(inetaddress, Long.valueOf(System.currentTimeMillis()));
            NetLoginHandler netloginhandler = new NetLoginHandler(a, socket, (new StringBuilder()).append("Connection #").append(NetworkListenThread.b(b)).toString());
            NetworkListenThread.a(b, netloginhandler);
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
        if(true) goto _L2; else goto _L1
_L1:
    }

    final MinecraftServer a;
    final NetworkListenThread b;
}
