// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityWaterAnimal, ItemStack, Item, AxisAlignedBB, 
//            Material, World, MathHelper, NBTTagCompound, 
//            EntityHuman

public class EntitySquid extends EntityWaterAnimal
{

    public EntitySquid(World world)
    {
        super(world);
        a = 0.0F;
        b = 0.0F;
        c = 0.0F;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0.0F;
        j = 0.0F;
        k = 0.0F;
        l = 0.0F;
        m = 0.0F;
        n = 0.0F;
        o = 0.0F;
        p = 0.0F;
        texture = "/mob/squid.png";
        b(0.95F, 0.95F);
        l = (1.0F / (random.nextFloat() + 1.0F)) * 0.2F;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected String g()
    {
        return null;
    }

    protected String h()
    {
        return null;
    }

    protected String i()
    {
        return null;
    }

    protected float k()
    {
        return 0.4F;
    }

    protected int j()
    {
        return 0;
    }

    protected void r()
    {
        int i1 = random.nextInt(3) + 1;
        for(int j1 = 0; j1 < i1; j1++)
            a(new ItemStack(Item.INK_SACK, 1, 0), 0.0F);

    }

    public boolean a(EntityHuman entityhuman)
    {
        return false;
    }

    public boolean Z()
    {
        return world.a(boundingBox.b(0.0D, -0.60000002384185791D, 0.0D), Material.WATER, this);
    }

    public void u()
    {
        super.u();
        b = a;
        f = c;
        h = g;
        j = i;
        g += l;
        if(g > 6.283185F)
        {
            g -= 6.283185F;
            if(random.nextInt(10) == 0)
                l = (1.0F / (random.nextFloat() + 1.0F)) * 0.2F;
        }
        if(Z())
        {
            if(g < 3.141593F)
            {
                float f1 = g / 3.141593F;
                i = MathHelper.sin(f1 * f1 * 3.141593F) * 3.141593F * 0.25F;
                if((double)f1 > 0.75D)
                {
                    k = 1.0F;
                    m = 1.0F;
                } else
                {
                    m = m * 0.8F;
                }
            } else
            {
                i = 0.0F;
                k = k * 0.9F;
                m = m * 0.99F;
            }
            if(!U)
            {
                motX = n * k;
                motY = o * k;
                motZ = p * k;
            }
            float f2 = MathHelper.a(motX * motX + motZ * motZ);
            G += ((-(float)Math.atan2(motX, motZ) * 180F) / 3.141593F - G) * 0.1F;
            yaw = G;
            c = c + 3.141593F * m * 1.5F;
            a += ((-(float)Math.atan2(f2, motY) * 180F) / 3.141593F - a) * 0.1F;
        } else
        {
            i = MathHelper.abs(MathHelper.sin(g)) * 3.141593F * 0.25F;
            if(!U)
            {
                motX = 0.0D;
                motY -= 0.080000000000000002D;
                motY *= 0.98000001907348633D;
                motZ = 0.0D;
            }
            a += (double)(-90F - a) * 0.02D;
        }
    }

    public void a(float f1, float f2)
    {
        move(motX, motY, motZ);
    }

    protected void c_()
    {
        if(random.nextInt(50) == 0 || !bw || n == 0.0F && o == 0.0F && p == 0.0F)
        {
            float f1 = random.nextFloat() * 3.141593F * 2.0F;
            n = MathHelper.cos(f1) * 0.2F;
            o = -0.1F + random.nextFloat() * 0.2F;
            p = MathHelper.sin(f1) * 0.2F;
        }
    }

    public float a;
    public float b;
    public float c;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    private float k;
    private float l;
    private float m;
    private float n;
    private float o;
    private float p;
}
