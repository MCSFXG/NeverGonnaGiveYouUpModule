// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityCreature.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityLiving, WorldServer, Entity, World, 
//            MathHelper, AxisAlignedBB, PathEntity, Vec3D

public class EntityCreature extends EntityLiving
{

    public EntityCreature(World world)
    {
        super(world);
        e = false;
    }

    protected boolean w()
    {
        return false;
    }

    protected void c_()
    {
        e = w();
        float f = 16F;
        if(this.target == null)
        {
            Entity target = findTarget();
            if(target != null)
            {
                EntityTargetEvent event = new EntityTargetEvent(getBukkitEntity(), target.getBukkitEntity(), org.bukkit.event.entity.EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
                CraftServer server = ((WorldServer)world).getServer();
                server.getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    if(event.getTarget() == null)
                        this.target = null;
                    else
                        this.target = ((CraftEntity)event.getTarget()).getHandle();
            }
            if(this.target != null)
                pathEntity = world.findPath(this, this.target, f);
        } else
        if(!this.target.P())
        {
            EntityTargetEvent event = new EntityTargetEvent(getBukkitEntity(), null, org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_DIED);
            CraftServer server = ((WorldServer)world).getServer();
            server.getPluginManager().callEvent(event);
            if(!event.isCancelled())
                if(event.getTarget() == null)
                    this.target = null;
                else
                    this.target = ((CraftEntity)event.getTarget()).getHandle();
        } else
        {
            float f1 = this.target.f(this);
            if(e(this.target))
                a(this.target, f1);
        }
        if(!e && this.target != null && (pathEntity == null || random.nextInt(20) == 0))
            pathEntity = world.findPath(this, this.target, f);
        else
        if(!e && (pathEntity == null && random.nextInt(80) == 0 || random.nextInt(80) == 0))
        {
            boolean flag = false;
            int i = -1;
            int j = -1;
            int k = -1;
            float f2 = -99999F;
            for(int l = 0; l < 10; l++)
            {
                int i1 = MathHelper.floor((locX + (double)random.nextInt(13)) - 6D);
                int j1 = MathHelper.floor((locY + (double)random.nextInt(7)) - 3D);
                int k1 = MathHelper.floor((locZ + (double)random.nextInt(13)) - 6D);
                float f3 = a(i1, j1, k1);
                if(f3 > f2)
                {
                    f2 = f3;
                    i = i1;
                    j = j1;
                    k = k1;
                    flag = true;
                }
            }

            if(flag)
                pathEntity = world.a(this, i, j, k, 10F);
        }
        int l1 = MathHelper.floor(boundingBox.b + 0.5D);
        boolean flag1 = Z();
        boolean flag2 = aa();
        pitch = 0.0F;
        if(pathEntity != null && random.nextInt(100) != 0)
        {
            Vec3D vec3d = pathEntity.a(this);
            for(double d0 = length * 2.0F; vec3d != null && vec3d.d(locX, vec3d.b, locZ) < d0 * d0;)
            {
                pathEntity.a();
                if(pathEntity.b())
                {
                    vec3d = null;
                    pathEntity = null;
                } else
                {
                    vec3d = pathEntity.a(this);
                }
            }

            ay = false;
            if(vec3d != null)
            {
                double d1 = vec3d.a - locX;
                double d2 = vec3d.c - locZ;
                double d3 = vec3d.b - (double)l1;
                float f4 = (float)((TrigMath.atan2(d2, d1) * 180D) / 3.1415927410125732D) - 90F;
                float f5 = f4 - yaw;
                aw = aA;
                for(; f5 < -180F; f5 += 360F);
                for(; f5 >= 180F; f5 -= 360F);
                if(f5 > 30F)
                    f5 = 30F;
                if(f5 < -30F)
                    f5 = -30F;
                yaw += f5;
                if(e && this.target != null)
                {
                    double d4 = this.target.locX - locX;
                    double d5 = this.target.locZ - locZ;
                    float f6 = yaw;
                    yaw = (float)((Math.atan2(d5, d4) * 180D) / 3.1415927410125732D) - 90F;
                    f5 = (((f6 - yaw) + 90F) * 3.141593F) / 180F;
                    av = -MathHelper.sin(f5) * aw * 1.0F;
                    aw = MathHelper.cos(f5) * aw * 1.0F;
                }
                if(d3 > 0.0D)
                    ay = true;
            }
            if(this.target != null)
                a(this.target, 30F, 30F);
            if(positionChanged && !C())
                ay = true;
            if(random.nextFloat() < 0.8F && (flag1 || flag2))
                ay = true;
        } else
        {
            super.c_();
            pathEntity = null;
        }
    }

    protected void a(Entity entity1, float f1)
    {
    }

    protected float a(int i, int j, int k)
    {
        return 0.0F;
    }

    protected Entity findTarget()
    {
        return null;
    }

    public boolean d()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        return super.d() && a(i, j, k) >= 0.0F;
    }

    public boolean C()
    {
        return pathEntity != null;
    }

    public void a(PathEntity pathentity)
    {
        pathEntity = pathentity;
    }

    public Entity D()
    {
        return target;
    }

    public void c(Entity entity)
    {
        target = entity;
    }

    public PathEntity pathEntity;
    public Entity target;
    protected boolean e;
}
