// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, EntityHuman, 
//            EnumBedError, BedBlockTextures, Item, ChunkCoordinates, 
//            IBlockAccess

public class BlockBed extends Block
{

    public BlockBed(int j)
    {
        super(j, 134, Material.CLOTH);
        i();
    }

    public boolean interact(World world, int j, int k, int l, EntityHuman entityhuman)
    {
        int i1 = world.getData(j, k, l);
        if(!d(i1))
        {
            int j1 = c(i1);
            j += a[j1][0];
            l += a[j1][1];
            if(world.getTypeId(j, k, l) != id)
                return true;
            i1 = world.getData(j, k, l);
        }
        if(e(i1))
        {
            entityhuman.a("tile.bed.occupied");
            return true;
        }
        EnumBedError enumbederror = entityhuman.a(j, k, l);
        if(enumbederror == EnumBedError.OK)
        {
            a(world, j, k, l, true);
            return true;
        }
        if(enumbederror == EnumBedError.NOT_POSSIBLE_NOW)
            entityhuman.a("tile.bed.noSleep");
        return true;
    }

    public int a(int j, int k)
    {
        if(j == 0)
            return Block.WOOD.textureId;
        int l = c(k);
        int i1 = BedBlockTextures.c[l][j];
        if(d(k))
        {
            if(i1 == 2)
                return textureId + 2 + 16;
            if(i1 == 5 || i1 == 4)
                return textureId + 1 + 16;
            else
                return textureId + 1;
        }
        if(i1 == 3)
            return (textureId - 1) + 16;
        if(i1 == 5 || i1 == 4)
            return textureId + 16;
        else
            return textureId;
    }

    public boolean a()
    {
        return false;
    }

    public void a(IBlockAccess iblockaccess, int j, int k, int l)
    {
        i();
    }

    public void doPhysics(World world, int j, int k, int l, int i1)
    {
        int j1 = world.getData(j, k, l);
        int k1 = c(j1);
        if(d(j1))
        {
            if(world.getTypeId(j - a[k1][0], k, l - a[k1][1]) != id)
                world.setTypeId(j, k, l, 0);
        } else
        if(world.getTypeId(j + a[k1][0], k, l + a[k1][1]) != id)
        {
            world.setTypeId(j, k, l, 0);
            if(!world.isStatic)
                a_(world, j, k, l, j1);
        }
    }

    public int a(int j, Random random)
    {
        if(d(j))
            return 0;
        else
            return Item.BED.id;
    }

    private void i()
    {
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.5625F, 1.0F);
    }

    public static int c(int j)
    {
        return j & 3;
    }

    public static boolean d(int j)
    {
        return (j & 8) != 0;
    }

    public static boolean e(int j)
    {
        return (j & 4) != 0;
    }

    public static void a(World world, int j, int k, int l, boolean flag)
    {
        int i1 = world.getData(j, k, l);
        if(flag)
            i1 |= 4;
        else
            i1 &= -5;
        world.setData(j, k, l, i1);
    }

    public static ChunkCoordinates f(World world, int j, int k, int l, int i1)
    {
        int j1 = world.getData(j, k, l);
        int k1 = c(j1);
        for(int l1 = 0; l1 <= 1; l1++)
        {
            int i2 = j - a[k1][0] * l1 - 1;
            int j2 = l - a[k1][1] * l1 - 1;
            int k2 = i2 + 2;
            int l2 = j2 + 2;
            for(int i3 = i2; i3 <= k2; i3++)
            {
                for(int j3 = j2; j3 <= l2; j3++)
                {
                    if(!world.d(i3, k - 1, j3) || !world.isEmpty(i3, k, j3) || !world.isEmpty(i3, k + 1, j3))
                        continue;
                    if(i1 > 0)
                        i1--;
                    else
                        return new ChunkCoordinates(i3, k, j3);
                }

            }

        }

        return null;
    }

    public static final int a[][] = {
        {
            0, 1
        }, {
            -1, 0
        }, {
            0, -1
        }, {
            1, 0
        }
    };

}
