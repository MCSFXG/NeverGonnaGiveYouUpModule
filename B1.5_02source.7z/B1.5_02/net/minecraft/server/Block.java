// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Material, IBlockAccess, AxisAlignedBB, EntityHuman, 
//            World, EntityItem, ItemStack, Vec3D, 
//            MovingObjectPosition, StatisticList, StatisticCollector, StepSound, 
//            StepSoundStone, StepSoundSand, BlockStone, BlockGrass, 
//            BlockDirt, BlockSapling, BlockFlowing, BlockStationary, 
//            BlockSand, BlockGravel, BlockOre, BlockLog, 
//            BlockLeaves, BlockSponge, BlockGlass, BlockDispenser, 
//            BlockSandStone, BlockNote, BlockBed, BlockMinecartTrack, 
//            BlockMinecartDetector, BlockWeb, BlockCloth, BlockFlower, 
//            BlockMushroom, BlockOreBlock, BlockStep, BlockTNT, 
//            BlockBookshelf, BlockObsidian, BlockTorch, BlockFire, 
//            BlockMobSpawner, BlockStairs, BlockChest, BlockRedstoneWire, 
//            BlockWorkbench, BlockCrops, BlockSoil, BlockFurnace, 
//            BlockSign, TileEntitySign, BlockDoor, BlockLadder, 
//            BlockLever, BlockPressurePlate, EnumMobType, BlockRedstoneOre, 
//            BlockRedstoneTorch, BlockButton, BlockSnow, BlockIce, 
//            BlockSnowBlock, BlockCactus, BlockClay, BlockReed, 
//            BlockJukeBox, BlockFence, BlockPumpkin, BlockBloodStone, 
//            BlockSlowSand, BlockLightStone, BlockPortal, BlockCake, 
//            BlockDiode, BlockLockedChest, Item, ItemCloth, 
//            ItemLog, ItemStep, ItemSapling, ItemBlock, 
//            Entity, EntityLiving

public class Block
{

    protected Block(int i1, Material material1)
    {
        bo = true;
        bp = true;
        stepSound = d;
        bx = 1.0F;
        frictionFactor = 0.6F;
        if(byId[i1] != null)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Slot ").append(i1).append(" is already occupied by ").append(byId[i1]).append(" when adding ").append(this).toString());
        } else
        {
            material = material1;
            byId[i1] = this;
            id = i1;
            a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            o[i1] = a();
            q[i1] = a() ? 255 : 0;
            r[i1] = !material1.blocksLight();
            isTileEntity[i1] = false;
            return;
        }
    }

    protected Block(int i1, int j1, Material material1)
    {
        this(i1, material1);
        textureId = j1;
    }

    protected Block a(StepSound stepsound)
    {
        stepSound = stepsound;
        return this;
    }

    protected Block f(int i1)
    {
        q[id] = i1;
        return this;
    }

    protected Block a(float f1)
    {
        s[id] = (int)(15F * f1);
        return this;
    }

    protected Block b(float f1)
    {
        durability = f1 * 3F;
        return this;
    }

    protected Block c(float f1)
    {
        strength = f1;
        if(durability < f1 * 5F)
            durability = f1 * 5F;
        return this;
    }

    protected Block a(boolean flag)
    {
        n[id] = flag;
        return this;
    }

    public void a(float f1, float f2, float f3, float f4, float f5, float f6)
    {
        minX = f1;
        minY = f2;
        minZ = f3;
        maxX = f4;
        maxY = f5;
        maxZ = f6;
    }

    public boolean a(IBlockAccess iblockaccess, int i1, int j1, int k1, int l1)
    {
        if(l1 == 0 && minY > 0.0D)
            return true;
        if(l1 == 1 && maxY < 1.0D)
            return true;
        if(l1 == 2 && minZ > 0.0D)
            return true;
        if(l1 == 3 && maxZ < 1.0D)
            return true;
        if(l1 == 4 && minX > 0.0D)
            return true;
        if(l1 == 5 && maxX < 1.0D)
            return true;
        else
            return !iblockaccess.d(i1, j1, k1);
    }

    public int a(int i1, int j1)
    {
        return a(i1);
    }

    public int a(int i1)
    {
        return textureId;
    }

    public void a(World world, int i1, int j1, int k1, AxisAlignedBB axisalignedbb, ArrayList arraylist)
    {
        AxisAlignedBB axisalignedbb1 = d(world, i1, j1, k1);
        if(axisalignedbb1 != null && axisalignedbb.a(axisalignedbb1))
            arraylist.add(axisalignedbb1);
    }

    public AxisAlignedBB d(World world, int i1, int j1, int k1)
    {
        return AxisAlignedBB.b((double)i1 + minX, (double)j1 + minY, (double)k1 + minZ, (double)i1 + maxX, (double)j1 + maxY, (double)k1 + maxZ);
    }

    public boolean a()
    {
        return true;
    }

    public boolean a(int i1, boolean flag)
    {
        return n_();
    }

    public boolean n_()
    {
        return true;
    }

    public void a(World world, int i1, int j1, int k1, Random random)
    {
    }

    public void postBreak(World world, int i1, int j1, int k1, int l1)
    {
    }

    public void doPhysics(World world, int i1, int j1, int k1, int l1)
    {
    }

    public int b()
    {
        return 10;
    }

    public void e(World world, int i1, int j1, int k1)
    {
    }

    public void remove(World world, int i1, int j1, int k1)
    {
    }

    public int a(Random random)
    {
        return 1;
    }

    public int a(int i1, Random random)
    {
        return id;
    }

    public float getDamage(EntityHuman entityhuman)
    {
        if(strength < 0.0F)
            return 0.0F;
        if(!entityhuman.b(this))
            return 1.0F / strength / 100F;
        else
            return entityhuman.a(this) / strength / 30F;
    }

    public void a_(World world, int i1, int j1, int k1, int l1)
    {
        dropNaturally(world, i1, j1, k1, l1, 1.0F);
    }

    public void dropNaturally(World world, int i1, int j1, int k1, int l1, float f1)
    {
        if(world.isStatic)
            return;
        int i2 = a(world.random);
        for(int j2 = 0; j2 < i2; j2++)
        {
            if(world.random.nextFloat() > f1)
                continue;
            int k2 = a(l1, world.random);
            if(k2 > 0)
            {
                float f2 = 0.7F;
                double d1 = (double)(world.random.nextFloat() * f2) + (double)(1.0F - f2) * 0.5D;
                double d2 = (double)(world.random.nextFloat() * f2) + (double)(1.0F - f2) * 0.5D;
                double d3 = (double)(world.random.nextFloat() * f2) + (double)(1.0F - f2) * 0.5D;
                EntityItem entityitem = new EntityItem(world, (double)i1 + d1, (double)j1 + d2, (double)k1 + d3, new ItemStack(k2, 1, b(l1)));
                entityitem.pickupDelay = 10;
                world.addEntity(entityitem);
            }
        }

    }

    protected int b(int i1)
    {
        return 0;
    }

    public float a(Entity entity)
    {
        return durability / 5F;
    }

    public MovingObjectPosition a(World world, int i1, int j1, int k1, Vec3D vec3d, Vec3D vec3d1)
    {
        a(((IBlockAccess) (world)), i1, j1, k1);
        vec3d = vec3d.add(-i1, -j1, -k1);
        vec3d1 = vec3d1.add(-i1, -j1, -k1);
        Vec3D vec3d2 = vec3d.a(vec3d1, minX);
        Vec3D vec3d3 = vec3d.a(vec3d1, maxX);
        Vec3D vec3d4 = vec3d.b(vec3d1, minY);
        Vec3D vec3d5 = vec3d.b(vec3d1, maxY);
        Vec3D vec3d6 = vec3d.c(vec3d1, minZ);
        Vec3D vec3d7 = vec3d.c(vec3d1, maxZ);
        if(!a(vec3d2))
            vec3d2 = null;
        if(!a(vec3d3))
            vec3d3 = null;
        if(!b(vec3d4))
            vec3d4 = null;
        if(!b(vec3d5))
            vec3d5 = null;
        if(!c(vec3d6))
            vec3d6 = null;
        if(!c(vec3d7))
            vec3d7 = null;
        Vec3D vec3d8 = null;
        if(vec3d2 != null && (vec3d8 == null || vec3d.a(vec3d2) < vec3d.a(vec3d8)))
            vec3d8 = vec3d2;
        if(vec3d3 != null && (vec3d8 == null || vec3d.a(vec3d3) < vec3d.a(vec3d8)))
            vec3d8 = vec3d3;
        if(vec3d4 != null && (vec3d8 == null || vec3d.a(vec3d4) < vec3d.a(vec3d8)))
            vec3d8 = vec3d4;
        if(vec3d5 != null && (vec3d8 == null || vec3d.a(vec3d5) < vec3d.a(vec3d8)))
            vec3d8 = vec3d5;
        if(vec3d6 != null && (vec3d8 == null || vec3d.a(vec3d6) < vec3d.a(vec3d8)))
            vec3d8 = vec3d6;
        if(vec3d7 != null && (vec3d8 == null || vec3d.a(vec3d7) < vec3d.a(vec3d8)))
            vec3d8 = vec3d7;
        if(vec3d8 == null)
            return null;
        byte byte0 = -1;
        if(vec3d8 == vec3d2)
            byte0 = 4;
        if(vec3d8 == vec3d3)
            byte0 = 5;
        if(vec3d8 == vec3d4)
            byte0 = 0;
        if(vec3d8 == vec3d5)
            byte0 = 1;
        if(vec3d8 == vec3d6)
            byte0 = 2;
        if(vec3d8 == vec3d7)
            byte0 = 3;
        return new MovingObjectPosition(i1, j1, k1, byte0, vec3d8.add(i1, j1, k1));
    }

    private boolean a(Vec3D vec3d)
    {
        if(vec3d == null)
            return false;
        else
            return vec3d.b >= minY && vec3d.b <= maxY && vec3d.c >= minZ && vec3d.c <= maxZ;
    }

    private boolean b(Vec3D vec3d)
    {
        if(vec3d == null)
            return false;
        else
            return vec3d.a >= minX && vec3d.a <= maxX && vec3d.c >= minZ && vec3d.c <= maxZ;
    }

    private boolean c(Vec3D vec3d)
    {
        if(vec3d == null)
            return false;
        else
            return vec3d.a >= minX && vec3d.a <= maxX && vec3d.b >= minY && vec3d.b <= maxY;
    }

    public void c(World world, int i1, int j1, int k1)
    {
    }

    public boolean canPlace(World world, int i1, int j1, int k1)
    {
        int l1 = world.getTypeId(i1, j1, k1);
        return l1 == 0 || byId[l1].material.isReplacable();
    }

    public boolean interact(World world, int i1, int j1, int k1, EntityHuman entityhuman)
    {
        return false;
    }

    public void b(World world, int i1, int j1, int k1, Entity entity)
    {
    }

    public void postPlace(World world, int i1, int j1, int k1, int l1)
    {
    }

    public void b(World world, int i1, int j1, int k1, EntityHuman entityhuman)
    {
    }

    public void a(World world, int i1, int j1, int k1, Entity entity, Vec3D vec3d)
    {
    }

    public void a(IBlockAccess iblockaccess, int i1, int j1, int k1)
    {
    }

    public boolean b(IBlockAccess iblockaccess, int i1, int j1, int k1, int l1)
    {
        return false;
    }

    public boolean isPowerSource()
    {
        return false;
    }

    public void a(World world, int i1, int j1, int k1, Entity entity)
    {
    }

    public boolean c(World world, int i1, int j1, int k1, int l1)
    {
        return false;
    }

    public void a(World world, EntityHuman entityhuman, int i1, int j1, int k1, int l1)
    {
        entityhuman.a(StatisticList.C[id], 1);
        a_(world, i1, j1, k1, l1);
    }

    public boolean f(World world, int i1, int j1, int k1)
    {
        return true;
    }

    public void postPlace(World world, int i1, int j1, int k1, EntityLiving entityliving)
    {
    }

    public Block a(String s1)
    {
        name = (new StringBuilder()).append("tile.").append(s1).toString();
        return this;
    }

    public String e()
    {
        return StatisticCollector.a((new StringBuilder()).append(f()).append(".name").toString());
    }

    public String f()
    {
        return name;
    }

    public void a(World world, int i1, int j1, int k1, int l1, int i2)
    {
    }

    public boolean g()
    {
        return bp;
    }

    protected Block h()
    {
        bp = false;
        return this;
    }

    public static final StepSound d;
    public static final StepSound e;
    public static final StepSound f;
    public static final StepSound g;
    public static final StepSound h;
    public static final StepSound i;
    public static final StepSound j;
    public static final StepSound k;
    public static final StepSound l;
    public static final Block byId[];
    public static final boolean n[] = new boolean[256];
    public static final boolean o[] = new boolean[256];
    public static final boolean isTileEntity[] = new boolean[256];
    public static final int q[] = new int[256];
    public static final boolean r[];
    public static final int s[] = new int[256];
    public static final Block STONE;
    public static final BlockGrass GRASS;
    public static final Block DIRT;
    public static final Block COBBLESTONE;
    public static final Block WOOD;
    public static final Block SAPLING;
    public static final Block BEDROCK;
    public static final Block WATER;
    public static final Block STATIONARY_WATER;
    public static final Block LAVA;
    public static final Block STATIONARY_LAVA;
    public static final Block SAND;
    public static final Block GRAVEL;
    public static final Block GOLD_ORE;
    public static final Block IRON_ORE;
    public static final Block COAL_ORE;
    public static final Block LOG;
    public static final BlockLeaves LEAVES;
    public static final Block SPONGE;
    public static final Block GLASS;
    public static final Block LAPIS_ORE;
    public static final Block LAPIS_BLOCK;
    public static final Block DISPENSER;
    public static final Block SANDSTONE;
    public static final Block NOTE_BLOCK = (new BlockNote(25)).c(0.8F).a("musicBlock");
    public static final Block BED = (new BlockBed(26)).c(0.2F).a("bed").h();
    public static final Block GOLDEN_RAIL;
    public static final Block DETECTOR_RAIL;
    public static final Block V = null;
    public static final Block WEB = new BlockWeb(30, 11);
    public static final Block X = null;
    public static final Block Y = null;
    public static final Block Z = null;
    public static final Block aa = null;
    public static final Block WOOL;
    public static final Block ac = null;
    public static final BlockFlower YELLOW_FLOWER;
    public static final BlockFlower RED_ROSE;
    public static final BlockFlower BROWN_MUSHROOM;
    public static final BlockFlower RED_MUSHROOM;
    public static final Block GOLD_BLOCK;
    public static final Block IRON_BLOCK;
    public static final Block DOUBLE_STEP;
    public static final Block STEP;
    public static final Block BRICK;
    public static final Block TNT;
    public static final Block BOOKSHELF;
    public static final Block MOSSY_COBBLESTONE;
    public static final Block OBSIDIAN;
    public static final Block TORCH;
    public static final BlockFire FIRE;
    public static final Block MOB_SPAWNER;
    public static final Block WOOD_STAIRS;
    public static final Block CHEST;
    public static final Block REDSTONE_WIRE;
    public static final Block DIAMOND_ORE;
    public static final Block DIAMOND_BLOCK;
    public static final Block WORKBENCH;
    public static final Block CROPS;
    public static final Block SOIL;
    public static final Block FURNACE;
    public static final Block BURNING_FURNACE;
    public static final Block SIGN_POST;
    public static final Block WOODEN_DOOR;
    public static final Block LADDER;
    public static final Block RAILS;
    public static final Block COBBLESTONE_STAIRS;
    public static final Block WALL_SIGN;
    public static final Block LEVER;
    public static final Block STONE_PLATE;
    public static final Block IRON_DOOR_BLOCK;
    public static final Block WOOD_PLATE;
    public static final Block REDSTONE_ORE;
    public static final Block GLOWING_REDSTONE_ORE;
    public static final Block REDSTONE_TORCH_OFF;
    public static final Block REDSTONE_TORCH_ON;
    public static final Block STONE_BUTTON;
    public static final Block SNOW;
    public static final Block ICE;
    public static final Block SNOW_BLOCK;
    public static final Block CACTUS;
    public static final Block CLAY;
    public static final Block SUGAR_CANE_BLOCK;
    public static final Block JUKEBOX;
    public static final Block FENCE;
    public static final Block PUMPKIN;
    public static final Block NETHERRACK;
    public static final Block SOUL_SAND;
    public static final Block GLOWSTONE;
    public static final BlockPortal PORTAL;
    public static final Block JACK_O_LANTERN;
    public static final Block CAKE_BLOCK;
    public static final Block DIODE_OFF;
    public static final Block DIODE_ON;
    public static final Block LOCKED_CHEST;
    public int textureId;
    public final int id;
    protected float strength;
    protected float durability;
    protected boolean bo;
    protected boolean bp;
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;
    public StepSound stepSound;
    public float bx;
    public final Material material;
    public float frictionFactor;
    private String name;

    static 
    {
        d = new StepSound("stone", 1.0F, 1.0F);
        e = new StepSound("wood", 1.0F, 1.0F);
        f = new StepSound("gravel", 1.0F, 1.0F);
        g = new StepSound("grass", 1.0F, 1.0F);
        h = new StepSound("stone", 1.0F, 1.0F);
        i = new StepSound("stone", 1.0F, 1.5F);
        j = new StepSoundStone("stone", 1.0F, 1.0F);
        k = new StepSound("cloth", 1.0F, 1.0F);
        l = new StepSoundSand("sand", 1.0F, 1.0F);
        byId = new Block[256];
        r = new boolean[256];
        STONE = (new BlockStone(1, 1)).c(1.5F).b(10F).a(h).a("stone");
        GRASS = (BlockGrass)(new BlockGrass(2)).c(0.6F).a(g).a("grass");
        DIRT = (new BlockDirt(3, 2)).c(0.5F).a(f).a("dirt");
        COBBLESTONE = (new Block(4, 16, Material.STONE)).c(2.0F).b(10F).a(h).a("stonebrick");
        WOOD = (new Block(5, 4, Material.WOOD)).c(2.0F).b(5F).a(e).a("wood");
        SAPLING = (new BlockSapling(6, 15)).c(0.0F).a(g).a("sapling");
        BEDROCK = (new Block(7, 17, Material.STONE)).c(-1F).b(6000000F).a(h).a("bedrock").h();
        WATER = (new BlockFlowing(8, Material.WATER)).c(100F).f(3).a("water").h();
        STATIONARY_WATER = (new BlockStationary(9, Material.WATER)).c(100F).f(3).a("water").h();
        LAVA = (new BlockFlowing(10, Material.LAVA)).c(0.0F).a(1.0F).f(255).a("lava").h();
        STATIONARY_LAVA = (new BlockStationary(11, Material.LAVA)).c(100F).a(1.0F).f(255).a("lava").h();
        SAND = (new BlockSand(12, 18)).c(0.5F).a(l).a("sand");
        GRAVEL = (new BlockGravel(13, 19)).c(0.6F).a(f).a("gravel");
        GOLD_ORE = (new BlockOre(14, 32)).c(3F).b(5F).a(h).a("oreGold");
        IRON_ORE = (new BlockOre(15, 33)).c(3F).b(5F).a(h).a("oreIron");
        COAL_ORE = (new BlockOre(16, 34)).c(3F).b(5F).a(h).a("oreCoal");
        LOG = (new BlockLog(17)).c(2.0F).a(e).a("log");
        LEAVES = (BlockLeaves)(new BlockLeaves(18, 52)).c(0.2F).f(1).a(g).a("leaves").h();
        SPONGE = (new BlockSponge(19)).c(0.6F).a(g).a("sponge");
        GLASS = (new BlockGlass(20, 49, Material.SHATTERABLE, false)).c(0.3F).a(j).a("glass");
        LAPIS_ORE = (new BlockOre(21, 160)).c(3F).b(5F).a(h).a("oreLapis");
        LAPIS_BLOCK = (new Block(22, 144, Material.STONE)).c(3F).b(5F).a(h).a("blockLapis");
        DISPENSER = (new BlockDispenser(23)).c(3.5F).a(h).a("dispenser");
        SANDSTONE = (new BlockSandStone(24)).a(h).c(0.8F).a("sandStone");
        GOLDEN_RAIL = (new BlockMinecartTrack(27, 179, true)).c(0.7F).a(i).a("goldenRail");
        DETECTOR_RAIL = (new BlockMinecartDetector(28, 195)).c(0.7F).a(i).a("detectorRail");
        WOOL = (new BlockCloth()).c(0.8F).a(k).a("cloth");
        YELLOW_FLOWER = (BlockFlower)(new BlockFlower(37, 13)).c(0.0F).a(g).a("flower");
        RED_ROSE = (BlockFlower)(new BlockFlower(38, 12)).c(0.0F).a(g).a("rose");
        BROWN_MUSHROOM = (BlockFlower)(new BlockMushroom(39, 29)).c(0.0F).a(g).a(0.125F).a("mushroom");
        RED_MUSHROOM = (BlockFlower)(new BlockMushroom(40, 28)).c(0.0F).a(g).a("mushroom");
        GOLD_BLOCK = (new BlockOreBlock(41, 23)).c(3F).b(10F).a(i).a("blockGold");
        IRON_BLOCK = (new BlockOreBlock(42, 22)).c(5F).b(10F).a(i).a("blockIron");
        DOUBLE_STEP = (new BlockStep(43, true)).c(2.0F).b(10F).a(h).a("stoneSlab");
        STEP = (new BlockStep(44, false)).c(2.0F).b(10F).a(h).a("stoneSlab");
        BRICK = (new Block(45, 7, Material.STONE)).c(2.0F).b(10F).a(h).a("brick");
        TNT = (new BlockTNT(46, 8)).c(0.0F).a(g).a("tnt");
        BOOKSHELF = (new BlockBookshelf(47, 35)).c(1.5F).a(e).a("bookshelf");
        MOSSY_COBBLESTONE = (new Block(48, 36, Material.STONE)).c(2.0F).b(10F).a(h).a("stoneMoss");
        OBSIDIAN = (new BlockObsidian(49, 37)).c(10F).b(2000F).a(h).a("obsidian");
        TORCH = (new BlockTorch(50, 80)).c(0.0F).a(0.9375F).a(e).a("torch");
        FIRE = (BlockFire)(new BlockFire(51, 31)).c(0.0F).a(1.0F).a(e).a("fire").h();
        MOB_SPAWNER = (new BlockMobSpawner(52, 65)).c(5F).a(i).a("mobSpawner").h();
        WOOD_STAIRS = (new BlockStairs(53, WOOD)).a("stairsWood");
        CHEST = (new BlockChest(54)).c(2.5F).a(e).a("chest");
        REDSTONE_WIRE = (new BlockRedstoneWire(55, 164)).c(0.0F).a(d).a("redstoneDust").h();
        DIAMOND_ORE = (new BlockOre(56, 50)).c(3F).b(5F).a(h).a("oreDiamond");
        DIAMOND_BLOCK = (new BlockOreBlock(57, 24)).c(5F).b(10F).a(i).a("blockDiamond");
        WORKBENCH = (new BlockWorkbench(58)).c(2.5F).a(e).a("workbench");
        CROPS = (new BlockCrops(59, 88)).c(0.0F).a(g).a("crops").h();
        SOIL = (new BlockSoil(60)).c(0.6F).a(f).a("farmland");
        FURNACE = (new BlockFurnace(61, false)).c(3.5F).a(h).a("furnace");
        BURNING_FURNACE = (new BlockFurnace(62, true)).c(3.5F).a(h).a(0.875F).a("furnace");
        SIGN_POST = (new BlockSign(63, net/minecraft/server/TileEntitySign, true)).c(1.0F).a(e).a("sign").h();
        WOODEN_DOOR = (new BlockDoor(64, Material.WOOD)).c(3F).a(e).a("doorWood").h();
        LADDER = (new BlockLadder(65, 83)).c(0.4F).a(e).a("ladder");
        RAILS = (new BlockMinecartTrack(66, 128, false)).c(0.7F).a(i).a("rail");
        COBBLESTONE_STAIRS = (new BlockStairs(67, COBBLESTONE)).a("stairsStone");
        WALL_SIGN = (new BlockSign(68, net/minecraft/server/TileEntitySign, false)).c(1.0F).a(e).a("sign").h();
        LEVER = (new BlockLever(69, 96)).c(0.5F).a(e).a("lever");
        STONE_PLATE = (new BlockPressurePlate(70, STONE.textureId, EnumMobType.MOBS)).c(0.5F).a(h).a("pressurePlate");
        IRON_DOOR_BLOCK = (new BlockDoor(71, Material.ORE)).c(5F).a(i).a("doorIron").h();
        WOOD_PLATE = (new BlockPressurePlate(72, WOOD.textureId, EnumMobType.EVERYTHING)).c(0.5F).a(e).a("pressurePlate");
        REDSTONE_ORE = (new BlockRedstoneOre(73, 51, false)).c(3F).b(5F).a(h).a("oreRedstone");
        GLOWING_REDSTONE_ORE = (new BlockRedstoneOre(74, 51, true)).a(0.625F).c(3F).b(5F).a(h).a("oreRedstone");
        REDSTONE_TORCH_OFF = (new BlockRedstoneTorch(75, 115, false)).c(0.0F).a(e).a("notGate");
        REDSTONE_TORCH_ON = (new BlockRedstoneTorch(76, 99, true)).c(0.0F).a(0.5F).a(e).a("notGate");
        STONE_BUTTON = (new BlockButton(77, STONE.textureId)).c(0.5F).a(h).a("button");
        SNOW = (new BlockSnow(78, 66)).c(0.1F).a(k).a("snow");
        ICE = (new BlockIce(79, 67)).c(0.5F).f(3).a(j).a("ice");
        SNOW_BLOCK = (new BlockSnowBlock(80, 66)).c(0.2F).a(k).a("snow");
        CACTUS = (new BlockCactus(81, 70)).c(0.4F).a(k).a("cactus");
        CLAY = (new BlockClay(82, 72)).c(0.6F).a(f).a("clay");
        SUGAR_CANE_BLOCK = (new BlockReed(83, 73)).c(0.0F).a(g).a("reeds").h();
        JUKEBOX = (new BlockJukeBox(84, 74)).c(2.0F).b(10F).a(h).a("jukebox");
        FENCE = (new BlockFence(85, 4)).c(2.0F).b(5F).a(e).a("fence");
        PUMPKIN = (new BlockPumpkin(86, 102, false)).c(1.0F).a(e).a("pumpkin");
        NETHERRACK = (new BlockBloodStone(87, 103)).c(0.4F).a(h).a("hellrock");
        SOUL_SAND = (new BlockSlowSand(88, 104)).c(0.5F).a(l).a("hellsand");
        GLOWSTONE = (new BlockLightStone(89, 105, Material.SHATTERABLE)).c(0.3F).a(j).a(1.0F).a("lightgem");
        PORTAL = (BlockPortal)(new BlockPortal(90, 14)).c(-1F).a(j).a(0.75F).a("portal");
        JACK_O_LANTERN = (new BlockPumpkin(91, 102, true)).c(1.0F).a(e).a(1.0F).a("litpumpkin");
        CAKE_BLOCK = (new BlockCake(92, 121)).c(0.5F).a(k).a("cake").h();
        DIODE_OFF = (new BlockDiode(93, false)).c(0.0F).a(e).a("diode").h();
        DIODE_ON = (new BlockDiode(94, true)).c(0.0F).a(0.625F).a(e).a("diode").h();
        LOCKED_CHEST = (new BlockLockedChest(95)).c(0.0F).a(1.0F).a(e).a("lockedchest").a(true);
        Item.byId[WOOL.id] = (new ItemCloth(WOOL.id - 256)).a("cloth");
        Item.byId[LOG.id] = (new ItemLog(LOG.id - 256)).a("log");
        Item.byId[STEP.id] = (new ItemStep(STEP.id - 256)).a("stoneSlab");
        Item.byId[SAPLING.id] = (new ItemSapling(SAPLING.id - 256)).a("sapling");
        for(int i1 = 0; i1 < 256; i1++)
            if(byId[i1] != null && Item.byId[i1] == null)
                Item.byId[i1] = new ItemBlock(i1 - 256);

        r[0] = true;
        StatisticList.b();
    }
}
