// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockFire.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.Server;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Block, WorldServer, Material, BlockLeaves, 
//            World, IBlockAccess, BlockPortal, AxisAlignedBB

public class BlockFire extends net.minecraft.server.Block
{

    protected BlockFire(int i, int j)
    {
        super(i, j, Material.FIRE);
        a = new int[256];
        b = new int[256];
        a(Block.WOOD.id, 5, 20);
        a(Block.LOG.id, 5, 5);
        a(Block.LEAVES.id, 30, 60);
        a(Block.BOOKSHELF.id, 30, 20);
        a(Block.TNT.id, 15, 100);
        a(Block.WOOL.id, 30, 60);
        a(true);
    }

    private void a(int i, int j, int k)
    {
        a[i] = j;
        b[i] = k;
    }

    public AxisAlignedBB d(World world, int i, int j, int l)
    {
        return null;
    }

    public boolean a()
    {
        return false;
    }

    public int a(Random random)
    {
        return 0;
    }

    public int b()
    {
        return 10;
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        boolean flag = world.getTypeId(i, j - 1, k) == Block.NETHERRACK.id;
        if(!flag && world.v() && (world.q(i, j, k) || world.q(i - 1, j, k) || world.q(i + 1, j, k) || world.q(i, j, k - 1) || world.q(i, j, k + 1)))
        {
            world.setTypeId(i, j, k, 0);
        } else
        {
            int l = world.getData(i, j, k);
            if(l < 15)
            {
                world.setData(i, j, k, l + 1);
                world.c(i, j, k, id, b());
            }
            if(!flag && !g(world, i, j, k))
            {
                if(!world.d(i, j - 1, k) || l > 3)
                    world.setTypeId(i, j, k, 0);
            } else
            if(!flag && !b(world, i, j - 1, k) && l == 15 && random.nextInt(4) == 0)
                world.setTypeId(i, j, k, 0);
            else
            if(l % 2 == 0 && l > 2)
            {
                a(world, i + 1, j, k, 300, random);
                a(world, i - 1, j, k, 300, random);
                a(world, i, j - 1, k, 250, random);
                a(world, i, j + 1, k, 250, random);
                a(world, i, j, k - 1, 300, random);
                a(world, i, j, k + 1, 300, random);
                Server server = ((WorldServer)world).getServer();
                CraftWorld cworld = ((WorldServer)world).getWorld();
                org.bukkit.event.block.BlockIgniteEvent.IgniteCause igniteCause = org.bukkit.event.block.BlockIgniteEvent.IgniteCause.SPREAD;
                org.bukkit.entity.Player thePlayer = null;
                for(int i1 = i - 1; i1 <= i + 1; i1++)
                {
                    for(int j1 = k - 1; j1 <= k + 1; j1++)
                    {
                        for(int k1 = j - 1; k1 <= j + 4; k1++)
                        {
                            if(i1 == i && k1 == j && j1 == k)
                                continue;
                            int l1 = 100;
                            if(k1 > j + 1)
                                l1 += (k1 - (j + 1)) * 100;
                            int i2 = h(world, i1, k1, j1);
                            if(i2 <= 0 || random.nextInt(l1) > i2 || world.v() && world.q(i1, k1, j1) || world.q(i1 - 1, k1, k) || world.q(i1 + 1, k1, j1) || world.q(i1, k1, j1 - 1) || world.q(i1, k1, j1 + 1))
                                continue;
                            Block theBlock = cworld.getBlockAt(i1, k1, j1);
                            if(theBlock.getTypeId() != Block.FIRE.id)
                            {
                                BlockIgniteEvent event = new BlockIgniteEvent(theBlock, igniteCause, thePlayer);
                                server.getPluginManager().callEvent(event);
                                if(event.isCancelled())
                                    continue;
                            }
                            world.setTypeId(i1, k1, j1, id);
                        }

                    }

                }

            }
            if(l == 15)
            {
                a(world, i + 1, j, k, 1, random);
                a(world, i - 1, j, k, 1, random);
                a(world, i, j - 1, k, 1, random);
                a(world, i, j + 1, k, 1, random);
                a(world, i, j, k - 1, 1, random);
                a(world, i, j, k + 1, 1, random);
            }
        }
    }

    private void a(World world, int i, int j, int k, int l, Random random)
    {
        int i1 = b[world.getTypeId(i, j, k)];
        if(random.nextInt(l) < i1)
        {
            boolean flag = world.getTypeId(i, j, k) == Block.TNT.id;
            Server server = ((WorldServer)world).getServer();
            CraftWorld cworld = ((WorldServer)world).getWorld();
            Block theBlock = cworld.getBlockAt(i, j, k);
            BlockBurnEvent event = new BlockBurnEvent(theBlock);
            server.getPluginManager().callEvent(event);
            if(event.isCancelled())
                return;
            if(random.nextInt(2) == 0 && !world.q(i, j, k))
                world.setTypeId(i, j, k, id);
            else
                world.setTypeId(i, j, k, 0);
            if(flag)
                Block.TNT.postBreak(world, i, j, k, 0);
        }
    }

    private boolean g(World world, int i, int j, int k)
    {
        return b(world, i + 1, j, k) ? true : b(world, i - 1, j, k) ? true : b(world, i, j - 1, k) ? true : b(world, i, j + 1, k) ? true : b(world, i, j, k - 1) ? true : b(world, i, j, k + 1);
    }

    private int h(World world, int i, int j, int k)
    {
        byte b0 = 0;
        if(!world.isEmpty(i, j, k))
        {
            return 0;
        } else
        {
            int l = f(world, i + 1, j, k, b0);
            l = f(world, i - 1, j, k, l);
            l = f(world, i, j - 1, k, l);
            l = f(world, i, j + 1, k, l);
            l = f(world, i, j, k - 1, l);
            l = f(world, i, j, k + 1, l);
            return l;
        }
    }

    public boolean n_()
    {
        return false;
    }

    public boolean b(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return a[iblockaccess.getTypeId(i, j, k)] > 0;
    }

    public int f(World world, int i, int j, int k, int l)
    {
        int i1 = a[world.getTypeId(i, j, k)];
        return i1 <= l ? l : i1;
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return world.d(i, j - 1, k) || g(world, i, j, k);
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if(!world.d(i, j - 1, k) && !g(world, i, j, k))
            world.setTypeId(i, j, k, 0);
    }

    public void e(World world, int i, int j, int k)
    {
        if(world.getTypeId(i, j - 1, k) != Block.OBSIDIAN.id || !Block.PORTAL.a_(world, i, j, k))
            if(!world.d(i, j - 1, k) && !g(world, i, j, k))
                world.setTypeId(i, j, k, 0);
            else
                world.c(i, j, k, id, b());
    }

    private int a[];
    private int b[];
}
