// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.PrintStream;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            RecipesTools, RecipesWeapons, RecipeIngots, RecipesFood, 
//            RecipesCrafting, RecipesArmor, RecipesDyes, ItemStack, 
//            Item, Block, RecipeSorter, ShapedRecipes, 
//            ShapelessRecipes, CraftingRecipe, InventoryCrafting

public class CraftingManager
{

    public static final CraftingManager a()
    {
        return a;
    }

    private CraftingManager()
    {
        b = new ArrayList();
        (new RecipesTools()).a(this);
        (new RecipesWeapons()).a(this);
        (new RecipeIngots()).a(this);
        (new RecipesFood()).a(this);
        (new RecipesCrafting()).a(this);
        (new RecipesArmor()).a(this);
        (new RecipesDyes()).a(this);
        a(new ItemStack(Item.PAPER, 3), new Object[] {
            "###", Character.valueOf('#'), Item.SUGAR_CANE
        });
        a(new ItemStack(Item.BOOK, 1), new Object[] {
            "#", "#", "#", Character.valueOf('#'), Item.PAPER
        });
        a(new ItemStack(Block.FENCE, 2), new Object[] {
            "###", "###", Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Block.JUKEBOX, 1), new Object[] {
            "###", "#X#", "###", Character.valueOf('#'), Block.WOOD, Character.valueOf('X'), Item.DIAMOND
        });
        a(new ItemStack(Block.NOTE_BLOCK, 1), new Object[] {
            "###", "#X#", "###", Character.valueOf('#'), Block.WOOD, Character.valueOf('X'), Item.REDSTONE
        });
        a(new ItemStack(Block.BOOKSHELF, 1), new Object[] {
            "###", "XXX", "###", Character.valueOf('#'), Block.WOOD, Character.valueOf('X'), Item.BOOK
        });
        a(new ItemStack(Block.SNOW_BLOCK, 1), new Object[] {
            "##", "##", Character.valueOf('#'), Item.SNOW_BALL
        });
        a(new ItemStack(Block.CLAY, 1), new Object[] {
            "##", "##", Character.valueOf('#'), Item.CLAY_BALL
        });
        a(new ItemStack(Block.BRICK, 1), new Object[] {
            "##", "##", Character.valueOf('#'), Item.CLAY_BRICK
        });
        a(new ItemStack(Block.GLOWSTONE, 1), new Object[] {
            "###", "###", "###", Character.valueOf('#'), Item.GLOWSTONE_DUST
        });
        a(new ItemStack(Block.WOOL, 1), new Object[] {
            "###", "###", "###", Character.valueOf('#'), Item.STRING
        });
        a(new ItemStack(Block.TNT, 1), new Object[] {
            "X#X", "#X#", "X#X", Character.valueOf('X'), Item.SULPHUR, Character.valueOf('#'), Block.SAND
        });
        a(new ItemStack(Block.STEP, 3, 3), new Object[] {
            "###", Character.valueOf('#'), Block.COBBLESTONE
        });
        a(new ItemStack(Block.STEP, 3, 0), new Object[] {
            "###", Character.valueOf('#'), Block.STONE
        });
        a(new ItemStack(Block.STEP, 3, 1), new Object[] {
            "###", Character.valueOf('#'), Block.SANDSTONE
        });
        a(new ItemStack(Block.STEP, 3, 2), new Object[] {
            "###", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Block.LADDER, 2), new Object[] {
            "# #", "###", "# #", Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Item.WOOD_DOOR, 1), new Object[] {
            "##", "##", "##", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Item.IRON_DOOR, 1), new Object[] {
            "##", "##", "##", Character.valueOf('#'), Item.IRON_INGOT
        });
        a(new ItemStack(Item.SIGN, 1), new Object[] {
            "###", "###", " X ", Character.valueOf('#'), Block.WOOD, Character.valueOf('X'), Item.STICK
        });
        a(new ItemStack(Item.CAKE, 1), new Object[] {
            "AAA", "BEB", "CCC", Character.valueOf('A'), Item.MILK_BUCKET, Character.valueOf('B'), Item.SUGAR, Character.valueOf('C'), Item.WHEAT, Character.valueOf('E'), 
            Item.EGG
        });
        a(new ItemStack(Item.SUGAR, 1), new Object[] {
            "#", Character.valueOf('#'), Item.SUGAR_CANE
        });
        a(new ItemStack(Block.WOOD, 4), new Object[] {
            "#", Character.valueOf('#'), Block.LOG
        });
        a(new ItemStack(Item.STICK, 4), new Object[] {
            "#", "#", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Block.TORCH, 4), new Object[] {
            "X", "#", Character.valueOf('X'), Item.COAL, Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Block.TORCH, 4), new Object[] {
            "X", "#", Character.valueOf('X'), new ItemStack(Item.COAL, 1, 1), Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Item.BOWL, 4), new Object[] {
            "# #", " # ", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Block.RAILS, 16), new Object[] {
            "X X", "X#X", "X X", Character.valueOf('X'), Item.IRON_INGOT, Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Block.GOLDEN_RAIL, 6), new Object[] {
            "X X", "X#X", "XRX", Character.valueOf('X'), Item.GOLD_INGOT, Character.valueOf('R'), Item.REDSTONE, Character.valueOf('#'), Item.STICK
        });
        a(new ItemStack(Block.DETECTOR_RAIL, 6), new Object[] {
            "X X", "X#X", "XRX", Character.valueOf('X'), Item.IRON_INGOT, Character.valueOf('R'), Item.REDSTONE, Character.valueOf('#'), Block.STONE_PLATE
        });
        a(new ItemStack(Item.MINECART, 1), new Object[] {
            "# #", "###", Character.valueOf('#'), Item.IRON_INGOT
        });
        a(new ItemStack(Block.JACK_O_LANTERN, 1), new Object[] {
            "A", "B", Character.valueOf('A'), Block.PUMPKIN, Character.valueOf('B'), Block.TORCH
        });
        a(new ItemStack(Item.STORAGE_MINECART, 1), new Object[] {
            "A", "B", Character.valueOf('A'), Block.CHEST, Character.valueOf('B'), Item.MINECART
        });
        a(new ItemStack(Item.POWERED_MINECART, 1), new Object[] {
            "A", "B", Character.valueOf('A'), Block.FURNACE, Character.valueOf('B'), Item.MINECART
        });
        a(new ItemStack(Item.BOAT, 1), new Object[] {
            "# #", "###", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Item.BUCKET, 1), new Object[] {
            "# #", " # ", Character.valueOf('#'), Item.IRON_INGOT
        });
        a(new ItemStack(Item.FLINT_AND_STEEL, 1), new Object[] {
            "A ", " B", Character.valueOf('A'), Item.IRON_INGOT, Character.valueOf('B'), Item.FLINT
        });
        a(new ItemStack(Item.BREAD, 1), new Object[] {
            "###", Character.valueOf('#'), Item.WHEAT
        });
        a(new ItemStack(Block.WOOD_STAIRS, 4), new Object[] {
            "#  ", "## ", "###", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Item.FISHING_ROD, 1), new Object[] {
            "  #", " #X", "# X", Character.valueOf('#'), Item.STICK, Character.valueOf('X'), Item.STRING
        });
        a(new ItemStack(Block.COBBLESTONE_STAIRS, 4), new Object[] {
            "#  ", "## ", "###", Character.valueOf('#'), Block.COBBLESTONE
        });
        a(new ItemStack(Item.PAINTING, 1), new Object[] {
            "###", "#X#", "###", Character.valueOf('#'), Item.STICK, Character.valueOf('X'), Block.WOOL
        });
        a(new ItemStack(Item.GOLDEN_APPLE, 1), new Object[] {
            "###", "#X#", "###", Character.valueOf('#'), Block.GOLD_BLOCK, Character.valueOf('X'), Item.APPLE
        });
        a(new ItemStack(Block.LEVER, 1), new Object[] {
            "X", "#", Character.valueOf('#'), Block.COBBLESTONE, Character.valueOf('X'), Item.STICK
        });
        a(new ItemStack(Block.REDSTONE_TORCH_ON, 1), new Object[] {
            "X", "#", Character.valueOf('#'), Item.STICK, Character.valueOf('X'), Item.REDSTONE
        });
        a(new ItemStack(Item.DIODE, 1), new Object[] {
            "#X#", "III", Character.valueOf('#'), Block.REDSTONE_TORCH_ON, Character.valueOf('X'), Item.REDSTONE, Character.valueOf('I'), Block.STONE
        });
        a(new ItemStack(Item.WATCH, 1), new Object[] {
            " # ", "#X#", " # ", Character.valueOf('#'), Item.GOLD_INGOT, Character.valueOf('X'), Item.REDSTONE
        });
        a(new ItemStack(Item.COMPASS, 1), new Object[] {
            " # ", "#X#", " # ", Character.valueOf('#'), Item.IRON_INGOT, Character.valueOf('X'), Item.REDSTONE
        });
        a(new ItemStack(Block.STONE_BUTTON, 1), new Object[] {
            "#", "#", Character.valueOf('#'), Block.STONE
        });
        a(new ItemStack(Block.STONE_PLATE, 1), new Object[] {
            "##", Character.valueOf('#'), Block.STONE
        });
        a(new ItemStack(Block.WOOD_PLATE, 1), new Object[] {
            "##", Character.valueOf('#'), Block.WOOD
        });
        a(new ItemStack(Block.DISPENSER, 1), new Object[] {
            "###", "#X#", "#R#", Character.valueOf('#'), Block.COBBLESTONE, Character.valueOf('X'), Item.BOW, Character.valueOf('R'), Item.REDSTONE
        });
        a(new ItemStack(Item.BED, 1), new Object[] {
            "###", "XXX", Character.valueOf('#'), Block.WOOL, Character.valueOf('X'), Block.WOOD
        });
        Collections.sort(b, new RecipeSorter(this));
        System.out.println((new StringBuilder()).append(b.size()).append(" recipes").toString());
    }

    transient void a(ItemStack itemstack, Object aobj[])
    {
        String s = "";
        int i = 0;
        int j = 0;
        int k = 0;
        if(aobj[i] instanceof String[])
        {
            String as[] = (String[])(String[])aobj[i++];
            for(int l = 0; l < as.length; l++)
            {
                String s2 = as[l];
                k++;
                j = s2.length();
                s = (new StringBuilder()).append(s).append(s2).toString();
            }

        } else
        {
            while(aobj[i] instanceof String) 
            {
                String s1 = (String)aobj[i++];
                k++;
                j = s1.length();
                s = (new StringBuilder()).append(s).append(s1).toString();
            }
        }
        HashMap hashmap = new HashMap();
        for(; i < aobj.length; i += 2)
        {
            Character character = (Character)aobj[i];
            ItemStack itemstack1 = null;
            if(aobj[i + 1] instanceof Item)
                itemstack1 = new ItemStack((Item)aobj[i + 1]);
            else
            if(aobj[i + 1] instanceof Block)
                itemstack1 = new ItemStack((Block)aobj[i + 1], 1, -1);
            else
            if(aobj[i + 1] instanceof ItemStack)
                itemstack1 = (ItemStack)aobj[i + 1];
            hashmap.put(character, itemstack1);
        }

        ItemStack aitemstack[] = new ItemStack[j * k];
        for(int i1 = 0; i1 < j * k; i1++)
        {
            char c = s.charAt(i1);
            if(hashmap.containsKey(Character.valueOf(c)))
                aitemstack[i1] = ((ItemStack)hashmap.get(Character.valueOf(c))).j();
            else
                aitemstack[i1] = null;
        }

        b.add(new ShapedRecipes(j, k, aitemstack, itemstack));
    }

    transient void b(ItemStack itemstack, Object aobj[])
    {
        ArrayList arraylist = new ArrayList();
        Object aobj1[] = aobj;
        int i = aobj1.length;
        for(int j = 0; j < i; j++)
        {
            Object obj = aobj1[j];
            if(obj instanceof ItemStack)
            {
                arraylist.add(((ItemStack)obj).j());
                continue;
            }
            if(obj instanceof Item)
            {
                arraylist.add(new ItemStack((Item)obj));
                continue;
            }
            if(obj instanceof Block)
                arraylist.add(new ItemStack((Block)obj));
            else
                throw new RuntimeException("Invalid shapeless recipy!");
        }

        b.add(new ShapelessRecipes(itemstack, arraylist));
    }

    public ItemStack a(InventoryCrafting inventorycrafting)
    {
        for(int i = 0; i < b.size(); i++)
        {
            CraftingRecipe craftingrecipe = (CraftingRecipe)b.get(i);
            if(craftingrecipe.a(inventorycrafting))
                return craftingrecipe.b(inventorycrafting);
        }

        return null;
    }

    public List b()
    {
        return b;
    }

    private static final CraftingManager a = new CraftingManager();
    private List b;

}
