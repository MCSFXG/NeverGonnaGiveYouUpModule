// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityTracker.java

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            EntityList, EntityPlayer, EntityTrackerEntry, EntityFish, 
//            EntityArrow, EntitySnowball, EntityEgg, EntityItem, 
//            EntityMinecart, EntityBoat, EntitySquid, IAnimal, 
//            EntityTNTPrimed, EntityFallingSand, EntityPainting, MinecraftServer, 
//            ServerConfigurationManager, Entity, World, Packet

public class EntityTracker
{

    public EntityTracker(MinecraftServer minecraftserver)
    {
        a = new HashSet();
        b = new EntityList();
        c = minecraftserver;
        d = minecraftserver.serverConfigurationManager.a();
    }

    public synchronized void a(Entity entity)
    {
        if(entity instanceof EntityPlayer)
        {
            a(entity, 512, 2);
            EntityPlayer entityplayer = (EntityPlayer)entity;
            Iterator iterator = a.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)iterator.next();
                if(entitytrackerentry.tracker != entityplayer)
                    entitytrackerentry.b(entityplayer);
            } while(true);
        } else
        if(entity instanceof EntityFish)
            a(entity, 64, 5, true);
        else
        if(entity instanceof EntityArrow)
            a(entity, 64, 5, true);
        else
        if(entity instanceof EntitySnowball)
            a(entity, 64, 5, true);
        else
        if(entity instanceof EntityEgg)
            a(entity, 64, 5, true);
        else
        if(entity instanceof EntityItem)
            a(entity, 64, 20, true);
        else
        if(entity instanceof EntityMinecart)
            a(entity, 160, 5, true);
        else
        if(entity instanceof EntityBoat)
            a(entity, 160, 5, true);
        else
        if(entity instanceof EntitySquid)
            a(entity, 160, 3, true);
        else
        if(entity instanceof IAnimal)
            a(entity, 160, 3);
        else
        if(entity instanceof EntityTNTPrimed)
            a(entity, 160, 10, true);
        else
        if(entity instanceof EntityFallingSand)
            a(entity, 160, 20, true);
        else
        if(entity instanceof EntityPainting)
            a(entity, 160, 0x7fffffff, false);
    }

    public void a(Entity entity, int i, int j)
    {
        a(entity, i, j, false);
    }

    public synchronized void a(Entity entity, int i, int j, boolean flag)
    {
        if(i > d)
            i = d;
        if(b.b(entity.id))
        {
            throw new IllegalStateException("Entity is already tracked!");
        } else
        {
            EntityTrackerEntry entitytrackerentry = new EntityTrackerEntry(entity, i, j, flag);
            a.add(entitytrackerentry);
            b.a(entity.id, entitytrackerentry);
            entitytrackerentry.scanPlayers(entity.world.players);
            return;
        }
    }

    public synchronized void untrackEntity(Entity entity)
    {
        if(entity instanceof EntityPlayer)
        {
            EntityPlayer entityplayer = (EntityPlayer)entity;
            EntityTrackerEntry entitytrackerentry;
            for(Iterator iterator = a.iterator(); iterator.hasNext(); entitytrackerentry.a(entityplayer))
                entitytrackerentry = (EntityTrackerEntry)iterator.next();

        }
        EntityTrackerEntry entitytrackerentry1 = (EntityTrackerEntry)b.d(entity.id);
        if(entitytrackerentry1 != null)
        {
            a.remove(entitytrackerentry1);
            entitytrackerentry1.a();
        }
    }

    public synchronized void a()
    {
        ArrayList arraylist = new ArrayList();
        Iterator iterator = a.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)iterator.next();
            entitytrackerentry.track(entitytrackerentry.tracker.world.players);
            if(entitytrackerentry.m && (entitytrackerentry.tracker instanceof EntityPlayer))
                arraylist.add((EntityPlayer)entitytrackerentry.tracker);
        } while(true);
label0:
        for(int i = 0; i < arraylist.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)arraylist.get(i);
            Iterator iterator1 = a.iterator();
            do
            {
                if(!iterator1.hasNext())
                    continue label0;
                EntityTrackerEntry entitytrackerentry1 = (EntityTrackerEntry)iterator1.next();
                if(entitytrackerentry1.tracker != entityplayer)
                    entitytrackerentry1.b(entityplayer);
            } while(true);
        }

    }

    public synchronized void a(Entity entity, Packet packet)
    {
        EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)b.a(entity.id);
        if(entitytrackerentry != null)
            entitytrackerentry.a(packet);
    }

    public synchronized void b(Entity entity, Packet packet)
    {
        EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)b.a(entity.id);
        if(entitytrackerentry != null)
            entitytrackerentry.b(packet);
    }

    public synchronized void trackPlayer(EntityPlayer entityplayer)
    {
        EntityTrackerEntry entitytrackerentry;
        for(Iterator iterator = a.iterator(); iterator.hasNext(); entitytrackerentry.c(entityplayer))
            entitytrackerentry = (EntityTrackerEntry)iterator.next();

    }

    private Set a;
    private EntityList b;
    private MinecraftServer c;
    private int d;
}
