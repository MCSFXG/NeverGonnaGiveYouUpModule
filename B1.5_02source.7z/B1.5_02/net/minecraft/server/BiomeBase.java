// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Block, BlockGrass, BiomeMeta, EntitySpider, 
//            EntityZombie, EntitySkeleton, EntityCreeper, EntitySlime, 
//            EntitySheep, EntityPig, EntityChicken, EntityCow, 
//            EntitySquid, WorldGenBigTree, WorldGenTrees, EnumCreatureType, 
//            BiomeRainforest, BiomeSwamp, BiomeForest, BiomeDesert, 
//            BiomeTaiga, BiomeHell, WorldGenerator

public class BiomeBase
{

    protected BiomeBase()
    {
        o = (byte)Block.GRASS.id;
        p = (byte)Block.DIRT.id;
        q = 0x4ee031;
        r = new ArrayList();
        s = new ArrayList();
        t = new ArrayList();
        v = true;
        r.add(new BiomeMeta(net/minecraft/server/EntitySpider, 10));
        r.add(new BiomeMeta(net/minecraft/server/EntityZombie, 10));
        r.add(new BiomeMeta(net/minecraft/server/EntitySkeleton, 10));
        r.add(new BiomeMeta(net/minecraft/server/EntityCreeper, 10));
        r.add(new BiomeMeta(net/minecraft/server/EntitySlime, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntitySheep, 12));
        s.add(new BiomeMeta(net/minecraft/server/EntityPig, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntityChicken, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntityCow, 8));
        t.add(new BiomeMeta(net/minecraft/server/EntitySquid, 10));
    }

    private BiomeBase e()
    {
        v = false;
        return this;
    }

    public static void a()
    {
        for(int i = 0; i < 64; i++)
        {
            for(int j = 0; j < 64; j++)
                w[i + j * 64] = a((float)i / 63F, (float)j / 63F);

        }

        DESERT.o = DESERT.p = (byte)Block.SAND.id;
        ICE_DESERT.o = ICE_DESERT.p = (byte)Block.SAND.id;
    }

    public WorldGenerator a(Random random)
    {
        if(random.nextInt(10) == 0)
            return new WorldGenBigTree();
        else
            return new WorldGenTrees();
    }

    protected BiomeBase b()
    {
        u = true;
        return this;
    }

    protected BiomeBase a(String s1)
    {
        m = s1;
        return this;
    }

    protected BiomeBase a(int i)
    {
        q = i;
        return this;
    }

    protected BiomeBase b(int i)
    {
        n = i;
        return this;
    }

    public static BiomeBase a(double d1, double d2)
    {
        int i = (int)(d1 * 63D);
        int j = (int)(d2 * 63D);
        return w[i + j * 64];
    }

    public static BiomeBase a(float f, float f1)
    {
        f1 *= f;
        if(f < 0.1F)
            return TUNDRA;
        if(f1 < 0.2F)
        {
            if(f < 0.5F)
                return TUNDRA;
            if(f < 0.95F)
                return SAVANNA;
            else
                return DESERT;
        }
        if(f1 > 0.5F && f < 0.7F)
            return SWAMPLAND;
        if(f < 0.5F)
            return TAIGA;
        if(f < 0.97F)
            if(f1 < 0.35F)
                return SHRUBLAND;
            else
                return FOREST;
        if(f1 < 0.45F)
            return PLAINS;
        if(f1 < 0.9F)
            return SEASONAL_FOREST;
        else
            return RAINFOREST;
    }

    public List a(EnumCreatureType enumcreaturetype)
    {
        if(enumcreaturetype == EnumCreatureType.MONSTER)
            return r;
        if(enumcreaturetype == EnumCreatureType.CREATURE)
            return s;
        if(enumcreaturetype == EnumCreatureType.WATER_CREATURE)
            return t;
        else
            return null;
    }

    public boolean c()
    {
        return u;
    }

    public boolean d()
    {
        if(u)
            return false;
        else
            return v;
    }

    public static final BiomeBase RAINFOREST = (new BiomeRainforest()).b(0x8fa36).a("Rainforest").a(0x1ff458);
    public static final BiomeBase SWAMPLAND = (new BiomeSwamp()).b(0x7f9b2).a("Swampland").a(0x8baf48);
    public static final BiomeBase SEASONAL_FOREST = (new BiomeBase()).b(0x9be023).a("Seasonal Forest");
    public static final BiomeBase FOREST = (new BiomeForest()).b(0x56621).a("Forest").a(0x4eba31);
    public static final BiomeBase SAVANNA = (new BiomeDesert()).b(0xd9e023).a("Savanna");
    public static final BiomeBase SHRUBLAND = (new BiomeBase()).b(0xa1ad20).a("Shrubland");
    public static final BiomeBase TAIGA = (new BiomeTaiga()).b(0x2eb153).a("Taiga").b().a(0x7bb731);
    public static final BiomeBase DESERT = (new BiomeDesert()).b(0xfa9418).a("Desert").e();
    public static final BiomeBase PLAINS = (new BiomeDesert()).b(0xffd910).a("Plains");
    public static final BiomeBase ICE_DESERT = (new BiomeDesert()).b(0xffed93).a("Ice Desert").b().e().a(0xc4d339);
    public static final BiomeBase TUNDRA = (new BiomeBase()).b(0x57ebf9).a("Tundra").b().a(0xc4d339);
    public static final BiomeBase HELL = (new BiomeHell()).b(0xff0000).a("Hell").e();
    public String m;
    public int n;
    public byte o;
    public byte p;
    public int q;
    protected List r;
    protected List s;
    protected List t;
    private boolean u;
    private boolean v;
    private static BiomeBase w[] = new BiomeBase[4096];

    static 
    {
        a();
    }
}
