// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, DataWatcher, NBTTagCompound, World, 
//            EntityHuman, EntitySheep, AxisAlignedBB, Entity, 
//            InventoryPlayer, ItemStack, Item, ItemFood, 
//            MathHelper, EntityArrow, EntityLiving

public class EntityWolf extends EntityAnimal
{

    public EntityWolf(World world)
    {
        super(world);
        a = false;
        texture = "/mob/wolf.png";
        b(0.8F, 0.8F);
        aA = 1.1F;
        health = 8;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
        datawatcher.a(17, "");
        datawatcher.a(18, new Integer(health));
    }

    protected boolean n()
    {
        return false;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Angry", isAngry());
        nbttagcompound.a("Sitting", isSitting());
        if(x() == null)
            nbttagcompound.setString("Owner", "");
        else
            nbttagcompound.setString("Owner", x());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setAngry(nbttagcompound.m("Angry"));
        setSitting(nbttagcompound.m("Sitting"));
        String s1 = nbttagcompound.getString("Owner");
        if(s1.length() > 0)
        {
            a(s1);
            d(true);
        }
    }

    protected boolean l_()
    {
        return !m_();
    }

    protected String g()
    {
        if(isAngry())
            return "mob.wolf.growl";
        if(random.nextInt(3) == 0)
        {
            if(m_() && datawatcher.b(18) < 10)
                return "mob.wolf.whine";
            else
                return "mob.wolf.panting";
        } else
        {
            return "mob.wolf.bark";
        }
    }

    protected String h()
    {
        return "mob.wolf.hurt";
    }

    protected String i()
    {
        return "mob.wolf.death";
    }

    protected float k()
    {
        return 0.4F;
    }

    protected int j()
    {
        return -1;
    }

    protected void c_()
    {
        super.c_();
        if(!e && !C() && m_() && vehicle == null)
        {
            EntityHuman entityhuman = world.a(x());
            if(entityhuman != null)
            {
                float f1 = entityhuman.f(this);
                if(f1 > 5F)
                    b(entityhuman, f1);
            } else
            if(!Z())
                setSitting(true);
        } else
        if(target == null && !C() && !m_() && world.random.nextInt(100) == 0)
        {
            List list = world.a(net/minecraft/server/EntitySheep, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).b(16D, 4D, 16D));
            if(!list.isEmpty())
                c((Entity)list.get(world.random.nextInt(list.size())));
        }
        if(Z())
            setSitting(false);
        if(!world.isStatic)
            datawatcher.b(18, Integer.valueOf(health));
    }

    public void u()
    {
        super.u();
        a = false;
        if(R() && !C() && !isAngry())
        {
            Entity entity = S();
            if(entity instanceof EntityHuman)
            {
                EntityHuman entityhuman = (EntityHuman)entity;
                ItemStack itemstack = entityhuman.inventory.getItemInHand();
                if(itemstack != null)
                    if(!m_() && itemstack.id == Item.BONE.id)
                        a = true;
                    else
                    if(m_() && (Item.byId[itemstack.id] instanceof ItemFood))
                        a = ((ItemFood)Item.byId[itemstack.id]).k();
            }
        }
        if(!U && f && !g && !C() && onGround)
        {
            g = true;
            h = 0.0F;
            i = 0.0F;
            world.a(this, (byte)8);
        }
    }

    public void p_()
    {
        super.p_();
        c = b;
        if(a)
            b = b + (1.0F - b) * 0.4F;
        else
            b = b + (0.0F - b) * 0.4F;
        if(a)
            aB = 10;
        if(Y())
        {
            f = true;
            g = false;
            h = 0.0F;
            i = 0.0F;
        } else
        if((f || g) && g)
        {
            if(h == 0.0F)
                world.makeSound(this, "mob.wolf.shake", k(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
            i = h;
            h += 0.05F;
            if(i >= 2.0F)
            {
                f = false;
                g = false;
                i = 0.0F;
                h = 0.0F;
            }
            if(h > 0.4F)
            {
                float f1 = (float)boundingBox.b;
                int i1 = (int)(MathHelper.sin((h - 0.4F) * 3.141593F) * 7F);
                for(int j1 = 0; j1 < i1; j1++)
                {
                    float f2 = (random.nextFloat() * 2.0F - 1.0F) * length * 0.5F;
                    float f3 = (random.nextFloat() * 2.0F - 1.0F) * length * 0.5F;
                    world.a("splash", locX + (double)f2, f1 + 0.8F, locZ + (double)f3, motX, motY, motZ);
                }

            }
        }
    }

    public float s()
    {
        return width * 0.8F;
    }

    protected int v()
    {
        if(isSitting())
            return 20;
        else
            return super.v();
    }

    private void b(Entity entity, float f1)
    {
        PathEntity pathentity = world.findPath(this, entity, 16F);
        if(pathentity == null && f1 > 12F)
        {
            int i1 = MathHelper.floor(entity.locX) - 2;
            int j1 = MathHelper.floor(entity.locZ) - 2;
            int k1 = MathHelper.floor(entity.boundingBox.b);
            for(int l1 = 0; l1 <= 4; l1++)
            {
                for(int i2 = 0; i2 <= 4; i2++)
                    if((l1 < 1 || i2 < 1 || l1 > 3 || i2 > 3) && world.d(i1 + l1, k1 - 1, j1 + i2) && !world.d(i1 + l1, k1, j1 + i2) && !world.d(i1 + l1, k1 + 1, j1 + i2))
                    {
                        setPositionRotation((float)(i1 + l1) + 0.5F, k1, (float)(j1 + i2) + 0.5F, yaw, pitch);
                        return;
                    }

            }

        } else
        {
            a(pathentity);
        }
    }

    protected boolean w()
    {
        return isSitting() || g;
    }

    public boolean damageEntity(Entity entity, int i1)
    {
        setSitting(false);
        if(entity != null && !(entity instanceof EntityHuman) && !(entity instanceof EntityArrow))
            i1 = (i1 + 1) / 2;
        if(super.damageEntity(entity, i1))
        {
            if(!m_() && !isAngry())
            {
                if(entity instanceof EntityHuman)
                {
                    setAngry(true);
                    target = entity;
                }
                if((entity instanceof EntityArrow) && ((EntityArrow)entity).shooter != null)
                    entity = ((EntityArrow)entity).shooter;
                if(entity instanceof EntityLiving)
                {
                    List list = world.a(net/minecraft/server/EntityWolf, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).b(16D, 4D, 16D));
                    Iterator iterator = list.iterator();
                    do
                    {
                        if(!iterator.hasNext())
                            break;
                        Entity entity1 = (Entity)iterator.next();
                        EntityWolf entitywolf = (EntityWolf)entity1;
                        if(!entitywolf.m_() && entitywolf.target == null)
                        {
                            entitywolf.target = entity;
                            if(entity instanceof EntityHuman)
                                entitywolf.setAngry(true);
                        }
                    } while(true);
                }
            } else
            if(entity != this && entity != null)
            {
                if(m_() && (entity instanceof EntityHuman) && ((EntityHuman)entity).name.equals(x()))
                    return true;
                target = entity;
            }
            return true;
        } else
        {
            return false;
        }
    }

    protected Entity findTarget()
    {
        if(isAngry())
            return world.a(this, 16D);
        else
            return null;
    }

    protected void a(Entity entity, float f1)
    {
        if(f1 > 2.0F && f1 < 6F && random.nextInt(10) == 0)
        {
            if(onGround)
            {
                double d1 = entity.locX - locX;
                double d2 = entity.locZ - locZ;
                float f2 = MathHelper.a(d1 * d1 + d2 * d2);
                motX = (d1 / (double)f2) * 0.5D * 0.80000001192092896D + motX * 0.20000000298023224D;
                motZ = (d2 / (double)f2) * 0.5D * 0.80000001192092896D + motZ * 0.20000000298023224D;
                motY = 0.40000000596046448D;
            }
        } else
        if((double)f1 < 1.5D && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            attackTicks = 20;
            byte byte0 = 2;
            if(m_())
                byte0 = 4;
            entity.damageEntity(this, byte0);
        }
    }

    public boolean a(EntityHuman entityhuman)
    {
        ItemStack itemstack = entityhuman.inventory.getItemInHand();
        if(!m_())
        {
            if(itemstack != null && itemstack.id == Item.BONE.id && !isAngry())
            {
                itemstack.count--;
                if(itemstack.count <= 0)
                    entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, null);
                if(!world.isStatic)
                    if(random.nextInt(3) == 0)
                    {
                        d(true);
                        a(((PathEntity) (null)));
                        setSitting(true);
                        health = 20;
                        a(entityhuman.name);
                        a(true);
                        world.a(this, (byte)7);
                    } else
                    {
                        a(false);
                        world.a(this, (byte)6);
                    }
                return true;
            }
        } else
        {
            if(itemstack != null && (Item.byId[itemstack.id] instanceof ItemFood))
            {
                ItemFood itemfood = (ItemFood)Item.byId[itemstack.id];
                if(itemfood.k() && datawatcher.b(18) < 20)
                {
                    itemstack.count--;
                    if(itemstack.count <= 0)
                        entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, null);
                    b(((ItemFood)Item.PORK).j());
                    return true;
                }
            }
            if(entityhuman.name.equals(x()))
            {
                if(!world.isStatic)
                {
                    setSitting(!isSitting());
                    ay = false;
                    a(((PathEntity) (null)));
                }
                return true;
            }
        }
        return false;
    }

    void a(boolean flag)
    {
        String s1 = "heart";
        if(!flag)
            s1 = "smoke";
        for(int i1 = 0; i1 < 7; i1++)
        {
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            double d3 = random.nextGaussian() * 0.02D;
            world.a(s1, (locX + (double)(random.nextFloat() * length * 2.0F)) - (double)length, locY + 0.5D + (double)(random.nextFloat() * width), (locZ + (double)(random.nextFloat() * length * 2.0F)) - (double)length, d1, d2, d3);
        }

    }

    public int l()
    {
        return 8;
    }

    public String x()
    {
        return datawatcher.c(17);
    }

    public void a(String s1)
    {
        datawatcher.b(17, s1);
    }

    public boolean isSitting()
    {
        return (datawatcher.a(16) & 1) != 0;
    }

    public void setSitting(boolean flag)
    {
        byte byte0 = datawatcher.a(16);
        if(flag)
            datawatcher.b(16, Byte.valueOf((byte)(byte0 | 1)));
        else
            datawatcher.b(16, Byte.valueOf((byte)(byte0 & -2)));
    }

    public boolean isAngry()
    {
        return (datawatcher.a(16) & 2) != 0;
    }

    public void setAngry(boolean flag)
    {
        byte byte0 = datawatcher.a(16);
        if(flag)
            datawatcher.b(16, Byte.valueOf((byte)(byte0 | 2)));
        else
            datawatcher.b(16, Byte.valueOf((byte)(byte0 & -3)));
    }

    public boolean m_()
    {
        return (datawatcher.a(16) & 4) != 0;
    }

    public void d(boolean flag)
    {
        byte byte0 = datawatcher.a(16);
        if(flag)
            datawatcher.b(16, Byte.valueOf((byte)(byte0 | 4)));
        else
            datawatcher.b(16, Byte.valueOf((byte)(byte0 & -5)));
    }

    private boolean a;
    private float b;
    private float c;
    private boolean f;
    private boolean g;
    private float h;
    private float i;
}
