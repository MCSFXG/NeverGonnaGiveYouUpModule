// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, Item, 
//            EntityItem, ItemStack, EntityHuman

public class BlockJukeBox extends Block
{

    protected BlockJukeBox(int i, int j)
    {
        super(i, j, Material.WOOD);
    }

    public int a(int i)
    {
        return textureId + (i != 1 ? 0 : 1);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        int l = world.getData(i, j, k);
        if(l > 0)
        {
            e(world, i, j, k, l);
            return true;
        } else
        {
            return false;
        }
    }

    public void e(World world, int i, int j, int k, int l)
    {
        world.a(null, i, j, k);
        world.setData(i, j, k, 0);
        int i1 = (Item.GOLD_RECORD.id + l) - 1;
        float f = 0.7F;
        double d = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
        double d1 = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.20000000000000001D + 0.59999999999999998D;
        double d2 = (double)(world.random.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
        EntityItem entityitem = new EntityItem(world, (double)i + d, (double)j + d1, (double)k + d2, new ItemStack(i1, 1, 0));
        entityitem.pickupDelay = 10;
        world.addEntity(entityitem);
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f)
    {
        if(world.isStatic)
            return;
        if(l > 0)
            e(world, i, j, k, l);
        super.dropNaturally(world, i, j, k, l, f);
    }
}
