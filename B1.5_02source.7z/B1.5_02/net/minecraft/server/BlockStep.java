// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, IBlockAccess

public class BlockStep extends Block
{

    public BlockStep(int i, boolean flag)
    {
        super(i, 6, Material.STONE);
        b = flag;
        if(!flag)
            a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        f(255);
    }

    public int a(int i, int j)
    {
        if(j == 0)
            return i > 1 ? 5 : 6;
        if(j == 1)
        {
            if(i == 0)
                return 208;
            return i != 1 ? 192 : 176;
        }
        if(j == 2)
            return 4;
        return j != 3 ? 6 : 16;
    }

    public int a(int i)
    {
        return a(i, 0);
    }

    public boolean a()
    {
        return b;
    }

    public void e(World world, int i, int j, int k)
    {
        if(this != Block.STEP)
            super.e(world, i, j, k);
        int l = world.getTypeId(i, j - 1, k);
        int i1 = world.getData(i, j, k);
        int j1 = world.getData(i, j - 1, k);
        if(i1 != j1)
            return;
        if(l == STEP.id)
        {
            world.setTypeId(i, j, k, 0);
            world.setTypeIdAndData(i, j - 1, k, Block.DOUBLE_STEP.id, i1);
        }
    }

    public int a(int i, Random random)
    {
        return Block.STEP.id;
    }

    public int a(Random random)
    {
        return !b ? 1 : 2;
    }

    protected int b(int i)
    {
        return i;
    }

    public boolean a(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        if(this != Block.STEP)
            super.a(iblockaccess, i, j, k, l);
        if(l == 1)
            return true;
        if(!super.a(iblockaccess, i, j, k, l))
            return false;
        if(l == 0)
            return true;
        else
            return iblockaccess.getTypeId(i, j, k) != id;
    }

    public static final String a[] = {
        "stone", "sand", "wood", "cobble"
    };
    private boolean b;

}
