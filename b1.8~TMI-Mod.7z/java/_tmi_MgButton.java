// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgButton.java


public class _tmi_MgButton extends _tmi_MgWidget
{

    public _tmi_MgButton(String s, _tmi_MgButtonHandler _ptmi_mgbuttonhandler, Object obj)
    {
        this(0, 0, 0, 0, 0, s, _ptmi_mgbuttonhandler, obj);
    }

    public _tmi_MgButton(int i, int j, int k, int l, int i1, String s, _tmi_MgButtonHandler _ptmi_mgbuttonhandler, 
            Object obj)
    {
        super(i, j, k, l, i1);
        label = s;
        controller = _ptmi_mgbuttonhandler;
        data = obj;
    }

    public void draw(_tmi_MgCanvas _ptmi_mgcanvas, int i, int j)
    {
        _ptmi_mgcanvas.drawRect(x, y, width, height, contains(i, j) ? 0xee401008 : 0xee000000);
        _ptmi_mgcanvas.drawTextCentered(x, y, width, height, label, -1);
    }

    public boolean click(int i, int j, int k)
    {
        if(k == 0)
            return controller.onButtonPress(data);
        else
            return true;
    }

    public String label;
    public _tmi_MgButtonHandler controller;
    public Object data;
}
