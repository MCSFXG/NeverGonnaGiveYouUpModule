// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TMIController.java

import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class TMIController
    implements _tmi_MgButtonHandler, _tmi_MgItemHandler
{

    public TMIController(em em1, pj pj)
    {
        window = null;
        drawItems = null;
        config = TMIConfig.getInstance();
        view = null;
        lastKeyPressTime = 0L;
        lastPrefsLoadTime = 0L;
        deleteAllWaitUntil = 0L;
        window = em1;
        drawItems = pj;
        canvas = new _tmi_MgCanvas(window, drawItems);
        view = new TMIView(canvas, config, this);
    }

    public void onEnterFrame(int i, int j, int k, int l)
    {
        try
        {
            if(System.currentTimeMillis() - lastKeyPressTime > 200L)
            {
                if(Keyboard.isKeyDown(24))
                {
                    config.toggleEnabled();
                    TMIUtils.savePreferences(config);
                    lastKeyPressTime = System.currentTimeMillis();
                }
                TMIUtils.updateUnlimitedItems();
            }
            if(System.currentTimeMillis() - lastPrefsLoadTime > 2000L)
            {
                TMIUtils.loadPreferences(config);
                if(lastPrefsLoadTime == 0L)
                    TMIUtils.savePreferences(config);
                TMIUtils.loadItems(config);
                lastPrefsLoadTime = System.currentTimeMillis();
            }
            if(config.isEnabled())
            {
                canvas.windowX = (window.m - k) / 2;
                canvas.windowY = (window.n - l) / 2;
                canvas.drawText(2, 11, "TooManyItems 1.8.1 2011-09-27", 0x454545);
                view.layout(window.m, window.n, k, l);
                canvas.drawWidgets(i, j);
                view.showToolTip(i, j);
                canvas.hardSetFlatMode(false);
            }
        }
        catch(Exception exception)
        {
            TMIUtils.safeReportException(exception);
            disable();
        }
    }

    public boolean onClick(int i, int j, int k)
    {
        if(!config.isEnabled())
            break MISSING_BLOCK_LABEL_89;
        canvas.sortByZOrder();
        for(Iterator iterator = canvas.widgets.iterator(); iterator.hasNext();)
        {
            _tmi_MgWidget _ltmi_mgwidget = (_tmi_MgWidget)iterator.next();
            if(_ltmi_mgwidget.contains(i, j))
                return _ltmi_mgwidget.click(i, j, k);
        }

        break MISSING_BLOCK_LABEL_89;
        Exception exception;
        exception;
        TMIUtils.safeReportException(exception);
        disable();
        return true;
    }

    public boolean onButtonPress(Object obj)
    {
        if(obj instanceof TMIStateButtonData)
        {
            TMIStateButtonData tmistatebuttondata = (TMIStateButtonData)obj;
            if(tmistatebuttondata.action == 1)
            {
                config.clearState(tmistatebuttondata.state);
                TMIUtils.savePreferences(config);
            } else
            if(config.isStateSaved(tmistatebuttondata.state))
            {
                config.loadState(tmistatebuttondata.state);
                TMIUtils.savePreferences(config);
            } else
            {
                config.saveState(tmistatebuttondata.state);
                TMIUtils.savePreferences(config);
            }
        } else
        if(obj instanceof String)
        {
            String s = (String)obj;
            if(s.equals("rain"))
                TMIUtils.getMinecraft().f.C.b(!TMIUtils.getMinecraft().f.C.o());
            else
            if(s.equals("next"))
            {
                _tmi_MgItemPanel _tmp = view.itemPanel;
                _tmi_MgItemPanel.page++;
            } else
            if(s.equals("prev"))
            {
                _tmi_MgItemPanel _tmp1 = view.itemPanel;
                _tmi_MgItemPanel.page--;
            } else
            if(s.equals("trash"))
                if(Keyboard.isKeyDown(54) || Keyboard.isKeyDown(42))
                {
                    if(TMIUtils.getHeldItem() == null)
                    {
                        if(System.currentTimeMillis() > deleteAllWaitUntil)
                        {
                            for(int i = 0; i < window.d.e.size(); i++)
                            {
                                sx sx1 = (sx)window.d.e.get(i);
                                sx1.c((ul)null);
                            }

                        }
                    } else
                    {
                        ul ul1 = TMIUtils.getHeldItem();
                        TMIUtils.deleteHeldItem();
                        for(int j = 0; j < window.d.e.size(); j++)
                        {
                            sx sx2 = (sx)window.d.e.get(j);
                            if(sx2 == null)
                                continue;
                            ul ul2 = sx2.a();
                            if(ul2 != null && ul2.c == ul1.c && ul2.i() == ul1.i())
                                sx2.c((ul)null);
                        }

                        deleteAllWaitUntil = System.currentTimeMillis() + 1000L;
                    }
                } else
                {
                    TMIUtils.deleteHeldItem();
                }
        }
        return true;
    }

    public boolean onItemEvent(ul ul1, int i)
    {
        if(i == 0)
            if(!TMIConfig.isMultiplayer() && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54)))
            {
                sv sv1 = sv.f[ul1.c];
                if(TMIConfig.isTool(sv1))
                {
                    TMIUtils.giveStack(new ul(ul1.c, 1, -32000), config, 1);
                    return false;
                }
                if(TMIConfig.canItemBeUnlimited(sv1))
                {
                    TMIUtils.giveStack(ul1, config, -100);
                    return false;
                } else
                {
                    TMIUtils.giveStack(ul1, config);
                    return false;
                }
            } else
            {
                TMIUtils.giveStack(ul1, config);
                return false;
            }
        if(i == 1)
        {
            TMIUtils.giveStack(ul1, config, 1);
            return false;
        } else
        {
            return true;
        }
    }

    public void onDestroy()
    {
    }

    public boolean isChest()
    {
        return window.d instanceof az;
    }

    public boolean isCrafting()
    {
        return (window.d instanceof r) || (window.d instanceof uf);
    }

    public void disable()
    {
        config.setEnabled(false);
    }

    private em window;
    private pj drawItems;
    private TMIConfig config;
    private TMIView view;
    long lastKeyPressTime;
    long lastPrefsLoadTime;
    long deleteAllWaitUntil;
    public static final long KEY_DELAY = 200L;
    public static final long PREFS_DELAY = 2000L;
    private _tmi_MgCanvas canvas;
}
