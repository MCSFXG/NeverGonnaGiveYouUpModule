// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgZOrder.java

import java.util.Comparator;

public class _tmi_MgZOrder
    implements Comparator
{

    public _tmi_MgZOrder()
    {
    }

    public int compare(_tmi_MgWidget _ptmi_mgwidget, _tmi_MgWidget _ptmi_mgwidget1)
    {
        return _ptmi_mgwidget.z <= _ptmi_mgwidget1.z ? _ptmi_mgwidget.z >= _ptmi_mgwidget1.z ? 0 : -1 : 1;
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((_tmi_MgWidget)obj, (_tmi_MgWidget)obj1);
    }
}
