// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TMIConfig.java

import java.io.PrintStream;
import java.util.*;
import net.minecraft.client.Minecraft;

public class TMIConfig
{

    public TMIConfig()
    {
        settings = new LinkedHashMap();
        settings.put("enable", "true");
        settings.put("enablemp", "false");
        settings.put("give-command", "/give {0} {1} {2}");
        for(int i = 0; i < getNumSaves(); i++)
            settings.put((new StringBuilder()).append("save-name").append(i + 1).toString(), (new StringBuilder()).append("").append(i + 1).toString());

        for(int j = 0; j < getNumSaves(); j++)
            settings.put((new StringBuilder()).append("save").append(j + 1).toString(), "");

        instance = this;
    }

    public static boolean isMultiplayer()
    {
        return TMIUtils.getMinecraft().f.I;
    }

    public static TMIConfig getInstance()
    {
        if(instance == null)
            new TMIConfig();
        return instance;
    }

    public Map getSettings()
    {
        return settings;
    }

    public List getItems()
    {
        return items;
    }

    public int getNumSaves()
    {
        return 7;
    }

    public boolean isStateSaved(int i)
    {
        return statesSaved[i];
    }

    public ul[] getState(int i)
    {
        return states[i];
    }

    public boolean getBooleanSetting(String s)
    {
        return Boolean.parseBoolean((String)settings.get(s));
    }

    public boolean isEnabled()
    {
        return isMultiplayer() && getBooleanSetting("enablemp") || !isMultiplayer() && getBooleanSetting("enable");
    }

    public void toggleEnabled()
    {
        String s = isMultiplayer() ? "enablemp" : "enable";
        settings.put(s, Boolean.toString(!getBooleanSetting(s)));
    }

    public void setEnabled(boolean flag)
    {
        String s = isMultiplayer() ? "enablemp" : "enable";
        settings.put(s, Boolean.toString(flag));
    }

    public static boolean isItemIncluded(int i)
    {
        return !excludeIds.contains(Integer.valueOf(i));
    }

    public static boolean isTool(sv sv1)
    {
        return toolIds.contains(Integer.valueOf(sv1.br));
    }

    public static boolean canItemBeUnlimited(sv sv1)
    {
        return !nonUnlimitedIds.contains(Integer.valueOf(sv1.br));
    }

    public boolean areDamageVariantsShown()
    {
        if(isMultiplayer())
        {
            String s = (String)getSettings().get("give-command");
            return s.contains("{3}");
        } else
        {
            return true;
        }
    }

    public void clearState(int i)
    {
        for(int j = 0; j < 44; j++)
        {
            states[i][j] = null;
            statesSaved[i] = false;
        }

        settings.put((new StringBuilder()).append("save").append(i + 1).toString(), "");
    }

    public void loadState(int i)
    {
        if(!statesSaved[i])
            return;
        List list = TMIUtils.getMinecraft().h.at.e;
        for(int j = 0; j < 44; j++)
        {
            sx sx1 = (sx)list.get(j + 1);
            sx1.c(null);
            ul ul1 = TMIUtils.copyStack(states[i][j]);
            if(ul1 != null && ul1.c >= 0 && ul1.c < sv.f.length && sv.f[ul1.c] != null)
                sx1.c(ul1);
        }

    }

    public void saveState(int i)
    {
        List list = TMIUtils.getMinecraft().h.at.e;
        for(int j = 0; j < 44; j++)
            states[i][j] = TMIUtils.copyStack(((sx)list.get(j + 1)).a());

        settings.put((new StringBuilder()).append("save").append(i + 1).toString(), encodeState(i));
        statesSaved[i] = true;
    }

    public String encodeState(int i)
    {
        StringBuilder stringbuilder = new StringBuilder();
        for(int j = 0; j < 44; j++)
        {
            if(states[i][j] != null)
            {
                stringbuilder.append(states[i][j].c);
                stringbuilder.append(":");
                stringbuilder.append(states[i][j].a);
                stringbuilder.append(":");
                stringbuilder.append(states[i][j].i());
            }
            stringbuilder.append(",");
        }

        return stringbuilder.toString();
    }

    public void decodeState(int i, String s)
    {
        if(s.trim().equals(""))
        {
            statesSaved[i] = false;
        } else
        {
            String as[] = s.split(",", 0);
            for(int j = 0; j < as.length && j < states[i].length; j++)
            {
                String as1[] = as[j].split(":");
                if(as1.length != 3)
                    continue;
                try
                {
                    states[i][j] = new ul(Integer.parseInt(as1[0]), Integer.parseInt(as1[1]), Integer.parseInt(as1[2]));
                }
                catch(Exception exception)
                {
                    System.out.println(exception);
                }
            }

            statesSaved[i] = true;
        }
    }

    public static final String VERSION = "1.8.1 2011-09-27";
    public static final int NUM_SAVES = 7;
    public static final int INVENTORY_SIZE = 44;
    public static boolean isModloaderEnabled = false;
    private static TMIConfig instance;
    private static List items = new ArrayList();
    private static HashSet toolIds;
    private static HashSet nonUnlimitedIds;
    private Map settings;
    private static ul states[][] = new ul[7][44];
    private static boolean statesSaved[] = new boolean[7];
    private static HashSet excludeIds;

    static 
    {
        toolIds = new HashSet();
        for(int i = 1; i <= 3; i++)
            toolIds.add(Integer.valueOf(i + 256));

        for(int j = 11; j <= 23; j++)
            toolIds.add(Integer.valueOf(j + 256));

        for(int k = 27; k <= 30; k++)
            toolIds.add(Integer.valueOf(k + 256));

        for(int l = 34; l <= 38; l++)
            toolIds.add(Integer.valueOf(l + 256));

        for(int i1 = 42; i1 <= 61; i1++)
            toolIds.add(Integer.valueOf(i1 + 256));

        toolIds.add(Integer.valueOf(359));
        toolIds.add(Integer.valueOf(346));
        nonUnlimitedIds = new HashSet();
        nonUnlimitedIds.add(Integer.valueOf(358));
        excludeIds = new HashSet();
        excludeIds.add(Integer.valueOf(9));
        excludeIds.add(Integer.valueOf(11));
        excludeIds.add(Integer.valueOf(63));
        excludeIds.add(Integer.valueOf(64));
        excludeIds.add(Integer.valueOf(68));
        excludeIds.add(Integer.valueOf(71));
        excludeIds.add(Integer.valueOf(74));
        excludeIds.add(Integer.valueOf(75));
        excludeIds.add(Integer.valueOf(59));
        excludeIds.add(Integer.valueOf(83));
        excludeIds.add(Integer.valueOf(55));
        excludeIds.add(Integer.valueOf(26));
        excludeIds.add(Integer.valueOf(93));
        excludeIds.add(Integer.valueOf(94));
    }
}
