// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TMIStateButtonData.java


class TMIStateButtonData
{

    public TMIStateButtonData(int i, int j)
    {
        state = i;
        action = j;
    }

    public int state;
    public int action;
    public static final int STATE = 0;
    public static final int CLEAR = 1;
}
