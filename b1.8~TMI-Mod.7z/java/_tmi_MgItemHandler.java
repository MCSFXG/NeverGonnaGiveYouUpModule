// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgItemHandler.java


public interface _tmi_MgItemHandler
{

    public abstract boolean onItemEvent(ul ul, int i);
}
