// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TMIView.java

import java.util.List;
import java.util.Map;
import org.lwjgl.input.Keyboard;

public class TMIView
{

    public TMIView(_tmi_MgCanvas _ptmi_mgcanvas, TMIConfig tmiconfig, TMIController tmicontroller)
    {
        widgetsCreated = false;
        canvas = _ptmi_mgcanvas;
        config = tmiconfig;
        controller = tmicontroller;
        stateButtons = new _tmi_MgButton[config.getNumSaves()];
        deleteButtons = new _tmi_MgButton[config.getNumSaves()];
        createWidgets();
    }

    public void createWidgets()
    {
        prevButton = new _tmi_MgButton("Prev", controller, "prev");
        canvas.widgets.add(prevButton);
        nextButton = new _tmi_MgButton("Next", controller, "next");
        canvas.widgets.add(nextButton);
        itemPanel = new _tmi_MgItemPanel(0, 0, 0, 0, 0, config.getItems(), controller);
        canvas.widgets.add(itemPanel);
        if(!TMIConfig.isMultiplayer())
        {
            trashButton = new _tmi_MgButton("Trash", controller, "trash");
            canvas.widgets.add(trashButton);
            stateButtons = new _tmi_MgButton[config.getNumSaves()];
            for(int i = 0; i < config.getNumSaves(); i++)
            {
                stateButtons[i] = new _tmi_MgButton((new StringBuilder()).append("Save ").append(i + 1).toString(), controller, new TMIStateButtonData(i, 0));
                canvas.widgets.add(stateButtons[i]);
                deleteButtons[i] = new _tmi_MgButton("x", controller, new TMIStateButtonData(i, 1));
                canvas.widgets.add(deleteButtons[i]);
            }

        }
        widgetsCreated = true;
    }

    public void layout(int i, int j, int k, int l)
    {
        if(!widgetsCreated)
            createWidgets();
        prevButton.x = (k + i) / 2;
        prevButton.y = 0;
        prevButton.width = canvas.windowX;
        prevButton.height = 28;
        nextButton.x = (k + i) / 2;
        nextButton.y = j - 28;
        nextButton.width = canvas.windowX;
        nextButton.height = 28;
        itemPanel.x = (i + k) / 2 + 5;
        itemPanel.y = 30;
        itemPanel.width = i - 5 - itemPanel.x;
        itemPanel.height = j - 30 - itemPanel.y;
        itemPanel.resize();
        _tmi_MgItemPanel _tmp = itemPanel;
        prevButton.label = (new StringBuilder()).append("Prev (").append(_tmi_MgItemPanel.page + 1).append("/").append(itemPanel.numPages).append(")").toString();
        if(!TMIConfig.isMultiplayer())
        {
            trashButton.x = 0;
            trashButton.y = j - 30;
            trashButton.width = 82;
            trashButton.height = 30;
            if(TMIUtils.getHeldItem() == null && (Keyboard.isKeyDown(54) || Keyboard.isKeyDown(42)))
                trashButton.label = "Delete all";
            else
                trashButton.label = "Trash";
            int i1 = 0;
            for(int j1 = 0; j1 < config.getNumSaves(); j1++)
            {
                deleteButtons[j1].x = -1000;
                stateButtons[j1].y = 30 + j1 * 22;
                stateButtons[j1].height = 20;
                String s = (String)config.getSettings().get((new StringBuilder()).append("save-name").append(j1 + 1).toString());
                if(s == null)
                    s = (new StringBuilder()).append("").append(j1 + 1).toString();
                if(config.isStateSaved(j1))
                    stateButtons[j1].label = (new StringBuilder()).append("Load ").append(s).toString();
                else
                    stateButtons[j1].label = (new StringBuilder()).append("Save ").append(s).toString();
                int l1 = canvas.getTextWidth(stateButtons[j1].label) + 26;
                if(l1 + 2 + 20 > canvas.windowX)
                    l1 = canvas.windowX - 20 - 2;
                if(l1 > i1)
                    i1 = l1;
            }

            for(int k1 = 0; k1 < config.getNumSaves(); k1++)
            {
                stateButtons[k1].width = i1;
                if(config.isStateSaved(k1))
                {
                    deleteButtons[k1].x = stateButtons[k1].width + 2;
                    deleteButtons[k1].y = stateButtons[k1].y;
                    deleteButtons[k1].width = 20;
                    deleteButtons[k1].height = 20;
                }
            }

        }
    }

    public void showToolTip(int i, int j)
    {
        if(!TMIConfig.isMultiplayer() && trashButton.contains(i, j))
            if(Keyboard.isKeyDown(54) || Keyboard.isKeyDown(42))
            {
                if(TMIUtils.getHeldItem() == null)
                    canvas.drawTip(i, j, "Delete ALL items from current inventory screen");
                else
                    canvas.drawTip(i, j, (new StringBuilder()).append("Delete ALL ").append(TMIUtils.itemDisplayName(TMIUtils.getHeldItem())).toString());
            } else
            if(TMIUtils.getHeldItem() == null)
                canvas.drawTip(i, j, "Drop item here to delete");
            else
                canvas.drawTip(i, j, (new StringBuilder()).append("Delete ").append(TMIUtils.itemDisplayName(TMIUtils.getHeldItem())).toString());
    }

    public boolean isInitialized()
    {
        return widgetsCreated;
    }

    private _tmi_MgCanvas canvas;
    private TMIConfig config;
    private TMIController controller;
    private boolean widgetsCreated;
    private _tmi_MgButton prevButton;
    private _tmi_MgButton nextButton;
    private _tmi_MgButton trashButton;
    private _tmi_MgButton stateButtons[];
    private _tmi_MgButton deleteButtons[];
    public _tmi_MgItemPanel itemPanel;
}
