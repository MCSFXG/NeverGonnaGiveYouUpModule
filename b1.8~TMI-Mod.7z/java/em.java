// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   em.java

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public abstract class em extends qr
{

    public em(cf cf1)
    {
        b = 176;
        c = 166;
        tmi = null;
        d = cf1;
        tmi = new TMIController(this, a);
    }

    public void a()
    {
        super.a();
        l.h.au = d;
    }

    public void a(int i, int j, float f)
    {
        k();
        int k = (m - b) / 2;
        int l = (n - c) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
        ow.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(k, l, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        sx sx1 = null;
        int i1 = 240;
        int j1 = 240;
        GL13.glMultiTexCoord2f(33985, (float)i1 / 1.0F, (float)j1 / 1.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        tmi.onEnterFrame(i, j, b, c);
        for(int k2 = 0; k2 < d.e.size(); k2++)
        {
            sx sx2 = (sx)d.e.get(k2);
            a(sx2);
            if(a(sx2, i, j))
            {
                sx1 = sx2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int k1 = sx2.c;
                int i2 = sx2.d;
                a(k1, i2, k1 + 16, i2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        ui ui1 = this.l.h.as;
        if(ui1.j() != null)
        {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            ul ul1 = TMIUtils.getValidItem(ui1.j());
            a.a(q, this.l.p, ul1, i - k - 8, j - l - 8);
            a.b(q, this.l.p, ul1, i - k - 8, j - l - 8);
        }
        GL11.glDisable(32826);
        ow.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        c();
        if(ui1.j() == null && sx1 != null && sx1.b())
        {
            String s = TMIUtils.getValidItemDisplayName(sx1.a());
            if(s.length() > 0)
            {
                int l1 = (i - k) + 12;
                int j2 = j - l - 12;
                int l2 = q.a(s);
                a(l1 - 3, j2 - 3, l1 + l2 + 3, j2 + 8 + 3, 0xc0000000, 0xc0000000);
                q.a(s, l1, j2, -1);
            }
        }
        GL11.glPopMatrix();
        super.a(i, j, f);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
    }

    protected void c()
    {
    }

    protected abstract void a(float f);

    private void a(sx sx1)
    {
        int i = sx1.c;
        int j = sx1.d;
        ul ul1 = sx1.a();
        if(ul1 == null)
        {
            int k = sx1.e();
            if(k >= 0)
            {
                GL11.glDisable(2896);
                l.p.b(l.p.b("/gui/items.png"));
                b(i, j, (k % 16) * 16, (k / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        a.a(q, l.p, ul1, i, j);
        a.b(q, l.p, ul1, i, j);
    }

    private sx a(int i, int j)
    {
        for(int k = 0; k < d.e.size(); k++)
        {
            sx sx1 = (sx)d.e.get(k);
            if(a(sx1, i, j))
                return sx1;
        }

        return null;
    }

    protected void a(int i, int j, int k)
    {
        super.a(i, j, k);
        if(k >= 0 && k <= 2)
        {
            sx sx1 = a(i, j);
            int l = (m - b) / 2;
            int i1 = (n - c) / 2;
            boolean flag = i < l || j < i1 || i >= l + b || j >= i1 + c;
            replacementClickHandler(i, j, k, !flag, sx1, this.l, d);
        }
    }

    private boolean a(sx sx1, int i, int j)
    {
        int k = (m - b) / 2;
        int l = (n - c) / 2;
        i -= k;
        j -= l;
        return i >= sx1.c - 1 && i < sx1.c + 16 + 1 && j >= sx1.d - 1 && j < sx1.d + 16 + 1;
    }

    protected void a(sx sx1, int i, int j, boolean flag)
    {
        if(sx1 != null)
            i = sx1.b;
        l.c.a(d.f, i, j, flag, l.h);
    }

    protected void b(int i, int j, int k)
    {
        if(k != 0);
    }

    protected void a(char c1, int i)
    {
        if(i == 1 || i == l.z.r.d)
            l.h.U();
    }

    public void d()
    {
        if(l.h != null)
        {
            d.a(l.h);
            l.c.a(d.f, l.h);
        }
    }

    public boolean e()
    {
        return false;
    }

    public void p_()
    {
        super.p_();
        if(!l.h.G() || l.h.G)
            l.h.U();
    }

    public void replacementClickHandler(int i, int j, int k, boolean flag, sx sx1, Minecraft minecraft, cf cf1)
    {
        if(!tmi.onClick(i, j, k))
            return;
        int l = -1;
        if(sx1 != null)
            l = sx1.b;
        else
        if(!flag)
        {
            l = -999;
            ul ul1 = TMIUtils.getHeldItem();
            if(ul1 != null && (ul1.a < 0 || ul1.a > 64))
                ul1.a = 1;
        }
        boolean flag1 = flag && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
        if(!TMICompatibility.callConvenientInventoryHandler(l, k, flag1, minecraft, cf1))
            if(l == 0 && k == 1 && tmi.isCrafting())
            {
                for(int i1 = 0; i1 < 64; i1++)
                    a(sx1, l, k, flag1);

            } else
            if(l != -1)
                if(tmi.isChest() && l >= 0 && !TMIConfig.isMultiplayer() && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54)) && TMIUtils.getHeldItem() != null && TMIUtils.isValidItem(TMIUtils.getHeldItem()))
                    try
                    {
                        fastTransfer(l, k);
                    }
                    catch(Exception exception)
                    {
                        TMIUtils.safeReportException(exception);
                    }
                else
                    a(sx1, l, k, flag1);
    }

    private void fastTransfer(int i, int j)
    {
        ul ul1 = TMIUtils.getHeldItem();
        this.l.c.a(d.f, i, j, false, this.l.h);
        int k = d.d.size() - 36;
        boolean flag = i < k;
        int l = 0;
        int i1 = k;
        int j1 = k - 1;
        int k1 = d.d.size();
        if(flag)
        {
            l = k;
            i1 = d.d.size();
            j1 = -1;
            k1 = k;
        }
        boolean flag1 = true;
        do
        {
            if(l >= i1 || j1 >= k1)
                break;
            sx sx1 = (sx)d.e.get(l);
            if(sx1 != null)
            {
                ul ul2 = sx1.a();
                if(ul2 != null && ul2.c == ul1.c && ul2.i() == ul1.i())
                {
                    sx sx2;
                    if(flag1)
                        sx2 = (sx)d.e.get(i);
                    else
                        sx2 = (sx)d.e.get(j1);
                    if(sx2 == null)
                    {
                        j1++;
                        flag1 = false;
                        continue;
                    }
                    ul ul3 = sx2.a();
                    if(ul3 == null)
                    {
                        sx2.c(ul2);
                        sx1.c((ul)null);
                    } else
                    if(ul3.c == ul2.c && ul3.i() == ul2.i())
                    {
                        int l1 = ul2.a + ul3.a;
                        int i2 = sv.f[ul2.c].d();
                        int j2 = l1 - i2;
                        if(j2 > 0)
                        {
                            ul3.a = i2;
                            ul2.a = j2;
                            j1++;
                            flag1 = false;
                            continue;
                        }
                        ul3.a = l1;
                        sx1.c((ul)null);
                    } else
                    {
                        j1++;
                        flag1 = false;
                        continue;
                    }
                }
            }
            l++;
        } while(true);
    }

    protected static pj a = new pj();
    protected int b;
    protected int c;
    public cf d;
    private TMIController tmi;

}
