// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgWidget.java


public class _tmi_MgWidget
{

    public _tmi_MgWidget(int i, int j)
    {
        this(i, j, 0, 0, 0);
    }

    public _tmi_MgWidget(int i, int j, int k)
    {
        this(i, j, k, 0, 0);
    }

    public _tmi_MgWidget(int i, int j, int k, int l, int i1)
    {
        mouseOver = false;
        x = i;
        y = j;
        z = k;
        width = l;
        height = i1;
    }

    public static _tmi_MgZOrder getComparator()
    {
        return new _tmi_MgZOrder();
    }

    public void draw(_tmi_MgCanvas _ptmi_mgcanvas, int i, int j)
    {
    }

    public boolean click(int i, int j, int k)
    {
        return true;
    }

    public boolean contains(int i, int j)
    {
        return i >= x && i <= x + width && j >= y && j <= y + height;
    }

    public void position(int i, int j, int k, int l, int i1)
    {
        x = i;
        y = j;
        z = k;
        width = l;
        height = i1;
        resize();
    }

    public void resize()
    {
    }

    public int x;
    public int y;
    public int z;
    public int width;
    public int height;
    public boolean mouseOver;
}
