// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TMIUtils.java

import java.io.*;
import java.lang.reflect.Field;
import java.text.*;
import java.util.*;
import net.minecraft.client.Minecraft;

public class TMIUtils
{

    public TMIUtils()
    {
    }

    public static Minecraft getMinecraft()
    {
        try
        {
            Field field = net/minecraft/client/Minecraft.getDeclaredField("a");
            field.setAccessible(true);
            return (Minecraft)field.get(null);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            illegalaccessexception.printStackTrace();
        }
        catch(NoSuchFieldException nosuchfieldexception)
        {
            nosuchfieldexception.printStackTrace();
        }
        return null;
    }

    public static void loadPreferences(TMIConfig tmiconfig)
    {
        try
        {
            Map map = tmiconfig.getSettings();
            File file = new File(Minecraft.a("minecraft"), "TooManyItems.txt");
            if(file.exists())
            {
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                do
                {
                    String s;
                    if((s = bufferedreader.readLine()) == null)
                        break;
                    String as[] = s.split(":", 2);
                    if(as.length > 1 && map.containsKey(as[0]))
                        map.put(as[0], as[1]);
                } while(true);
                bufferedreader.close();
                for(int i = 0; i < tmiconfig.getNumSaves(); i++)
                    tmiconfig.decodeState(i, (String)map.get((new StringBuilder()).append("save").append(i + 1).toString()));

            }
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }
    }

    public static void savePreferences(TMIConfig tmiconfig)
    {
        try
        {
            Map map = tmiconfig.getSettings();
            File file = new File(Minecraft.a("minecraft"), "TooManyItems.txt");
            PrintWriter printwriter = new PrintWriter(new FileWriter(file));
            String s;
            for(Iterator iterator = map.keySet().iterator(); iterator.hasNext(); printwriter.println((new StringBuilder()).append(s).append(":").append((String)map.get(s)).toString()))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }
    }

    public static void loadItems(TMIConfig tmiconfig)
    {
        List list = tmiconfig.getItems();
        list.clear();
        sv asv[] = sv.f;
        int i = asv.length;
        for(int j = 0; j < i; j++)
        {
            sv sv1 = asv[j];
            if(sv1 == null)
                continue;
            TMIConfig _tmp = tmiconfig;
            if(!TMIConfig.isItemIncluded(sv1.br))
                continue;
            HashSet hashset = new HashSet();
            byte byte0 = ((byte)(tmiconfig.areDamageVariantsShown() ? 15 : 0));
            for(int k = 0; k <= byte0; k++)
            {
                ul ul1 = new ul(sv1, sv1.d(), k);
                try
                {
                    int l = sv1.d(ul1);
                    String s = (new StringBuilder()).append(ul1.l()).append("@").append(l).toString();
                    if(!hashset.contains(s) || sv1.br == 18 && k == 2)
                    {
                        list.add(ul1);
                        hashset.add(s);
                    }
                }
                catch(NullPointerException nullpointerexception) { }
                catch(IndexOutOfBoundsException indexoutofboundsexception) { }
            }

        }

    }

    public static void safeReportException(Exception exception)
    {
        try
        {
            SimpleDateFormat simpledateformat = new SimpleDateFormat(".yyyyMMdd.HHmmss");
            StringBuffer stringbuffer = new StringBuffer();
            simpledateformat.format(new Date(), stringbuffer, new FieldPosition(1));
            String s = (new StringBuilder()).append("tmi").append(stringbuffer.toString()).append(".txt").toString();
            File file = new File(Minecraft.a("minecraft"), s);
            PrintWriter printwriter = new PrintWriter(new FileWriter(file));
            printwriter.print("[code]TMI Version: 1.8.1 2011-09-27\n");
            exception.printStackTrace(printwriter);
            printwriter.println("[/code]");
            printwriter.close();
            getMinecraft().v.a((new StringBuilder()).append("Error written to ").append(s).toString());
        }
        catch(Exception exception1)
        {
            System.out.println("Error during safeReportException:");
            exception1.printStackTrace();
        }
    }

    public static String itemDisplayName(ul ul1)
    {
        try
        {
            String s = wv.a().b(ul1.l());
            if(!s.trim().equals(""))
                return s;
        }
        catch(NullPointerException nullpointerexception) { }
        return "Unnamed";
    }

    public static boolean isValidItem(ul ul1)
    {
        return ul1 == null || ul1.c >= 0 && ul1.c < sv.f.length && sv.f[ul1.c] != null;
    }

    public static ul getValidItem(ul ul1)
    {
        if(isValidItem(ul1))
            return ul1;
        else
            return new ul(lr.at);
    }

    public static String getValidItemDisplayName(ul ul1)
    {
        if(isValidItem(ul1))
            return itemDisplayName(ul1);
        else
            return "Undefined Item";
    }

    public static void deleteHeldItem()
    {
        getMinecraft().h.as.b((ul)null);
    }

    public static ul getHeldItem()
    {
        return getMinecraft().h.as.j();
    }

    public static void giveStack(ul ul1, TMIConfig tmiconfig)
    {
        giveStack(ul1, tmiconfig, ul1.a);
    }

    public static void giveStack(ul ul1, TMIConfig tmiconfig, int i)
    {
        ul ul2 = copyStack(ul1, i);
        Minecraft minecraft = getMinecraft();
        if(TMIConfig.isMultiplayer())
        {
            NumberFormat numberformat = NumberFormat.getIntegerInstance();
            numberformat.setGroupingUsed(false);
            MessageFormat messageformat = new MessageFormat((String)tmiconfig.getSettings().get("give-command"));
            messageformat.setFormatByArgumentIndex(1, numberformat);
            messageformat.setFormatByArgumentIndex(2, numberformat);
            messageformat.setFormatByArgumentIndex(3, numberformat);
            Object aobj[] = {
                minecraft.h.aD, Integer.valueOf(ul2.c), Integer.valueOf(ul2.a), Integer.valueOf(ul2.i())
            };
            minecraft.h.a(messageformat.format(((Object) (aobj))));
        } else
        {
            minecraft.h.as.a(ul2);
        }
    }

    public static ul copyStack(ul ul1, int i)
    {
        if(ul1 == null)
        {
            return null;
        } else
        {
            ul1.a += i;
            return ul1.a(i);
        }
    }

    public static ul copyStack(ul ul1)
    {
        if(ul1 == null)
            return null;
        else
            return copyStack(ul1, ul1.a);
    }

    public static void updateUnlimitedItems()
    {
        if(TMIConfig.isMultiplayer() || !TMIConfig.getInstance().isEnabled())
            return;
        ul aul[] = getMinecraft().h.as.a;
        int i = aul.length;
        for(int j = 0; j < i; j++)
        {
            ul ul2 = aul[j];
            if(ul2 == null)
                continue;
            if(ul2.a < 0 || ul2.a > 64)
                ul2.a = 111;
            if(ul2.i() < 0)
                setStackDamage(ul2, -32000);
        }

        ul ul1 = getHeldItem();
        if(ul1 != null && ul1.a > 64)
            ul1.a = -1;
    }

    public static void setStackDamage(ul ul1, int i)
    {
        try
        {
            Field afield[] = ul.getDeclaredFields();
            int j = afield.length;
            int k = 0;
            do
            {
                if(k >= j)
                    break;
                Field field = afield[k];
                if(field.getName().equals("d"))
                {
                    field.setAccessible(true);
                    field.setInt(ul1, i);
                    break;
                }
                k++;
            } while(true);
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }
    }

    public static final String CONFIG_FILENAME = "TooManyItems.txt";
}
