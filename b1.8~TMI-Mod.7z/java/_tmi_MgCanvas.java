// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgCanvas.java

import java.util.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class _tmi_MgCanvas
{

    public _tmi_MgCanvas(qr qr1, pj pj1)
    {
        windowX = 0;
        windowY = 0;
        widgets = new ArrayList();
        flatMode = false;
        window = qr1;
        drawItems = pj1;
    }

    public void drawRect(int i, int j, int k, int l, int i1)
    {
        flatMode(true);
        window.a(i - windowX, j - windowY, (i + k) - windowX, (j + l) - windowY, i1, i1);
    }

    public void drawText(int i, int j, String s, int k)
    {
        flatMode(true);
        window.q.a(s, i - windowX, j - windowY, k);
    }

    public void drawTextCentered(int i, int j, int k, int l, String s, int i1)
    {
        drawText(i + (k - getTextWidth(s)) / 2, j + (l - 8) / 2, s, i1);
    }

    public void drawText(int i, int j, String s)
    {
        drawText(i, j, s, -1);
    }

    public void drawTip(int i, int j, String s)
    {
        byte byte0 = 3;
        int k = i + 12;
        int l = j - 15;
        if(l < 0)
            l = 0;
        int i1 = getTextWidth(s) + byte0 * 2;
        if(k + i1 > window.m)
            k -= (k + i1) - window.m;
        drawRect(k, l, i1, 8 + byte0 * 2, 0xee000000);
        drawText(k + byte0, l + byte0, s, -1);
    }

    public void drawItem(int i, int j, ul ul1)
    {
        hardSetFlatMode(false);
        try
        {
            drawItems.a(window.q, window.l.p, ul1, i - windowX, j - windowY);
        }
        catch(RuntimeException runtimeexception)
        {
            drawItems.a(window.q, window.l.p, new ul(51, 1, 0), i - windowX, j - windowY);
        }
    }

    public void drawChrome(int i, int j, int k, int l, int i1, int j1)
    {
        flatMode(true);
        window.l.p.b(window.l.p.b("/tmi.png"));
        window.b(i - windowX, j - windowY, k, l, i1, j1);
    }

    public void sortByZOrder()
    {
        Collections.sort(widgets, _tmi_MgWidget.getComparator());
    }

    public void drawWidgets(int i, int j)
    {
        sortByZOrder();
        _tmi_MgWidget _ltmi_mgwidget;
        for(Iterator iterator = widgets.iterator(); iterator.hasNext(); _ltmi_mgwidget.draw(this, i, j))
            _ltmi_mgwidget = (_tmi_MgWidget)iterator.next();

    }

    public int getTextWidth(String s)
    {
        return window.q.a(s);
    }

    public void flatMode(boolean flag)
    {
        if(flag && !flatMode)
        {
            GL11.glDisable(2896);
            GL11.glDisable(2929);
        } else
        if(!flag && flatMode)
        {
            GL11.glEnable(2896);
            GL11.glEnable(2929);
        }
        flatMode = flag;
    }

    public void hardSetFlatMode(boolean flag)
    {
        if(flag)
        {
            GL11.glDisable(2896);
            GL11.glDisable(2929);
        } else
        {
            GL11.glEnable(2896);
            GL11.glEnable(2929);
        }
        flatMode = flag;
    }

    public int windowX;
    public int windowY;
    public qr window;
    private pj drawItems;
    public List widgets;
    public static final int WHITE = -1;
    public static final int SHADE = 0xee000000;
    public static final int RED_SHADE = 0xee401008;
    public static final int LIGHT_SHADE = 0xee555555;
    private boolean flatMode;
}
