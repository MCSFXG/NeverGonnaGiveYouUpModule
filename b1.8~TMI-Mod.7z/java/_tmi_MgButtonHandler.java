// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   _tmi_MgButtonHandler.java


public interface _tmi_MgButtonHandler
{

    public abstract boolean onButtonPress(Object obj);
}
