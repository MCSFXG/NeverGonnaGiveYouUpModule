// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   mod_TooManyItems.java

import net.minecraft.client.Minecraft;

public class mod_TooManyItems extends BaseMod
{

    public mod_TooManyItems()
    {
        lastInvUpdate = 0L;
        TMIConfig.isModloaderEnabled = true;
        ModLoader.SetInGameHook(this, true, true);
        TMIUtils.loadPreferences(TMIConfig.getInstance());
    }

    public boolean OnTickInGame(Minecraft minecraft)
    {
        long l = System.currentTimeMillis();
        if(l - lastInvUpdate > 250L)
        {
            TMIUtils.updateUnlimitedItems();
            lastInvUpdate = l;
        }
        return true;
    }

    public String Version()
    {
        return "1.8.1 2011-09-27";
    }

    private long lastInvUpdate;
}
