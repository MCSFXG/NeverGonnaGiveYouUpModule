// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HitResult.java

package com.mojang.rubydung;


public class HitResult
{

    public HitResult(int x, int y, int z, int o, int f)
    {
        this.x = x;
        this.y = y;
        this.z = z;
        this.o = o;
        this.f = f;
    }

    public int x;
    public int y;
    public int z;
    public int o;
    public int f;
}
