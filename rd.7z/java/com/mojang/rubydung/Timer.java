// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Timer.java

package com.mojang.rubydung;


public class Timer
{

    public Timer(float ticksPerSecond)
    {
        timeScale = 1.0F;
        fps = 0.0F;
        passedTime = 0.0F;
        this.ticksPerSecond = ticksPerSecond;
        lastTime = System.nanoTime();
    }

    public void advanceTime()
    {
        long now = System.nanoTime();
        long passedNs = now - lastTime;
        lastTime = now;
        if(passedNs < 0L)
            passedNs = 0L;
        if(passedNs > 0x3b9aca00L)
            passedNs = 0x3b9aca00L;
        fps = 0x3b9aca00L / passedNs;
        passedTime += ((float)passedNs * timeScale * ticksPerSecond) / 1E+009F;
        ticks = (int)passedTime;
        if(ticks > 100)
            ticks = 100;
        passedTime -= ticks;
        a = passedTime;
    }

    private static final long NS_PER_SECOND = 0x3b9aca00L;
    private static final long MAX_NS_PER_UPDATE = 0x3b9aca00L;
    private static final int MAX_TICKS_PER_UPDATE = 100;
    private float ticksPerSecond;
    private long lastTime;
    public int ticks;
    public float a;
    public float timeScale;
    public float fps;
    public float passedTime;
}
