// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Player.java

package com.mojang.rubydung;

import com.mojang.rubydung.level.Level;
import com.mojang.rubydung.phys.AABB;
import java.util.List;
import org.lwjgl.input.Keyboard;

public class Player
{

    public Player(Level level)
    {
        onGround = false;
        this.level = level;
        resetPos();
    }

    private void resetPos()
    {
        float x = (float)Math.random() * (float)level.width;
        float y = level.depth + 10;
        float z = (float)Math.random() * (float)level.height;
        setPos(x, y, z);
    }

    private void setPos(float x, float y, float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
        float w = 0.3F;
        float h = 0.9F;
        bb = new AABB(x - w, y - h, z - w, x + w, y + h, z + w);
    }

    public void turn(float xo, float yo)
    {
        yRot += (double)xo * 0.14999999999999999D;
        xRot -= (double)yo * 0.14999999999999999D;
        if(xRot < -90F)
            xRot = -90F;
        if(xRot > 90F)
            xRot = 90F;
    }

    public void tick()
    {
        xo = x;
        yo = y;
        zo = z;
        float xa = 0.0F;
        float ya = 0.0F;
        if(Keyboard.isKeyDown(19))
            resetPos();
        if(Keyboard.isKeyDown(200) || Keyboard.isKeyDown(17))
            ya--;
        if(Keyboard.isKeyDown(208) || Keyboard.isKeyDown(31))
            ya++;
        if(Keyboard.isKeyDown(203) || Keyboard.isKeyDown(30))
            xa--;
        if(Keyboard.isKeyDown(205) || Keyboard.isKeyDown(32))
            xa++;
        if((Keyboard.isKeyDown(57) || Keyboard.isKeyDown(219)) && onGround)
            yd = 0.12F;
        moveRelative(xa, ya, onGround ? 0.02F : 0.005F);
        yd -= 0.0050000000000000001D;
        move(xd, yd, zd);
        xd *= 0.91F;
        yd *= 0.98F;
        zd *= 0.91F;
        if(onGround)
        {
            xd *= 0.8F;
            zd *= 0.8F;
        }
    }

    public void move(float xa, float ya, float za)
    {
        float xaOrg = xa;
        float yaOrg = ya;
        float zaOrg = za;
        List aABBs = level.getCubes(bb.expand(xa, ya, za));
        for(int i = 0; i < aABBs.size(); i++)
            ya = ((AABB)aABBs.get(i)).clipYCollide(bb, ya);

        bb.move(0.0F, ya, 0.0F);
        for(int i = 0; i < aABBs.size(); i++)
            xa = ((AABB)aABBs.get(i)).clipXCollide(bb, xa);

        bb.move(xa, 0.0F, 0.0F);
        for(int i = 0; i < aABBs.size(); i++)
            za = ((AABB)aABBs.get(i)).clipZCollide(bb, za);

        bb.move(0.0F, 0.0F, za);
        onGround = yaOrg != ya && yaOrg < 0.0F;
        if(xaOrg != xa)
            xd = 0.0F;
        if(yaOrg != ya)
            yd = 0.0F;
        if(zaOrg != za)
            zd = 0.0F;
        x = (bb.x0 + bb.x1) / 2.0F;
        y = bb.y0 + 1.62F;
        z = (bb.z0 + bb.z1) / 2.0F;
    }

    public void moveRelative(float xa, float za, float speed)
    {
        float dist = xa * xa + za * za;
        if(dist < 0.01F)
        {
            return;
        } else
        {
            dist = speed / (float)Math.sqrt(dist);
            xa *= dist;
            za *= dist;
            float sin = (float)Math.sin(((double)yRot * 3.1415926535897931D) / 180D);
            float cos = (float)Math.cos(((double)yRot * 3.1415926535897931D) / 180D);
            xd += xa * cos - za * sin;
            zd += za * cos + xa * sin;
            return;
        }
    }

    private Level level;
    public float xo;
    public float yo;
    public float zo;
    public float x;
    public float y;
    public float z;
    public float xd;
    public float yd;
    public float zd;
    public float yRot;
    public float xRot;
    public AABB bb;
    public boolean onGround;
}
