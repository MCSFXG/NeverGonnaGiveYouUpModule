// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Tesselator.java

package com.mojang.rubydung.level;

import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class Tesselator
{

    public Tesselator()
    {
        vertexBuffer = BufferUtils.createFloatBuffer(0x493e0);
        texCoordBuffer = BufferUtils.createFloatBuffer(0x30d40);
        colorBuffer = BufferUtils.createFloatBuffer(0x493e0);
        vertices = 0;
        hasColor = false;
        hasTexture = false;
    }

    public void flush()
    {
        vertexBuffer.flip();
        texCoordBuffer.flip();
        colorBuffer.flip();
        GL11.glVertexPointer(3, 0, vertexBuffer);
        if(hasTexture)
            GL11.glTexCoordPointer(2, 0, texCoordBuffer);
        if(hasColor)
            GL11.glColorPointer(3, 0, colorBuffer);
        GL11.glEnableClientState(32884);
        if(hasTexture)
            GL11.glEnableClientState(32888);
        if(hasColor)
            GL11.glEnableClientState(32886);
        GL11.glDrawArrays(7, 0, vertices);
        GL11.glDisableClientState(32884);
        if(hasTexture)
            GL11.glDisableClientState(32888);
        if(hasColor)
            GL11.glDisableClientState(32886);
        clear();
    }

    private void clear()
    {
        vertices = 0;
        vertexBuffer.clear();
        texCoordBuffer.clear();
        colorBuffer.clear();
    }

    public void init()
    {
        clear();
        hasColor = false;
        hasTexture = false;
    }

    public void tex(float u, float v)
    {
        hasTexture = true;
        this.u = u;
        this.v = v;
    }

    public void color(float r, float g, float b)
    {
        hasColor = true;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public void vertex(float x, float y, float z)
    {
        vertexBuffer.put(vertices * 3 + 0, x).put(vertices * 3 + 1, y).put(vertices * 3 + 2, z);
        if(hasTexture)
            texCoordBuffer.put(vertices * 2 + 0, u).put(vertices * 2 + 1, v);
        if(hasColor)
            colorBuffer.put(vertices * 3 + 0, r).put(vertices * 3 + 1, g).put(vertices * 3 + 2, b);
        vertices++;
        if(vertices == 0x186a0)
            flush();
    }

    private static final int MAX_VERTICES = 0x186a0;
    private FloatBuffer vertexBuffer;
    private FloatBuffer texCoordBuffer;
    private FloatBuffer colorBuffer;
    private int vertices;
    private float u;
    private float v;
    private float r;
    private float g;
    private float b;
    private boolean hasColor;
    private boolean hasTexture;
}
