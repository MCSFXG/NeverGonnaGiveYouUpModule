// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Textures.java

package com.mojang.rubydung;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import javax.imageio.ImageIO;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class Textures
{

    public Textures()
    {
    }

    public static int loadTexture(String resourceName, int mode)
    {
        IntBuffer ib;
        int id;
        BufferedImage img;
        int w;
        int h;
        ByteBuffer pixels;
        int rawPixels[];
        try
        {
            if(idMap.containsKey(resourceName))
                return ((Integer)idMap.get(resourceName)).intValue();
        }
        catch(IOException e)
        {
            throw new RuntimeException("!!");
        }
        ib = BufferUtils.createIntBuffer(1);
        GL11.glGenTextures(ib);
        id = ib.get(0);
        bind(id);
        GL11.glTexParameteri(3553, 10241, mode);
        GL11.glTexParameteri(3553, 10240, mode);
        img = ImageIO.read(com/mojang/rubydung/Textures.getResourceAsStream(resourceName));
        w = img.getWidth();
        h = img.getHeight();
        pixels = BufferUtils.createByteBuffer(w * h * 4);
        rawPixels = new int[w * h];
        img.getRGB(0, 0, w, h, rawPixels, 0, w);
        for(int i = 0; i < rawPixels.length; i++)
        {
            int a = rawPixels[i] >> 24 & 0xff;
            int r = rawPixels[i] >> 16 & 0xff;
            int g = rawPixels[i] >> 8 & 0xff;
            int b = rawPixels[i] & 0xff;
            rawPixels[i] = a << 24 | b << 16 | g << 8 | r;
        }

        pixels.asIntBuffer().put(rawPixels);
        GLU.gluBuild2DMipmaps(3553, 6408, w, h, 6408, 5121, pixels);
        return id;
    }

    public static void bind(int id)
    {
        if(id != lastId)
        {
            GL11.glBindTexture(3553, id);
            lastId = id;
        }
    }

    private static HashMap idMap = new HashMap();
    private static int lastId = 0xff676981;

}
