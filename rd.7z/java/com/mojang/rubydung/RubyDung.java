// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RubyDung.java

package com.mojang.rubydung;

import com.mojang.rubydung.level.Chunk;
import com.mojang.rubydung.level.Level;
import com.mojang.rubydung.level.LevelRenderer;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import javax.swing.JOptionPane;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;

// Referenced classes of package com.mojang.rubydung:
//            Timer, Player, HitResult

public class RubyDung
    implements Runnable
{

    public RubyDung()
    {
        fogColor = BufferUtils.createFloatBuffer(4);
        timer = new Timer(60F);
        viewportBuffer = BufferUtils.createIntBuffer(16);
        selectBuffer = BufferUtils.createIntBuffer(2000);
        hitResult = null;
    }

    public void init()
        throws LWJGLException, IOException
    {
        int col = 0xe0b0a;
        float fr = 0.5F;
        float fg = 0.8F;
        float fb = 1.0F;
        fogColor.put(new float[] {
            (float)(col >> 16 & 0xff) / 255F, (float)(col >> 8 & 0xff) / 255F, (float)(col & 0xff) / 255F, 1.0F
        });
        fogColor.flip();
        Display.setDisplayMode(new DisplayMode(1024, 768));
        Display.create();
        Keyboard.create();
        Mouse.create();
        width = Display.getDisplayMode().getWidth();
        height = Display.getDisplayMode().getHeight();
        GL11.glEnable(3553);
        GL11.glShadeModel(7425);
        GL11.glClearColor(fr, fg, fb, 0.0F);
        GL11.glClearDepth(1.0D);
        GL11.glEnable(2929);
        GL11.glDepthFunc(515);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glMatrixMode(5888);
        level = new Level(256, 256, 64);
        levelRenderer = new LevelRenderer(level);
        player = new Player(level);
        Mouse.setGrabbed(true);
    }

    public void destroy()
    {
        level.save();
        Mouse.destroy();
        Keyboard.destroy();
        Display.destroy();
    }

    public void run()
    {
        long lastTime;
        int frames;
        try
        {
            init();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.toString(), "Failed to start RubyDung", 0);
            System.exit(0);
        }
        lastTime = System.currentTimeMillis();
        frames = 0;
        try
        {
            while(!Keyboard.isKeyDown(1) && !Display.isCloseRequested()) 
            {
                timer.advanceTime();
                for(int i = 0; i < timer.ticks; i++)
                    tick();

                render(timer.a);
                for(frames++; System.currentTimeMillis() >= lastTime + 1000L; frames = 0)
                {
                    System.out.println((new StringBuilder(String.valueOf(frames))).append(" fps, ").append(Chunk.updates).toString());
                    Chunk.updates = 0;
                    lastTime += 1000L;
                }

            }
            break MISSING_BLOCK_LABEL_175;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        destroy();
        break MISSING_BLOCK_LABEL_179;
        Exception exception;
        exception;
        destroy();
        throw exception;
        destroy();
    }

    public void tick()
    {
        player.tick();
    }

    private void moveCameraToPlayer(float a)
    {
        GL11.glTranslatef(0.0F, 0.0F, -0.3F);
        GL11.glRotatef(player.xRot, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(player.yRot, 0.0F, 1.0F, 0.0F);
        float x = player.xo + (player.x - player.xo) * a;
        float y = player.yo + (player.y - player.yo) * a;
        float z = player.zo + (player.z - player.zo) * a;
        GL11.glTranslatef(-x, -y, -z);
    }

    private void setupCamera(float a)
    {
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GLU.gluPerspective(70F, (float)width / (float)height, 0.05F, 1000F);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        moveCameraToPlayer(a);
    }

    private void setupPickCamera(float a, int x, int y)
    {
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        viewportBuffer.clear();
        GL11.glGetInteger(2978, viewportBuffer);
        viewportBuffer.flip();
        viewportBuffer.limit(16);
        GLU.gluPickMatrix(x, y, 5F, 5F, viewportBuffer);
        GLU.gluPerspective(70F, (float)width / (float)height, 0.05F, 1000F);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        moveCameraToPlayer(a);
    }

    private void pick(float a)
    {
        selectBuffer.clear();
        GL11.glSelectBuffer(selectBuffer);
        GL11.glRenderMode(7170);
        setupPickCamera(a, width / 2, height / 2);
        levelRenderer.pick(player);
        int hits = GL11.glRenderMode(7168);
        selectBuffer.flip();
        selectBuffer.limit(selectBuffer.capacity());
        long closest = 0L;
        int names[] = new int[10];
        int hitNameCount = 0;
        for(int i = 0; i < hits; i++)
        {
            int nameCount = selectBuffer.get();
            long minZ = selectBuffer.get();
            selectBuffer.get();
            long dist = minZ;
            if(dist < closest || i == 0)
            {
                closest = dist;
                hitNameCount = nameCount;
                for(int j = 0; j < nameCount; j++)
                    names[j] = selectBuffer.get();

            } else
            {
                for(int j = 0; j < nameCount; j++)
                    selectBuffer.get();

            }
        }

        if(hitNameCount > 0)
            hitResult = new HitResult(names[0], names[1], names[2], names[3], names[4]);
        else
            hitResult = null;
    }

    public void render(float a)
    {
        float xo = Mouse.getDX();
        float yo = Mouse.getDY();
        player.turn(xo, yo);
        pick(a);
        while(Mouse.next()) 
        {
            if(Mouse.getEventButton() == 1 && Mouse.getEventButtonState() && hitResult != null)
                level.setTile(hitResult.x, hitResult.y, hitResult.z, 0);
            if(Mouse.getEventButton() == 0 && Mouse.getEventButtonState() && hitResult != null)
            {
                int x = hitResult.x;
                int y = hitResult.y;
                int z = hitResult.z;
                if(hitResult.f == 0)
                    y--;
                if(hitResult.f == 1)
                    y++;
                if(hitResult.f == 2)
                    z--;
                if(hitResult.f == 3)
                    z++;
                if(hitResult.f == 4)
                    x--;
                if(hitResult.f == 5)
                    x++;
                level.setTile(x, y, z, 1);
            }
        }
        while(Keyboard.next()) 
            if(Keyboard.getEventKey() == 28 && Keyboard.getEventKeyState())
                level.save();
        GL11.glClear(16640);
        setupCamera(a);
        GL11.glEnable(2884);
        GL11.glEnable(2912);
        GL11.glFogi(2917, 2048);
        GL11.glFogf(2914, 0.2F);
        GL11.glFog(2918, fogColor);
        GL11.glDisable(2912);
        levelRenderer.render(player, 0);
        GL11.glEnable(2912);
        levelRenderer.render(player, 1);
        GL11.glDisable(3553);
        if(hitResult != null)
            levelRenderer.renderHit(hitResult);
        GL11.glDisable(2912);
        Display.update();
    }

    public static void checkError()
    {
        int e = GL11.glGetError();
        if(e != 0)
            throw new IllegalStateException(GLU.gluErrorString(e));
        else
            return;
    }

    public static void main(String args[])
        throws LWJGLException
    {
        (new Thread(new RubyDung())).start();
    }

    private static final boolean FULLSCREEN_MODE = false;
    private int width;
    private int height;
    private FloatBuffer fogColor;
    private Timer timer;
    private Level level;
    private LevelRenderer levelRenderer;
    private Player player;
    private IntBuffer viewportBuffer;
    private IntBuffer selectBuffer;
    private HitResult hitResult;
}
