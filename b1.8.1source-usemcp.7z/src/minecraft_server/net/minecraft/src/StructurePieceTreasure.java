package net.minecraft.src;

public class StructurePieceTreasure extends WeightedRandomChoice {
    public int field_35489_a;
    public int field_35487_b;
    public int field_35488_c;
    public int field_35486_e;

    public StructurePieceTreasure(int var1, int var2, int var3, int var4, int var5) {
        super(var5);
        this.field_35489_a = var1;
        this.field_35487_b = var2;
        this.field_35488_c = var3;
        this.field_35486_e = var4;
    }
}
