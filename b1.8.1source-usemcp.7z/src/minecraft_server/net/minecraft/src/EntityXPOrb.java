package net.minecraft.src;

public class EntityXPOrb extends Entity {
    public int field_35159_a;
    public int field_35157_b = 0;
    public int field_35158_c;
    private int field_35156_e = 5;
    private int field_35154_f;
    public float field_35155_d = (float)(Math.random() * 3.141592653589793D * 2.0D);

    public EntityXPOrb(World var1, double var2, double var4, double var6, int var8) {
        super(var1);
        this.setSize(0.5F, 0.5F);
        this.yOffset = this.height / 2.0F;
        this.setPosition(var2, var4, var6);
        this.rotationYaw = (float)(Math.random() * 360.0D);
        this.motionX = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
        this.motionY = (double)((float)(Math.random() * 0.2D) * 2.0F);
        this.motionZ = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
        this.field_35154_f = var8;
    }

    protected boolean canTriggerWalking() {
        return false;
    }

    public EntityXPOrb(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.yOffset = this.height / 2.0F;
    }

    protected void entityInit() {
    }

    public void onUpdate() {
        super.onUpdate();
        if (this.field_35158_c > 0) {
            --this.field_35158_c;
        }

        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.029999999329447746D;
        if (this.worldObj.getBlockMaterial(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) == Material.lava) {
            this.motionY = 0.20000000298023224D;
            this.motionX = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.motionZ = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.worldObj.playSoundAtEntity(this, "random.fizz", 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
        }

        this.pushOutOfBlocks(this.posX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0D, this.posZ);
        double var1 = 8.0D;
        EntityPlayer var3 = this.worldObj.getClosestPlayerToEntity(this, var1);
        if (var3 != null) {
            double var4 = (var3.posX - this.posX) / var1;
            double var6 = (var3.posY + (double)var3.getEyeHeight() - this.posY) / var1;
            double var8 = (var3.posZ - this.posZ) / var1;
            double var10 = Math.sqrt(var4 * var4 + var6 * var6 + var8 * var8);
            double var12 = 1.0D - var10;
            if (var12 > 0.0D) {
                var12 *= var12;
                this.motionX += var4 / var10 * var12 * 0.1D;
                this.motionY += var6 / var10 * var12 * 0.1D;
                this.motionZ += var8 / var10 * var12 * 0.1D;
            }
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        float var14 = 0.98F;
        if (this.onGround) {
            var14 = 0.58800006F;
            int var5 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
            if (var5 > 0) {
                var14 = Block.blocksList[var5].slipperiness * 0.98F;
            }
        }

        this.motionX *= (double)var14;
        this.motionY *= 0.9800000190734863D;
        this.motionZ *= (double)var14;
        if (this.onGround) {
            this.motionY *= -0.8999999761581421D;
        }

        ++this.field_35159_a;
        ++this.field_35157_b;
        if (this.field_35157_b >= 6000) {
            this.setEntityDead();
        }

    }

    public boolean handleWaterMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }

    protected void dealFireDamage(int var1) {
        this.attackEntityFrom(DamageSource.field_35091_a, var1);
    }

    public boolean attackEntityFrom(DamageSource var1, int var2) {
        this.setBeenAttacked();
        this.field_35156_e -= var2;
        if (this.field_35156_e <= 0) {
            this.setEntityDead();
        }

        return false;
    }

    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("Health", (short)((byte)this.field_35156_e));
        var1.setShort("Age", (short)this.field_35157_b);
        var1.setShort("Value", (short)this.field_35154_f);
    }

    public void readEntityFromNBT(NBTTagCompound var1) {
        this.field_35156_e = var1.getShort("Health") & 255;
        this.field_35157_b = var1.getShort("Age");
        this.field_35154_f = var1.getShort("Value");
    }

    public void onCollideWithPlayer(EntityPlayer var1) {
        if (!this.worldObj.singleplayerWorld) {
            if (this.field_35158_c == 0 && var1.field_35218_w == 0) {
                var1.field_35218_w = 2;
                this.worldObj.playSoundAtEntity(this, "random.pop", 0.2F, 0.5F * ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F));
                var1.onItemPickup(this, 1);
                var1.func_35195_d(this.field_35154_f);
                this.setEntityDead();
            }

        }
    }

    public int func_35153_j_() {
        return this.field_35154_f;
    }

    public static int func_35152_b(int var0) {
        if (var0 >= 2477) {
            return 2477;
        } else if (var0 >= 1237) {
            return 1237;
        } else if (var0 >= 617) {
            return 617;
        } else if (var0 >= 307) {
            return 307;
        } else if (var0 >= 149) {
            return 149;
        } else if (var0 >= 73) {
            return 73;
        } else if (var0 >= 37) {
            return 37;
        } else if (var0 >= 17) {
            return 17;
        } else if (var0 >= 7) {
            return 7;
        } else {
            return var0 >= 3 ? 3 : 1;
        }
    }
}
