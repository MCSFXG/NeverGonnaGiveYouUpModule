package net.minecraft.src;

public class RecipesFood {
    public void addRecipes(CraftingManager var1) {
        var1.addRecipe(new ItemStack(Item.bowlSoup), "Y", "X", "#", 'X', Block.mushroomBrown, 'Y', Block.mushroomRed, '#', Item.bowlEmpty);
        var1.addRecipe(new ItemStack(Item.bowlSoup), "Y", "X", "#", 'X', Block.mushroomRed, 'Y', Block.mushroomBrown, '#', Item.bowlEmpty);
        var1.addRecipe(new ItemStack(Item.cookie, 8), "#X#", 'X', new ItemStack(Item.dyePowder, 1, 3), '#', Item.wheat);
        var1.addRecipe(new ItemStack(Block.field_35048_bs), "MMM", "MMM", "MMM", 'M', Item.field_35416_bd);
        var1.addRecipe(new ItemStack(Item.field_35412_bf), "M", 'M', Item.field_35416_bd);
    }
}
