package net.minecraft.src;

public class BiomeGenHills extends BiomeGenBase {
    protected BiomeGenHills(int var1) {
        super(var1);
    }
}
