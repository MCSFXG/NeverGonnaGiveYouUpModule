package net.minecraft.src;

// $FF: synthetic class
class Empty2 {
}
