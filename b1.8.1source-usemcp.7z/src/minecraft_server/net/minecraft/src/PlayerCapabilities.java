package net.minecraft.src;

public class PlayerCapabilities {
    public boolean field_35660_a = false;
    public boolean field_35658_b = false;
    public boolean field_35659_c = false;
    public boolean field_35657_d = false;
}
