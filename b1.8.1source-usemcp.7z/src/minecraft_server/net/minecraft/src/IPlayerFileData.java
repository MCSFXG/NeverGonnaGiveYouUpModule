package net.minecraft.src;

public interface IPlayerFileData {
    void writePlayerData(EntityPlayer var1);

    void readPlayerData(EntityPlayer var1);
}
