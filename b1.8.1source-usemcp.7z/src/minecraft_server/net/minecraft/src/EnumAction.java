package net.minecraft.src;

public enum EnumAction {
    none,
    eat,
    block,
    bow;
}
