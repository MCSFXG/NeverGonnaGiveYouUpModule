package net.minecraft.src;

public class BiomeGenRiver extends BiomeGenBase {
    public BiomeGenRiver(int var1) {
        super(var1);
        this.spawnableCreatureList.clear();
    }
}
