package net.minecraft.src;

final class StatTypeDistance implements IStatType {
}
