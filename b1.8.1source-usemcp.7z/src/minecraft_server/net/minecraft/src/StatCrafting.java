package net.minecraft.src;

public class StatCrafting extends StatBase {
    private final int field_27990_a;

    public StatCrafting(int var1, String var2, int var3) {
        super(var1, var2);
        this.field_27990_a = var3;
    }
}
