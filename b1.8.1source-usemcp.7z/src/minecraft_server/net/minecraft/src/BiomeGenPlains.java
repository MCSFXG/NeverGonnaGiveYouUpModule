package net.minecraft.src;

public class BiomeGenPlains extends BiomeGenBase {
    protected BiomeGenPlains(int var1) {
        super(var1);
        this.field_35523_u.field_35284_r = -999;
        this.field_35523_u.field_35283_s = 4;
        this.field_35523_u.field_35282_t = 10;
    }
}
