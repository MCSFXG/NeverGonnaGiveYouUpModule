package net.minecraft.src;

public class PotionHealth extends Potion {
    public PotionHealth(int var1) {
        super(var1);
    }

    public boolean func_35437_a(int var1, int var2) {
        return var1 >= 1;
    }
}
