package net.minecraft.src;

final class StatTypeTime implements IStatType {
}
