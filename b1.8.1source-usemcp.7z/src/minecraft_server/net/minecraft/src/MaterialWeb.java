package net.minecraft.src;

final class MaterialWeb extends Material {
    MaterialWeb(MapColor var1) {
        super(var1);
    }

    public boolean getIsSolid() {
        return false;
    }
}
