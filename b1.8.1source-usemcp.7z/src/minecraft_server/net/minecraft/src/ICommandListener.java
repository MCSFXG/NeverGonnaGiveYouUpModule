package net.minecraft.src;

public interface ICommandListener {
    void log(String var1);

    String getUsername();
}
