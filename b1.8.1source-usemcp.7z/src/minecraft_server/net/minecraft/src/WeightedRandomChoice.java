package net.minecraft.src;

public class WeightedRandomChoice {
    protected int field_35483_d;

    public WeightedRandomChoice(int var1) {
        this.field_35483_d = var1;
    }
}
