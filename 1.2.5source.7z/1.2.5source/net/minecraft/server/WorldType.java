// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class WorldType
{

    private WorldType(int i, String s)
    {
        this(i, s, 0);
    }

    private WorldType(int i, String s, int j)
    {
        name = s;
        version = j;
        g = true;
        types[i] = this;
    }

    public String name()
    {
        return name;
    }

    public int getVersion()
    {
        return version;
    }

    public WorldType a(int i)
    {
        if(this == NORMAL && i == 0)
            return VERSION_1_1f;
        else
            return this;
    }

    private WorldType a(boolean flag)
    {
        g = flag;
        return this;
    }

    private WorldType d()
    {
        h = true;
        return this;
    }

    public boolean c()
    {
        return h;
    }

    public static WorldType getType(String s)
    {
        for(int i = 0; i < types.length; i++)
            if(types[i] != null && types[i].name.equalsIgnoreCase(s))
                return types[i];

        return null;
    }

    public static final WorldType types[] = new WorldType[16];
    public static final WorldType NORMAL = (new WorldType(0, "default", 1)).d();
    public static final WorldType FLAT = new WorldType(1, "flat");
    public static final WorldType VERSION_1_1f = (new WorldType(8, "default_1_1", 0)).a(false);
    private final String name;
    private final int version;
    private boolean g;
    private boolean h;

}
