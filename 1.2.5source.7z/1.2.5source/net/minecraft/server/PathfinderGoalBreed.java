// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PathfinderGoalBreed.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.event.entity.CreatureSpawnEvent;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, Entity, EntityAnimal, ControllerLook, 
//            Navigation, AxisAlignedBB, World

public class PathfinderGoalBreed extends PathfinderGoal
{

    public PathfinderGoalBreed(EntityAnimal entityanimal, float f)
    {
        b = 0;
        d = entityanimal;
        a = entityanimal.world;
        c = f;
        a(3);
    }

    public boolean a()
    {
        if(!d.r_())
        {
            return false;
        } else
        {
            e = f();
            return e != null;
        }
    }

    public boolean b()
    {
        return e.isAlive() && e.r_() && b < 60;
    }

    public void d()
    {
        e = null;
        b = 0;
    }

    public void e()
    {
        d.getControllerLook().a(e, 10F, d.D());
        d.al().a(e, c);
        b++;
        if(b == 60)
            i();
    }

    private EntityAnimal f()
    {
        float f = 8F;
        List list = a.a(d.getClass(), d.boundingBox.grow(f, f, f));
        Iterator iterator = list.iterator();
        EntityAnimal entityanimal;
        do
        {
            if(!iterator.hasNext())
                return null;
            Entity entity = (Entity)iterator.next();
            entityanimal = (EntityAnimal)entity;
        } while(!d.mate(entityanimal));
        return entityanimal;
    }

    private void i()
    {
        EntityAnimal entityanimal = d.createChild(e);
        if(entityanimal != null)
        {
            d.setAge(6000);
            e.setAge(6000);
            d.s_();
            e.s_();
            entityanimal.setAge(-24000);
            entityanimal.setPositionRotation(d.locX, d.locY, d.locZ, 0.0F, 0.0F);
            a.addEntity(entityanimal, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.BREEDING);
            Random random = d.an();
            for(int i = 0; i < 7; i++)
            {
                double d0 = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                a.a("heart", (d.locX + (double)(random.nextFloat() * d.width * 2.0F)) - (double)d.width, d.locY + 0.5D + (double)(random.nextFloat() * d.length), (d.locZ + (double)(random.nextFloat() * d.width * 2.0F)) - (double)d.width, d0, d1, d2);
            }

        }
    }

    private EntityAnimal d;
    World a;
    private EntityAnimal e;
    int b;
    float c;
}
