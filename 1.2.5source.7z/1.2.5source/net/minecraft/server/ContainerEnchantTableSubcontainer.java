// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerEnchantTableSubcontainer.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            ItemStack, IInventoryListener, IInventory, EntityHuman

public class ContainerEnchantTableSubcontainer
    implements IInventory
{

    public ItemStack[] getContents()
    {
        return items;
    }

    public void onOpen(CraftHumanEntity who)
    {
        transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        transaction.remove(who);
    }

    public List getViewers()
    {
        return transaction;
    }

    public InventoryHolder getOwner()
    {
        return player;
    }

    public void setMaxStackSize(int size)
    {
        maxStack = size;
    }

    public ContainerEnchantTableSubcontainer(String s, int i)
    {
        transaction = new ArrayList();
        maxStack = 64;
        a = s;
        b = i;
        items = new ItemStack[i];
    }

    public ItemStack getItem(int i)
    {
        return items[i];
    }

    public ItemStack splitStack(int i, int j)
    {
        if(items[i] != null)
        {
            ItemStack itemstack;
            if(items[i].count <= j)
            {
                itemstack = items[i];
                items[i] = null;
                update();
                return itemstack;
            }
            itemstack = items[i].a(j);
            if(items[i].count == 0)
                items[i] = null;
            update();
            return itemstack;
        } else
        {
            return null;
        }
    }

    public ItemStack splitWithoutUpdate(int i)
    {
        if(items[i] != null)
        {
            ItemStack itemstack = items[i];
            items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        items[i] = itemstack;
        if(itemstack != null && itemstack.count > getMaxStackSize())
            itemstack.count = getMaxStackSize();
        update();
    }

    public int getSize()
    {
        return b;
    }

    public String getName()
    {
        return a;
    }

    public int getMaxStackSize()
    {
        return maxStack;
    }

    public void update()
    {
        if(d != null)
        {
            for(int i = 0; i < d.size(); i++)
                ((IInventoryListener)d.get(i)).a(this);

        }
    }

    public boolean a(EntityHuman entityhuman)
    {
        return true;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    private String a;
    private int b;
    private ItemStack items[];
    private List d;
    public List transaction;
    public Player player;
    private int maxStack;
}
