// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType

public class EnchantmentOxygen extends Enchantment
{

    public EnchantmentOxygen(int i, int j)
    {
        super(i, j, EnchantmentSlotType.ARMOR_HEAD);
        a("oxygen");
    }

    public int a(int i)
    {
        return 10 * i;
    }

    public int b(int i)
    {
        return a(i) + 30;
    }

    public int getMaxLevel()
    {
        return 3;
    }
}
