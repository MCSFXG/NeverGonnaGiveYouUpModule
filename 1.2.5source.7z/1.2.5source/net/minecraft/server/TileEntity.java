// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TileEntity.java

package net.minecraft.server;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            TileEntityFurnace, TileEntityChest, TileEntityRecordPlayer, TileEntityDispenser, 
//            TileEntitySign, TileEntityMobSpawner, TileEntityNote, TileEntityPiston, 
//            TileEntityBrewingStand, TileEntityEnchantTable, TileEntityEnderPortal, NBTTagCompound, 
//            World, Block, Packet

public class TileEntity
{

    public TileEntity()
    {
        p = -1;
    }

    private static void a(Class oclass, String s)
    {
        if(b.containsKey(s))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Duplicate id: ").append(s).toString());
        } else
        {
            a.put(s, oclass);
            b.put(oclass, s);
            return;
        }
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        x = nbttagcompound.getInt("x");
        y = nbttagcompound.getInt("y");
        z = nbttagcompound.getInt("z");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        String s = (String)b.get(getClass());
        if(s == null)
        {
            throw new RuntimeException((new StringBuilder()).append(getClass()).append(" is missing a mapping! This is a bug!").toString());
        } else
        {
            nbttagcompound.setString("id", s);
            nbttagcompound.setInt("x", x);
            nbttagcompound.setInt("y", y);
            nbttagcompound.setInt("z", z);
            return;
        }
    }

    public void q_()
    {
    }

    public static TileEntity c(NBTTagCompound nbttagcompound)
    {
        TileEntity tileentity = null;
        try
        {
            Class oclass = (Class)a.get(nbttagcompound.getString("id"));
            if(oclass != null)
                tileentity = (TileEntity)oclass.newInstance();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        if(tileentity != null)
            tileentity.a(nbttagcompound);
        else
            System.out.println((new StringBuilder()).append("Skipping TileEntity with id ").append(nbttagcompound.getString("id")).toString());
        return tileentity;
    }

    public int k()
    {
        if(p == -1)
            p = world.getData(x, y, z);
        return p;
    }

    public void update()
    {
        if(world != null)
        {
            p = world.getData(x, y, z);
            world.b(x, y, z, this);
        }
    }

    public Packet d()
    {
        return null;
    }

    public boolean l()
    {
        return o;
    }

    public void j()
    {
        o = true;
    }

    public void m()
    {
        o = false;
    }

    public void b(int i1, int j1)
    {
    }

    public void h()
    {
        q = null;
        p = -1;
    }

    public InventoryHolder getOwner()
    {
        org.bukkit.block.BlockState state = world.getWorld().getBlockAt(x, y, z).getState();
        if(state instanceof InventoryHolder)
            return (InventoryHolder)state;
        else
            return null;
    }

    private static Map a = new HashMap();
    private static Map b = new HashMap();
    public World world;
    public int x;
    public int y;
    public int z;
    protected boolean o;
    public int p;
    public net.minecraft.server.Block q;

    static 
    {
        a(net/minecraft/server/TileEntityFurnace, "Furnace");
        a(net/minecraft/server/TileEntityChest, "Chest");
        a(net/minecraft/server/TileEntityRecordPlayer, "RecordPlayer");
        a(net/minecraft/server/TileEntityDispenser, "Trap");
        a(net/minecraft/server/TileEntitySign, "Sign");
        a(net/minecraft/server/TileEntityMobSpawner, "MobSpawner");
        a(net/minecraft/server/TileEntityNote, "Music");
        a(net/minecraft/server/TileEntityPiston, "Piston");
        a(net/minecraft/server/TileEntityBrewingStand, "Cauldron");
        a(net/minecraft/server/TileEntityEnchantTable, "EnchantTable");
        a(net/minecraft/server/TileEntityEnderPortal, "Airportal");
    }
}
