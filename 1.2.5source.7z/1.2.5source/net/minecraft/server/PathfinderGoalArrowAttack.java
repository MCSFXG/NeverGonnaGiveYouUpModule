// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PathfinderGoalArrowAttack.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityArrow, EntitySnowball, EntityLiving, 
//            Navigation, AxisAlignedBB, EntitySenses, ControllerLook, 
//            World, MathHelper

public class PathfinderGoalArrowAttack extends PathfinderGoal
{

    public PathfinderGoalArrowAttack(EntityLiving entityliving, float f, int i, int j)
    {
        d = 0;
        this.f = 0;
        b = entityliving;
        a = entityliving.world;
        e = f;
        g = i;
        h = j;
        a(3);
    }

    public boolean a()
    {
        EntityLiving entityliving = b.at();
        if(entityliving == null)
        {
            return false;
        } else
        {
            c = entityliving;
            return true;
        }
    }

    public boolean b()
    {
        return a() || !b.al().e();
    }

    public void d()
    {
        org.bukkit.event.entity.EntityTargetEvent.TargetReason reason = c.isAlive() ? org.bukkit.event.entity.EntityTargetEvent.TargetReason.FORGOT_TARGET : org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_DIED;
        CraftEventFactory.callEntityTargetEvent(b, null, reason);
        c = null;
    }

    public void e()
    {
        double d0 = 100D;
        double d1 = b.e(c.locX, c.boundingBox.b, c.locZ);
        boolean flag = b.am().canSee(c);
        if(flag)
            f++;
        else
            f = 0;
        if(d1 <= d0 && f >= 20)
            b.al().f();
        else
            b.al().a(c, e);
        b.getControllerLook().a(c, 30F, 30F);
        d = Math.max(d - 1, 0);
        if(d <= 0 && d1 <= d0 && flag)
        {
            f();
            d = h;
        }
    }

    private void f()
    {
        if(g == 1)
        {
            EntityArrow entityarrow = new EntityArrow(a, b, c, 1.6F, 12F);
            a.makeSound(b, "random.bow", 1.0F, 1.0F / (b.an().nextFloat() * 0.4F + 0.8F));
            a.addEntity(entityarrow);
        } else
        if(g == 2)
        {
            EntitySnowball entitysnowball = new EntitySnowball(a, b);
            double d0 = c.locX - b.locX;
            double d1 = (c.locY + (double)c.getHeadHeight()) - 1.1000000238418579D - entitysnowball.locY;
            double d2 = c.locZ - b.locZ;
            float f = MathHelper.sqrt(d0 * d0 + d2 * d2) * 0.2F;
            entitysnowball.a(d0, d1 + (double)f, d2, 1.6F, 12F);
            a.makeSound(b, "random.bow", 1.0F, 1.0F / (b.an().nextFloat() * 0.4F + 0.8F));
            a.addEntity(entitysnowball);
        }
    }

    World a;
    EntityLiving b;
    EntityLiving c;
    int d;
    float e;
    int f;
    int g;
    int h;
}
