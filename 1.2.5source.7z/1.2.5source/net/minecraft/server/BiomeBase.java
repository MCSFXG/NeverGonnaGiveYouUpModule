// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Block, BlockGrass, WorldGenTrees, WorldGenBigTree, 
//            WorldGenForest, WorldGenSwampTree, BiomeMeta, EntitySheep, 
//            EntityPig, EntityChicken, EntityCow, EntitySpider, 
//            EntityZombie, EntitySkeleton, EntityCreeper, EntitySlime, 
//            EntityEnderman, EntitySquid, BiomeDecorator, WorldGenGrass, 
//            BlockLongGrass, EnumCreatureType, BiomeOcean, BiomePlains, 
//            BiomeDesert, BiomeBigHills, BiomeForest, BiomeTaiga, 
//            BiomeSwamp, BiomeRiver, BiomeHell, BiomeTheEnd, 
//            BiomeIcePlains, BiomeMushrooms, BiomeBeach, BiomeJungle, 
//            WorldGenerator, World

public abstract class BiomeBase
{

    protected BiomeBase(int k)
    {
        A = (byte)Block.GRASS.id;
        B = (byte)Block.DIRT.id;
        C = 0x4ee031;
        D = 0.1F;
        E = 0.3F;
        F = 0.5F;
        G = 0.5F;
        H = 0xffffff;
        J = new ArrayList();
        K = new ArrayList();
        L = new ArrayList();
        S = true;
        N = new WorldGenTrees(false);
        O = new WorldGenBigTree(false);
        P = new WorldGenForest(false);
        Q = new WorldGenSwampTree();
        id = k;
        biomes[k] = this;
        I = a();
        K.add(new BiomeMeta(net/minecraft/server/EntitySheep, 12, 4, 4));
        K.add(new BiomeMeta(net/minecraft/server/EntityPig, 10, 4, 4));
        K.add(new BiomeMeta(net/minecraft/server/EntityChicken, 10, 4, 4));
        K.add(new BiomeMeta(net/minecraft/server/EntityCow, 8, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntitySpider, 10, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntityZombie, 10, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntitySkeleton, 10, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntityCreeper, 10, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntitySlime, 10, 4, 4));
        J.add(new BiomeMeta(net/minecraft/server/EntityEnderman, 1, 1, 4));
        L.add(new BiomeMeta(net/minecraft/server/EntitySquid, 10, 4, 4));
    }

    protected BiomeDecorator a()
    {
        return new BiomeDecorator(this);
    }

    private BiomeBase a(float f1, float f2)
    {
        if(f1 > 0.1F && f1 < 0.2F)
        {
            throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
        } else
        {
            F = f1;
            G = f2;
            return this;
        }
    }

    private BiomeBase b(float f1, float f2)
    {
        D = f1;
        E = f2;
        return this;
    }

    private BiomeBase j()
    {
        S = false;
        return this;
    }

    public WorldGenerator a(Random random)
    {
        if(random.nextInt(10) == 0)
            return O;
        else
            return N;
    }

    public WorldGenerator b(Random random)
    {
        return new WorldGenGrass(Block.LONG_GRASS.id, 1);
    }

    protected BiomeBase b()
    {
        R = true;
        return this;
    }

    protected BiomeBase a(String s)
    {
        y = s;
        return this;
    }

    protected BiomeBase a(int k)
    {
        C = k;
        return this;
    }

    protected BiomeBase b(int k)
    {
        z = k;
        return this;
    }

    public List getMobs(EnumCreatureType enumcreaturetype)
    {
        if(enumcreaturetype == EnumCreatureType.MONSTER)
            return J;
        if(enumcreaturetype == EnumCreatureType.CREATURE)
            return K;
        if(enumcreaturetype == EnumCreatureType.WATER_CREATURE)
            return L;
        else
            return null;
    }

    public boolean c()
    {
        return R;
    }

    public boolean d()
    {
        if(R)
            return false;
        else
            return S;
    }

    public boolean e()
    {
        return G > 0.85F;
    }

    public float f()
    {
        return 0.1F;
    }

    public final int g()
    {
        return (int)(G * 65536F);
    }

    public final int h()
    {
        return (int)(F * 65536F);
    }

    public final float i()
    {
        return F;
    }

    public void a(World world, Random random, int k, int l)
    {
        I.a(world, random, k, l);
    }

    public static final BiomeBase biomes[] = new BiomeBase[256];
    public static final BiomeBase OCEAN = (new BiomeOcean(0)).b(112).a("Ocean").b(-1F, 0.4F);
    public static final BiomeBase PLAINS = (new BiomePlains(1)).b(0x8db360).a("Plains").a(0.8F, 0.4F);
    public static final BiomeBase DESERT = (new BiomeDesert(2)).b(0xfa9418).a("Desert").j().a(2.0F, 0.0F).b(0.1F, 0.2F);
    public static final BiomeBase EXTREME_HILLS = (new BiomeBigHills(3)).b(0x606060).a("Extreme Hills").b(0.2F, 1.3F).a(0.2F, 0.3F);
    public static final BiomeBase FOREST = (new BiomeForest(4)).b(0x56621).a("Forest").a(0x4eba31).a(0.7F, 0.8F);
    public static final BiomeBase TAIGA = (new BiomeTaiga(5)).b(0xb6659).a("Taiga").a(0x4eba31).b().a(0.05F, 0.8F).b(0.1F, 0.4F);
    public static final BiomeBase SWAMPLAND = (new BiomeSwamp(6)).b(0x7f9b2).a("Swampland").a(0x8baf48).b(-0.2F, 0.1F).a(0.8F, 0.9F);
    public static final BiomeBase RIVER = (new BiomeRiver(7)).b(255).a("River").b(-0.5F, 0.0F);
    public static final BiomeBase HELL = (new BiomeHell(8)).b(0xff0000).a("Hell").j().a(2.0F, 0.0F);
    public static final BiomeBase SKY = (new BiomeTheEnd(9)).b(0x8080ff).a("Sky").j();
    public static final BiomeBase FROZEN_OCEAN = (new BiomeOcean(10)).b(0x9090a0).a("FrozenOcean").b().b(-1F, 0.5F).a(0.0F, 0.5F);
    public static final BiomeBase FROZEN_RIVER = (new BiomeRiver(11)).b(0xa0a0ff).a("FrozenRiver").b().b(-0.5F, 0.0F).a(0.0F, 0.5F);
    public static final BiomeBase ICE_PLAINS = (new BiomeIcePlains(12)).b(0xffffff).a("Ice Plains").b().a(0.0F, 0.5F);
    public static final BiomeBase ICE_MOUNTAINS = (new BiomeIcePlains(13)).b(0xa0a0a0).a("Ice Mountains").b().b(0.2F, 1.2F).a(0.0F, 0.5F);
    public static final BiomeBase MUSHROOM_ISLAND = (new BiomeMushrooms(14)).b(0xff00ff).a("MushroomIsland").a(0.9F, 1.0F).b(0.2F, 1.0F);
    public static final BiomeBase MUSHROOM_SHORE = (new BiomeMushrooms(15)).b(0xa000ff).a("MushroomIslandShore").a(0.9F, 1.0F).b(-1F, 0.1F);
    public static final BiomeBase BEACH = (new BiomeBeach(16)).b(0xfade55).a("Beach").a(0.8F, 0.4F).b(0.0F, 0.1F);
    public static final BiomeBase DESERT_HILLS = (new BiomeDesert(17)).b(0xd25f12).a("DesertHills").j().a(2.0F, 0.0F).b(0.2F, 0.7F);
    public static final BiomeBase FOREST_HILLS = (new BiomeForest(18)).b(0x22551c).a("ForestHills").a(0x4eba31).a(0.7F, 0.8F).b(0.2F, 0.6F);
    public static final BiomeBase TAIGA_HILLS = (new BiomeTaiga(19)).b(0x163933).a("TaigaHills").b().a(0x4eba31).a(0.05F, 0.8F).b(0.2F, 0.7F);
    public static final BiomeBase SMALL_MOUNTAINS = (new BiomeBigHills(20)).b(0x72789a).a("Extreme Hills Edge").b(0.2F, 0.8F).a(0.2F, 0.3F);
    public static final BiomeBase JUNGLE = (new BiomeJungle(21)).b(0x537b09).a("Jungle").a(0x537b09).a(1.2F, 0.9F).b(0.2F, 0.4F);
    public static final BiomeBase JUNGLE_HILLS = (new BiomeJungle(22)).b(0x2c4205).a("JungleHills").a(0x537b09).a(1.2F, 0.9F).b(1.8F, 0.2F);
    public String y;
    public int z;
    public byte A;
    public byte B;
    public int C;
    public float D;
    public float E;
    public float F;
    public float G;
    public int H;
    public BiomeDecorator I;
    protected List J;
    protected List K;
    protected List L;
    private boolean R;
    private boolean S;
    public final int id;
    protected WorldGenTrees N;
    protected WorldGenBigTree O;
    protected WorldGenForest P;
    protected WorldGenSwampTree Q;

}
