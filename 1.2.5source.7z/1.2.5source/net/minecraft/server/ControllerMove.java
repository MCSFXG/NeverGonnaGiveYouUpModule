// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityLiving, AxisAlignedBB, MathHelper, ControllerJump

public class ControllerMove
{

    public ControllerMove(EntityLiving entityliving)
    {
        f = false;
        a = entityliving;
        b = entityliving.locX;
        c = entityliving.locY;
        d = entityliving.locZ;
    }

    public boolean a()
    {
        return f;
    }

    public float b()
    {
        return e;
    }

    public void a(double d1, double d2, double d3, float f1)
    {
        b = d1;
        c = d2;
        d = d3;
        e = f1;
        f = true;
    }

    public void c()
    {
        a.e(0.0F);
        if(!f)
            return;
        f = false;
        int i = MathHelper.floor(a.boundingBox.b + 0.5D);
        double d1 = b - a.locX;
        double d2 = d - a.locZ;
        double d3 = c - (double)i;
        double d4 = d1 * d1 + d3 * d3 + d2 * d2;
        if(d4 < 2.5000002779052011E-007D)
            return;
        float f1 = (float)((Math.atan2(d2, d1) * 180D) / 3.1415927410125732D) - 90F;
        a.yaw = a(a.yaw, f1, 30F);
        a.d(e);
        if(d3 > 0.0D && d1 * d1 + d2 * d2 < 1.0D)
            a.getControllerJump().a();
    }

    private float a(float f1, float f2, float f3)
    {
        float f4;
        for(f4 = f2 - f1; f4 < -180F; f4 += 360F);
        for(; f4 >= 180F; f4 -= 360F);
        if(f4 > f3)
            f4 = f3;
        if(f4 < -f3)
            f4 = -f3;
        return f1 + f4;
    }

    private EntityLiving a;
    private double b;
    private double c;
    private double d;
    private float e;
    private boolean f;
}
