// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerChest.java

package net.minecraft.server;

import java.util.List;
import org.bukkit.craftbukkit.inventory.*;
import org.bukkit.inventory.InventoryView;

// Referenced classes of package net.minecraft.server:
//            Container, PlayerInventory, InventoryLargeChest, Slot, 
//            ItemStack, EntityHuman, IInventory

public class ContainerChest extends Container
{

    public CraftInventoryView getBukkitView()
    {
        if(bukkitEntity != null)
            return bukkitEntity;
        CraftInventory inventory;
        if(container instanceof PlayerInventory)
            inventory = new CraftInventoryPlayer((PlayerInventory)container);
        else
        if(container instanceof InventoryLargeChest)
            inventory = new CraftInventoryDoubleChest((InventoryLargeChest)container);
        else
            inventory = new CraftInventory(container);
        bukkitEntity = new CraftInventoryView(player.player.getBukkitEntity(), inventory, this);
        return bukkitEntity;
    }

    public ContainerChest(IInventory iinventory, IInventory iinventory1)
    {
        bukkitEntity = null;
        container = iinventory1;
        b = iinventory1.getSize() / 9;
        iinventory1.f();
        int i = (b - 4) * 18;
        player = (PlayerInventory)iinventory;
        for(int j = 0; j < b; j++)
        {
            for(int k = 0; k < 9; k++)
                a(new Slot(iinventory1, k + j * 9, 8 + k * 18, 18 + j * 18));

        }

        for(int j = 0; j < 3; j++)
        {
            for(int k = 0; k < 9; k++)
                a(new Slot(iinventory, k + j * 9 + 9, 8 + k * 18, 103 + j * 18 + i));

        }

        for(int j = 0; j < 9; j++)
            a(new Slot(iinventory, j, 8 + j * 18, 161 + i));

    }

    public boolean b(EntityHuman entityhuman)
    {
        if(!checkReachable)
            return true;
        else
            return container.a(entityhuman);
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i < b * 9)
            {
                if(!a(itemstack1, b * 9, e.size(), true))
                    return null;
            } else
            if(!a(itemstack1, 0, b * 9, false))
                return null;
            if(itemstack1.count == 0)
                slot.set((ItemStack)null);
            else
                slot.d();
        }
        return itemstack;
    }

    public void a(EntityHuman entityhuman)
    {
        super.a(entityhuman);
        container.g();
    }

    public volatile InventoryView getBukkitView()
    {
        return getBukkitView();
    }

    public IInventory container;
    private int b;
    private CraftInventoryView bukkitEntity;
    private PlayerInventory player;
}
