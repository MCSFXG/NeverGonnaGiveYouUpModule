// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, PlayerAbilities, NetHandler

public class Packet202Abilities extends Packet
{

    public Packet202Abilities()
    {
        a = false;
        b = false;
        c = false;
        d = false;
    }

    public Packet202Abilities(PlayerAbilities playerabilities)
    {
        a = false;
        b = false;
        c = false;
        d = false;
        a = playerabilities.isInvulnerable;
        b = playerabilities.isFlying;
        c = playerabilities.canFly;
        d = playerabilities.canInstantlyBuild;
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readBoolean();
        b = datainputstream.readBoolean();
        c = datainputstream.readBoolean();
        d = datainputstream.readBoolean();
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeBoolean(a);
        dataoutputstream.writeBoolean(b);
        dataoutputstream.writeBoolean(c);
        dataoutputstream.writeBoolean(d);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 1;
    }

    public boolean a;
    public boolean b;
    public boolean c;
    public boolean d;
}
