// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package net.minecraft.server:
//            MonsterEggInfo, World, Entity, NBTTagCompound, 
//            EntityItem, EntityExperienceOrb, EntityPainting, EntityArrow, 
//            EntitySnowball, EntityFireball, EntitySmallFireball, EntityEnderPearl, 
//            EntityEnderSignal, EntityPotion, EntityThrownExpBottle, EntityTNTPrimed, 
//            EntityFallingBlock, EntityMinecart, EntityBoat, EntityLiving, 
//            EntityMonster, EntityCreeper, EntitySkeleton, EntitySpider, 
//            EntityGiantZombie, EntityZombie, EntitySlime, EntityGhast, 
//            EntityPigZombie, EntityEnderman, EntityCaveSpider, EntitySilverfish, 
//            EntityBlaze, EntityMagmaCube, EntityEnderDragon, EntityPig, 
//            EntitySheep, EntityCow, EntityChicken, EntitySquid, 
//            EntityWolf, EntityMushroomCow, EntitySnowman, EntityOcelot, 
//            EntityIronGolem, EntityVillager, EntityEnderCrystal

public class EntityTypes
{

    public EntityTypes()
    {
    }

    private static void a(Class class1, String s, int i)
    {
        b.put(s, class1);
        c.put(class1, s);
        d.put(Integer.valueOf(i), class1);
        e.put(class1, Integer.valueOf(i));
        f.put(s, Integer.valueOf(i));
    }

    private static void a(Class class1, String s, int i, int j, int k)
    {
        a(class1, s, i);
        a.put(Integer.valueOf(i), new MonsterEggInfo(i, j, k));
    }

    public static Entity createEntityByName(String s, World world)
    {
        Entity entity = null;
        try
        {
            Class class1 = (Class)b.get(s);
            if(class1 != null)
                entity = (Entity)class1.getConstructor(new Class[] {
                    net/minecraft/server/World
                }).newInstance(new Object[] {
                    world
                });
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return entity;
    }

    public static Entity a(NBTTagCompound nbttagcompound, World world)
    {
        Entity entity = null;
        try
        {
            Class class1 = (Class)b.get(nbttagcompound.getString("id"));
            if(class1 != null)
                entity = (Entity)class1.getConstructor(new Class[] {
                    net/minecraft/server/World
                }).newInstance(new Object[] {
                    world
                });
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        if(entity != null)
            entity.e(nbttagcompound);
        else
            System.out.println((new StringBuilder()).append("Skipping Entity with id ").append(nbttagcompound.getString("id")).toString());
        return entity;
    }

    public static Entity a(int i, World world)
    {
        Entity entity = null;
        try
        {
            Class class1 = (Class)d.get(Integer.valueOf(i));
            if(class1 != null)
                entity = (Entity)class1.getConstructor(new Class[] {
                    net/minecraft/server/World
                }).newInstance(new Object[] {
                    world
                });
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        if(entity == null)
            System.out.println((new StringBuilder()).append("Skipping Entity with id ").append(i).toString());
        return entity;
    }

    public static int a(Entity entity)
    {
        return ((Integer)e.get(entity.getClass())).intValue();
    }

    public static String b(Entity entity)
    {
        return (String)c.get(entity.getClass());
    }

    public static int a(String s)
    {
        Integer integer = (Integer)f.get(s);
        if(integer == null)
            return 90;
        else
            return integer.intValue();
    }

    private static Map b = new HashMap();
    private static Map c = new HashMap();
    private static Map d = new HashMap();
    private static Map e = new HashMap();
    private static Map f = new HashMap();
    public static HashMap a = new HashMap();

    static 
    {
        a(net/minecraft/server/EntityItem, "Item", 1);
        a(net/minecraft/server/EntityExperienceOrb, "XPOrb", 2);
        a(net/minecraft/server/EntityPainting, "Painting", 9);
        a(net/minecraft/server/EntityArrow, "Arrow", 10);
        a(net/minecraft/server/EntitySnowball, "Snowball", 11);
        a(net/minecraft/server/EntityFireball, "Fireball", 12);
        a(net/minecraft/server/EntitySmallFireball, "SmallFireball", 13);
        a(net/minecraft/server/EntityEnderPearl, "ThrownEnderpearl", 14);
        a(net/minecraft/server/EntityEnderSignal, "EyeOfEnderSignal", 15);
        a(net/minecraft/server/EntityPotion, "ThrownPotion", 16);
        a(net/minecraft/server/EntityThrownExpBottle, "ThrownExpBottle", 17);
        a(net/minecraft/server/EntityTNTPrimed, "PrimedTnt", 20);
        a(net/minecraft/server/EntityFallingBlock, "FallingSand", 21);
        a(net/minecraft/server/EntityMinecart, "Minecart", 40);
        a(net/minecraft/server/EntityBoat, "Boat", 41);
        a(net/minecraft/server/EntityLiving, "Mob", 48);
        a(net/minecraft/server/EntityMonster, "Monster", 49);
        a(net/minecraft/server/EntityCreeper, "Creeper", 50, 0xda70b, 0);
        a(net/minecraft/server/EntitySkeleton, "Skeleton", 51, 0xc1c1c1, 0x494949);
        a(net/minecraft/server/EntitySpider, "Spider", 52, 0x342d27, 0xa80e0e);
        a(net/minecraft/server/EntityGiantZombie, "Giant", 53);
        a(net/minecraft/server/EntityZombie, "Zombie", 54, 44975, 0x799c65);
        a(net/minecraft/server/EntitySlime, "Slime", 55, 0x51a03e, 0x7ebf6e);
        a(net/minecraft/server/EntityGhast, "Ghast", 56, 0xf9f9f9, 0xbcbcbc);
        a(net/minecraft/server/EntityPigZombie, "PigZombie", 57, 0xea9393, 0x4c7129);
        a(net/minecraft/server/EntityEnderman, "Enderman", 58, 0x161616, 0);
        a(net/minecraft/server/EntityCaveSpider, "CaveSpider", 59, 0xc424e, 0xa80e0e);
        a(net/minecraft/server/EntitySilverfish, "Silverfish", 60, 0x6e6e6e, 0x303030);
        a(net/minecraft/server/EntityBlaze, "Blaze", 61, 0xf6b201, 0xfff87e);
        a(net/minecraft/server/EntityMagmaCube, "LavaSlime", 62, 0x340000, 0xfcfc00);
        a(net/minecraft/server/EntityEnderDragon, "EnderDragon", 63);
        a(net/minecraft/server/EntityPig, "Pig", 90, 0xf0a5a2, 0xdb635f);
        a(net/minecraft/server/EntitySheep, "Sheep", 91, 0xe7e7e7, 0xffb5b5);
        a(net/minecraft/server/EntityCow, "Cow", 92, 0x443626, 0xa1a1a1);
        a(net/minecraft/server/EntityChicken, "Chicken", 93, 0xa1a1a1, 0xff0000);
        a(net/minecraft/server/EntitySquid, "Squid", 94, 0x223b4d, 0x708899);
        a(net/minecraft/server/EntityWolf, "Wolf", 95, 0xd7d3d3, 0xceaf96);
        a(net/minecraft/server/EntityMushroomCow, "MushroomCow", 96, 0xa00f10, 0xb7b7b7);
        a(net/minecraft/server/EntitySnowman, "SnowMan", 97);
        a(net/minecraft/server/EntityOcelot, "Ozelot", 98, 0xefde7d, 0x564434);
        a(net/minecraft/server/EntityIronGolem, "VillagerGolem", 99);
        a(net/minecraft/server/EntityVillager, "Villager", 120, 0x563c33, 0xbd8b72);
        a(net/minecraft/server/EntityEnderCrystal, "EnderCrystal", 200);
    }
}
