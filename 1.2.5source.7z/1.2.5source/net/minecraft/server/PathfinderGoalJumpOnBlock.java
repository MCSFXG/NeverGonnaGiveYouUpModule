// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityOcelot, Navigation, PathfinderGoalSit, 
//            World, Block, TileEntityChest, BlockBed

public class PathfinderGoalJumpOnBlock extends PathfinderGoal
{

    public PathfinderGoalJumpOnBlock(EntityOcelot entityocelot, float f1)
    {
        c = 0;
        h = 0;
        d = 0;
        e = 0;
        f = 0;
        g = 0;
        a = entityocelot;
        b = f1;
        a(5);
    }

    public boolean a()
    {
        return a.isTamed() && !a.isSitting() && a.an().nextDouble() <= 0.0065000001341104507D && f();
    }

    public boolean b()
    {
        return c <= d && h <= 60 && a(a.world, e, f, g);
    }

    public void c()
    {
        a.al().a((double)(float)e + 0.5D, f + 1, (double)(float)g + 0.5D, b);
        c = 0;
        h = 0;
        d = a.an().nextInt(a.an().nextInt(1200) + 1200) + 1200;
        a.C().a(false);
    }

    public void d()
    {
        a.setSitting(false);
    }

    public void e()
    {
        c++;
        a.C().a(false);
        if(a.e(e, f + 1, g) > 1.0D)
        {
            a.setSitting(false);
            a.al().a((double)(float)e + 0.5D, f + 1, (double)(float)g + 0.5D, b);
            h++;
        } else
        if(!a.isSitting())
            a.setSitting(true);
        else
            h--;
    }

    private boolean f()
    {
        int i = (int)a.locY;
        double d1 = 2147483647D;
        for(int j = (int)a.locX - 8; (double)j < a.locX + 8D; j++)
        {
            for(int k = (int)a.locZ - 8; (double)k < a.locZ + 8D; k++)
            {
                if(!a(a.world, j, i, k) || !a.world.isEmpty(j, i + 1, k))
                    continue;
                double d2 = a.e(j, i, k);
                if(d2 < d1)
                {
                    e = j;
                    f = i;
                    g = k;
                    d1 = d2;
                }
            }

        }

        return d1 < 2147483647D;
    }

    private boolean a(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j, k);
        int i1 = world.getData(i, j, k);
        if(l == Block.CHEST.id)
        {
            TileEntityChest tileentitychest = (TileEntityChest)world.getTileEntity(i, j, k);
            if(tileentitychest.h < 1)
                return true;
        } else
        {
            if(l == Block.BURNING_FURNACE.id)
                return true;
            if(l == Block.BED.id && !BlockBed.d(i1))
                return true;
        }
        return false;
    }

    private final EntityOcelot a;
    private final float b;
    private int c;
    private int h;
    private int d;
    private int e;
    private int f;
    private int g;
}
