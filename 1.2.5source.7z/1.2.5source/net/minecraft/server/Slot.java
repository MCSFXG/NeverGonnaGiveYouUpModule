// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Slot.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemStack, IInventory

public class Slot
{

    public Slot(IInventory iinventory, int i, int j, int k)
    {
        inventory = iinventory;
        index = i;
        d = j;
        e = k;
    }

    public void a(ItemStack itemstack, ItemStack itemstack1)
    {
        if(itemstack != null && itemstack1 != null && itemstack.id == itemstack1.id)
        {
            int i = itemstack1.count - itemstack.count;
            if(i > 0)
                a(itemstack, i);
        }
    }

    protected void a(ItemStack itemstack1, int j)
    {
    }

    protected void b(ItemStack itemstack1)
    {
    }

    public void c(ItemStack itemstack)
    {
        d();
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        return true;
    }

    public ItemStack getItem()
    {
        return inventory.getItem(index);
    }

    public boolean c()
    {
        return getItem() != null;
    }

    public void set(ItemStack itemstack)
    {
        inventory.setItem(index, itemstack);
        d();
    }

    public void d()
    {
        inventory.update();
    }

    public int a()
    {
        return inventory.getMaxStackSize();
    }

    public ItemStack a(int i)
    {
        return inventory.splitStack(index, i);
    }

    public boolean a(IInventory iinventory, int i)
    {
        return iinventory == inventory && i == index;
    }

    public final int index;
    public final IInventory inventory;
    public int c;
    public int d;
    public int e;
}
