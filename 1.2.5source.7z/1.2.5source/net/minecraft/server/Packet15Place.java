// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler, ItemStack

public class Packet15Place extends Packet
{

    public Packet15Place()
    {
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readInt();
        b = datainputstream.read();
        c = datainputstream.readInt();
        face = datainputstream.read();
        itemstack = b(datainputstream);
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeInt(a);
        dataoutputstream.write(b);
        dataoutputstream.writeInt(c);
        dataoutputstream.write(face);
        a(itemstack, dataoutputstream);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 15;
    }

    public int a;
    public int b;
    public int c;
    public int face;
    public ItemStack itemstack;
}
