// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityEnderPearl.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityProjectile, EntityPlayer, MovingObjectPosition, DamageSource, 
//            Entity, World, EntityLiving, NetServerHandler

public class EntityEnderPearl extends EntityProjectile
{

    public EntityEnderPearl(World world)
    {
        super(world);
    }

    public EntityEnderPearl(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityEnderPearl(World world, double d0, double d1, double d2)
    {
        super(world, d0, d1, d2);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(movingobjectposition.entity != null)
            if(!movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), 0));
        for(int i = 0; i < 32; i++)
            world.a("portal", locX, locY + random.nextDouble() * 2D, locZ, random.nextGaussian(), 0.0D, random.nextGaussian());

        if(!world.isStatic)
        {
            boolean teleport = false;
            PlayerTeleportEvent teleEvent = null;
            if(shooter != null)
                if(shooter instanceof EntityPlayer)
                {
                    CraftPlayer player = (CraftPlayer)shooter.bukkitEntity;
                    teleport = player.isOnline() && player.getWorld() == getBukkitEntity().getWorld();
                    Location location = getBukkitEntity().getLocation();
                    location.setPitch(player.getLocation().getPitch());
                    location.setYaw(player.getLocation().getYaw());
                    if(teleport)
                    {
                        teleEvent = new PlayerTeleportEvent(player, player.getLocation(), location, org.bukkit.event.player.PlayerTeleportEvent.TeleportCause.ENDER_PEARL);
                        Bukkit.getPluginManager().callEvent(teleEvent);
                        teleport = !teleEvent.isCancelled();
                    }
                } else
                {
                    teleport = true;
                }
            if(teleport)
            {
                if(shooter instanceof EntityPlayer)
                    ((EntityPlayer)shooter).netServerHandler.teleport(teleEvent.getTo());
                else
                    shooter.enderTeleportTo(locX, locY, locZ);
                shooter.fallDistance = 0.0F;
                EntityDamageByEntityEvent damageEvent = new EntityDamageByEntityEvent(getBukkitEntity(), shooter.getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL, 5);
                Bukkit.getPluginManager().callEvent(damageEvent);
                if(!damageEvent.isCancelled())
                {
                    org.bukkit.entity.Player bPlayer = Bukkit.getPlayerExact(((EntityPlayer)shooter).name);
                    ((CraftPlayer)bPlayer).getHandle().invulnerableTicks = -1;
                    ((CraftPlayer)bPlayer).getHandle().damageEntity(DamageSource.FALL, damageEvent.getDamage());
                }
            }
            die();
        }
    }
}
