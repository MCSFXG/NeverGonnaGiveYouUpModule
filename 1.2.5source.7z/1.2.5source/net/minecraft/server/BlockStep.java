// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, IBlockAccess, World, 
//            ItemStack, AxisAlignedBB

public class BlockStep extends Block
{

    public BlockStep(int i, boolean flag)
    {
        super(i, 6, Material.STONE);
        b = flag;
        if(!flag)
            a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        else
            n[i] = true;
        f(255);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if(b)
        {
            a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        } else
        {
            boolean flag = (iblockaccess.getData(i, j, k) & 8) != 0;
            if(flag)
                a(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
            else
                a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        }
    }

    public void f()
    {
        if(b)
            a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        else
            a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
    }

    public void a(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, ArrayList arraylist)
    {
        updateShape(world, i, j, k);
        super.a(world, i, j, k, axisalignedbb, arraylist);
    }

    public int a(int i, int j)
    {
        int k = j & 7;
        if(k == 0)
            return i > 1 ? 5 : 6;
        if(k == 1)
        {
            if(i == 0)
                return 208;
            return i != 1 ? 192 : 176;
        }
        if(k == 2)
            return 4;
        if(k == 3)
            return 16;
        if(k == 4)
            return Block.BRICK.textureId;
        if(k == 5)
            return Block.SMOOTH_BRICK.textureId;
        else
            return 6;
    }

    public int a(int i)
    {
        return a(i, 0);
    }

    public boolean a()
    {
        return b;
    }

    public void postPlace(World world, int i, int j, int k, int l)
    {
        if(l == 0 && !b)
        {
            int i1 = world.getData(i, j, k) & 7;
            world.setData(i, j, k, i1 | 8);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.STEP.id;
    }

    public int a(Random random)
    {
        return !b ? 1 : 2;
    }

    protected int getDropData(int i)
    {
        return i & 7;
    }

    public boolean b()
    {
        return b;
    }

    protected ItemStack a_(int i)
    {
        return new ItemStack(Block.STEP.id, 1, i & 7);
    }

    public static final String a[] = {
        "stone", "sand", "wood", "cobble", "brick", "smoothStoneBrick"
    };
    private boolean b;

}
