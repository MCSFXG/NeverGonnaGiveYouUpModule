// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package net.minecraft.server:
//            WorldLoader, ServerNBTManager, WorldData, IProgressUpdate, 
//            WorldType, WorldChunkManagerHell, BiomeBase, WorldChunkManager, 
//            IDataManager, RegionFile, NBTCompressedStreamTools, NBTTagCompound, 
//            OldChunkLoader, ChunkFilenameFilter

public class WorldLoaderServer extends WorldLoader
{

    public WorldLoaderServer(File file)
    {
        super(file);
    }

    protected int a()
    {
        return 19133;
    }

    public IDataManager a(String s, boolean flag)
    {
        return new ServerNBTManager(a, s, flag);
    }

    public boolean isConvertable(String s)
    {
        WorldData worlddata = b(s);
        return worlddata != null && worlddata.h() != a();
    }

    public boolean convert(String s, IProgressUpdate iprogressupdate)
    {
        iprogressupdate.a(0);
        ArrayList arraylist = new ArrayList();
        ArrayList arraylist1 = new ArrayList();
        ArrayList arraylist2 = new ArrayList();
        File file = new File(a, s);
        File file1 = new File(file, "DIM-1");
        File file2 = new File(file, "DIM1");
        System.out.println("Scanning folders...");
        a(file, arraylist);
        if(file1.exists())
            a(file1, arraylist1);
        if(file2.exists())
            a(file2, arraylist2);
        int i = arraylist.size() + arraylist1.size() + arraylist2.size();
        System.out.println((new StringBuilder()).append("Total conversion count is ").append(i).toString());
        WorldData worlddata = b(s);
        Object obj = null;
        if(worlddata.getType() == WorldType.FLAT)
            obj = new WorldChunkManagerHell(BiomeBase.PLAINS, 0.5F, 0.5F);
        else
            obj = new WorldChunkManager(worlddata.getSeed(), worlddata.getType());
        a(new File(file, "region"), arraylist, ((WorldChunkManager) (obj)), 0, i, iprogressupdate);
        a(new File(file1, "region"), arraylist1, new WorldChunkManagerHell(BiomeBase.HELL, 1.0F, 0.0F), arraylist.size(), i, iprogressupdate);
        a(new File(file2, "region"), arraylist2, new WorldChunkManagerHell(BiomeBase.SKY, 0.5F, 0.0F), arraylist.size() + arraylist1.size(), i, iprogressupdate);
        worlddata.a(19133);
        if(worlddata.getType() == WorldType.VERSION_1_1f)
            worlddata.setType(WorldType.NORMAL);
        c(s);
        IDataManager idatamanager = a(s, false);
        idatamanager.saveWorldData(worlddata);
        return true;
    }

    private void c(String s)
    {
        File file = new File(a, s);
        if(!file.exists())
        {
            System.out.println("Warning: Unable to create level.dat_mcr backup");
            return;
        }
        File file1 = new File(file, "level.dat");
        if(!file1.exists())
        {
            System.out.println("Warning: Unable to create level.dat_mcr backup");
            return;
        }
        File file2 = new File(file, "level.dat_mcr");
        if(!file1.renameTo(file2))
            System.out.println("Warning: Unable to create level.dat_mcr backup");
    }

    private void a(File file, ArrayList arraylist, WorldChunkManager worldchunkmanager, int i, int j, IProgressUpdate iprogressupdate)
    {
        int k;
        for(Iterator iterator = arraylist.iterator(); iterator.hasNext(); iprogressupdate.a(k))
        {
            File file1 = (File)iterator.next();
            a(file, file1, worldchunkmanager, i, j, iprogressupdate);
            i++;
            k = (int)Math.round((100D * (double)i) / (double)j);
        }

    }

    private void a(File file, File file1, WorldChunkManager worldchunkmanager, int i, int j, IProgressUpdate iprogressupdate)
    {
        try
        {
            String s = file1.getName();
            RegionFile regionfile = new RegionFile(file1);
            RegionFile regionfile1 = new RegionFile(new File(file, (new StringBuilder()).append(s.substring(0, s.length() - ".mcr".length())).append(".mca").toString()));
            for(int k = 0; k < 32; k++)
            {
                for(int l = 0; l < 32; l++)
                {
                    if(!regionfile.c(k, l) || regionfile1.c(k, l))
                        continue;
                    DataInputStream datainputstream = regionfile.a(k, l);
                    if(datainputstream == null)
                    {
                        System.out.println("Failed to fetch input stream");
                    } else
                    {
                        NBTTagCompound nbttagcompound = NBTCompressedStreamTools.a(datainputstream);
                        datainputstream.close();
                        NBTTagCompound nbttagcompound1 = nbttagcompound.getCompound("Level");
                        OldChunk oldchunk = OldChunkLoader.a(nbttagcompound1);
                        NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                        NBTTagCompound nbttagcompound3 = new NBTTagCompound();
                        nbttagcompound2.set("Level", nbttagcompound3);
                        OldChunkLoader.a(oldchunk, nbttagcompound3, worldchunkmanager);
                        DataOutputStream dataoutputstream = regionfile1.b(k, l);
                        NBTCompressedStreamTools.a(nbttagcompound2, dataoutputstream);
                        dataoutputstream.close();
                    }
                }

                int i1 = (int)Math.round((100D * (double)(i * 1024)) / (double)(j * 1024));
                int j1 = (int)Math.round((100D * (double)((k + 1) * 32 + i * 1024)) / (double)(j * 1024));
                if(j1 > i1)
                    iprogressupdate.a(j1);
            }

            regionfile.a();
            regionfile1.a();
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
    }

    private void a(File file, ArrayList arraylist)
    {
        File file1 = new File(file, "region");
        File afile[] = file1.listFiles(new ChunkFilenameFilter(this));
        if(afile != null)
        {
            File afile1[] = afile;
            int i = afile1.length;
            for(int j = 0; j < i; j++)
            {
                File file2 = afile1[j];
                arraylist.add(file2);
            }

        }
    }
}
