// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, PathfinderGoalSit, DataWatcher, NBTTagCompound, 
//            World, EntityLiving

public abstract class EntityTameableAnimal extends EntityAnimal
{

    public EntityTameableAnimal(World world)
    {
        super(world);
        a = new PathfinderGoalSit(this);
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
        datawatcher.a(17, "");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        if(getOwnerName() == null)
            nbttagcompound.setString("Owner", "");
        else
            nbttagcompound.setString("Owner", getOwnerName());
        nbttagcompound.setBoolean("Sitting", isSitting());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        String s = nbttagcompound.getString("Owner");
        if(s.length() > 0)
        {
            setOwnerName(s);
            setTamed(true);
        }
        a.a(nbttagcompound.getBoolean("Sitting"));
    }

    protected void a(boolean flag)
    {
        String s = "heart";
        if(!flag)
            s = "smoke";
        for(int i = 0; i < 7; i++)
        {
            double d = random.nextGaussian() * 0.02D;
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            world.a(s, (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + 0.5D + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, d, d1, d2);
        }

    }

    public boolean isTamed()
    {
        return (datawatcher.getByte(16) & 4) != 0;
    }

    public void setTamed(boolean flag)
    {
        byte byte0 = datawatcher.getByte(16);
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)(byte0 | 4)));
        else
            datawatcher.watch(16, Byte.valueOf((byte)(byte0 & -5)));
    }

    public boolean isSitting()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    public void setSitting(boolean flag)
    {
        byte byte0 = datawatcher.getByte(16);
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)(byte0 | 1)));
        else
            datawatcher.watch(16, Byte.valueOf((byte)(byte0 & -2)));
    }

    public String getOwnerName()
    {
        return datawatcher.getString(17);
    }

    public void setOwnerName(String s)
    {
        datawatcher.watch(17, s);
    }

    public EntityLiving getOwner()
    {
        return world.a(getOwnerName());
    }

    public PathfinderGoalSit C()
    {
        return a;
    }

    protected PathfinderGoalSit a;
}
