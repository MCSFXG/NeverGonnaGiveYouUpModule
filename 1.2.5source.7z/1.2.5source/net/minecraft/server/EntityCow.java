// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityCow.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Location;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.inventory.ItemStack;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, PathfinderGoalFloat, PathfinderGoalPanic, PathfinderGoalBreed, 
//            PathfinderGoalTempt, PathfinderGoalFollowParent, PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, 
//            EntityHuman, PathfinderGoalRandomLookaround, Navigation, PathfinderGoalSelector, 
//            Item, PlayerInventory, ItemStack, World, 
//            NBTTagCompound

public class EntityCow extends EntityAnimal
{

    public EntityCow(World world)
    {
        super(world);
        texture = "/mob/cow.png";
        b(0.9F, 1.3F);
        al().a(true);
        goalSelector.a(0, new PathfinderGoalFloat(this));
        goalSelector.a(1, new PathfinderGoalPanic(this, 0.38F));
        goalSelector.a(2, new PathfinderGoalBreed(this, 0.2F));
        goalSelector.a(3, new PathfinderGoalTempt(this, 0.25F, Item.WHEAT.id, false));
        goalSelector.a(4, new PathfinderGoalFollowParent(this, 0.25F));
        goalSelector.a(5, new PathfinderGoalRandomStroll(this, 0.2F));
        goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 6F));
        goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
    }

    public boolean c_()
    {
        return true;
    }

    public int getMaxHealth()
    {
        return 10;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected String i()
    {
        return "mob.cow";
    }

    protected String j()
    {
        return "mob.cowhurt";
    }

    protected String k()
    {
        return "mob.cowhurt";
    }

    protected float p()
    {
        return 0.4F;
    }

    protected int getLootId()
    {
        return Item.LEATHER.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = random.nextInt(3) + random.nextInt(1 + i);
        if(j > 0)
            loot.add(new ItemStack(Item.LEATHER.id, j));
        j = random.nextInt(3) + 1 + random.nextInt(1 + i);
        if(j > 0)
            loot.add(new ItemStack(isBurning() ? Item.COOKED_BEEF.id : Item.RAW_BEEF.id, j));
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public boolean b(EntityHuman entityhuman)
    {
        net.minecraft.server.ItemStack itemstack = entityhuman.inventory.getItemInHand();
        if(itemstack != null && itemstack.id == Item.BUCKET.id)
        {
            Location loc = getBukkitEntity().getLocation();
            PlayerBucketFillEvent event = CraftEventFactory.callPlayerBucketFillEvent(entityhuman, loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), -1, itemstack, Item.MILK_BUCKET);
            if(event.isCancelled())
            {
                return false;
            } else
            {
                entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, CraftItemStack.createNMSItemStack(event.getItemStack()));
                return true;
            }
        } else
        {
            return super.b(entityhuman);
        }
    }

    public EntityAnimal createChild(EntityAnimal entityanimal)
    {
        return new EntityCow(world);
    }
}
