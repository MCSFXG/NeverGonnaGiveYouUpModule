// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Item, ItemStack, PotionBrewer, World, 
//            MobEffect, EntityHuman, PlayerInventory, EnumAnimation, 
//            EntityPotion

public class ItemPotion extends Item
{

    public ItemPotion(int i)
    {
        super(i);
        a = new HashMap();
        e(1);
        a(true);
        setMaxDurability(0);
    }

    public List b(ItemStack itemstack)
    {
        return b(itemstack.getData());
    }

    public List b(int i)
    {
        List list = (List)a.get(Integer.valueOf(i));
        if(list == null)
        {
            list = PotionBrewer.getEffects(i, false);
            a.put(Integer.valueOf(i), list);
        }
        return list;
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        itemstack.count--;
        if(!world.isStatic)
        {
            List list = b(itemstack);
            if(list != null)
            {
                MobEffect mobeffect;
                for(Iterator iterator = list.iterator(); iterator.hasNext(); entityhuman.addEffect(new MobEffect(mobeffect)))
                    mobeffect = (MobEffect)iterator.next();

            }
        }
        if(itemstack.count <= 0)
        {
            return new ItemStack(Item.GLASS_BOTTLE);
        } else
        {
            entityhuman.inventory.pickup(new ItemStack(Item.GLASS_BOTTLE));
            return itemstack;
        }
    }

    public int c(ItemStack itemstack)
    {
        return 32;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.c;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        if(c(itemstack.getData()))
        {
            itemstack.count--;
            world.makeSound(entityhuman, "random.bow", 0.5F, 0.4F / (c.nextFloat() * 0.4F + 0.8F));
            if(!world.isStatic)
                world.addEntity(new EntityPotion(world, entityhuman, itemstack.getData()));
            return itemstack;
        } else
        {
            entityhuman.a(itemstack, c(itemstack));
            return itemstack;
        }
    }

    public boolean interactWith(ItemStack itemstack, EntityHuman entityhuman, World world, int i, int j, int k, int l)
    {
        return false;
    }

    public static boolean c(int i)
    {
        return (i & 0x4000) != 0;
    }

    private HashMap a;
}
