// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType

public class EnchantmentArrowDamage extends Enchantment
{

    public EnchantmentArrowDamage(int i, int j)
    {
        super(i, j, EnchantmentSlotType.BOW);
        a("arrowDamage");
    }

    public int a(int i)
    {
        return 1 + (i - 1) * 10;
    }

    public int b(int i)
    {
        return a(i) + 15;
    }

    public int getMaxLevel()
    {
        return 5;
    }
}
