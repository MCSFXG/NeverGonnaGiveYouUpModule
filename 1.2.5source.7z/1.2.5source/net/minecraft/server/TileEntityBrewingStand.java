// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TileEntityBrewingStand.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.inventory.BrewerInventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            TileEntity, ItemStack, NBTTagCompound, NBTTagList, 
//            IInventory, World, Item, ItemPotion, 
//            PotionBrewer, EntityHuman

public class TileEntityBrewingStand extends TileEntity
    implements IInventory
{

    public TileEntityBrewingStand()
    {
        items = new ItemStack[4];
        transaction = new ArrayList();
        maxStack = 1;
    }

    public void onOpen(CraftHumanEntity who)
    {
        transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        transaction.remove(who);
    }

    public List getViewers()
    {
        return transaction;
    }

    public ItemStack[] getContents()
    {
        return items;
    }

    public void setMaxStackSize(int size)
    {
        maxStack = size;
    }

    public String getName()
    {
        return "container.brewing";
    }

    public int getSize()
    {
        return items.length;
    }

    public void q_()
    {
        if(brewTime > 0)
        {
            brewTime--;
            if(brewTime == 0)
            {
                p();
                update();
            } else
            if(!o())
            {
                brewTime = 0;
                update();
            } else
            if(d != items[3].id)
            {
                brewTime = 0;
                update();
            }
        } else
        if(o())
        {
            brewTime = 400;
            d = items[3].id;
        }
        int i = n();
        if(i != c)
        {
            c = i;
            world.setData(x, y, z, i);
        }
        super.q_();
    }

    public int i()
    {
        return brewTime;
    }

    private boolean o()
    {
        if(items[3] != null && items[3].count > 0)
        {
            ItemStack itemstack = items[3];
            if(!Item.byId[itemstack.id].n())
                return false;
            boolean flag = false;
            for(int i = 0; i < 3; i++)
            {
                if(items[i] == null || items[i].id != Item.POTION.id)
                    continue;
                int j = items[i].getData();
                int k = b(j, itemstack);
                if(!ItemPotion.c(j) && ItemPotion.c(k))
                {
                    flag = true;
                    break;
                }
                List list = Item.POTION.b(j);
                List list1 = Item.POTION.b(k);
                if(j > 0 && list == list1 || list != null && (list.equals(list1) || list1 == null) || j == k)
                    continue;
                flag = true;
                break;
            }

            return flag;
        } else
        {
            return false;
        }
    }

    private void p()
    {
        if(o())
        {
            ItemStack itemstack = items[3];
            if(getOwner() != null)
            {
                BrewEvent event = new BrewEvent(world.getWorld().getBlockAt(x, y, z), (BrewerInventory)getOwner().getInventory());
                Bukkit.getPluginManager().callEvent(event);
                if(event.isCancelled())
                    return;
            }
            for(int i = 0; i < 3; i++)
            {
                if(items[i] == null || items[i].id != Item.POTION.id)
                    continue;
                int j = items[i].getData();
                int k = b(j, itemstack);
                List list = Item.POTION.b(j);
                List list1 = Item.POTION.b(k);
                if((j <= 0 || list != list1) && (list == null || !list.equals(list1) && list1 != null))
                {
                    if(j != k)
                        items[i].setData(k);
                    continue;
                }
                if(!ItemPotion.c(j) && ItemPotion.c(k))
                    items[i].setData(k);
            }

            if(Item.byId[itemstack.id].k())
            {
                items[3] = new ItemStack(Item.byId[itemstack.id].j());
            } else
            {
                items[3].count--;
                if(items[3].count <= 0)
                    items[3] = null;
            }
        }
    }

    private int b(int i, ItemStack itemstack)
    {
        return itemstack != null ? Item.byId[itemstack.id].n() ? PotionBrewer.a(i, Item.byId[itemstack.id].m()) : i : i;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.getList("Items");
        items = new ItemStack[getSize()];
        for(int i = 0; i < nbttaglist.size(); i++)
        {
            NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.get(i);
            byte b0 = nbttagcompound1.getByte("Slot");
            if(b0 >= 0 && b0 < items.length)
                items[b0] = ItemStack.a(nbttagcompound1);
        }

        brewTime = nbttagcompound.getShort("BrewTime");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setShort("BrewTime", (short)brewTime);
        NBTTagList nbttaglist = new NBTTagList();
        for(int i = 0; i < items.length; i++)
            if(items[i] != null)
            {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.setByte("Slot", (byte)i);
                items[i].save(nbttagcompound1);
                nbttaglist.add(nbttagcompound1);
            }

        nbttagcompound.set("Items", nbttaglist);
    }

    public ItemStack getItem(int i)
    {
        return i < 0 || i >= items.length ? null : items[i];
    }

    public ItemStack splitStack(int i, int j)
    {
        if(i >= 0 && i < items.length)
        {
            ItemStack itemstack = items[i];
            items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public ItemStack splitWithoutUpdate(int i)
    {
        if(i >= 0 && i < items.length)
        {
            ItemStack itemstack = items[i];
            items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        if(i >= 0 && i < items.length)
            items[i] = itemstack;
    }

    public int getMaxStackSize()
    {
        return maxStack;
    }

    public boolean a(EntityHuman entityhuman)
    {
        return world.getTileEntity(x, y, z) == this ? entityhuman.e((double)x + 0.5D, (double)y + 0.5D, (double)z + 0.5D) <= 64D : false;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    public int n()
    {
        int i = 0;
        for(int j = 0; j < 3; j++)
            if(items[j] != null)
                i |= 1 << j;

        return i;
    }

    public ItemStack items[];
    public int brewTime;
    private int c;
    private int d;
    public List transaction;
    private int maxStack;
}
