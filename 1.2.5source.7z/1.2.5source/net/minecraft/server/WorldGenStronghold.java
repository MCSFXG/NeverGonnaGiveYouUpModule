// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.PrintStream;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            StructureGenerator, BiomeBase, ChunkCoordIntPair, World, 
//            WorldChunkManager, ChunkPosition, WorldGenStrongholdStart, WorldGenStrongholdStairs2, 
//            StructureStart

public class WorldGenStronghold extends StructureGenerator
{

    public WorldGenStronghold()
    {
        a = (new BiomeBase[] {
            BiomeBase.DESERT, BiomeBase.FOREST, BiomeBase.EXTREME_HILLS, BiomeBase.SWAMPLAND, BiomeBase.TAIGA, BiomeBase.ICE_PLAINS, BiomeBase.ICE_MOUNTAINS, BiomeBase.DESERT_HILLS, BiomeBase.FOREST_HILLS, BiomeBase.SMALL_MOUNTAINS, 
            BiomeBase.JUNGLE, BiomeBase.JUNGLE_HILLS
        });
        g = new ChunkCoordIntPair[3];
    }

    protected boolean a(int i, int j)
    {
        if(!f)
        {
            Random random = new Random();
            random.setSeed(this.d.getSeed());
            double d = random.nextDouble() * 3.1415926535897931D * 2D;
            for(int k = 0; k < g.length; k++)
            {
                double d1 = (1.25D + random.nextDouble()) * 32D;
                int l = (int)Math.round(Math.cos(d) * d1);
                int i1 = (int)Math.round(Math.sin(d) * d1);
                ArrayList arraylist = new ArrayList();
                BiomeBase abiomebase[] = a;
                int j1 = abiomebase.length;
                for(int k1 = 0; k1 < j1; k1++)
                {
                    BiomeBase biomebase = abiomebase[k1];
                    arraylist.add(biomebase);
                }

                ChunkPosition chunkposition = this.d.getWorldChunkManager().a((l << 4) + 8, (i1 << 4) + 8, 112, arraylist, random);
                if(chunkposition != null)
                {
                    l = chunkposition.x >> 4;
                    i1 = chunkposition.z >> 4;
                } else
                {
                    System.out.println((new StringBuilder()).append("Placed stronghold in INVALID biome at (").append(l).append(", ").append(i1).append(")").toString());
                }
                g[k] = new ChunkCoordIntPair(l, i1);
                d += 6.2831853071795862D / (double)g.length;
            }

            f = true;
        }
        ChunkCoordIntPair achunkcoordintpair[] = g;
        int l1 = achunkcoordintpair.length;
        for(int i2 = 0; i2 < l1; i2++)
        {
            ChunkCoordIntPair chunkcoordintpair = achunkcoordintpair[i2];
            if(i == chunkcoordintpair.x && j == chunkcoordintpair.z)
            {
                System.out.println((new StringBuilder()).append(i).append(", ").append(j).toString());
                return true;
            }
        }

        return false;
    }

    protected List a()
    {
        ArrayList arraylist = new ArrayList();
        ChunkCoordIntPair achunkcoordintpair[] = g;
        int i = achunkcoordintpair.length;
        for(int j = 0; j < i; j++)
        {
            ChunkCoordIntPair chunkcoordintpair = achunkcoordintpair[j];
            if(chunkcoordintpair != null)
                arraylist.add(chunkcoordintpair.a(64));
        }

        return arraylist;
    }

    protected StructureStart b(int i, int j)
    {
        WorldGenStrongholdStart worldgenstrongholdstart;
        for(worldgenstrongholdstart = new WorldGenStrongholdStart(d, c, i, j); worldgenstrongholdstart.c().isEmpty() || ((WorldGenStrongholdStairs2)worldgenstrongholdstart.c().get(0)).b == null; worldgenstrongholdstart = new WorldGenStrongholdStart(d, c, i, j));
        return worldgenstrongholdstart;
    }

    private BiomeBase a[];
    private boolean f;
    private ChunkCoordIntPair g[];
}
