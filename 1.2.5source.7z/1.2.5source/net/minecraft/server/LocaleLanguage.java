// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;
import java.util.*;

public class LocaleLanguage
{

    private LocaleLanguage()
    {
        b = new Properties();
        b();
        a("en_US");
    }

    public static LocaleLanguage a()
    {
        return a;
    }

    private void b()
    {
        TreeMap treemap = new TreeMap();
        try
        {
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(net/minecraft/server/LocaleLanguage.getResourceAsStream("/lang/languages.txt"), "UTF-8"));
            for(String s = bufferedreader.readLine(); s != null; s = bufferedreader.readLine())
            {
                String as[] = s.split("=");
                if(as != null && as.length == 2)
                    treemap.put(as[0], as[1]);
            }

        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
            return;
        }
        c = treemap;
    }

    private void a(Properties properties, String s)
    {
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(net/minecraft/server/LocaleLanguage.getResourceAsStream((new StringBuilder()).append("/lang/").append(s).append(".lang").toString()), "UTF-8"));
        for(String s1 = bufferedreader.readLine(); s1 != null; s1 = bufferedreader.readLine())
        {
            s1 = s1.trim();
            if(s1.startsWith("#"))
                continue;
            String as[] = s1.split("=");
            if(as != null && as.length == 2)
                properties.setProperty(as[0], as[1]);
        }

    }

    public void a(String s)
    {
        Properties properties;
        if(s.equals(d))
            return;
        properties = new Properties();
        try
        {
            a(properties, "en_US");
        }
        catch(IOException ioexception) { }
        e = false;
        if("en_US".equals(s))
            break MISSING_BLOCK_LABEL_152;
        Enumeration enumeration;
        a(properties, s);
        enumeration = properties.propertyNames();
_L2:
        String s1;
        int i;
        Object obj1;
        do
        {
            if(!enumeration.hasMoreElements() || e)
                break MISSING_BLOCK_LABEL_152;
            Object obj = enumeration.nextElement();
            obj1 = properties.get(obj);
        } while(obj1 == null);
        s1 = obj1.toString();
        i = 0;
_L5:
        if(i >= s1.length()) goto _L2; else goto _L1
_L1:
        if(s1.charAt(i) < '\u0100') goto _L4; else goto _L3
_L3:
        e = true;
          goto _L2
_L4:
        i++;
          goto _L5
        IOException ioexception1;
        ioexception1;
        ioexception1.printStackTrace();
        return;
        d = s;
        b = properties;
        return;
          goto _L2
    }

    public String b(String s)
    {
        return b.getProperty(s, s);
    }

    public transient String a(String s, Object aobj[])
    {
        String s1 = b.getProperty(s, s);
        return String.format(s1, aobj);
    }

    private static LocaleLanguage a = new LocaleLanguage();
    private Properties b;
    private TreeMap c;
    private String d;
    private boolean e;

}
