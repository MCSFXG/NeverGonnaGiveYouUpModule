// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler

public class Packet131ItemData extends Packet
{

    public Packet131ItemData()
    {
        lowPriority = true;
    }

    public Packet131ItemData(short word0, short word1, byte abyte0[])
    {
        lowPriority = true;
        a = word0;
        b = word1;
        c = abyte0;
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readShort();
        b = datainputstream.readShort();
        c = new byte[datainputstream.readByte() & 0xff];
        datainputstream.readFully(c);
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeShort(a);
        dataoutputstream.writeShort(b);
        dataoutputstream.writeByte(c.length);
        dataoutputstream.write(c);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 4 + c.length;
    }

    public short a;
    public short b;
    public byte c[];
}
