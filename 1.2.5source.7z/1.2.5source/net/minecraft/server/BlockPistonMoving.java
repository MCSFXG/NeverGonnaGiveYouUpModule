// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockContainer, Material, World, TileEntityPiston, 
//            Block, Facing, AxisAlignedBB, IBlockAccess, 
//            TileEntity, EntityHuman

public class BlockPistonMoving extends BlockContainer
{

    public BlockPistonMoving(int i)
    {
        super(i, Material.PISTON);
        c(-1F);
    }

    public TileEntity a_()
    {
        return null;
    }

    public void onPlace(World world, int i, int j, int k)
    {
    }

    public void remove(World world, int i, int j, int k)
    {
        TileEntity tileentity = world.getTileEntity(i, j, k);
        if(tileentity != null && (tileentity instanceof TileEntityPiston))
            ((TileEntityPiston)tileentity).g();
        else
            super.remove(world, i, j, k);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return false;
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        return false;
    }

    public int c()
    {
        return -1;
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(!world.isStatic && world.getTileEntity(i, j, k) == null)
        {
            world.setTypeId(i, j, k, 0);
            return true;
        } else
        {
            return false;
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return 0;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        if(world.isStatic)
            return;
        TileEntityPiston tileentitypiston = c(world, i, j, k);
        if(tileentitypiston == null)
        {
            return;
        } else
        {
            Block.byId[tileentitypiston.c()].b(world, i, j, k, tileentitypiston.k(), 0);
            return;
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if(!world.isStatic)
            if(world.getTileEntity(i, j, k) != null);
    }

    public static TileEntity a(int i, int j, int k, boolean flag, boolean flag1)
    {
        return new TileEntityPiston(i, j, k, flag, flag1);
    }

    public AxisAlignedBB e(World world, int i, int j, int k)
    {
        TileEntityPiston tileentitypiston = c(world, i, j, k);
        if(tileentitypiston == null)
            return null;
        float f = tileentitypiston.a(0.0F);
        if(tileentitypiston.e())
            f = 1.0F - f;
        return b(world, i, j, k, tileentitypiston.c(), f, tileentitypiston.f());
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        TileEntityPiston tileentitypiston = c(iblockaccess, i, j, k);
        if(tileentitypiston != null)
        {
            Block block = Block.byId[tileentitypiston.c()];
            if(block == null || block == this)
                return;
            block.updateShape(iblockaccess, i, j, k);
            float f = tileentitypiston.a(0.0F);
            if(tileentitypiston.e())
                f = 1.0F - f;
            int l = tileentitypiston.f();
            minX = block.minX - (double)((float)Facing.b[l] * f);
            minY = block.minY - (double)((float)Facing.c[l] * f);
            minZ = block.minZ - (double)((float)Facing.d[l] * f);
            maxX = block.maxX - (double)((float)Facing.b[l] * f);
            maxY = block.maxY - (double)((float)Facing.c[l] * f);
            maxZ = block.maxZ - (double)((float)Facing.d[l] * f);
        }
    }

    public AxisAlignedBB b(World world, int i, int j, int k, int l, float f, int i1)
    {
        if(l == 0 || l == id)
            return null;
        AxisAlignedBB axisalignedbb = Block.byId[l].e(world, i, j, k);
        if(axisalignedbb == null)
            return null;
        if(Facing.b[i1] < 0)
            axisalignedbb.a -= (float)Facing.b[i1] * f;
        else
            axisalignedbb.d -= (float)Facing.b[i1] * f;
        if(Facing.c[i1] < 0)
            axisalignedbb.b -= (float)Facing.c[i1] * f;
        else
            axisalignedbb.e -= (float)Facing.c[i1] * f;
        if(Facing.d[i1] < 0)
            axisalignedbb.c -= (float)Facing.d[i1] * f;
        else
            axisalignedbb.f -= (float)Facing.d[i1] * f;
        return axisalignedbb;
    }

    private TileEntityPiston c(IBlockAccess iblockaccess, int i, int j, int k)
    {
        TileEntity tileentity = iblockaccess.getTileEntity(i, j, k);
        if(tileentity != null && (tileentity instanceof TileEntityPiston))
            return (TileEntityPiston)tileentity;
        else
            return null;
    }
}
