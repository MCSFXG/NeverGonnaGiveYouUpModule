// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ItemFood.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.FoodLevelChangeEvent;

// Referenced classes of package net.minecraft.server:
//            Item, MobEffect, ItemStack, EntityHuman, 
//            FoodMetaData, World, EnumAnimation

public class ItemFood extends Item
{

    public ItemFood(int i, int j, float f, boolean flag)
    {
        super(i);
        a = 32;
        b = j;
        bV = flag;
        bU = f;
    }

    public ItemFood(int i, int j, boolean flag)
    {
        this(i, j, 0.6F, flag);
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        itemstack.count--;
        int oldFoodLevel = entityhuman.getFoodData().foodLevel;
        FoodLevelChangeEvent event = CraftEventFactory.callFoodLevelChangeEvent(entityhuman, getNutrition() + oldFoodLevel);
        if(!event.isCancelled())
            entityhuman.getFoodData().eat(event.getFoodLevel() - oldFoodLevel, getSaturationModifier());
        world.makeSound(entityhuman, "random.burp", 0.5F, world.random.nextFloat() * 0.1F + 0.9F);
        if(!world.isStatic && bX > 0 && world.random.nextFloat() < ca)
            entityhuman.addEffect(new MobEffect(bX, bY * 20, bZ));
        return itemstack;
    }

    public int c(ItemStack itemstack)
    {
        return 32;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.b;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        if(entityhuman.b(bW))
            entityhuman.a(itemstack, c(itemstack));
        return itemstack;
    }

    public int getNutrition()
    {
        return b;
    }

    public float getSaturationModifier()
    {
        return bU;
    }

    public boolean q()
    {
        return bV;
    }

    public ItemFood a(int i, int j, int k, float f)
    {
        bX = i;
        bY = j;
        bZ = k;
        ca = f;
        return this;
    }

    public ItemFood r()
    {
        bW = true;
        return this;
    }

    public Item a(String s)
    {
        return super.a(s);
    }

    public final int a;
    private final int b;
    private final float bU;
    private final boolean bV;
    private boolean bW;
    private int bX;
    private int bY;
    private int bZ;
    private float ca;
}
