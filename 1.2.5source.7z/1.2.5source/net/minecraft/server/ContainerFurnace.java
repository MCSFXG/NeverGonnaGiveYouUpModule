// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerFurnace.java

package net.minecraft.server;

import java.util.List;
import org.bukkit.craftbukkit.inventory.CraftInventoryFurnace;
import org.bukkit.craftbukkit.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

// Referenced classes of package net.minecraft.server:
//            Container, Slot, SlotResult2, ICrafting, 
//            ItemStack, PlayerInventory, EntityHuman, TileEntityFurnace, 
//            FurnaceRecipes, Item

public class ContainerFurnace extends Container
{

    public CraftInventoryView getBukkitView()
    {
        if(bukkitEntity != null)
        {
            return bukkitEntity;
        } else
        {
            CraftInventoryFurnace inventory = new CraftInventoryFurnace(furnace);
            bukkitEntity = new CraftInventoryView(player.player.getBukkitEntity(), inventory, this);
            return bukkitEntity;
        }
    }

    public ContainerFurnace(PlayerInventory playerinventory, TileEntityFurnace tileentityfurnace)
    {
        b = 0;
        c = 0;
        h = 0;
        bukkitEntity = null;
        furnace = tileentityfurnace;
        a(new Slot(tileentityfurnace, 0, 56, 17));
        a(new Slot(tileentityfurnace, 1, 56, 53));
        a(new SlotResult2(playerinventory.player, tileentityfurnace, 2, 116, 35));
        player = playerinventory;
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 9; j++)
                a(new Slot(playerinventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));

        }

        for(int i = 0; i < 9; i++)
            a(new Slot(playerinventory, i, 8 + i * 18, 142));

    }

    public void addSlotListener(ICrafting icrafting)
    {
        super.addSlotListener(icrafting);
        icrafting.setContainerData(this, 0, furnace.cookTime);
        icrafting.setContainerData(this, 1, furnace.burnTime);
        icrafting.setContainerData(this, 2, furnace.ticksForCurrentFuel);
    }

    public void a()
    {
        super.a();
        for(int i = 0; i < listeners.size(); i++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i);
            if(b != furnace.cookTime)
                icrafting.setContainerData(this, 0, furnace.cookTime);
            if(c != furnace.burnTime)
                icrafting.setContainerData(this, 1, furnace.burnTime);
            if(h != furnace.ticksForCurrentFuel)
                icrafting.setContainerData(this, 2, furnace.ticksForCurrentFuel);
        }

        b = furnace.cookTime;
        c = furnace.burnTime;
        h = furnace.ticksForCurrentFuel;
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(!checkReachable)
            return true;
        else
            return furnace.a(entityhuman);
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i == 2)
            {
                if(!a(itemstack1, 3, 39, true))
                    return null;
                slot.a(itemstack1, itemstack);
            } else
            if(i != 1 && i != 0)
            {
                if(FurnaceRecipes.getInstance().getResult(itemstack1.getItem().id) != null)
                {
                    if(!a(itemstack1, 0, 1, false))
                        return null;
                } else
                if(TileEntityFurnace.isFuel(itemstack1))
                {
                    if(!a(itemstack1, 1, 2, false))
                        return null;
                } else
                if(i >= 3 && i < 30)
                {
                    if(!a(itemstack1, 30, 39, false))
                        return null;
                } else
                if(i >= 30 && i < 39 && !a(itemstack1, 3, 30, false))
                    return null;
            } else
            if(!a(itemstack1, 3, 39, false))
                return null;
            if(itemstack1.count == 0)
                slot.set((ItemStack)null);
            else
                slot.d();
            if(itemstack1.count == itemstack.count)
                return null;
            slot.c(itemstack1);
        }
        return itemstack;
    }

    public volatile InventoryView getBukkitView()
    {
        return getBukkitView();
    }

    public TileEntityFurnace furnace;
    private int b;
    private int c;
    private int h;
    private CraftInventoryView bukkitEntity;
    private PlayerInventory player;
}
