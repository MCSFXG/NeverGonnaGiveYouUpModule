// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            StructureGenerator, BiomeMeta, EntityBlaze, EntityPigZombie, 
//            EntityMagmaCube, World, WorldGenNetherStart, StructureStart

public class WorldGenNether extends StructureGenerator
{

    public WorldGenNether()
    {
        a = new ArrayList();
        a.add(new BiomeMeta(net/minecraft/server/EntityBlaze, 10, 2, 3));
        a.add(new BiomeMeta(net/minecraft/server/EntityPigZombie, 10, 4, 4));
        a.add(new BiomeMeta(net/minecraft/server/EntityMagmaCube, 3, 4, 4));
    }

    public List b()
    {
        return a;
    }

    protected boolean a(int i, int j)
    {
        int k = i >> 4;
        int l = j >> 4;
        c.setSeed((long)(k ^ l << 4) ^ d.getSeed());
        c.nextInt();
        if(c.nextInt(3) != 0)
            return false;
        if(i != (k << 4) + 4 + c.nextInt(8))
            return false;
        return j == (l << 4) + 4 + c.nextInt(8);
    }

    protected StructureStart b(int i, int j)
    {
        return new WorldGenNetherStart(d, c, i, j);
    }

    private List a;
}
