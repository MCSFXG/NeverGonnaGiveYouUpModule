// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityLiving.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, PathfinderGoalSelector, ChunkCoordinates, ControllerLook, 
//            ControllerMove, ControllerJump, EntityAIBodyControl, Navigation, 
//            EntitySenses, EntityCreeper, EntityGhast, EntityEnderDragon, 
//            EntityExperienceOrb, EntityDamageSource, EntityHuman, EntityWolf, 
//            NBTTagList, MobEffect, NBTTagCompound, MathHelper, 
//            DataWatcher, Vec3D, World, DamageSource, 
//            Material, MobEffectList, EnchantmentManager, Block, 
//            StepSound, AxisAlignedBB, PotionBrewer, MonsterType, 
//            ItemStack, Item

public abstract class EntityLiving extends Entity
{

    public EntityLiving(World world)
    {
        super(world);
        maxNoDamageTicks = 20;
        V = 0.0F;
        W = 0.0F;
        X = 0.0F;
        Y = 0.0F;
        ad = true;
        texture = "/mob/char.png";
        af = true;
        ag = 0.0F;
        ah = null;
        ai = 1.0F;
        aj = 0;
        ak = 0.0F;
        al = 0.1F;
        am = 0.02F;
        health = getMaxHealth();
        au = 0.0F;
        deathTicks = 0;
        attackTicks = 0;
        az = false;
        aB = -1;
        aC = (float)(Math.random() * 0.89999997615814209D + 0.10000000149011612D);
        killer = null;
        lastDamageByPlayerTime = 0;
        lastDamager = null;
        c = 0;
        d = null;
        aI = 0;
        aJ = 0;
        effects = new HashMap();
        e = true;
        goalSelector = new PathfinderGoalSelector();
        targetSelector = new PathfinderGoalSelector();
        o = new ChunkCoordinates(0, 0, 0);
        p = -1F;
        aT = 0.0F;
        lastDamage = 0;
        aV = 0;
        aZ = false;
        ba = 0.0F;
        bb = 0.7F;
        q = 0;
        bc = 0;
        expToDrop = 0;
        maxAirTicks = 300;
        bf = true;
        lookController = new ControllerLook(this);
        moveController = new ControllerMove(this);
        jumpController = new ControllerJump(this);
        senses = new EntityAIBodyControl(this);
        navigation = new Navigation(this, world, 16F);
        m = new EntitySenses(this);
        U = (float)(Math.random() + 1.0D) * 0.01F;
        setPosition(locX, locY, locZ);
        T = (float)Math.random() * 12398F;
        yaw = (float)(Math.random() * 3.1415927410125732D * 2D);
        X = yaw;
        bP = 0.5F;
    }

    public ControllerLook getControllerLook()
    {
        return lookController;
    }

    public ControllerMove getControllerMove()
    {
        return moveController;
    }

    public ControllerJump getControllerJump()
    {
        return jumpController;
    }

    public Navigation al()
    {
        return navigation;
    }

    public EntitySenses am()
    {
        return m;
    }

    public Random an()
    {
        return random;
    }

    public EntityLiving ao()
    {
        return lastDamager;
    }

    public EntityLiving ap()
    {
        return d;
    }

    public void g(Entity entity)
    {
        if(entity instanceof EntityLiving)
            d = (EntityLiving)entity;
    }

    public int aq()
    {
        return aV;
    }

    public float ar()
    {
        return X;
    }

    public float as()
    {
        return n;
    }

    public void d(float f)
    {
        n = f;
        e(f);
    }

    public boolean a(Entity entity)
    {
        g(entity);
        return false;
    }

    public EntityLiving at()
    {
        return l;
    }

    public void b(EntityLiving entityliving)
    {
        l = entityliving;
    }

    public boolean a(Class oclass)
    {
        return net/minecraft/server/EntityCreeper != oclass && net/minecraft/server/EntityGhast != oclass;
    }

    public void z()
    {
    }

    public boolean au()
    {
        return e(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
    }

    public boolean e(int i, int j, int k)
    {
        return p != -1F ? o.c(i, j, k) < p * p : true;
    }

    public void b(int i, int j, int k, int l)
    {
        o.a(i, j, k);
        p = l;
    }

    public ChunkCoordinates av()
    {
        return o;
    }

    public float aw()
    {
        return p;
    }

    public void ax()
    {
        p = -1F;
    }

    public boolean ay()
    {
        return p != -1F;
    }

    public void a(EntityLiving entityliving)
    {
        lastDamager = entityliving;
        c = lastDamager == null ? 0 : 60;
    }

    protected void b()
    {
        datawatcher.a(8, Integer.valueOf(f));
    }

    public boolean h(Entity entity)
    {
        return world.a(Vec3D.create(locX, locY + (double)getHeadHeight(), locZ), Vec3D.create(entity.locX, entity.locY + (double)entity.getHeadHeight(), entity.locZ)) == null;
    }

    public boolean o_()
    {
        return !dead;
    }

    public boolean e_()
    {
        return !dead;
    }

    public float getHeadHeight()
    {
        return length * 0.85F;
    }

    public int m()
    {
        return 80;
    }

    public void az()
    {
        String s = i();
        if(s != null)
            world.makeSound(this, s, p(), A());
    }

    public void aA()
    {
        an = ao;
        super.aA();
        if(isAlive() && random.nextInt(1000) < a++)
        {
            a = -m();
            az();
        }
        if(isAlive() && inBlock() && !(this instanceof EntityEnderDragon))
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.SUFFOCATION, 1);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                damageEntity(DamageSource.STUCK, event.getDamage());
        }
        if(isFireproof() || world.isStatic)
            extinguish();
        if(isAlive() && a(Material.WATER) && !f_() && !effects.containsKey(Integer.valueOf(MobEffectList.WATER_BREATHING.id)))
        {
            setAirTicks(b_(getAirTicks()));
            if(getAirTicks() == -20)
            {
                setAirTicks(0);
                for(int i = 0; i < 8; i++)
                {
                    float f = random.nextFloat() - random.nextFloat();
                    float f1 = random.nextFloat() - random.nextFloat();
                    float f2 = random.nextFloat() - random.nextFloat();
                    world.a("bubble", locX + (double)f, locY + (double)f1, locZ + (double)f2, motX, motY, motZ);
                }

                EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.DROWNING, 2);
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled() && event.getDamage() != 0)
                    damageEntity(DamageSource.DROWN, event.getDamage());
            }
            extinguish();
        } else
        if(getAirTicks() != 300)
            setAirTicks(maxAirTicks);
        ax = ay;
        if(attackTicks > 0)
            attackTicks--;
        if(hurtTicks > 0)
            hurtTicks--;
        if(noDamageTicks > 0)
            noDamageTicks--;
        if(health <= 0)
            aB();
        if(lastDamageByPlayerTime > 0)
            lastDamageByPlayerTime--;
        else
            killer = null;
        if(d != null && !d.isAlive())
            d = null;
        if(lastDamager != null)
            if(!lastDamager.isAlive())
                a((EntityLiving)null);
            else
            if(c > 0)
                c--;
            else
                a((EntityLiving)null);
        aK();
        ac = ab;
        W = V;
        Y = X;
        lastYaw = yaw;
        lastPitch = pitch;
    }

    public int getExpReward()
    {
        int exp = getExpValue(killer);
        if(!world.isStatic && (lastDamageByPlayerTime > 0 || alwaysGivesExp()) && !isBaby())
            return exp;
        else
            return 0;
    }

    protected void aB()
    {
        deathTicks++;
        if(deathTicks >= 20 && !dead)
        {
            for(int i = expToDrop; i > 0;)
            {
                int j = EntityExperienceOrb.getOrbValue(i);
                i -= j;
                world.addEntity(new EntityExperienceOrb(world, locX, locY, locZ, j));
            }

            aH();
            die();
            for(int i = 0; i < 20; i++)
            {
                double d0 = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                world.a("explode", (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, d0, d1, d2);
            }

        }
    }

    protected int b_(int i)
    {
        return i - 1;
    }

    protected int getExpValue(EntityHuman entityhuman)
    {
        return aA;
    }

    protected boolean alwaysGivesExp()
    {
        return false;
    }

    public void aC()
    {
        for(int i = 0; i < 20; i++)
        {
            double d0 = random.nextGaussian() * 0.02D;
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            double d3 = 10D;
            world.a("explode", (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width - d0 * d3, (locY + (double)(random.nextFloat() * length)) - d1 * d3, (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width - d2 * d3, d0, d1, d2);
        }

    }

    public void R()
    {
        super.R();
        Z = aa;
        aa = 0.0F;
        fallDistance = 0.0F;
    }

    public void F_()
    {
        super.F_();
        if(aI > 0)
        {
            if(aJ <= 0)
                aJ = 60;
            aJ--;
            if(aJ <= 0)
                aI--;
        }
        e();
        double d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f = MathHelper.sqrt(d0 * d0 + d1 * d1);
        float f1 = V;
        float f2 = 0.0F;
        Z = aa;
        float f3 = 0.0F;
        if(f > 0.05F)
        {
            f3 = 1.0F;
            f2 = f * 3F;
            f1 = ((float)TrigMath.atan2(d1, d0) * 180F) / 3.141593F - 90F;
        }
        if(ao > 0.0F)
            f1 = yaw;
        if(!onGround)
            f3 = 0.0F;
        aa += (f3 - aa) * 0.3F;
        if(c_())
        {
            senses.a();
        } else
        {
            float f4;
            for(f4 = f1 - V; f4 < -180F; f4 += 360F);
            for(; f4 >= 180F; f4 -= 360F);
            V += f4 * 0.3F;
            float f5;
            for(f5 = yaw - V; f5 < -180F; f5 += 360F);
            for(; f5 >= 180F; f5 -= 360F);
            boolean flag = f5 < -90F || f5 >= 90F;
            if(f5 < -75F)
                f5 = -75F;
            if(f5 >= 75F)
                f5 = 75F;
            V = yaw - f5;
            if(f5 * f5 > 2500F)
                V += f5 * 0.2F;
            if(flag)
                f2 *= -1F;
        }
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        for(; V - W < -180F; W -= 360F);
        for(; V - W >= 180F; W += 360F);
        for(; pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        for(; X - Y < -180F; Y -= 360F);
        for(; X - Y >= 180F; Y += 360F);
        ab += f2;
    }

    protected void b(float f, float f1)
    {
        super.b(f, f1);
    }

    public void heal(int i)
    {
        heal(i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.CUSTOM);
    }

    public void heal(int i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason regainReason)
    {
        if(health > 0)
        {
            EntityRegainHealthEvent event = new EntityRegainHealthEvent(getBukkitEntity(), i, regainReason);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                health += event.getAmount();
            if(health > getMaxHealth())
                health = getMaxHealth();
            noDamageTicks = maxNoDamageTicks / 2;
        }
    }

    public abstract int getMaxHealth();

    public int getHealth()
    {
        return health;
    }

    public void setHealth(int i)
    {
        health = i;
        if(i > getMaxHealth())
            i = getMaxHealth();
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(world.isStatic)
            return false;
        aV = 0;
        if(health <= 0)
            return false;
        if(damagesource.k() && hasEffect(MobEffectList.FIRE_RESISTANCE))
            return false;
        aE = 1.5F;
        boolean flag = true;
        if(damagesource instanceof EntityDamageSource)
        {
            EntityDamageEvent event = CraftEventFactory.handleEntityDamageEvent(this, damagesource, i);
            if(event.isCancelled())
                return false;
            i = event.getDamage();
        }
        if((float)noDamageTicks > (float)maxNoDamageTicks / 2.0F)
        {
            if(i <= lastDamage)
                return false;
            c(damagesource, i - lastDamage);
            lastDamage = i;
            flag = false;
        } else
        {
            lastDamage = i;
            aq = health;
            noDamageTicks = maxNoDamageTicks;
            c(damagesource, i);
            hurtTicks = at = 10;
        }
        au = 0.0F;
        Entity entity = damagesource.getEntity();
        if(entity != null)
        {
            if(entity instanceof EntityLiving)
                a((EntityLiving)entity);
            if(entity instanceof EntityHuman)
            {
                lastDamageByPlayerTime = 60;
                killer = (EntityHuman)entity;
            } else
            if(entity instanceof EntityWolf)
            {
                EntityWolf entitywolf = (EntityWolf)entity;
                if(entitywolf.isTamed())
                {
                    lastDamageByPlayerTime = 60;
                    killer = null;
                }
            }
        }
        if(flag)
        {
            world.broadcastEntityEffect(this, (byte)2);
            aW();
            if(entity != null)
            {
                double d0 = entity.locX - locX;
                double d1;
                for(d1 = entity.locZ - locZ; d0 * d0 + d1 * d1 < 0.0001D; d1 = (Math.random() - Math.random()) * 0.01D)
                    d0 = (Math.random() - Math.random()) * 0.01D;

                au = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - yaw;
                a(entity, i, d0, d1);
            } else
            {
                au = (int)(Math.random() * 2D) * 180;
            }
        }
        if(health <= 0)
        {
            if(flag)
                world.makeSound(this, k(), p(), A());
            die(damagesource);
        } else
        if(flag)
            world.makeSound(this, j(), p(), A());
        return true;
    }

    private float A()
    {
        return isBaby() ? (random.nextFloat() - random.nextFloat()) * 0.2F + 1.5F : (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F;
    }

    public int T()
    {
        return 0;
    }

    protected void f(int i1)
    {
    }

    protected int d(DamageSource damagesource, int i)
    {
        if(!damagesource.ignoresArmor())
        {
            int j = 25 - T();
            int k = i * j + ar;
            f(i);
            i = k / 25;
            ar = k % 25;
        }
        return i;
    }

    protected int b(DamageSource damagesource, int i)
    {
        if(hasEffect(MobEffectList.RESISTANCE))
        {
            int j = (getEffect(MobEffectList.RESISTANCE).getAmplifier() + 1) * 5;
            int k = 25 - j;
            int l = i * k + ar;
            i = l / 25;
            ar = l % 25;
        }
        return i;
    }

    protected void c(DamageSource damagesource, int i)
    {
        i = d(damagesource, i);
        i = b(damagesource, i);
        health -= i;
    }

    protected float p()
    {
        return 1.0F;
    }

    protected String i()
    {
        return null;
    }

    protected String j()
    {
        return "damage.hurtflesh";
    }

    protected String k()
    {
        return "damage.hurtflesh";
    }

    public void a(Entity entity, int i, double d0, double d1)
    {
        ce = true;
        float f = MathHelper.sqrt(d0 * d0 + d1 * d1);
        float f1 = 0.4F;
        motX /= 2D;
        motY /= 2D;
        motZ /= 2D;
        motX -= (d0 / (double)f) * (double)f1;
        motY += f1;
        motZ -= (d1 / (double)f) * (double)f1;
        if(motY > 0.40000000596046448D)
            motY = 0.40000000596046448D;
    }

    public void die(DamageSource damagesource)
    {
        Entity entity = damagesource.getEntity();
        if(aj >= 0 && entity != null)
            entity.b(this, aj);
        if(entity != null)
            entity.c(this);
        az = true;
        if(!world.isStatic)
        {
            int i = 0;
            if(entity instanceof EntityHuman)
                i = EnchantmentManager.getBonusMonsterLootEnchantmentLevel(((EntityHuman)entity).inventory);
            if(!isBaby())
                dropDeathLoot(lastDamageByPlayerTime > 0, i);
            else
                CraftEventFactory.callEntityDeathEvent(this);
        }
        world.broadcastEntityEffect(this, (byte)3);
    }

    protected net.minecraft.server.ItemStack b(int i)
    {
        return null;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        int j = getLootId();
        List loot = new ArrayList();
        if(j > 0)
        {
            int k = random.nextInt(3);
            if(i > 0)
                k += random.nextInt(i + 1);
            if(k > 0)
                loot.add(new ItemStack(j, k));
        }
        if(lastDamageByPlayerTime > 0)
        {
            int k = random.nextInt(200) - i;
            if(k < 5)
            {
                net.minecraft.server.ItemStack itemstack = b(k > 0 ? 0 : 1);
                if(itemstack != null)
                    loot.add(new CraftItemStack(itemstack));
            }
        }
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    protected int getLootId()
    {
        return 0;
    }

    protected void a(float f)
    {
        super.a(f);
        int i = (int)Math.ceil(f - 3F);
        if(i > 0)
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL, i);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled() && event.getDamage() != 0)
            {
                i = event.getDamage();
                if(i > 4)
                    world.makeSound(this, "damage.fallbig", 1.0F, 1.0F);
                else
                    world.makeSound(this, "damage.fallsmall", 1.0F, 1.0F);
                damageEntity(DamageSource.FALL, i);
            }
            int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(locY - 0.20000000298023224D - (double)height), MathHelper.floor(locZ));
            if(j > 0)
            {
                StepSound stepsound = Block.byId[j].stepSound;
                world.makeSound(this, stepsound.getName(), stepsound.getVolume1() * 0.5F, stepsound.getVolume2() * 0.75F);
            }
        }
    }

    public void a(float f, float f1)
    {
        double d0;
        if(aU())
        {
            d0 = locY;
            a(f, f1, c_() ? 0.04F : 0.02F);
            move(motX, motY, motZ);
            motX *= 0.80000001192092896D;
            motY *= 0.80000001192092896D;
            motZ *= 0.80000001192092896D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        if(aV())
        {
            d0 = locY;
            a(f, f1, 0.02F);
            move(motX, motY, motZ);
            motX *= 0.5D;
            motY *= 0.5D;
            motZ *= 0.5D;
            motY -= 0.02D;
            if(positionChanged && d(motX, ((motY + 0.60000002384185791D) - locY) + d0, motZ))
                motY = 0.30000001192092896D;
        } else
        {
            float f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int i = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(i > 0)
                    f2 = Block.byId[i].frictionFactor * 0.91F;
            }
            float f3 = 0.1627714F / (f2 * f2 * f2);
            float f4;
            if(onGround)
            {
                if(c_())
                    f4 = as();
                else
                    f4 = al;
                f4 *= f3;
            } else
            {
                f4 = am;
            }
            a(f, f1, f4);
            f2 = 0.91F;
            if(onGround)
            {
                f2 = 0.5460001F;
                int j = world.getTypeId(MathHelper.floor(locX), MathHelper.floor(boundingBox.b) - 1, MathHelper.floor(locZ));
                if(j > 0)
                    f2 = Block.byId[j].frictionFactor * 0.91F;
            }
            if(t())
            {
                float f5 = 0.15F;
                if(motX < (double)(-f5))
                    motX = -f5;
                if(motX > (double)f5)
                    motX = f5;
                if(motZ < (double)(-f5))
                    motZ = -f5;
                if(motZ > (double)f5)
                    motZ = f5;
                fallDistance = 0.0F;
                if(motY < -0.14999999999999999D)
                    motY = -0.14999999999999999D;
                boolean flag = isSneaking() && (this instanceof EntityHuman);
                if(flag && motY < 0.0D)
                    motY = 0.0D;
            }
            move(motX, motY, motZ);
            if(positionChanged && t())
                motY = 0.20000000000000001D;
            motY -= 0.080000000000000002D;
            motY *= 0.98000001907348633D;
            motX *= f2;
            motZ *= f2;
        }
        aD = aE;
        d0 = locX - lastX;
        double d1 = locZ - lastZ;
        float f6 = MathHelper.sqrt(d0 * d0 + d1 * d1) * 4F;
        if(f6 > 1.0F)
            f6 = 1.0F;
        aE += (f6 - aE) * 0.4F;
        aF += aE;
    }

    public boolean t()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        int l = world.getTypeId(i, j, k);
        return l == Block.LADDER.id || l == Block.VINE.id;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("Health", (short)health);
        nbttagcompound.setShort("HurtTime", (short)hurtTicks);
        nbttagcompound.setShort("DeathTime", (short)deathTicks);
        nbttagcompound.setShort("AttackTime", (short)attackTicks);
        if(!effects.isEmpty())
        {
            NBTTagList nbttaglist = new NBTTagList();
            NBTTagCompound nbttagcompound1;
            for(Iterator iterator = effects.values().iterator(); iterator.hasNext(); nbttaglist.add(nbttagcompound1))
            {
                MobEffect mobeffect = (MobEffect)iterator.next();
                nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.setByte("Id", (byte)mobeffect.getEffectId());
                nbttagcompound1.setByte("Amplifier", (byte)mobeffect.getAmplifier());
                nbttagcompound1.setInt("Duration", mobeffect.getDuration());
            }

            nbttagcompound.set("ActiveEffects", nbttaglist);
        }
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        if(health < -32768)
            health = -32768;
        health = nbttagcompound.getShort("Health");
        if(!nbttagcompound.hasKey("Health"))
            health = getMaxHealth();
        hurtTicks = nbttagcompound.getShort("HurtTime");
        deathTicks = nbttagcompound.getShort("DeathTime");
        attackTicks = nbttagcompound.getShort("AttackTime");
        if(nbttagcompound.hasKey("ActiveEffects"))
        {
            NBTTagList nbttaglist = nbttagcompound.getList("ActiveEffects");
            for(int i = 0; i < nbttaglist.size(); i++)
            {
                NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.get(i);
                byte b0 = nbttagcompound1.getByte("Id");
                byte b1 = nbttagcompound1.getByte("Amplifier");
                int j = nbttagcompound1.getInt("Duration");
                effects.put(Integer.valueOf(b0), new MobEffect(b0, j, b1));
            }

        }
    }

    public boolean isAlive()
    {
        return !dead && health > 0;
    }

    public boolean f_()
    {
        return false;
    }

    public void e(float f)
    {
        aX = f;
    }

    public void f(boolean flag)
    {
        aZ = flag;
    }

    public void e()
    {
        if(q > 0)
            q--;
        if(aN > 0)
        {
            double d0 = locX + (aO - locX) / (double)aN;
            double d1 = locY + (aP - locY) / (double)aN;
            double d2 = locZ + (aQ - locZ) / (double)aN;
            double d3;
            for(d3 = aR - (double)yaw; d3 < -180D; d3 += 360D);
            for(; d3 >= 180D; d3 -= 360D);
            yaw = (float)((double)yaw + d3 / (double)aN);
            pitch = (float)((double)pitch + (aS - (double)pitch) / (double)aN);
            aN--;
            setPosition(d0, d1, d2);
            c(yaw, pitch);
            if(world.getTypeId(MathHelper.floor(d0), MathHelper.floor(d1), MathHelper.floor(d2)) != 0)
            {
                d1++;
                setPosition(d0, d1, d2);
            }
        }
        if(Q())
        {
            aZ = false;
            aW = 0.0F;
            aX = 0.0F;
            aY = 0.0F;
        } else
        if(aF())
            if(c_())
            {
                z_();
            } else
            {
                d_();
                X = yaw;
            }
        boolean flag = aU();
        boolean flag1 = aV();
        if(aZ)
        {
            if(flag)
                motY += 0.039999999105930328D;
            else
            if(flag1)
                motY += 0.039999999105930328D;
            else
            if(onGround && q == 0)
            {
                ac();
                q = 10;
            }
        } else
        {
            q = 0;
        }
        aW *= 0.98F;
        aX *= 0.98F;
        aY *= 0.9F;
        float f = al;
        al *= J();
        a(aW, aX);
        al = f;
        List list1 = world.getEntities(this, boundingBox.grow(0.20000000298023224D, 0.0D, 0.20000000298023224D));
        if(list1 != null && list1.size() > 0)
        {
            for(int j = 0; j < list1.size(); j++)
            {
                Entity entity = (Entity)list1.get(j);
                if(entity.e_())
                    entity.collide(this);
            }

        }
    }

    protected boolean c_()
    {
        return false;
    }

    protected boolean aF()
    {
        return !world.isStatic;
    }

    protected boolean Q()
    {
        return health <= 0;
    }

    public boolean P()
    {
        return false;
    }

    protected void ac()
    {
        motY = 0.41999998688697815D;
        if(hasEffect(MobEffectList.JUMP))
            motY += (float)(getEffect(MobEffectList.JUMP).getAmplifier() + 1) * 0.1F;
        if(isSprinting())
        {
            float f = yaw * 0.01745329F;
            motX -= MathHelper.sin(f) * 0.2F;
            motZ += MathHelper.cos(f) * 0.2F;
        }
        ce = true;
    }

    protected boolean n()
    {
        return true;
    }

    protected void aG()
    {
        EntityHuman entityhuman = world.findNearbyPlayer(this, -1D);
        if(entityhuman != null)
        {
            double d0 = entityhuman.locX - locX;
            double d1 = entityhuman.locY - locY;
            double d2 = entityhuman.locZ - locZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if(n() && d3 > 16384D)
                die();
            if(aV > 600 && random.nextInt(800) == 0 && d3 > 1024D && n())
                die();
            else
            if(d3 < 1024D)
                aV = 0;
        }
    }

    protected void z_()
    {
        aV++;
        aG();
        m.a();
        targetSelector.a();
        goalSelector.a();
        navigation.d();
        g();
        moveController.c();
        lookController.a();
        jumpController.b();
    }

    protected void g()
    {
    }

    protected void d_()
    {
        aV++;
        aG();
        aW = 0.0F;
        aX = 0.0F;
        float f = 8F;
        if(random.nextFloat() < 0.02F)
        {
            EntityHuman entityhuman = world.findNearbyPlayer(this, f);
            if(entityhuman != null)
            {
                r = entityhuman;
                bc = 10 + random.nextInt(20);
            } else
            {
                aY = (random.nextFloat() - 0.5F) * 20F;
            }
        }
        if(r != null)
        {
            a(r, 10F, D());
            if(bc-- <= 0 || r.dead || r.j(this) > (double)(f * f))
                r = null;
        } else
        {
            if(random.nextFloat() < 0.05F)
                aY = (random.nextFloat() - 0.5F) * 20F;
            yaw += aY;
            pitch = ba;
        }
        boolean flag = aU();
        boolean flag1 = aV();
        if(flag || flag1)
            aZ = random.nextFloat() < 0.8F;
    }

    public int D()
    {
        return 40;
    }

    public void a(Entity entity, float f, float f1)
    {
        double d0 = entity.locX - locX;
        double d1 = entity.locZ - locZ;
        double d2;
        if(entity instanceof EntityLiving)
        {
            EntityLiving entityliving = (EntityLiving)entity;
            d2 = (locY + (double)getHeadHeight()) - (entityliving.locY + (double)entityliving.getHeadHeight());
        } else
        {
            d2 = (entity.boundingBox.b + entity.boundingBox.e) / 2D - (locY + (double)getHeadHeight());
        }
        double d3 = MathHelper.sqrt(d0 * d0 + d1 * d1);
        float f2 = (float)((Math.atan2(d1, d0) * 180D) / 3.1415927410125732D) - 90F;
        float f3 = (float)(-((Math.atan2(d2, d3) * 180D) / 3.1415927410125732D));
        pitch = -b(pitch, f3, f1);
        yaw = b(yaw, f2, f);
    }

    private float b(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f1 - f; f3 < -180F; f3 += 360F);
        for(; f3 >= 180F; f3 -= 360F);
        if(f3 > f2)
            f3 = f2;
        if(f3 < -f2)
            f3 = -f2;
        return f + f3;
    }

    public void aH()
    {
    }

    public boolean canSpawn()
    {
        return world.containsEntity(boundingBox) && world.getCubes(this, boundingBox).size() == 0 && !world.containsLiquid(boundingBox);
    }

    protected void aI()
    {
        EntityDamageByBlockEvent event = new EntityDamageByBlockEvent(null, getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.VOID, 4);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled() || event.getDamage() == 0)
        {
            return;
        } else
        {
            damageEntity(DamageSource.OUT_OF_WORLD, event.getDamage());
            return;
        }
    }

    public Vec3D aJ()
    {
        return f(1.0F);
    }

    public Vec3D f(float f)
    {
        if(f == 1.0F)
        {
            float f1 = MathHelper.cos(-yaw * 0.01745329F - 3.141593F);
            float f2 = MathHelper.sin(-yaw * 0.01745329F - 3.141593F);
            float f3 = -MathHelper.cos(-pitch * 0.01745329F);
            float f4 = MathHelper.sin(-pitch * 0.01745329F);
            return Vec3D.create(f2 * f3, f4, f1 * f3);
        } else
        {
            float f1 = lastPitch + (pitch - lastPitch) * f;
            float f2 = lastYaw + (yaw - lastYaw) * f;
            float f3 = MathHelper.cos(-f2 * 0.01745329F - 3.141593F);
            float f4 = MathHelper.sin(-f2 * 0.01745329F - 3.141593F);
            float f5 = -MathHelper.cos(-f1 * 0.01745329F);
            float f6 = MathHelper.sin(-f1 * 0.01745329F);
            return Vec3D.create(f4 * f5, f6, f3 * f5);
        }
    }

    public int q()
    {
        return 4;
    }

    public boolean isSleeping()
    {
        return false;
    }

    protected void aK()
    {
        Iterator iterator = effects.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Integer integer = (Integer)iterator.next();
            MobEffect mobeffect = (MobEffect)effects.get(integer);
            if(!mobeffect.tick(this) && !world.isStatic)
            {
                iterator.remove();
                d(mobeffect);
            }
        } while(true);
        if(e)
        {
            if(!world.isStatic)
                if(!effects.isEmpty())
                {
                    int i = PotionBrewer.a(effects.values());
                    datawatcher.watch(8, Integer.valueOf(i));
                } else
                {
                    datawatcher.watch(8, Integer.valueOf(0));
                }
            e = false;
        }
        if(random.nextBoolean())
        {
            int i = datawatcher.getInt(8);
            if(i > 0)
            {
                double d0 = (double)(i >> 16 & 0xff) / 255D;
                double d1 = (double)(i >> 8 & 0xff) / 255D;
                double d2 = (double)(i >> 0 & 0xff) / 255D;
                world.a("mobSpell", locX + (random.nextDouble() - 0.5D) * (double)width, (locY + random.nextDouble() * (double)length) - (double)height, locZ + (random.nextDouble() - 0.5D) * (double)width, d0, d1, d2);
            }
        }
    }

    public void aL()
    {
        Iterator iterator = effects.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Integer integer = (Integer)iterator.next();
            MobEffect mobeffect = (MobEffect)effects.get(integer);
            if(!world.isStatic)
            {
                iterator.remove();
                d(mobeffect);
            }
        } while(true);
    }

    public Collection getEffects()
    {
        return effects.values();
    }

    public boolean hasEffect(MobEffectList mobeffectlist)
    {
        return effects.containsKey(Integer.valueOf(mobeffectlist.id));
    }

    public MobEffect getEffect(MobEffectList mobeffectlist)
    {
        return (MobEffect)effects.get(Integer.valueOf(mobeffectlist.id));
    }

    public void addEffect(MobEffect mobeffect)
    {
        if(a(mobeffect))
            if(effects.containsKey(Integer.valueOf(mobeffect.getEffectId())))
            {
                ((MobEffect)effects.get(Integer.valueOf(mobeffect.getEffectId()))).a(mobeffect);
                c((MobEffect)effects.get(Integer.valueOf(mobeffect.getEffectId())));
            } else
            {
                effects.put(Integer.valueOf(mobeffect.getEffectId()), mobeffect);
                b(mobeffect);
            }
    }

    public boolean a(MobEffect mobeffect)
    {
        if(getMonsterType() == MonsterType.UNDEAD)
        {
            int i = mobeffect.getEffectId();
            if(i == MobEffectList.REGENERATION.id || i == MobEffectList.POISON.id)
                return false;
        }
        return true;
    }

    public boolean aN()
    {
        return getMonsterType() == MonsterType.UNDEAD;
    }

    protected void b(MobEffect mobeffect)
    {
        e = true;
    }

    protected void c(MobEffect mobeffect)
    {
        e = true;
    }

    protected void d(MobEffect mobeffect)
    {
        e = true;
    }

    protected float J()
    {
        float f = 1.0F;
        if(hasEffect(MobEffectList.FASTER_MOVEMENT))
            f *= 1.0F + 0.2F * (float)(getEffect(MobEffectList.FASTER_MOVEMENT).getAmplifier() + 1);
        if(hasEffect(MobEffectList.SLOWER_MOVEMENT))
            f *= 1.0F - 0.15F * (float)(getEffect(MobEffectList.SLOWER_MOVEMENT).getAmplifier() + 1);
        return f;
    }

    public void enderTeleportTo(double d0, double d1, double d2)
    {
        setPositionRotation(d0, d1, d2, yaw, pitch);
    }

    public boolean isBaby()
    {
        return false;
    }

    public MonsterType getMonsterType()
    {
        return MonsterType.UNDEFINED;
    }

    public void c(net.minecraft.server.ItemStack itemstack)
    {
        world.makeSound(this, "random.break", 0.8F, 0.8F + world.random.nextFloat() * 0.4F);
        for(int i = 0; i < 5; i++)
        {
            Vec3D vec3d = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
            vec3d.a((-pitch * 3.141593F) / 180F);
            vec3d.b((-yaw * 3.141593F) / 180F);
            Vec3D vec3d1 = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-random.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
            vec3d1.a((-pitch * 3.141593F) / 180F);
            vec3d1.b((-yaw * 3.141593F) / 180F);
            vec3d1 = vec3d1.add(locX, locY + (double)getHeadHeight(), locZ);
            world.a((new StringBuilder()).append("iconcrack_").append(itemstack.getItem().id).toString(), vec3d1.a, vec3d1.b, vec3d1.c, vec3d.a, vec3d.b + 0.050000000000000003D, vec3d.c);
        }

    }

    public int maxNoDamageTicks;
    public float T;
    public float U;
    public float V;
    public float W;
    public float X;
    public float Y;
    protected float Z;
    protected float aa;
    protected float ab;
    protected float ac;
    protected boolean ad;
    protected String texture;
    protected boolean af;
    protected float ag;
    protected String ah;
    protected float ai;
    protected int aj;
    protected float ak;
    public float al;
    public float am;
    public float an;
    public float ao;
    protected int health;
    public int aq;
    protected int ar;
    private int a;
    public int hurtTicks;
    public int at;
    public float au;
    public int deathTicks;
    public int attackTicks;
    public float ax;
    public float ay;
    protected boolean az;
    protected int aA;
    public int aB;
    public float aC;
    public float aD;
    public float aE;
    public float aF;
    public EntityHuman killer;
    protected int lastDamageByPlayerTime;
    public EntityLiving lastDamager;
    private int c;
    private EntityLiving d;
    public int aI;
    public int aJ;
    public HashMap effects;
    public boolean e;
    private int f;
    private ControllerLook lookController;
    private ControllerMove moveController;
    private ControllerJump jumpController;
    private EntityAIBodyControl senses;
    private Navigation navigation;
    protected PathfinderGoalSelector goalSelector;
    protected PathfinderGoalSelector targetSelector;
    private EntityLiving l;
    private EntitySenses m;
    private float n;
    private ChunkCoordinates o;
    private float p;
    protected int aN;
    protected double aO;
    protected double aP;
    protected double aQ;
    protected double aR;
    protected double aS;
    float aT;
    public int lastDamage;
    protected int aV;
    protected float aW;
    protected float aX;
    protected float aY;
    protected boolean aZ;
    protected float ba;
    protected float bb;
    private int q;
    private Entity r;
    protected int bc;
    public int expToDrop;
    public int maxAirTicks;
}
