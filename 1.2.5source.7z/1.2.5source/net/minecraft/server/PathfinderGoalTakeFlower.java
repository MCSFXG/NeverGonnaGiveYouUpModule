// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityVillager, World, EntityIronGolem, 
//            AxisAlignedBB, Entity, Navigation, ControllerLook

public class PathfinderGoalTakeFlower extends PathfinderGoal
{

    public PathfinderGoalTakeFlower(EntityVillager entityvillager)
    {
        d = false;
        a = entityvillager;
        a(3);
    }

    public boolean a()
    {
        if(a.getAge() >= 0)
            return false;
        if(!a.world.e())
            return false;
        List list = a.world.a(net/minecraft/server/EntityIronGolem, a.boundingBox.grow(6D, 2D, 6D));
        if(list.size() == 0)
            return false;
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Entity entity = (Entity)iterator.next();
            EntityIronGolem entityirongolem = (EntityIronGolem)entity;
            if(entityirongolem.m_() <= 0)
                continue;
            b = entityirongolem;
            break;
        } while(true);
        return b != null;
    }

    public boolean b()
    {
        return b.m_() > 0;
    }

    public void c()
    {
        c = a.an().nextInt(320);
        d = false;
        b.al().f();
    }

    public void d()
    {
        b = null;
        a.al().f();
    }

    public void e()
    {
        a.getControllerLook().a(b, 30F, 30F);
        if(b.m_() == c)
        {
            a.al().a(b, 0.15F);
            d = true;
        }
        if(d && a.j(b) < 4D)
        {
            b.a(false);
            a.al().f();
        }
    }

    private EntityVillager a;
    private EntityIronGolem b;
    private int c;
    private boolean d;
}
