// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Chunk, World, EnumSkyBlock, Entity, 
//            TileEntity, AxisAlignedBB

public class EmptyChunk extends Chunk
{

    public EmptyChunk(World world, int i, int j)
    {
        super(world, i, j);
    }

    public boolean a(int i, int j)
    {
        return i == x && j == z;
    }

    public int b(int i, int j)
    {
        return 0;
    }

    public void initLighting()
    {
    }

    public void loadNOP()
    {
    }

    public int getTypeId(int i, int j, int k)
    {
        return 0;
    }

    public int b(int i, int j, int k)
    {
        return 255;
    }

    public boolean a(int i, int j, int k, int l, int i1)
    {
        return true;
    }

    public boolean a(int i, int j, int k, int l)
    {
        return true;
    }

    public int getData(int i, int j, int k)
    {
        return 0;
    }

    public boolean b(int i, int j, int k, int l)
    {
        return false;
    }

    public int getBrightness(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        return 0;
    }

    public void a(EnumSkyBlock enumskyblock, int i, int j, int k, int l)
    {
    }

    public int c(int i, int j, int k, int l)
    {
        return 0;
    }

    public void a(Entity entity)
    {
    }

    public void b(Entity entity)
    {
    }

    public void a(Entity entity, int i)
    {
    }

    public boolean d(int i, int j, int k)
    {
        return false;
    }

    public TileEntity e(int i, int j, int k)
    {
        return null;
    }

    public void a(TileEntity tileentity)
    {
    }

    public void a(int i, int j, int k, TileEntity tileentity)
    {
    }

    public void f(int i, int j, int k)
    {
    }

    public void addEntities()
    {
    }

    public void removeEntities()
    {
    }

    public void e()
    {
    }

    public void a(Entity entity, AxisAlignedBB axisalignedbb, List list)
    {
    }

    public void a(Class class1, AxisAlignedBB axisalignedbb, List list)
    {
    }

    public boolean a(boolean flag)
    {
        return false;
    }

    public Random a(long l)
    {
        return new Random(world.getSeed() + (long)(x * x * 0x4c1906) + (long)(x * 0x5ac0db) + (long)(z * z) * 0x4307a7L + (long)(z * 0x5f24f) ^ l);
    }

    public boolean isEmpty()
    {
        return true;
    }

    public boolean c(int i, int j)
    {
        return true;
    }
}
