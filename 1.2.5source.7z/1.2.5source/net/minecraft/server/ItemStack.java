// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ItemStack.java

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            NBTTagCompound, EntityHuman, NBTTagList, Block, 
//            Item, StatisticList, EnchantmentManager, EntityLiving, 
//            World, Enchantment, Entity, EnumAnimation

public final class ItemStack
{

    public ItemStack(Block block)
    {
        this(block, 1);
    }

    public ItemStack(Block block, int i)
    {
        this(block.id, i, 0);
    }

    public ItemStack(Block block, int i, int j)
    {
        this(block.id, i, j);
    }

    public ItemStack(Item item)
    {
        this(item.id, 1, 0);
    }

    public ItemStack(Item item, int i)
    {
        this(item.id, i, 0);
    }

    public ItemStack(Item item, int i, int j)
    {
        this(item.id, i, j);
    }

    public ItemStack(int i, int j, int k)
    {
        count = 0;
        id = i;
        count = j;
        setData(k);
    }

    public ItemStack(int id, int count, int data, NBTTagList enchantments)
    {
        this(id, count, data);
        if(enchantments != null && Item.byId[this.id].getMaxStackSize() == 1)
        {
            if(tag == null)
                setTag(new NBTTagCompound());
            tag.set("ench", enchantments.clone());
        }
    }

    public static ItemStack a(NBTTagCompound nbttagcompound)
    {
        ItemStack itemstack = new ItemStack();
        itemstack.c(nbttagcompound);
        return itemstack.getItem() == null ? null : itemstack;
    }

    private ItemStack()
    {
        count = 0;
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = new ItemStack(id, i, damage);
        if(tag != null)
            itemstack.tag = (NBTTagCompound)tag.clone();
        count -= i;
        return itemstack;
    }

    public Item getItem()
    {
        return Item.byId[id];
    }

    public boolean placeItem(EntityHuman entityhuman, World world, int i, int j, int k, int l)
    {
        boolean flag = getItem().interactWith(this, entityhuman, world, i, j, k, l);
        if(flag)
            entityhuman.a(StatisticList.E[id], 1);
        return flag;
    }

    public float a(Block block)
    {
        return getItem().getDestroySpeed(this, block);
    }

    public ItemStack a(World world, EntityHuman entityhuman)
    {
        return getItem().a(this, world, entityhuman);
    }

    public ItemStack b(World world, EntityHuman entityhuman)
    {
        return getItem().b(this, world, entityhuman);
    }

    public NBTTagCompound save(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("id", (short)id);
        nbttagcompound.setByte("Count", (byte)count);
        nbttagcompound.setShort("Damage", (short)damage);
        if(tag != null)
            nbttagcompound.set("tag", tag);
        return nbttagcompound;
    }

    public void c(NBTTagCompound nbttagcompound)
    {
        id = nbttagcompound.getShort("id");
        count = nbttagcompound.getByte("Count");
        damage = nbttagcompound.getShort("Damage");
        if(nbttagcompound.hasKey("tag"))
            tag = nbttagcompound.getCompound("tag");
    }

    public int getMaxStackSize()
    {
        return getItem().getMaxStackSize();
    }

    public boolean isStackable()
    {
        return getMaxStackSize() > 1 && (!d() || !f());
    }

    public boolean d()
    {
        return Item.byId[id].getMaxDurability() > 0;
    }

    public boolean usesData()
    {
        return Item.byId[id].e();
    }

    public boolean f()
    {
        return d() && damage > 0;
    }

    public int g()
    {
        return damage;
    }

    public int getData()
    {
        return damage;
    }

    public void setData(int i)
    {
        damage = id <= 0 || id >= 256 ? i : Item.byId[id].filterData(i);
    }

    public int i()
    {
        return Item.byId[id].getMaxDurability();
    }

    public void damage(int i, EntityLiving entityliving)
    {
        if(d())
        {
            if(i > 0 && (entityliving instanceof EntityHuman))
            {
                int j = EnchantmentManager.getDurabilityEnchantmentLevel(((EntityHuman)entityliving).inventory);
                if(j > 0 && entityliving.world.random.nextInt(j + 1) > 0)
                    return;
            }
            damage += i;
            if(damage > i())
            {
                entityliving.c(this);
                if(entityliving instanceof EntityHuman)
                    ((EntityHuman)entityliving).a(StatisticList.F[id], 1);
                count--;
                if(count < 0)
                    count = 0;
                damage = 0;
            }
        }
    }

    public void a(EntityLiving entityliving, EntityHuman entityhuman)
    {
        boolean flag = Item.byId[id].a(this, entityliving, entityhuman);
        if(flag)
            entityhuman.a(StatisticList.E[id], 1);
    }

    public void a(int i, int j, int k, int l, EntityHuman entityhuman)
    {
        boolean flag = Item.byId[id].a(this, i, j, k, l, entityhuman);
        if(flag)
            entityhuman.a(StatisticList.E[id], 1);
    }

    public int a(Entity entity)
    {
        return Item.byId[id].a(entity);
    }

    public boolean b(Block block)
    {
        return Item.byId[id].canDestroySpecialBlock(block);
    }

    public void a(EntityHuman entityhuman1)
    {
    }

    public void a(EntityLiving entityliving)
    {
        Item.byId[id].a(this, entityliving);
    }

    public ItemStack cloneItemStack()
    {
        ItemStack itemstack = new ItemStack(id, count, damage);
        if(tag != null)
        {
            itemstack.tag = (NBTTagCompound)tag.clone();
            if(!itemstack.tag.equals(tag))
                return itemstack;
        }
        return itemstack;
    }

    public static boolean equals(ItemStack itemstack, ItemStack itemstack1)
    {
        return itemstack != null || itemstack1 != null ? itemstack == null || itemstack1 == null ? false : itemstack.tag != null || itemstack1.tag == null ? itemstack.tag == null || itemstack.tag.equals(itemstack1.tag) : false : true;
    }

    public static boolean matches(ItemStack itemstack, ItemStack itemstack1)
    {
        return itemstack != null || itemstack1 != null ? itemstack == null || itemstack1 == null ? false : itemstack.d(itemstack1) : true;
    }

    private boolean d(ItemStack itemstack)
    {
        return count == itemstack.count ? id == itemstack.id ? damage == itemstack.damage ? tag != null || itemstack.tag == null ? tag == null || tag.equals(itemstack.tag) : false : false : false : false;
    }

    public boolean doMaterialsMatch(ItemStack itemstack)
    {
        return id == itemstack.id && damage == itemstack.damage;
    }

    public String k()
    {
        return Item.byId[id].a(this);
    }

    public static ItemStack b(ItemStack itemstack)
    {
        return itemstack != null ? itemstack.cloneItemStack() : null;
    }

    public String toString()
    {
        return (new StringBuilder()).append(count).append("x").append(Item.byId[id].getName()).append("@").append(damage).toString();
    }

    public void a(World world, Entity entity, int i, boolean flag)
    {
        if(b > 0)
            b--;
        Item.byId[id].a(this, world, entity, i, flag);
    }

    public void a(World world, EntityHuman entityhuman, int i)
    {
        entityhuman.a(StatisticList.D[id], i);
        Item.byId[id].d(this, world, entityhuman);
    }

    public boolean c(ItemStack itemstack)
    {
        return id == itemstack.id && count == itemstack.count && damage == itemstack.damage;
    }

    public int l()
    {
        return getItem().c(this);
    }

    public EnumAnimation m()
    {
        return getItem().d(this);
    }

    public void b(World world, EntityHuman entityhuman, int i)
    {
        getItem().a(this, world, entityhuman, i);
    }

    public boolean hasTag()
    {
        return tag != null;
    }

    public NBTTagCompound getTag()
    {
        return tag;
    }

    public NBTTagList getEnchantments()
    {
        return tag != null ? (NBTTagList)tag.get("ench") : null;
    }

    public void setTag(NBTTagCompound nbttagcompound)
    {
        tag = nbttagcompound;
    }

    public boolean q()
    {
        return getItem().f(this) ? !hasEnchantments() : false;
    }

    public void addEnchantment(Enchantment enchantment, int i)
    {
        if(tag == null)
            setTag(new NBTTagCompound());
        if(!tag.hasKey("ench"))
            tag.set("ench", new NBTTagList("ench"));
        NBTTagList nbttaglist = (NBTTagList)tag.get("ench");
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.setShort("id", (short)enchantment.id);
        nbttagcompound.setShort("lvl", (byte)i);
        nbttaglist.add(nbttagcompound);
    }

    public boolean hasEnchantments()
    {
        return tag != null && tag.hasKey("ench");
    }

    public int count;
    public int b;
    public int id;
    public NBTTagCompound tag;
    private int damage;
}
