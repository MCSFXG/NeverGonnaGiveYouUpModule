// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityEnderCrystal.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.event.CraftEventFactory;

// Referenced classes of package net.minecraft.server:
//            Entity, DataWatcher, MathHelper, World, 
//            Block, BlockFire, NBTTagCompound, DamageSource

public class EntityEnderCrystal extends Entity
{

    public EntityEnderCrystal(World world)
    {
        super(world);
        a = 0;
        bf = true;
        b(2.0F, 2.0F);
        height = length / 2.0F;
        b = 5;
        a = random.nextInt(0x186a0);
    }

    protected boolean g_()
    {
        return false;
    }

    protected void b()
    {
        datawatcher.a(8, Integer.valueOf(b));
    }

    public void F_()
    {
        lastX = locX;
        lastY = locY;
        lastZ = locZ;
        a++;
        datawatcher.watch(8, Integer.valueOf(b));
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locY);
        int k = MathHelper.floor(locZ);
        if(world.getTypeId(i, j, k) != Block.FIRE.id)
            world.setTypeId(i, j, k, Block.FIRE.id);
    }

    protected void b(NBTTagCompound nbttagcompound1)
    {
    }

    protected void a(NBTTagCompound nbttagcompound1)
    {
    }

    public boolean o_()
    {
        return true;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(!dead && !world.isStatic)
        {
            b = 0;
            if(b <= 0)
                if(!world.isStatic)
                {
                    if(CraftEventFactory.handleNonLivingEntityDamageEvent(this, damagesource, i))
                        return false;
                    die();
                    world.explode(this, locX, locY, locZ, 6F);
                } else
                {
                    die();
                }
        }
        return true;
    }

    public int a;
    public int b;
}
