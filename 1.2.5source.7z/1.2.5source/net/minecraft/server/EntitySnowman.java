// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySnowman.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.block.EntityBlockFormEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityGolem, PathfinderGoalArrowAttack, PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, 
//            EntityHuman, PathfinderGoalRandomLookaround, PathfinderGoalNearestAttackableTarget, EntityMonster, 
//            Navigation, PathfinderGoalSelector, World, DamageSource, 
//            MathHelper, BiomeBase, Block, Item, 
//            NBTTagCompound

public class EntitySnowman extends EntityGolem
{

    public EntitySnowman(World world)
    {
        super(world);
        texture = "/mob/snowman.png";
        b(0.4F, 1.8F);
        al().a(true);
        goalSelector.a(1, new PathfinderGoalArrowAttack(this, 0.25F, 2, 20));
        goalSelector.a(2, new PathfinderGoalRandomStroll(this, 0.2F));
        goalSelector.a(3, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 6F));
        goalSelector.a(4, new PathfinderGoalRandomLookaround(this));
        targetSelector.a(1, new PathfinderGoalNearestAttackableTarget(this, net/minecraft/server/EntityMonster, 16F, 0, true));
    }

    public boolean c_()
    {
        return true;
    }

    public int getMaxHealth()
    {
        return 4;
    }

    public void e()
    {
        super.e();
        if(aT())
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.DROWNING, 1);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                damageEntity(DamageSource.DROWN, event.getDamage());
        }
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locZ);
        if(world.getBiome(i, j).i() > 1.0F)
        {
            EntityDamageEvent event = new EntityDamageEvent(getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.MELTING, 1);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                damageEntity(DamageSource.BURN, event.getDamage());
        }
        for(i = 0; i < 4; i++)
        {
            j = MathHelper.floor(locX + (double)((float)((i % 2) * 2 - 1) * 0.25F));
            int k = MathHelper.floor(locY);
            int l = MathHelper.floor(locZ + (double)((float)(((i / 2) % 2) * 2 - 1) * 0.25F));
            if(world.getTypeId(j, k, l) != 0 || world.getBiome(j, l).i() >= 0.8F || !Block.SNOW.canPlace(world, j, k, l))
                continue;
            BlockState blockState = world.getWorld().getBlockAt(j, k, l).getState();
            blockState.setTypeId(Block.SNOW.id);
            EntityBlockFormEvent event = new EntityBlockFormEvent(getBukkitEntity(), blockState.getBlock(), blockState);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
                blockState.update(true);
        }

    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int getLootId()
    {
        return Item.SNOW_BALL.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = random.nextInt(16);
        if(j > 0)
            loot.add(new ItemStack(Item.SNOW_BALL.id, j));
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }
}
