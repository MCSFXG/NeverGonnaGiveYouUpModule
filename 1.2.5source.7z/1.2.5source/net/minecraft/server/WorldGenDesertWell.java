// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenerator, World, Block

public class WorldGenDesertWell extends WorldGenerator
{

    public WorldGenDesertWell()
    {
    }

    public boolean a(World world, Random random, int i, int j, int k)
    {
        for(; world.isEmpty(i, j, k) && j > 2; j--);
        int l = world.getTypeId(i, j, k);
        if(l != Block.SAND.id)
            return false;
        for(int i1 = -2; i1 <= 2; i1++)
        {
            for(int j2 = -2; j2 <= 2; j2++)
                if(world.isEmpty(i + i1, j - 1, k + j2) && world.isEmpty(i + i1, j - 2, k + j2))
                    return false;

        }

        for(int j1 = -1; j1 <= 0; j1++)
        {
            for(int k2 = -2; k2 <= 2; k2++)
            {
                for(int j3 = -2; j3 <= 2; j3++)
                    world.setRawTypeId(i + k2, j + j1, k + j3, Block.SANDSTONE.id);

            }

        }

        world.setRawTypeId(i, j, k, Block.WATER.id);
        world.setRawTypeId(i - 1, j, k, Block.WATER.id);
        world.setRawTypeId(i + 1, j, k, Block.WATER.id);
        world.setRawTypeId(i, j, k - 1, Block.WATER.id);
        world.setRawTypeId(i, j, k + 1, Block.WATER.id);
        for(int k1 = -2; k1 <= 2; k1++)
        {
            for(int l2 = -2; l2 <= 2; l2++)
                if(k1 == -2 || k1 == 2 || l2 == -2 || l2 == 2)
                    world.setRawTypeId(i + k1, j + 1, k + l2, Block.SANDSTONE.id);

        }

        world.setRawTypeIdAndData(i + 2, j + 1, k, Block.STEP.id, 1);
        world.setRawTypeIdAndData(i - 2, j + 1, k, Block.STEP.id, 1);
        world.setRawTypeIdAndData(i, j + 1, k + 2, Block.STEP.id, 1);
        world.setRawTypeIdAndData(i, j + 1, k - 2, Block.STEP.id, 1);
        for(int l1 = -1; l1 <= 1; l1++)
        {
            for(int i3 = -1; i3 <= 1; i3++)
                if(l1 == 0 && i3 == 0)
                    world.setRawTypeId(i + l1, j + 4, k + i3, Block.SANDSTONE.id);
                else
                    world.setRawTypeIdAndData(i + l1, j + 4, k + i3, Block.STEP.id, 1);

        }

        for(int i2 = 1; i2 <= 3; i2++)
        {
            world.setRawTypeId(i - 1, j + i2, k - 1, Block.SANDSTONE.id);
            world.setRawTypeId(i - 1, j + i2, k + 1, Block.SANDSTONE.id);
            world.setRawTypeId(i + 1, j + i2, k - 1, Block.SANDSTONE.id);
            world.setRawTypeId(i + 1, j + i2, k + 1, Block.SANDSTONE.id);
        }

        return true;
    }
}
