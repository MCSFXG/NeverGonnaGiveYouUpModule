// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            WorldGenNetherPiece9, WorldGenNetherPieces, WorldGenNetherPieceWeight

public class WorldGenNetherPiece15 extends WorldGenNetherPiece9
{

    public WorldGenNetherPiece15(Random random, int i, int j)
    {
        super(random, i, j);
        d = new ArrayList();
        b = new ArrayList();
        WorldGenNetherPieceWeight aworldgennetherpieceweight[] = WorldGenNetherPieces.a();
        int k = aworldgennetherpieceweight.length;
        for(int l = 0; l < k; l++)
        {
            WorldGenNetherPieceWeight worldgennetherpieceweight = aworldgennetherpieceweight[l];
            worldgennetherpieceweight.c = 0;
            b.add(worldgennetherpieceweight);
        }

        c = new ArrayList();
        aworldgennetherpieceweight = WorldGenNetherPieces.b();
        k = aworldgennetherpieceweight.length;
        for(int i1 = 0; i1 < k; i1++)
        {
            WorldGenNetherPieceWeight worldgennetherpieceweight1 = aworldgennetherpieceweight[i1];
            worldgennetherpieceweight1.c = 0;
            c.add(worldgennetherpieceweight1);
        }

    }

    public WorldGenNetherPieceWeight a;
    public List b;
    public List c;
    public ArrayList d;
}
