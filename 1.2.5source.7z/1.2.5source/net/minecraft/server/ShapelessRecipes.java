// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ShapelessRecipes.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Material;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.craftbukkit.inventory.CraftShapelessRecipe;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapelessRecipe;

// Referenced classes of package net.minecraft.server:
//            ItemStack, CraftingRecipe, InventoryCrafting

public class ShapelessRecipes
    implements CraftingRecipe
{

    public ShapelessRecipes(ItemStack itemstack, List list)
    {
        result = itemstack;
        ingredients = list;
    }

    public ShapelessRecipe toBukkitRecipe()
    {
        CraftItemStack result = new CraftItemStack(this.result);
        CraftShapelessRecipe recipe = new CraftShapelessRecipe(result, this);
        Iterator i$ = ingredients.iterator();
        do
        {
            if(!i$.hasNext())
                break;
            ItemStack stack = (ItemStack)i$.next();
            if(stack != null)
                recipe.addIngredient(Material.getMaterial(stack.id), stack.getData());
        } while(true);
        return recipe;
    }

    public ItemStack b()
    {
        return result;
    }

    public boolean a(InventoryCrafting inventorycrafting)
    {
        ArrayList arraylist = new ArrayList(ingredients);
        int i = 0;
        do
        {
            if(i >= 3)
                break;
            for(int j = 0; j < 3; j++)
            {
                ItemStack itemstack = inventorycrafting.b(j, i);
                if(itemstack == null)
                    continue;
                boolean flag = false;
                Iterator iterator = arraylist.iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    ItemStack itemstack1 = (ItemStack)iterator.next();
                    if(itemstack.id != itemstack1.id || itemstack1.getData() != -1 && itemstack.getData() != itemstack1.getData())
                        continue;
                    flag = true;
                    arraylist.remove(itemstack1);
                    break;
                } while(true);
                if(!flag)
                    return false;
            }

            i++;
        } while(true);
        return arraylist.isEmpty();
    }

    public ItemStack b(InventoryCrafting inventorycrafting)
    {
        return result.cloneItemStack();
    }

    public int a()
    {
        return ingredients.size();
    }

    public volatile Recipe toBukkitRecipe()
    {
        return toBukkitRecipe();
    }

    private final ItemStack result;
    private final List ingredients;
}
