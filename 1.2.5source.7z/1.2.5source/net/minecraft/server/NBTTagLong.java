// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagLong extends NBTBase
{

    public NBTTagLong(String s)
    {
        super(s);
    }

    public NBTTagLong(String s, long l)
    {
        super(s);
        data = l;
    }

    void write(DataOutput dataoutput)
    {
        dataoutput.writeLong(data);
    }

    void load(DataInput datainput)
    {
        data = datainput.readLong();
    }

    public byte getTypeId()
    {
        return 4;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(data).toString();
    }

    public NBTBase clone()
    {
        return new NBTTagLong(getName(), data);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagLong nbttaglong = (NBTTagLong)obj;
            return data == nbttaglong.data;
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        return super.hashCode() ^ (int)(data ^ data >>> 32);
    }

    public long data;
}
