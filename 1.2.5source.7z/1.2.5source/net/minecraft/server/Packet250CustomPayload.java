// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler

public class Packet250CustomPayload extends Packet
{

    public Packet250CustomPayload()
    {
    }

    public void a(DataInputStream datainputstream)
    {
        tag = a(datainputstream, 16);
        length = datainputstream.readShort();
        if(length > 0 && length < 32767)
        {
            data = new byte[length];
            datainputstream.readFully(data);
        }
    }

    public void a(DataOutputStream dataoutputstream)
    {
        a(tag, dataoutputstream);
        dataoutputstream.writeShort((short)length);
        if(data != null)
            dataoutputstream.write(data);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 2 + tag.length() * 2 + 2 + length;
    }

    public String tag;
    public int length;
    public byte data[];
}
