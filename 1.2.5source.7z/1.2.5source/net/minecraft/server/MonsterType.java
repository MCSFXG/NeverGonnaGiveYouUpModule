// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public final class MonsterType extends Enum
{

    public static MonsterType[] values()
    {
        return (MonsterType[])d.clone();
    }

    public static MonsterType valueOf(String s)
    {
        return (MonsterType)Enum.valueOf(net/minecraft/server/MonsterType, s);
    }

    private MonsterType(String s, int i)
    {
        super(s, i);
    }

    public static final MonsterType UNDEFINED;
    public static final MonsterType UNDEAD;
    public static final MonsterType ARTHROPOD;
    private static final MonsterType d[];

    static 
    {
        UNDEFINED = new MonsterType("UNDEFINED", 0);
        UNDEAD = new MonsterType("UNDEAD", 1);
        ARTHROPOD = new MonsterType("ARTHROPOD", 2);
        d = (new MonsterType[] {
            UNDEFINED, UNDEAD, ARTHROPOD
        });
    }
}
