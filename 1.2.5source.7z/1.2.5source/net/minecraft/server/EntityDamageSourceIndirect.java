// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityDamageSourceIndirect.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityDamageSource, Entity, EntityHuman, LocaleI18n

public class EntityDamageSourceIndirect extends EntityDamageSource
{

    public EntityDamageSourceIndirect(String s, Entity entity, Entity entity1)
    {
        super(s, entity);
        owner = entity1;
    }

    public Entity b()
    {
        return a;
    }

    public Entity getEntity()
    {
        return owner;
    }

    public String getLocalizedDeathMessage(EntityHuman entityhuman)
    {
        String source = owner != null ? owner.getLocalizedName() : "Herobrine";
        return LocaleI18n.get((new StringBuilder()).append("death.").append(translationIndex).toString(), new Object[] {
            entityhuman.name, source
        });
    }

    public Entity getProximateDamageSource()
    {
        return super.getEntity();
    }

    private Entity owner;
}
