// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NetworkWriterThread.java

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.IOException;

// Referenced classes of package net.minecraft.server:
//            NetworkManager

class NetworkWriterThread extends Thread
{

    NetworkWriterThread(NetworkManager networkmanager, String s)
    {
        super(s);
        a = networkmanager;
    }

    public void run()
    {
        Object object = NetworkManager.a;
        synchronized(NetworkManager.a)
        {
            NetworkManager.c++;
        }
_L2:
        boolean flag = false;
        flag = true;
        if(NetworkManager.a(a))
            break MISSING_BLOCK_LABEL_84;
        flag = false;
        if(flag)
        {
            Object object1 = NetworkManager.a;
            synchronized(NetworkManager.a)
            {
                NetworkManager.c--;
            }
        }
        break; /* Loop/switch isn't completed */
        while(NetworkManager.d(a)) ;
        try
        {
            if(NetworkManager.e(a) != null)
                NetworkManager.e(a).flush();
        }
        catch(IOException ioexception)
        {
            if(!NetworkManager.f(a))
                NetworkManager.a(a, ioexception);
        }
        try
        {
            sleep(2L);
        }
        catch(InterruptedException interruptedexception) { }
        if(flag)
        {
            Object object1 = NetworkManager.a;
            synchronized(NetworkManager.a)
            {
                NetworkManager.c--;
            }
        }
        if(true) goto _L2; else goto _L1
        Exception exception3;
        exception3;
        if(flag)
        {
            Object object1 = NetworkManager.a;
            synchronized(NetworkManager.a)
            {
                NetworkManager.c--;
            }
        }
        throw exception3;
_L1:
        Object object = NetworkManager.a;
        synchronized(NetworkManager.a)
        {
            NetworkManager.c--;
        }
        return;
    }

    final NetworkManager a;
}
