// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoalNearestAttackableTarget, EntityTameableAnimal

public class PathfinderGoalRandomTargetNonTamed extends PathfinderGoalNearestAttackableTarget
{

    public PathfinderGoalRandomTargetNonTamed(EntityTameableAnimal entitytameableanimal, Class class1, float f, int i, boolean flag)
    {
        super(entitytameableanimal, class1, f, i, flag);
        g = entitytameableanimal;
    }

    public boolean a()
    {
        if(g.isTamed())
            return false;
        else
            return super.a();
    }

    private EntityTameableAnimal g;
}
