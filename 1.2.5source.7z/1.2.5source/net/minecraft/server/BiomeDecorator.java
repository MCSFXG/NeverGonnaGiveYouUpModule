// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenClay, WorldGenSand, Block, WorldGenMinable, 
//            WorldGenFlowers, BlockFlower, WorldGenHugeMushroom, WorldGenReed, 
//            WorldGenCactus, WorldGenWaterLily, World, WorldGenerator, 
//            BiomeBase, WorldGenDeadBush, BlockDeadBush, WorldGenPumpkin, 
//            WorldGenLiquids

public class BiomeDecorator
{

    public BiomeDecorator(BiomeBase biomebase)
    {
        f = new WorldGenClay(4);
        g = new WorldGenSand(7, Block.SAND.id);
        h = new WorldGenSand(6, Block.GRAVEL.id);
        i = new WorldGenMinable(Block.DIRT.id, 32);
        j = new WorldGenMinable(Block.GRAVEL.id, 32);
        k = new WorldGenMinable(Block.COAL_ORE.id, 16);
        l = new WorldGenMinable(Block.IRON_ORE.id, 8);
        m = new WorldGenMinable(Block.GOLD_ORE.id, 8);
        n = new WorldGenMinable(Block.REDSTONE_ORE.id, 7);
        o = new WorldGenMinable(Block.DIAMOND_ORE.id, 7);
        p = new WorldGenMinable(Block.LAPIS_ORE.id, 6);
        q = new WorldGenFlowers(Block.YELLOW_FLOWER.id);
        r = new WorldGenFlowers(Block.RED_ROSE.id);
        s = new WorldGenFlowers(Block.BROWN_MUSHROOM.id);
        t = new WorldGenFlowers(Block.RED_MUSHROOM.id);
        u = new WorldGenHugeMushroom();
        v = new WorldGenReed();
        w = new WorldGenCactus();
        x = new WorldGenWaterLily();
        y = 0;
        z = 0;
        A = 2;
        B = 1;
        C = 0;
        D = 0;
        E = 0;
        F = 0;
        G = 1;
        H = 3;
        I = 1;
        J = 0;
        K = true;
        e = biomebase;
    }

    public void a(World world, Random random, int i1, int j1)
    {
        if(a != null)
        {
            throw new RuntimeException("Already decorating!!");
        } else
        {
            a = world;
            b = random;
            c = i1;
            d = j1;
            a();
            a = null;
            b = null;
            return;
        }
    }

    protected void a()
    {
        b();
        for(int i1 = 0; i1 < H; i1++)
        {
            int i2 = c + b.nextInt(16) + 8;
            int k6 = d + b.nextInt(16) + 8;
            g.a(a, b, i2, a.g(i2, k6), k6);
        }

        for(int j1 = 0; j1 < I; j1++)
        {
            int j2 = c + b.nextInt(16) + 8;
            int l6 = d + b.nextInt(16) + 8;
            f.a(a, b, j2, a.g(j2, l6), l6);
        }

        for(int k1 = 0; k1 < G; k1++)
        {
            int k2 = c + b.nextInt(16) + 8;
            int i7 = d + b.nextInt(16) + 8;
            g.a(a, b, k2, a.g(k2, i7), i7);
        }

        int l1 = z;
        if(b.nextInt(10) == 0)
            l1++;
        for(int l2 = 0; l2 < l1; l2++)
        {
            int j7 = c + b.nextInt(16) + 8;
            int k11 = d + b.nextInt(16) + 8;
            WorldGenerator worldgenerator = e.a(b);
            worldgenerator.a(1.0D, 1.0D, 1.0D);
            worldgenerator.a(a, b, j7, a.getHighestBlockYAt(j7, k11), k11);
        }

        for(int i3 = 0; i3 < J; i3++)
        {
            int k7 = c + b.nextInt(16) + 8;
            int l11 = d + b.nextInt(16) + 8;
            u.a(a, b, k7, a.getHighestBlockYAt(k7, l11), l11);
        }

        for(int j3 = 0; j3 < A; j3++)
        {
            int l7 = c + b.nextInt(16) + 8;
            int i12 = b.nextInt(128);
            int l15 = d + b.nextInt(16) + 8;
            q.a(a, b, l7, i12, l15);
            if(b.nextInt(4) == 0)
            {
                int i8 = c + b.nextInt(16) + 8;
                int j12 = b.nextInt(128);
                int i16 = d + b.nextInt(16) + 8;
                r.a(a, b, i8, j12, i16);
            }
        }

        for(int k3 = 0; k3 < B; k3++)
        {
            int j8 = c + b.nextInt(16) + 8;
            int k12 = b.nextInt(128);
            int j16 = d + b.nextInt(16) + 8;
            WorldGenerator worldgenerator1 = e.b(b);
            worldgenerator1.a(a, b, j8, k12, j16);
        }

        for(int l3 = 0; l3 < C; l3++)
        {
            int k8 = c + b.nextInt(16) + 8;
            int l12 = b.nextInt(128);
            int k16 = d + b.nextInt(16) + 8;
            (new WorldGenDeadBush(Block.DEAD_BUSH.id)).a(a, b, k8, l12, k16);
        }

        for(int i4 = 0; i4 < y; i4++)
        {
            int l8 = c + b.nextInt(16) + 8;
            int i13 = d + b.nextInt(16) + 8;
            int l16;
            for(l16 = b.nextInt(128); l16 > 0 && a.getTypeId(l8, l16 - 1, i13) == 0; l16--);
            x.a(a, b, l8, l16, i13);
        }

        for(int j4 = 0; j4 < D; j4++)
        {
            if(b.nextInt(4) == 0)
            {
                int i9 = c + b.nextInt(16) + 8;
                int j13 = d + b.nextInt(16) + 8;
                int i17 = a.getHighestBlockYAt(i9, j13);
                s.a(a, b, i9, i17, j13);
            }
            if(b.nextInt(8) == 0)
            {
                int j9 = c + b.nextInt(16) + 8;
                int k13 = d + b.nextInt(16) + 8;
                int j17 = b.nextInt(128);
                t.a(a, b, j9, j17, k13);
            }
        }

        if(b.nextInt(4) == 0)
        {
            int k4 = c + b.nextInt(16) + 8;
            int k9 = b.nextInt(128);
            int l13 = d + b.nextInt(16) + 8;
            s.a(a, b, k4, k9, l13);
        }
        if(b.nextInt(8) == 0)
        {
            int l4 = c + b.nextInt(16) + 8;
            int l9 = b.nextInt(128);
            int i14 = d + b.nextInt(16) + 8;
            t.a(a, b, l4, l9, i14);
        }
        for(int i5 = 0; i5 < E; i5++)
        {
            int i10 = c + b.nextInt(16) + 8;
            int j14 = d + b.nextInt(16) + 8;
            int k17 = b.nextInt(128);
            v.a(a, b, i10, k17, j14);
        }

        for(int j5 = 0; j5 < 10; j5++)
        {
            int j10 = c + b.nextInt(16) + 8;
            int k14 = b.nextInt(128);
            int l17 = d + b.nextInt(16) + 8;
            v.a(a, b, j10, k14, l17);
        }

        if(b.nextInt(32) == 0)
        {
            int k5 = c + b.nextInt(16) + 8;
            int k10 = b.nextInt(128);
            int l14 = d + b.nextInt(16) + 8;
            (new WorldGenPumpkin()).a(a, b, k5, k10, l14);
        }
        for(int l5 = 0; l5 < F; l5++)
        {
            int l10 = c + b.nextInt(16) + 8;
            int i15 = b.nextInt(128);
            int i18 = d + b.nextInt(16) + 8;
            w.a(a, b, l10, i15, i18);
        }

        if(K)
        {
            for(int i6 = 0; i6 < 50; i6++)
            {
                int i11 = c + b.nextInt(16) + 8;
                int j15 = b.nextInt(b.nextInt(120) + 8);
                int j18 = d + b.nextInt(16) + 8;
                (new WorldGenLiquids(Block.WATER.id)).a(a, b, i11, j15, j18);
            }

            for(int j6 = 0; j6 < 20; j6++)
            {
                int j11 = c + b.nextInt(16) + 8;
                int k15 = b.nextInt(b.nextInt(b.nextInt(112) + 8) + 8);
                int k18 = d + b.nextInt(16) + 8;
                (new WorldGenLiquids(Block.LAVA.id)).a(a, b, j11, k15, k18);
            }

        }
    }

    protected void a(int i1, WorldGenerator worldgenerator, int j1, int k1)
    {
        for(int l1 = 0; l1 < i1; l1++)
        {
            int i2 = c + b.nextInt(16);
            int j2 = b.nextInt(k1 - j1) + j1;
            int k2 = d + b.nextInt(16);
            worldgenerator.a(a, b, i2, j2, k2);
        }

    }

    protected void b(int i1, WorldGenerator worldgenerator, int j1, int k1)
    {
        for(int l1 = 0; l1 < i1; l1++)
        {
            int i2 = c + b.nextInt(16);
            int j2 = b.nextInt(k1) + b.nextInt(k1) + (j1 - k1);
            int k2 = d + b.nextInt(16);
            worldgenerator.a(a, b, i2, j2, k2);
        }

    }

    protected void b()
    {
        a(20, i, 0, 128);
        a(10, j, 0, 128);
        a(20, k, 0, 128);
        a(20, l, 0, 64);
        a(2, m, 0, 32);
        a(8, n, 0, 16);
        a(1, o, 0, 16);
        b(1, p, 16, 16);
    }

    protected World a;
    protected Random b;
    protected int c;
    protected int d;
    protected BiomeBase e;
    protected WorldGenerator f;
    protected WorldGenerator g;
    protected WorldGenerator h;
    protected WorldGenerator i;
    protected WorldGenerator j;
    protected WorldGenerator k;
    protected WorldGenerator l;
    protected WorldGenerator m;
    protected WorldGenerator n;
    protected WorldGenerator o;
    protected WorldGenerator p;
    protected WorldGenerator q;
    protected WorldGenerator r;
    protected WorldGenerator s;
    protected WorldGenerator t;
    protected WorldGenerator u;
    protected WorldGenerator v;
    protected WorldGenerator w;
    protected WorldGenerator x;
    protected int y;
    protected int z;
    protected int A;
    protected int B;
    protected int C;
    protected int D;
    protected int E;
    protected int F;
    protected int G;
    protected int H;
    protected int I;
    protected int J;
    public boolean K;
}
