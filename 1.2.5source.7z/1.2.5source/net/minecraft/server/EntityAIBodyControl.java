// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityLiving

public class EntityAIBodyControl
{

    public EntityAIBodyControl(EntityLiving entityliving)
    {
        b = 0;
        c = 0.0F;
        entity = entityliving;
    }

    public void a()
    {
        double d = entity.locX - entity.lastX;
        double d1 = entity.locZ - entity.lastZ;
        if(d * d + d1 * d1 > 2.5000002779052011E-007D)
        {
            entity.V = entity.yaw;
            entity.X = a(entity.V, entity.X, 75F);
            c = entity.X;
            b = 0;
            return;
        }
        float f = 75F;
        if(Math.abs(entity.X - c) > 15F)
        {
            b = 0;
            c = entity.X;
        } else
        {
            b++;
            if(b > 10)
                f = Math.max(1.0F - (float)(b - 10) / 10F, 0.0F) * 75F;
        }
        entity.V = a(entity.X, entity.V, f);
    }

    private float a(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f - f1; f3 < -180F; f3 += 360F);
        for(; f3 >= 180F; f3 -= 360F);
        if(f3 < -f2)
            f3 = -f2;
        if(f3 >= f2)
            f3 = f2;
        return f - f3;
    }

    private EntityLiving entity;
    private int b;
    private float c;
}
