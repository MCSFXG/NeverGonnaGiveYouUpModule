// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ItemFireball.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Item, World, EntityHuman, PlayerAbilities, 
//            ItemStack, Block, BlockFire

public class ItemFireball extends Item
{

    public ItemFireball(int i)
    {
        super(i);
    }

    public boolean interactWith(ItemStack itemstack, EntityHuman entityhuman, World world, int i, int j, int k, int l)
    {
        if(world.isStatic)
            return true;
        if(l == 0)
            j--;
        if(l == 1)
            j++;
        if(l == 2)
            k--;
        if(l == 3)
            k++;
        if(l == 4)
            i--;
        if(l == 5)
            i++;
        if(!entityhuman.d(i, j, k))
            return false;
        int i1 = world.getTypeId(i, j, k);
        if(i1 == 0)
        {
            org.bukkit.block.Block blockClicked = world.getWorld().getBlockAt(i, j, k);
            Player thePlayer = (Player)entityhuman.getBukkitEntity();
            BlockIgniteEvent eventIgnite = new BlockIgniteEvent(blockClicked, org.bukkit.event.block.BlockIgniteEvent.IgniteCause.FIREBALL, thePlayer);
            world.getServer().getPluginManager().callEvent(eventIgnite);
            if(eventIgnite.isCancelled())
            {
                if(!entityhuman.abilities.canInstantlyBuild)
                    itemstack.count--;
                return false;
            }
            world.makeSound((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D, "fire.ignite", 1.0F, c.nextFloat() * 0.4F + 0.8F);
            world.setTypeId(i, j, k, Block.FIRE.id);
        }
        if(!entityhuman.abilities.canInstantlyBuild)
            itemstack.count--;
        return true;
    }
}
