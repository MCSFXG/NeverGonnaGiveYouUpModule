// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityLiving

public class ControllerJump
{

    public ControllerJump(EntityLiving entityliving)
    {
        b = false;
        a = entityliving;
    }

    public void a()
    {
        b = true;
    }

    public void b()
    {
        a.f(b);
        b = false;
    }

    private EntityLiving a;
    private boolean b;
}
