// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType, EntityLiving, MonsterType

public class EnchantmentWeaponDamage extends Enchantment
{

    public EnchantmentWeaponDamage(int i, int j, int k)
    {
        super(i, j, EnchantmentSlotType.WEAPON);
        a = k;
    }

    public int a(int i)
    {
        return B[a] + (i - 1) * C[a];
    }

    public int b(int i)
    {
        return a(i) + D[a];
    }

    public int getMaxLevel()
    {
        return 5;
    }

    public int a(int i, EntityLiving entityliving)
    {
        if(a == 0)
            return i * 3;
        if(a == 1 && entityliving.getMonsterType() == MonsterType.UNDEAD)
            return i * 4;
        if(a == 2 && entityliving.getMonsterType() == MonsterType.ARTHROPOD)
            return i * 4;
        else
            return 0;
    }

    public boolean a(Enchantment enchantment)
    {
        return !(enchantment instanceof EnchantmentWeaponDamage);
    }

    private static final String A[] = {
        "all", "undead", "arthropods"
    };
    private static final int B[] = {
        1, 5, 5
    };
    private static final int C[] = {
        16, 8, 8
    };
    private static final int D[] = {
        20, 20, 20
    };
    public final int a;

}
