// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, WorldType, NetHandler

public class Packet1Login extends Packet
{

    public Packet1Login()
    {
    }

    public Packet1Login(String s, int i, WorldType worldtype, int j, int k, byte byte0, byte byte1, 
            byte byte2)
    {
        name = s;
        a = i;
        c = worldtype;
        e = k;
        f = byte0;
        d = j;
        g = byte1;
        h = byte2;
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readInt();
        name = a(datainputstream, 16);
        String s = a(datainputstream, 16);
        c = WorldType.getType(s);
        if(c == null)
            c = WorldType.NORMAL;
        d = datainputstream.readInt();
        e = datainputstream.readInt();
        f = datainputstream.readByte();
        g = datainputstream.readByte();
        h = datainputstream.readByte();
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeInt(a);
        a(name, dataoutputstream);
        if(c == null)
            a("", dataoutputstream);
        else
            a(c.name(), dataoutputstream);
        dataoutputstream.writeInt(d);
        dataoutputstream.writeInt(e);
        dataoutputstream.writeByte(f);
        dataoutputstream.writeByte(g);
        dataoutputstream.writeByte(h);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        int i = 0;
        if(c != null)
            i = c.name().length();
        return 4 + name.length() + 4 + 7 + 7 + i;
    }

    public int a;
    public String name;
    public WorldType c;
    public int d;
    public int e;
    public byte f;
    public byte g;
    public byte h;
}
