// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NetworkAcceptThread.java

package net.minecraft.server;

import java.io.IOException;
import java.net.*;
import java.util.HashMap;
import org.bukkit.craftbukkit.CraftServer;

// Referenced classes of package net.minecraft.server:
//            NetLoginHandler, NetworkListenThread, MinecraftServer

class NetworkAcceptThread extends Thread
{

    NetworkAcceptThread(NetworkListenThread networklistenthread, String s, MinecraftServer minecraftserver)
    {
        super(s);
        listenThread = networklistenthread;
        a = minecraftserver;
    }

    public void run()
    {
_L3:
        if(!listenThread.b)
            break; /* Loop/switch isn't completed */
        Socket socket;
        NetLoginHandler netloginhandler;
        InetAddress inetaddress;
        try
        {
label0:
            {
                socket = NetworkListenThread.a(listenThread).accept();
                if(socket == null)
                    continue; /* Loop/switch isn't completed */
                synchronized(NetworkListenThread.getRecentConnectionAttempts(listenThread))
                {
                    inetaddress = socket.getInetAddress();
                    if(a.server != null)
                        break label0;
                    socket.close();
                }
                continue; /* Loop/switch isn't completed */
            }
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
        continue; /* Loop/switch isn't completed */
        connectionThrottle = a.server.getConnectionThrottle();
        if(!NetworkListenThread.getRecentConnectionAttempts(listenThread).containsKey(inetaddress) || "127.0.0.1".equals(inetaddress.getHostAddress()) || System.currentTimeMillis() - ((Long)NetworkListenThread.getRecentConnectionAttempts(listenThread).get(inetaddress)).longValue() >= connectionThrottle)
            break MISSING_BLOCK_LABEL_155;
        NetworkListenThread.getRecentConnectionAttempts(listenThread).put(inetaddress, Long.valueOf(System.currentTimeMillis()));
        socket.close();
        hashmap;
        JVM INSTR monitorexit ;
        continue; /* Loop/switch isn't completed */
        NetworkListenThread.getRecentConnectionAttempts(listenThread).put(inetaddress, Long.valueOf(System.currentTimeMillis()));
        hashmap;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
        netloginhandler = new NetLoginHandler(a, socket, (new StringBuilder()).append("Connection #").append(NetworkListenThread.c(listenThread)).toString());
        NetworkListenThread.a(listenThread, netloginhandler);
        continue; /* Loop/switch isn't completed */
        if(true) goto _L3; else goto _L2
_L2:
    }

    final MinecraftServer a;
    final NetworkListenThread listenThread;
    long connectionThrottle;
}
