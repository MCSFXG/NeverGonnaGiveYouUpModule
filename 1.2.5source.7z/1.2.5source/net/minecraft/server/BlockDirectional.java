// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Block, Material

public abstract class BlockDirectional extends Block
{

    protected BlockDirectional(int i, int j, Material material)
    {
        super(i, j, material);
    }

    protected BlockDirectional(int i, Material material)
    {
        super(i, material);
    }

    public static int b(int i)
    {
        return i & 3;
    }
}
