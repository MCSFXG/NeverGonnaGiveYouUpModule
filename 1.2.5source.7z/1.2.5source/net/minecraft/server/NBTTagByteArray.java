// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.Arrays;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagByteArray extends NBTBase
{

    public NBTTagByteArray(String s)
    {
        super(s);
    }

    public NBTTagByteArray(String s, byte abyte0[])
    {
        super(s);
        data = abyte0;
    }

    void write(DataOutput dataoutput)
    {
        dataoutput.writeInt(data.length);
        dataoutput.write(data);
    }

    void load(DataInput datainput)
    {
        int i = datainput.readInt();
        data = new byte[i];
        datainput.readFully(data);
    }

    public byte getTypeId()
    {
        return 7;
    }

    public String toString()
    {
        return (new StringBuilder()).append("[").append(data.length).append(" bytes]").toString();
    }

    public NBTBase clone()
    {
        byte abyte0[] = new byte[data.length];
        System.arraycopy(data, 0, abyte0, 0, data.length);
        return new NBTTagByteArray(getName(), abyte0);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
            return Arrays.equals(data, ((NBTTagByteArray)obj).data);
        else
            return false;
    }

    public int hashCode()
    {
        return super.hashCode() ^ Arrays.hashCode(data);
    }

    public byte data[];
}
