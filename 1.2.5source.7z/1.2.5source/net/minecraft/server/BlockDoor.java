// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockDoor.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Block, EntityHuman, Material, World, 
//            Item, IBlockAccess, AxisAlignedBB, Vec3D, 
//            MovingObjectPosition

public class BlockDoor extends net.minecraft.server.Block
{

    protected BlockDoor(int i, Material material)
    {
        super(i, material);
        textureId = 97;
        if(material == Material.ORE)
            textureId++;
        float f = 0.5F;
        float f1 = 1.0F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f1, 0.5F + f);
    }

    public boolean a()
    {
        return false;
    }

    public boolean b(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = e(iblockaccess, i, j, k);
        return (l & 4) != 0;
    }

    public boolean b()
    {
        return false;
    }

    public int c()
    {
        return 7;
    }

    public AxisAlignedBB e(net.minecraft.server.World world, int i, int j, int k)
    {
        updateShape(world, i, j, k);
        return super.e(world, i, j, k);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        d(e(iblockaccess, i, j, k));
    }

    public int c(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return e(iblockaccess, i, j, k) & 3;
    }

    public boolean d(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return (e(iblockaccess, i, j, k) & 4) != 0;
    }

    private void d(int i)
    {
        float f = 0.1875F;
        a(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
        int j = i & 3;
        boolean flag = (i & 4) != 0;
        boolean flag1 = (i & 0x10) != 0;
        if(j == 0)
        {
            if(!flag)
                a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
            else
            if(!flag1)
                a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
            else
                a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        } else
        if(j == 1)
        {
            if(!flag)
                a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
            else
            if(!flag1)
                a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            else
                a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        } else
        if(j == 2)
        {
            if(!flag)
                a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            else
            if(!flag1)
                a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
            else
                a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        } else
        if(j == 3)
            if(!flag)
                a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
            else
            if(!flag1)
                a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
            else
                a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public void attack(net.minecraft.server.World world, int i, int j, int k, EntityHuman entityhuman)
    {
        interact(world, i, j, k, entityhuman);
    }

    public boolean interact(net.minecraft.server.World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(material == Material.ORE)
            return true;
        int l = e(world, i, j, k);
        int i1 = l & 7;
        i1 ^= 4;
        if((l & 8) != 0)
        {
            world.setData(i, j - 1, k, i1);
            world.b(i, j - 1, k, i, j, k);
        } else
        {
            world.setData(i, j, k, i1);
            world.b(i, j, k, i, j, k);
        }
        world.a(entityhuman, 1003, i, j, k, 0);
        return true;
    }

    public void setDoor(net.minecraft.server.World world, int i, int j, int k, boolean flag)
    {
        int l = e(world, i, j, k);
        boolean flag1 = (l & 4) != 0;
        if(flag1 != flag)
        {
            int i1 = l & 7;
            i1 ^= 4;
            if((l & 8) != 0)
            {
                world.setData(i, j - 1, k, i1);
                world.b(i, j - 1, k, i, j, k);
            } else
            {
                world.setData(i, j, k, i1);
                world.b(i, j, k, i, j, k);
            }
            world.a((EntityHuman)null, 1003, i, j, k, 0);
        }
    }

    public void doPhysics(net.minecraft.server.World world, int i, int j, int k, int l)
    {
        int i1 = world.getData(i, j, k);
        if((i1 & 8) != 0)
        {
            if(world.getTypeId(i, j - 1, k) != id)
                world.setTypeId(i, j, k, 0);
            else
            if(l > 0 && l != id)
                doPhysics(world, i, j - 1, k, l);
        } else
        {
            boolean flag = false;
            if(world.getTypeId(i, j + 1, k) != id)
            {
                world.setTypeId(i, j, k, 0);
                flag = true;
            }
            if(!world.e(i, j - 1, k))
            {
                world.setTypeId(i, j, k, 0);
                flag = true;
                if(world.getTypeId(i, j + 1, k) == id)
                    world.setTypeId(i, j + 1, k, 0);
            }
            if(flag)
            {
                if(!world.isStatic)
                    b(world, i, j, k, i1, 0);
            } else
            if(l > 0 && Block.byId[l].isPowerSource())
            {
                World bworld = world.getWorld();
                Block block = bworld.getBlockAt(i, j, k);
                Block blockTop = bworld.getBlockAt(i, j + 1, k);
                int power = block.getBlockPower();
                int powerTop = blockTop.getBlockPower();
                if(powerTop > power)
                    power = powerTop;
                int oldPower = (world.getData(i, j, k) & 4) <= 0 ? 0 : 15;
                if((oldPower == 0) ^ (power == 0))
                {
                    BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, oldPower, power);
                    world.getServer().getPluginManager().callEvent(eventRedstone);
                    setDoor(world, i, j, k, eventRedstone.getNewCurrent() > 0);
                }
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return (i & 8) == 0 ? material != Material.ORE ? Item.WOOD_DOOR.id : Item.IRON_DOOR.id : 0;
    }

    public MovingObjectPosition a(net.minecraft.server.World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
    {
        updateShape(world, i, j, k);
        return super.a(world, i, j, k, vec3d, vec3d1);
    }

    public boolean canPlace(net.minecraft.server.World world, int i, int j, int k)
    {
        return j < 255 ? world.e(i, j - 1, k) && super.canPlace(world, i, j, k) && super.canPlace(world, i, j + 1, k) : false;
    }

    public int g()
    {
        return 1;
    }

    public int e(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getData(i, j, k);
        boolean flag = (l & 8) != 0;
        int i1;
        int j1;
        if(flag)
        {
            i1 = iblockaccess.getData(i, j - 1, k);
            j1 = l;
        } else
        {
            i1 = l;
            j1 = iblockaccess.getData(i, j + 1, k);
        }
        boolean flag1 = (j1 & 1) != 0;
        int k1 = i1 & 7 | (flag ? 8 : 0) | (flag1 ? 0x10 : 0);
        return k1;
    }
}
