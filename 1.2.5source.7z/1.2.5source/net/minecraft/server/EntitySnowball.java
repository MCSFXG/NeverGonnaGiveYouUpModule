// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityProjectile, MovingObjectPosition, EntityBlaze, DamageSource, 
//            Entity, World, EntityLiving

public class EntitySnowball extends EntityProjectile
{

    public EntitySnowball(World world)
    {
        super(world);
    }

    public EntitySnowball(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntitySnowball(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(movingobjectposition.entity != null)
        {
            byte byte0 = 0;
            if(movingobjectposition.entity instanceof EntityBlaze)
                byte0 = 3;
            if(!movingobjectposition.entity.damageEntity(DamageSource.projectile(this, shooter), byte0));
        }
        for(int i = 0; i < 8; i++)
            world.a("snowballpoof", locX, locY, locZ, 0.0D, 0.0D, 0.0D);

        if(!world.isStatic)
            die();
    }
}
