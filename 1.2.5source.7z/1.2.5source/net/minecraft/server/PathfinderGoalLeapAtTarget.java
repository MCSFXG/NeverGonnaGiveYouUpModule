// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityLiving, MathHelper

public class PathfinderGoalLeapAtTarget extends PathfinderGoal
{

    public PathfinderGoalLeapAtTarget(EntityLiving entityliving, float f)
    {
        a = entityliving;
        c = f;
        a(5);
    }

    public boolean a()
    {
        b = a.at();
        if(b == null)
            return false;
        double d = a.j(b);
        if(d < 4D || d > 16D)
            return false;
        if(!a.onGround)
            return false;
        return a.an().nextInt(5) == 0;
    }

    public boolean b()
    {
        return !a.onGround;
    }

    public void c()
    {
        double d = b.locX - a.locX;
        double d1 = b.locZ - a.locZ;
        float f = MathHelper.sqrt(d * d + d1 * d1);
        a.motX += (d / (double)f) * 0.5D * 0.80000001192092896D + a.motX * 0.20000000298023224D;
        a.motZ += (d1 / (double)f) * 0.5D * 0.80000001192092896D + a.motZ * 0.20000000298023224D;
        a.motY = c;
    }

    EntityLiving a;
    EntityLiving b;
    float c;
}
