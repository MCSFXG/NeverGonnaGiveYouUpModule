// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityAgeable, NPC, Navigation, PathfinderGoalFloat, 
//            PathfinderGoalSelector, PathfinderGoalAvoidPlayer, EntityZombie, PathfinderGoalMoveIndoors, 
//            PathfinderGoalRestrictOpenDoor, PathfinderGoalOpenDoor, PathfinderGoalMoveTowardsRestriction, PathfinderGoalMakeLove, 
//            PathfinderGoalTakeFlower, PathfinderGoalPlay, PathfinderGoalInteract, EntityHuman, 
//            PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, EntityLiving, World, 
//            MathHelper, VillageCollection, Village, ChunkCoordinates, 
//            DataWatcher, NBTTagCompound

public class EntityVillager extends EntityAgeable
    implements NPC
{

    public EntityVillager(World world)
    {
        this(world, 0);
    }

    public EntityVillager(World world, int l)
    {
        super(world);
        profession = 0;
        c = false;
        g = false;
        village = null;
        setProfession(l);
        texture = "/mob/villager/villager.png";
        bb = 0.5F;
        al().b(true);
        al().a(true);
        goalSelector.a(0, new PathfinderGoalFloat(this));
        goalSelector.a(1, new PathfinderGoalAvoidPlayer(this, net/minecraft/server/EntityZombie, 8F, 0.3F, 0.35F));
        goalSelector.a(2, new PathfinderGoalMoveIndoors(this));
        goalSelector.a(3, new PathfinderGoalRestrictOpenDoor(this));
        goalSelector.a(4, new PathfinderGoalOpenDoor(this, true));
        goalSelector.a(5, new PathfinderGoalMoveTowardsRestriction(this, 0.3F));
        goalSelector.a(6, new PathfinderGoalMakeLove(this));
        goalSelector.a(7, new PathfinderGoalTakeFlower(this));
        goalSelector.a(8, new PathfinderGoalPlay(this, 0.32F));
        goalSelector.a(9, new PathfinderGoalInteract(this, net/minecraft/server/EntityHuman, 3F, 1.0F));
        goalSelector.a(9, new PathfinderGoalInteract(this, net/minecraft/server/EntityVillager, 5F, 0.02F));
        goalSelector.a(9, new PathfinderGoalRandomStroll(this, 0.3F));
        goalSelector.a(10, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityLiving, 8F));
    }

    public boolean c_()
    {
        return true;
    }

    protected void g()
    {
        if(--profession <= 0)
        {
            world.villages.a(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
            profession = 70 + random.nextInt(50);
            village = world.villages.getClosestVillage(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ), 32);
            if(village == null)
            {
                ax();
            } else
            {
                ChunkCoordinates chunkcoordinates = village.getCenter();
                b(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, village.getSize());
            }
        }
        super.g();
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Integer.valueOf(0));
    }

    public int getMaxHealth()
    {
        return 20;
    }

    public void e()
    {
        super.e();
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setInt("Profession", getProfession());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setProfession(nbttagcompound.getInt("Profession"));
    }

    protected boolean n()
    {
        return false;
    }

    protected String i()
    {
        return "mob.villager.default";
    }

    protected String j()
    {
        return "mob.villager.defaulthurt";
    }

    protected String k()
    {
        return "mob.villager.defaultdeath";
    }

    public void setProfession(int l)
    {
        datawatcher.watch(16, Integer.valueOf(l));
    }

    public int getProfession()
    {
        return datawatcher.getInt(16);
    }

    public boolean A()
    {
        return c;
    }

    public void a(boolean flag)
    {
        c = flag;
    }

    public void b(boolean flag)
    {
        g = flag;
    }

    public boolean C()
    {
        return g;
    }

    public void a(EntityLiving entityliving)
    {
        super.a(entityliving);
        if(village != null && entityliving != null)
            village.a(entityliving);
    }

    private int profession;
    private boolean c;
    private boolean g;
    Village village;
}
