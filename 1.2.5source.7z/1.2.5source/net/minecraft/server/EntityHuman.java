// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityHuman.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.craftbukkit.*;
import org.bukkit.craftbukkit.entity.CraftItem;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityLiving, PlayerInventory, FoodMetaData, PlayerAbilities, 
//            ContainerPlayer, Entity, ItemStack, EntityItem, 
//            ChunkCoordinates, NBTTagList, EntityMonster, EntityArrow, 
//            EntityCreeper, EntityGhast, EntityWolf, EntityMinecart, 
//            EntityBoat, EntityPig, World, DataWatcher, 
//            Item, EnumAnimation, Container, StatisticList, 
//            Vec3D, MobEffectList, MobEffect, MathHelper, 
//            AxisAlignedBB, EnchantmentManager, Material, NBTTagCompound, 
//            DamageSource, AchievementList, EnumBedResult, WorldProvider, 
//            BlockBed, Block, IChunkProvider, WorldData, 
//            EntityFishingHook, IInventory, TileEntityFurnace, TileEntityDispenser, 
//            TileEntitySign, TileEntityBrewingStand, Statistic

public abstract class EntityHuman extends EntityLiving
{

    public HumanEntity getBukkitEntity()
    {
        return (HumanEntity)super.getBukkitEntity();
    }

    public EntityHuman(net.minecraft.server.World world)
    {
        super(world);
        inventory = new net.minecraft.server.PlayerInventory(this);
        foodData = new FoodMetaData();
        o = 0;
        p = 0;
        q = 0;
        t = false;
        u = 0;
        x = 0;
        spawnWorld = "";
        I = 20;
        J = false;
        abilities = new PlayerAbilities();
        oldLevel = -1;
        P = 0.1F;
        Q = 0.02F;
        hookedFish = null;
        defaultContainer = new ContainerPlayer(inventory, !world.isStatic);
        activeContainer = defaultContainer;
        height = 1.62F;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        setPositionRotation((double)chunkcoordinates.x + 0.5D, chunkcoordinates.y + 1, (double)chunkcoordinates.z + 0.5D, 0.0F, 0.0F);
        ah = "humanoid";
        ag = 180F;
        maxFireTicks = 20;
        texture = "/mob/char.png";
    }

    public int getMaxHealth()
    {
        return 20;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
        datawatcher.a(17, Byte.valueOf((byte)0));
    }

    public boolean M()
    {
        return d != null;
    }

    public void N()
    {
        if(d != null)
            d.b(world, this, e);
        O();
    }

    public void O()
    {
        d = null;
        e = 0;
        if(!world.isStatic)
            i(false);
    }

    public boolean P()
    {
        return M() && Item.byId[d.id].d(d) == EnumAnimation.d;
    }

    public void F_()
    {
        if(d != null)
        {
            net.minecraft.server.ItemStack itemstack = inventory.getItemInHand();
            if(itemstack != d)
            {
                O();
            } else
            {
                if(e <= 25 && e % 4 == 0)
                    b(itemstack, 5);
                if(--e == 0 && !world.isStatic)
                    K();
            }
        }
        if(x > 0)
            x--;
        if(isSleeping())
        {
            sleepTicks++;
            if(sleepTicks > 100)
                sleepTicks = 100;
            if(!world.isStatic)
                if(!G())
                    a(true, true, false);
                else
                if(world.e())
                    a(false, true, true);
        } else
        if(sleepTicks > 0)
        {
            sleepTicks++;
            if(sleepTicks >= 110)
                sleepTicks = 0;
        }
        super.F_();
        if(!world.isStatic && activeContainer != null && !activeContainer.b(this))
        {
            closeInventory();
            activeContainer = defaultContainer;
        }
        if(abilities.isFlying)
        {
            for(int i = 0; i < 8; i++);
        }
        if(isBurning() && abilities.isInvulnerable)
            extinguish();
        y = B;
        z = C;
        A = D;
        double d0 = locX - B;
        double d1 = locY - C;
        double d2 = locZ - D;
        double d3 = 10D;
        if(d0 > d3)
            y = B = locX;
        if(d2 > d3)
            A = D = locZ;
        if(d1 > d3)
            z = C = locY;
        if(d0 < -d3)
            y = B = locX;
        if(d2 < -d3)
            A = D = locZ;
        if(d1 < -d3)
            z = C = locY;
        B += d0 * 0.25D;
        D += d2 * 0.25D;
        C += d1 * 0.25D;
        a(StatisticList.k, 1);
        if(vehicle == null)
            c = null;
        if(!world.isStatic)
            foodData.a(this);
    }

    protected void b(net.minecraft.server.ItemStack itemstack, int i)
    {
        if(itemstack.m() == EnumAnimation.c)
            world.makeSound(this, "random.drink", 0.5F, world.random.nextFloat() * 0.1F + 0.9F);
        if(itemstack.m() == EnumAnimation.b)
        {
            for(int j = 0; j < i; j++)
            {
                Vec3D vec3d = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                vec3d.a((-pitch * 3.141593F) / 180F);
                vec3d.b((-yaw * 3.141593F) / 180F);
                Vec3D vec3d1 = Vec3D.create(((double)random.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-random.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                vec3d1.a((-pitch * 3.141593F) / 180F);
                vec3d1.b((-yaw * 3.141593F) / 180F);
                vec3d1 = vec3d1.add(locX, locY + (double)getHeadHeight(), locZ);
                world.a((new StringBuilder()).append("iconcrack_").append(itemstack.getItem().id).toString(), vec3d1.a, vec3d1.b, vec3d1.c, vec3d.a, vec3d.b + 0.050000000000000003D, vec3d.c);
            }

            world.makeSound(this, "random.eat", 0.5F + 0.5F * (float)random.nextInt(2), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void K()
    {
        if(d != null)
        {
            b(d, 16);
            int i = d.count;
            net.minecraft.server.ItemStack itemstack = d.b(world, this);
            if(itemstack != d || itemstack != null && itemstack.count != i)
            {
                inventory.items[inventory.itemInHandIndex] = itemstack;
                if(itemstack.count == 0)
                    inventory.items[inventory.itemInHandIndex] = null;
            }
            O();
        }
    }

    protected boolean Q()
    {
        return getHealth() <= 0 || isSleeping();
    }

    public void closeInventory()
    {
        activeContainer = defaultContainer;
    }

    public void R()
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        super.R();
        r = s;
        s = 0.0F;
        h(locX - d0, locY - d1, locZ - d2);
    }

    private int E()
    {
        return hasEffect(MobEffectList.FASTER_DIG) ? 6 - (1 + getEffect(MobEffectList.FASTER_DIG).getAmplifier()) * 1 : hasEffect(MobEffectList.SLOWER_DIG) ? 6 + (1 + getEffect(MobEffectList.SLOWER_DIG).getAmplifier()) * 2 : 6;
    }

    protected void d_()
    {
        int i = E();
        if(t)
        {
            u++;
            if(u >= i)
            {
                u = 0;
                t = false;
            }
        } else
        {
            u = 0;
        }
        ao = (float)u / (float)i;
    }

    public void e()
    {
        if(o > 0)
            o--;
        if(world.difficulty == 0 && getHealth() < getMaxHealth() && (ticksLived % 20) * 12 == 0)
            heal(1, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.REGEN);
        inventory.i();
        r = s;
        super.e();
        al = P;
        am = Q;
        if(isSprinting())
        {
            al = (float)((double)al + (double)P * 0.29999999999999999D);
            am = (float)((double)am + (double)Q * 0.29999999999999999D);
        }
        float f = MathHelper.sqrt(motX * motX + motZ * motZ);
        float f1 = (float)TrigMath.atan(-motY * 0.20000000298023224D) * 15F;
        if(f > 0.1F)
            f = 0.1F;
        if(!onGround || getHealth() <= 0)
            f = 0.0F;
        if(onGround || getHealth() <= 0)
            f1 = 0.0F;
        s += (f - s) * 0.4F;
        ay += (f1 - ay) * 0.8F;
        if(getHealth() > 0)
        {
            List list = world.getEntities(this, boundingBox.grow(1.0D, 0.0D, 1.0D));
            if(list != null)
            {
                for(int i = 0; i < list.size(); i++)
                {
                    net.minecraft.server.Entity entity = (net.minecraft.server.Entity)list.get(i);
                    if(!entity.dead)
                        l(entity);
                }

            }
        }
    }

    private void l(net.minecraft.server.Entity entity)
    {
        entity.a_(this);
    }

    public void die(DamageSource damagesource)
    {
        super.die(damagesource);
        b(0.2F, 0.2F);
        setPosition(locX, locY, locZ);
        motY = 0.10000000149011612D;
        if(name.equals("Notch"))
            a(new net.minecraft.server.ItemStack(Item.APPLE, 1), true);
        inventory.k();
        if(damagesource != null)
        {
            motX = -MathHelper.cos(((au + yaw) * 3.141593F) / 180F) * 0.1F;
            motZ = -MathHelper.sin(((au + yaw) * 3.141593F) / 180F) * 0.1F;
        } else
        {
            motX = motZ = 0.0D;
        }
        height = 0.1F;
        a(StatisticList.y, 1);
    }

    public void b(net.minecraft.server.Entity entity, int i)
    {
        q += i;
        if(entity instanceof EntityHuman)
            a(StatisticList.A, 1);
        else
            a(StatisticList.z, 1);
    }

    protected int b_(int i)
    {
        int j = EnchantmentManager.getOxygenEnchantmentLevel(inventory);
        return j <= 0 || random.nextInt(j + 1) <= 0 ? super.b_(i) : i;
    }

    public EntityItem S()
    {
        return a(inventory.splitStack(inventory.itemInHandIndex, 1), false);
    }

    public EntityItem drop(net.minecraft.server.ItemStack itemstack)
    {
        return a(itemstack, false);
    }

    public EntityItem a(net.minecraft.server.ItemStack itemstack, boolean flag)
    {
        if(itemstack == null)
            return null;
        EntityItem entityitem = new EntityItem(world, locX, (locY - 0.30000001192092896D) + (double)getHeadHeight(), locZ, itemstack);
        entityitem.pickupDelay = 40;
        float f = 0.1F;
        if(flag)
        {
            float f1 = random.nextFloat() * 0.5F;
            float f2 = random.nextFloat() * 3.141593F * 2.0F;
            entityitem.motX = -MathHelper.sin(f2) * f1;
            entityitem.motZ = MathHelper.cos(f2) * f1;
            entityitem.motY = 0.20000000298023224D;
        } else
        {
            f = 0.3F;
            entityitem.motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
            entityitem.motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
            entityitem.motY = -MathHelper.sin((pitch / 180F) * 3.141593F) * f + 0.1F;
            f = 0.02F;
            float f1 = random.nextFloat() * 3.141593F * 2.0F;
            f *= random.nextFloat();
            entityitem.motX += Math.cos(f1) * (double)f;
            entityitem.motY += (random.nextFloat() - random.nextFloat()) * 0.1F;
            entityitem.motZ += Math.sin(f1) * (double)f;
        }
        Player player = (Player)getBukkitEntity();
        CraftItem drop = new CraftItem(world.getServer(), entityitem);
        PlayerDropItemEvent event = new PlayerDropItemEvent(player, drop);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled())
        {
            player.getInventory().addItem(new ItemStack[] {
                drop.getItemStack()
            });
            return null;
        } else
        {
            a(entityitem);
            a(StatisticList.v, 1);
            return entityitem;
        }
    }

    protected void a(EntityItem entityitem)
    {
        world.addEntity(entityitem);
    }

    public float a(Block block)
    {
        float f = inventory.a(block);
        float f1 = f;
        int i = EnchantmentManager.getDigSpeedEnchantmentLevel(inventory);
        if(i > 0 && inventory.b(block))
            f1 = f + (float)(i * i + 1);
        if(hasEffect(MobEffectList.FASTER_DIG))
            f1 *= 1.0F + (float)(getEffect(MobEffectList.FASTER_DIG).getAmplifier() + 1) * 0.2F;
        if(hasEffect(MobEffectList.SLOWER_DIG))
            f1 *= 1.0F - (float)(getEffect(MobEffectList.SLOWER_DIG).getAmplifier() + 1) * 0.2F;
        if(a(Material.WATER) && !EnchantmentManager.hasWaterWorkerEnchantment(inventory))
            f1 /= 5F;
        if(!onGround)
            f1 /= 5F;
        return f1;
    }

    public boolean b(Block block)
    {
        return inventory.b(block);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.getList("Inventory");
        inventory.b(nbttaglist);
        dimension = nbttagcompound.getInt("Dimension");
        sleeping = nbttagcompound.getBoolean("Sleeping");
        sleepTicks = nbttagcompound.getShort("SleepTimer");
        exp = nbttagcompound.getFloat("XpP");
        expLevel = nbttagcompound.getInt("XpLevel");
        expTotal = nbttagcompound.getInt("XpTotal");
        if(sleeping)
        {
            F = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
            a(true, true, false);
        }
        spawnWorld = nbttagcompound.getString("SpawnWorld");
        if("".equals(spawnWorld))
            spawnWorld = ((World)world.getServer().getWorlds().get(0)).getName();
        if(nbttagcompound.hasKey("SpawnX") && nbttagcompound.hasKey("SpawnY") && nbttagcompound.hasKey("SpawnZ"))
            b = new ChunkCoordinates(nbttagcompound.getInt("SpawnX"), nbttagcompound.getInt("SpawnY"), nbttagcompound.getInt("SpawnZ"));
        foodData.a(nbttagcompound);
        abilities.b(nbttagcompound);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.set("Inventory", inventory.a(new NBTTagList()));
        nbttagcompound.setInt("Dimension", dimension);
        nbttagcompound.setBoolean("Sleeping", sleeping);
        nbttagcompound.setShort("SleepTimer", (short)sleepTicks);
        nbttagcompound.setFloat("XpP", exp);
        nbttagcompound.setInt("XpLevel", expLevel);
        nbttagcompound.setInt("XpTotal", expTotal);
        if(b != null)
        {
            nbttagcompound.setInt("SpawnX", b.x);
            nbttagcompound.setInt("SpawnY", b.y);
            nbttagcompound.setInt("SpawnZ", b.z);
            nbttagcompound.setString("SpawnWorld", spawnWorld);
        }
        foodData.b(nbttagcompound);
        abilities.a(nbttagcompound);
    }

    public void openContainer(IInventory iinventory1)
    {
    }

    public void startEnchanting(int i1, int j1, int k1)
    {
    }

    public void startCrafting(int i1, int j1, int k1)
    {
    }

    public void receive(net.minecraft.server.Entity entity1, int j)
    {
    }

    public float getHeadHeight()
    {
        return 0.12F;
    }

    protected void A()
    {
        height = 1.62F;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(abilities.isInvulnerable && !damagesource.ignoresInvulnerability())
            return false;
        aV = 0;
        if(getHealth() <= 0)
            return false;
        if(isSleeping() && !world.isStatic)
            a(true, true, false);
        net.minecraft.server.Entity entity = damagesource.getEntity();
        if((entity instanceof EntityMonster) || (entity instanceof EntityArrow))
        {
            if(world.difficulty == 0)
                return false;
            if(world.difficulty == 1)
                i = i / 2 + 1;
            if(world.difficulty == 3)
                i = (i * 3) / 2;
        }
        net.minecraft.server.Entity entity1 = entity;
        if((entity instanceof EntityArrow) && ((EntityArrow)entity).shooter != null)
            entity1 = ((EntityArrow)entity).shooter;
        if(entity1 instanceof EntityLiving)
            a((EntityLiving)entity1, false);
        a(StatisticList.x, i);
        return super.damageEntity(damagesource, i);
    }

    protected int b(DamageSource damagesource, int i)
    {
        int j = super.b(damagesource, i);
        if(j <= 0)
            return 0;
        int k = EnchantmentManager.a(inventory, damagesource);
        if(k > 20)
            k = 20;
        if(k > 0 && k <= 20)
        {
            int l = 25 - k;
            int i1 = j * l + ar;
            j = i1 / 25;
            ar = i1 % 25;
        }
        return j;
    }

    protected boolean C()
    {
        return false;
    }

    protected void a(EntityLiving entityliving, boolean flag)
    {
        if(!(entityliving instanceof EntityCreeper) && !(entityliving instanceof EntityGhast))
        {
            if(entityliving instanceof EntityWolf)
            {
                EntityWolf entitywolf = (EntityWolf)entityliving;
                if(entitywolf.isTamed() && name.equals(entitywolf.getOwnerName()))
                    return;
            }
            if(!(entityliving instanceof EntityHuman) || C())
            {
                List list = world.a(net/minecraft/server/EntityWolf, AxisAlignedBB.b(locX, locY, locZ, locX + 1.0D, locY + 1.0D, locZ + 1.0D).grow(16D, 4D, 16D));
                Iterator iterator = list.iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    net.minecraft.server.Entity entity = (net.minecraft.server.Entity)iterator.next();
                    EntityWolf entitywolf1 = (EntityWolf)entity;
                    if(entitywolf1.isTamed() && entitywolf1.I() == null && name.equals(entitywolf1.getOwnerName()) && (!flag || !entitywolf1.isSitting()))
                    {
                        entitywolf1.setSitting(false);
                        entitywolf1.setTarget(entityliving);
                    }
                } while(true);
            }
        }
    }

    protected void f(int i)
    {
        inventory.e(i);
    }

    public int T()
    {
        return inventory.j();
    }

    protected void c(DamageSource damagesource, int i)
    {
        if(!damagesource.ignoresArmor() && P())
            i = 1 + i >> 1;
        i = d(damagesource, i);
        i = b(damagesource, i);
        c(damagesource.f());
        health -= i;
    }

    public void openFurnace(TileEntityFurnace tileentityfurnace1)
    {
    }

    public void openDispenser(TileEntityDispenser tileentitydispenser1)
    {
    }

    public void a(TileEntitySign tileentitysign1)
    {
    }

    public void openBrewingStand(TileEntityBrewingStand tileentitybrewingstand1)
    {
    }

    public void e(net.minecraft.server.Entity entity)
    {
        if(!entity.b(this))
        {
            net.minecraft.server.ItemStack itemstack = U();
            if(itemstack != null && (entity instanceof EntityLiving))
            {
                if(abilities.canInstantlyBuild)
                    itemstack = itemstack.cloneItemStack();
                itemstack.a((EntityLiving)entity);
                if(itemstack.count == 0 && !abilities.canInstantlyBuild)
                {
                    itemstack.a(this);
                    V();
                }
            }
        }
    }

    public net.minecraft.server.ItemStack U()
    {
        return inventory.getItemInHand();
    }

    public void V()
    {
        inventory.setItem(inventory.itemInHandIndex, (net.minecraft.server.ItemStack)null);
    }

    public double W()
    {
        return (double)(height - 0.5F);
    }

    public void C_()
    {
        if(!t || u >= E() / 2 || u < 0)
        {
            u = -1;
            t = true;
        }
    }

    public void attack(net.minecraft.server.Entity entity)
    {
        if(entity.k_())
        {
            int i = inventory.a(entity);
            if(hasEffect(MobEffectList.INCREASE_DAMAGE))
                i += 3 << getEffect(MobEffectList.INCREASE_DAMAGE).getAmplifier();
            if(hasEffect(MobEffectList.WEAKNESS))
                i -= 2 << getEffect(MobEffectList.WEAKNESS).getAmplifier();
            int j = 0;
            int k = 0;
            if(entity instanceof EntityLiving)
            {
                k = EnchantmentManager.a(inventory, (EntityLiving)entity);
                j += EnchantmentManager.getKnockbackEnchantmentLevel(inventory, (EntityLiving)entity);
            }
            if(isSprinting())
                j++;
            if(i > 0 || k > 0)
            {
                boolean flag = fallDistance > 0.0F && !onGround && !t() && !aU() && !hasEffect(MobEffectList.BLINDNESS) && vehicle == null && (entity instanceof EntityLiving);
                if(flag)
                    i += random.nextInt(i / 2 + 2);
                i += k;
                boolean flag1 = entity.damageEntity(DamageSource.playerAttack(this), i);
                if(!flag1)
                    return;
                if(flag1)
                {
                    if(j > 0)
                    {
                        entity.b_(-MathHelper.sin((yaw * 3.141593F) / 180F) * (float)j * 0.5F, 0.10000000000000001D, MathHelper.cos((yaw * 3.141593F) / 180F) * (float)j * 0.5F);
                        motX *= 0.59999999999999998D;
                        motZ *= 0.59999999999999998D;
                        setSprinting(false);
                    }
                    if(flag)
                        c(entity);
                    if(k > 0)
                        d(entity);
                    if(i >= 18)
                        a(AchievementList.E);
                    g(entity);
                }
                net.minecraft.server.ItemStack itemstack = U();
                if(itemstack != null && (entity instanceof EntityLiving))
                {
                    itemstack.a((EntityLiving)entity, this);
                    if(itemstack.count == 0)
                    {
                        itemstack.a(this);
                        V();
                    }
                }
                if(entity instanceof EntityLiving)
                {
                    if(entity.isAlive())
                        a((EntityLiving)entity, true);
                    a(StatisticList.w, i);
                    int l = EnchantmentManager.getFireAspectEnchantmentLevel(inventory, (EntityLiving)entity);
                    if(l > 0)
                    {
                        EntityCombustByEntityEvent combustEvent = new EntityCombustByEntityEvent(getBukkitEntity(), entity.getBukkitEntity(), l * 4);
                        Bukkit.getPluginManager().callEvent(combustEvent);
                        if(!combustEvent.isCancelled())
                            entity.setOnFire(combustEvent.getDuration());
                    }
                }
                c(0.3F);
            }
        }
    }

    public void c(net.minecraft.server.Entity entity1)
    {
    }

    public void d(net.minecraft.server.Entity entity1)
    {
    }

    public void carriedChanged(net.minecraft.server.ItemStack itemstack1)
    {
    }

    public void die()
    {
        super.die();
        defaultContainer.a(this);
        if(activeContainer != null)
            activeContainer.a(this);
    }

    public boolean inBlock()
    {
        return !sleeping && super.inBlock();
    }

    public EnumBedResult a(int i, int j, int k)
    {
        if(!world.isStatic)
        {
            if(isSleeping() || !isAlive())
                return EnumBedResult.OTHER_PROBLEM;
            if(!world.worldProvider.d())
                return EnumBedResult.NOT_POSSIBLE_HERE;
            if(world.e())
                return EnumBedResult.NOT_POSSIBLE_NOW;
            if(Math.abs(locX - (double)i) > 3D || Math.abs(locY - (double)j) > 2D || Math.abs(locZ - (double)k) > 3D)
                return EnumBedResult.TOO_FAR_AWAY;
            double d0 = 8D;
            double d1 = 5D;
            List list = world.a(net/minecraft/server/EntityMonster, AxisAlignedBB.b((double)i - d0, (double)j - d1, (double)k - d0, (double)i + d0, (double)j + d1, (double)k + d0));
            if(!list.isEmpty())
                return EnumBedResult.NOT_SAFE;
        }
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed = world.getWorld().getBlockAt(i, j, k);
            PlayerBedEnterEvent event = new PlayerBedEnterEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return EnumBedResult.OTHER_PROBLEM;
        }
        b(0.2F, 0.2F);
        height = 0.2F;
        if(world.isLoaded(i, j, k))
        {
            int l = world.getData(i, j, k);
            int i1 = BlockBed.b(l);
            float f = 0.5F;
            float f1 = 0.5F;
            switch(i1)
            {
            case 0: // '\0'
                f1 = 0.9F;
                break;

            case 1: // '\001'
                f = 0.1F;
                break;

            case 2: // '\002'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f = 0.9F;
                break;
            }
            c(i1);
            setPosition((float)i + f, (float)j + 0.9375F, (float)k + f1);
        } else
        {
            setPosition((float)i + 0.5F, (float)j + 0.9375F, (float)k + 0.5F);
        }
        sleeping = true;
        sleepTicks = 0;
        F = new ChunkCoordinates(i, j, k);
        motX = motZ = motY = 0.0D;
        if(!world.isStatic)
            world.everyoneSleeping();
        return EnumBedResult.OK;
    }

    private void c(int i)
    {
        G = 0.0F;
        H = 0.0F;
        switch(i)
        {
        case 0: // '\0'
            H = -1.8F;
            break;

        case 1: // '\001'
            G = 1.8F;
            break;

        case 2: // '\002'
            H = 1.8F;
            break;

        case 3: // '\003'
            G = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        if(fauxSleeping && !sleeping)
            return;
        b(0.6F, 1.8F);
        A();
        ChunkCoordinates chunkcoordinates = F;
        ChunkCoordinates chunkcoordinates1 = F;
        if(chunkcoordinates != null && world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) == Block.BED.id)
        {
            BlockBed.a(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, false);
            chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            if(chunkcoordinates1 == null)
                chunkcoordinates1 = new ChunkCoordinates(chunkcoordinates.x, chunkcoordinates.y + 1, chunkcoordinates.z);
            setPosition((float)chunkcoordinates1.x + 0.5F, (float)chunkcoordinates1.y + height + 0.1F, (float)chunkcoordinates1.z + 0.5F);
        }
        sleeping = false;
        if(!world.isStatic && flag1)
            world.everyoneSleeping();
        if(getBukkitEntity() instanceof Player)
        {
            Player player = (Player)getBukkitEntity();
            org.bukkit.block.Block bed;
            if(chunkcoordinates != null)
                bed = world.getWorld().getBlockAt(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z);
            else
                bed = world.getWorld().getBlockAt(player.getLocation());
            PlayerBedLeaveEvent event = new PlayerBedLeaveEvent(player, bed);
            world.getServer().getPluginManager().callEvent(event);
        }
        if(flag)
            sleepTicks = 0;
        else
            sleepTicks = 100;
        if(flag2)
            setRespawnPosition(F);
    }

    private boolean G()
    {
        return world.getTypeId(F.x, F.y, F.z) == Block.BED.id;
    }

    public static ChunkCoordinates getBed(net.minecraft.server.World world, ChunkCoordinates chunkcoordinates)
    {
        IChunkProvider ichunkprovider = world.q();
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z - 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z + 3 >> 4);
        ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z + 3 >> 4);
        if(world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) != Block.BED.id)
        {
            return null;
        } else
        {
            ChunkCoordinates chunkcoordinates1 = BlockBed.f(world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, 0);
            return chunkcoordinates1;
        }
    }

    public boolean isSleeping()
    {
        return sleeping;
    }

    public boolean isDeeplySleeping()
    {
        return sleeping && sleepTicks >= 100;
    }

    public void a(String s1)
    {
    }

    public ChunkCoordinates getBed()
    {
        return b;
    }

    public void setRespawnPosition(ChunkCoordinates chunkcoordinates)
    {
        if(chunkcoordinates != null)
        {
            b = new ChunkCoordinates(chunkcoordinates);
            spawnWorld = world.worldData.name;
        } else
        {
            b = null;
        }
    }

    public void a(Statistic statistic)
    {
        a(statistic, 1);
    }

    public void a(Statistic statistic1, int j)
    {
    }

    protected void ac()
    {
        super.ac();
        a(StatisticList.u, 1);
        if(isSprinting())
            c(0.8F);
        else
            c(0.2F);
    }

    public void a(float f, float f1)
    {
        double d0 = locX;
        double d1 = locY;
        double d2 = locZ;
        if(abilities.isFlying)
        {
            double d3 = motY;
            float f2 = am;
            am = 0.05F;
            super.a(f, f1);
            motY = d3 * 0.59999999999999998D;
            am = f2;
        } else
        {
            super.a(f, f1);
        }
        checkMovement(locX - d0, locY - d1, locZ - d2);
    }

    public void checkMovement(double d0, double d1, double d2)
    {
        if(vehicle == null)
            if(a(Material.WATER))
            {
                int i = Math.round(MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.q, i);
                    c(0.015F * (float)i * 0.01F);
                }
            } else
            if(aU())
            {
                int i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.m, i);
                    c(0.015F * (float)i * 0.01F);
                }
            } else
            if(t())
            {
                if(d1 > 0.0D)
                    a(StatisticList.o, (int)Math.round(d1 * 100D));
            } else
            if(onGround)
            {
                int i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100F);
                if(i > 0)
                {
                    a(StatisticList.l, i);
                    if(isSprinting())
                        c(0.09999999F * (float)i * 0.01F);
                    else
                        c(0.01F * (float)i * 0.01F);
                }
            } else
            {
                int i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100F);
                if(i > 25)
                    a(StatisticList.p, i);
            }
    }

    private void h(double d0, double d1, double d2)
    {
        if(vehicle != null)
        {
            int i = Math.round(MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2) * 100F);
            if(i > 0)
                if(vehicle instanceof EntityMinecart)
                {
                    a(StatisticList.r, i);
                    if(c == null)
                        c = new ChunkCoordinates(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ));
                    else
                    if(c.b(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) >= 1000D)
                        a(AchievementList.q, 1);
                } else
                if(vehicle instanceof EntityBoat)
                    a(StatisticList.s, i);
                else
                if(vehicle instanceof EntityPig)
                    a(StatisticList.t, i);
        }
    }

    protected void a(float f)
    {
        if(!abilities.canFly)
        {
            if(f >= 2.0F)
                a(StatisticList.n, (int)Math.round((double)f * 100D));
            super.a(f);
        }
    }

    public void c(EntityLiving entityliving)
    {
        if(entityliving instanceof EntityMonster)
            a(AchievementList.s);
    }

    public void ad()
    {
        if(I > 0)
            I = 10;
        else
            J = true;
    }

    public void giveExp(int i)
    {
        q += i;
        int j = 0x7fffffff - expTotal;
        if(i > j)
            i = j;
        exp += (float)i / (float)getExpToLevel();
        expTotal += i;
        for(; exp >= 1.0F; exp /= getExpToLevel())
        {
            exp = (exp - 1.0F) * (float)getExpToLevel();
            levelUp();
        }

    }

    public void levelDown(int i)
    {
        expLevel -= i;
        if(expLevel < 0)
            expLevel = 0;
    }

    public int getExpToLevel()
    {
        return 7 + (expLevel * 7 >> 1);
    }

    private void levelUp()
    {
        expLevel++;
    }

    public void c(float f)
    {
        if(!abilities.isInvulnerable && !world.isStatic)
            foodData.a(f);
    }

    public FoodMetaData getFoodData()
    {
        return foodData;
    }

    public boolean b(boolean flag)
    {
        return (flag || foodData.b()) && !abilities.isInvulnerable;
    }

    public boolean ag()
    {
        return getHealth() > 0 && getHealth() < getMaxHealth();
    }

    public void a(net.minecraft.server.ItemStack itemstack, int i)
    {
        if(itemstack != d)
        {
            d = itemstack;
            e = i;
            if(!world.isStatic)
                i(true);
        }
    }

    public boolean d(int i, int j, int k)
    {
        return true;
    }

    protected int getExpValue(EntityHuman entityhuman)
    {
        int i = expLevel * 7;
        return i <= 100 ? i : 100;
    }

    protected boolean alwaysGivesExp()
    {
        return true;
    }

    public String getLocalizedName()
    {
        return name;
    }

    public void e(int j)
    {
    }

    public void copyTo(EntityHuman entityhuman)
    {
        inventory.a(entityhuman.inventory);
        health = entityhuman.health;
        foodData = entityhuman.foodData;
        expLevel = entityhuman.expLevel;
        expTotal = entityhuman.expTotal;
        exp = entityhuman.exp;
        q = entityhuman.q;
    }

    protected boolean g_()
    {
        return !abilities.isFlying;
    }

    public void updateAbilities()
    {
    }

    public volatile Entity getBukkitEntity()
    {
        return getBukkitEntity();
    }

    public net.minecraft.server.PlayerInventory inventory;
    public Container defaultContainer;
    public Container activeContainer;
    protected FoodMetaData foodData;
    protected int o;
    public byte p;
    public int q;
    public float r;
    public float s;
    public boolean t;
    public int u;
    public String name;
    public int dimension;
    public int x;
    public double y;
    public double z;
    public double A;
    public double B;
    public double C;
    public double D;
    public boolean sleeping;
    public boolean fauxSleeping;
    public String spawnWorld;
    public ChunkCoordinates F;
    public int sleepTicks;
    public float G;
    public float H;
    private ChunkCoordinates b;
    private ChunkCoordinates c;
    public int I;
    protected boolean J;
    public float K;
    public PlayerAbilities abilities;
    public int oldLevel;
    public int expLevel;
    public int expTotal;
    public float exp;
    private net.minecraft.server.ItemStack d;
    private int e;
    protected float P;
    protected float Q;
    public EntityFishingHook hookedFish;
}
