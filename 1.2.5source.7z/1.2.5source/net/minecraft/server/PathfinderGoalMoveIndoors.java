// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, World, WorldProvider, 
//            MathHelper, VillageCollection, Village, Navigation, 
//            VillageDoor, Vec3D, RandomPositionGenerator

public class PathfinderGoalMoveIndoors extends PathfinderGoal
{

    public PathfinderGoalMoveIndoors(EntityCreature entitycreature)
    {
        c = -1;
        d = -1;
        a = entitycreature;
        a(1);
    }

    public boolean a()
    {
        if(a.world.e() && !a.world.x() || a.world.worldProvider.e)
            return false;
        if(a.an().nextInt(50) != 0)
            return false;
        if(c != -1 && a.e(c, a.locY, d) < 4D)
            return false;
        Village village = a.world.villages.getClosestVillage(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ), 14);
        if(village == null)
        {
            return false;
        } else
        {
            b = village.c(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ));
            return b != null;
        }
    }

    public boolean b()
    {
        return !a.al().e();
    }

    public void c()
    {
        c = -1;
        if(a.e(b.getIndoorsX(), b.locY, b.getIndoorsZ()) > 256D)
        {
            Vec3D vec3d = RandomPositionGenerator.a(a, 14, 3, Vec3D.create((double)b.getIndoorsX() + 0.5D, b.getIndoorsY(), (double)b.getIndoorsZ() + 0.5D));
            if(vec3d != null)
                a.al().a(vec3d.a, vec3d.b, vec3d.c, 0.3F);
        } else
        {
            a.al().a((double)b.getIndoorsX() + 0.5D, b.getIndoorsY(), (double)b.getIndoorsZ() + 0.5D, 0.3F);
        }
    }

    public void d()
    {
        c = b.getIndoorsX();
        d = b.getIndoorsZ();
        b = null;
    }

    private EntityCreature a;
    private VillageDoor b;
    private int c;
    private int d;
}
