// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


class WorldGenNetherPieceWeight
{

    public WorldGenNetherPieceWeight(Class class1, int i, int j, boolean flag)
    {
        a = class1;
        b = i;
        d = j;
        e = flag;
    }

    public WorldGenNetherPieceWeight(Class class1, int i, int j)
    {
        this(class1, i, j, false);
    }

    public boolean a(int i)
    {
        return d == 0 || c < d;
    }

    public boolean a()
    {
        return d == 0 || c < d;
    }

    public Class a;
    public final int b;
    public int c;
    public int d;
    public boolean e;
}
