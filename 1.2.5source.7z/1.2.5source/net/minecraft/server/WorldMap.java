// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldMap.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.map.CraftMapView;

// Referenced classes of package net.minecraft.server:
//            WorldMapBase, WorldMapHumanTracker, WorldMapDecoration, NBTTagCompound, 
//            WorldServer, EntityHuman, PlayerInventory, ItemStack, 
//            World

public class WorldMap extends WorldMapBase
{

    public WorldMap(String s)
    {
        super(s);
        colors = new byte[16384];
        h = new ArrayList();
        j = new HashMap();
        decorations = new ArrayList();
        uniqueId = null;
        server = (CraftServer)Bukkit.getServer();
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        byte dimension = nbttagcompound.getByte("dimension");
        if(dimension >= 10)
        {
            long least = nbttagcompound.getLong("UUIDLeast");
            long most = nbttagcompound.getLong("UUIDMost");
            if(least != 0L && most != 0L)
            {
                uniqueId = new UUID(most, least);
                CraftWorld world = (CraftWorld)server.getWorld(uniqueId);
                if(world == null)
                    dimension = 127;
                else
                    dimension = (byte)world.getHandle().dimension;
            }
        }
        map = dimension;
        centerX = nbttagcompound.getInt("xCenter");
        centerZ = nbttagcompound.getInt("zCenter");
        scale = nbttagcompound.getByte("scale");
        if(scale < 0)
            scale = 0;
        if(scale > 4)
            scale = 4;
        short short1 = nbttagcompound.getShort("width");
        short short2 = nbttagcompound.getShort("height");
        if(short1 == 128 && short2 == 128)
        {
            colors = nbttagcompound.getByteArray("colors");
        } else
        {
            byte abyte[] = nbttagcompound.getByteArray("colors");
            colors = new byte[16384];
            int i = (128 - short1) / 2;
            int j = (128 - short2) / 2;
            for(int k = 0; k < short2; k++)
            {
                int l = k + j;
                if(l < 0 && l >= 128)
                    continue;
                for(int i1 = 0; i1 < short1; i1++)
                {
                    int j1 = i1 + i;
                    if(j1 >= 0 || j1 < 128)
                        colors[j1 + l * 128] = abyte[i1 + k * short1];
                }

            }

        }
    }

    public void b(NBTTagCompound nbttagcompound)
    {
label0:
        {
label1:
            {
                if(map < 10)
                    break label0;
                if(uniqueId != null)
                    break label1;
                Iterator i$ = server.getWorlds().iterator();
                CraftWorld cWorld;
                do
                {
                    if(!i$.hasNext())
                        break label1;
                    World world = (World)i$.next();
                    cWorld = (CraftWorld)world;
                } while(cWorld.getHandle().dimension != map);
                uniqueId = cWorld.getUID();
            }
            if(uniqueId != null)
            {
                nbttagcompound.setLong("UUIDLeast", uniqueId.getLeastSignificantBits());
                nbttagcompound.setLong("UUIDMost", uniqueId.getMostSignificantBits());
            }
        }
        nbttagcompound.setByte("dimension", map);
        nbttagcompound.setInt("xCenter", centerX);
        nbttagcompound.setInt("zCenter", centerZ);
        nbttagcompound.setByte("scale", scale);
        nbttagcompound.setShort("width", (short)128);
        nbttagcompound.setShort("height", (short)128);
        nbttagcompound.setByteArray("colors", colors);
    }

    public void a(EntityHuman entityhuman, ItemStack itemstack)
    {
        if(!this.j.containsKey(entityhuman))
        {
            WorldMapHumanTracker worldmaphumantracker = new WorldMapHumanTracker(this, entityhuman);
            this.j.put(entityhuman, worldmaphumantracker);
            h.add(worldmaphumantracker);
        }
        decorations.clear();
        for(int i = 0; i < h.size(); i++)
        {
            WorldMapHumanTracker worldmaphumantracker1 = (WorldMapHumanTracker)h.get(i);
            if(!worldmaphumantracker1.trackee.dead && worldmaphumantracker1.trackee.inventory.c(itemstack))
            {
                float f = (float)(worldmaphumantracker1.trackee.locX - (double)centerX) / (float)(1 << scale);
                float f1 = (float)(worldmaphumantracker1.trackee.locZ - (double)centerZ) / (float)(1 << scale);
                byte b0 = 64;
                byte b1 = 64;
                if(f < (float)(-b0) || f1 < (float)(-b1) || f > (float)b0 || f1 > (float)b1)
                    continue;
                byte b2 = 0;
                byte b3 = (byte)(int)((double)(f * 2.0F) + 0.5D);
                byte b4 = (byte)(int)((double)(f1 * 2.0F) + 0.5D);
                byte b5 = (byte)(int)((double)((worldmaphumantracker1.trackee.yaw * 16F) / 360F) + 0.5D);
                if(map < 0)
                {
                    int j = g / 10;
                    b5 = (byte)(j * j * 0x209a771 + j * 121 >> 15 & 0xf);
                }
                if(worldmaphumantracker1.trackee.dimension == map)
                    decorations.add(new WorldMapDecoration(this, b2, b3, b4, b5));
            } else
            {
                this.j.remove(worldmaphumantracker1.trackee);
                h.remove(worldmaphumantracker1);
            }
        }

    }

    public byte[] getUpdatePacket(ItemStack itemstack, net.minecraft.server.World world, EntityHuman entityhuman)
    {
        WorldMapHumanTracker worldmaphumantracker = (WorldMapHumanTracker)j.get(entityhuman);
        if(worldmaphumantracker == null)
        {
            return null;
        } else
        {
            byte abyte[] = worldmaphumantracker.a(itemstack);
            return abyte;
        }
    }

    public void flagDirty(int i, int j, int k)
    {
        super.a();
        for(int l = 0; l < h.size(); l++)
        {
            WorldMapHumanTracker worldmaphumantracker = (WorldMapHumanTracker)h.get(l);
            if(worldmaphumantracker.b[i] < 0 || worldmaphumantracker.b[i] > j)
                worldmaphumantracker.b[i] = j;
            if(worldmaphumantracker.c[i] < 0 || worldmaphumantracker.c[i] < k)
                worldmaphumantracker.c[i] = k;
        }

    }

    public int centerX;
    public int centerZ;
    public byte map;
    public byte scale;
    public byte colors[];
    public int g;
    public List h;
    private Map j;
    public List decorations;
    public final CraftMapView mapView = new CraftMapView(this);
    private CraftServer server;
    private UUID uniqueId;
}
