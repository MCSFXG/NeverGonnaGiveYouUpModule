// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            WorldType

public final class WorldSettings
{

    public WorldSettings(long l, int i, boolean flag, boolean flag1, WorldType worldtype)
    {
        a = l;
        b = i;
        c = flag;
        d = flag1;
        e = worldtype;
    }

    public long a()
    {
        return a;
    }

    public int b()
    {
        return b;
    }

    public boolean c()
    {
        return d;
    }

    public boolean d()
    {
        return c;
    }

    public WorldType e()
    {
        return e;
    }

    public static int a(int i)
    {
        switch(i)
        {
        case 0: // '\0'
        case 1: // '\001'
            return i;
        }
        return 0;
    }

    private final long a;
    private final int b;
    private final boolean c;
    private final boolean d;
    private final WorldType e;
}
