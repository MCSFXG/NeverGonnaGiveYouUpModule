// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

public class RemoteStatusReply
{

    public RemoteStatusReply(int i)
    {
        buffer = new ByteArrayOutputStream(i);
        stream = new DataOutputStream(buffer);
    }

    public void write(byte abyte0[])
    {
        stream.write(abyte0, 0, abyte0.length);
    }

    public void write(String s)
    {
        stream.writeBytes(s);
        stream.write(0);
    }

    public void write(int i)
    {
        stream.write(i);
    }

    public void write(short word0)
    {
        stream.writeShort(Short.reverseBytes(word0));
    }

    public byte[] getBytes()
    {
        return buffer.toByteArray();
    }

    public void reset()
    {
        buffer.reset();
    }

    private ByteArrayOutputStream buffer;
    private DataOutputStream stream;
}
