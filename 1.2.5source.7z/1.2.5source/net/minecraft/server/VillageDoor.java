// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class VillageDoor
{

    public VillageDoor(int i, int j, int k, int l, int i1, int j1)
    {
        g = false;
        h = 0;
        locX = i;
        locY = j;
        locZ = k;
        d = l;
        e = i1;
        addedTime = j1;
    }

    public int a(int i, int j, int k)
    {
        int l = i - locX;
        int i1 = j - locY;
        int j1 = k - locZ;
        return l * l + i1 * i1 + j1 * j1;
    }

    public int b(int i, int j, int k)
    {
        int l = i - locX - d;
        int i1 = j - locY;
        int j1 = k - locZ - e;
        return l * l + i1 * i1 + j1 * j1;
    }

    public int getIndoorsX()
    {
        return locX + d;
    }

    public int getIndoorsY()
    {
        return locY;
    }

    public int getIndoorsZ()
    {
        return locZ + e;
    }

    public boolean a(int i, int j)
    {
        int k = i - locX;
        int l = j - locZ;
        return k * d + l * e >= 0;
    }

    public void d()
    {
        h = 0;
    }

    public void e()
    {
        h++;
    }

    public int f()
    {
        return h;
    }

    public final int locX;
    public final int locY;
    public final int locZ;
    public final int d;
    public final int e;
    public int addedTime;
    public boolean g;
    private int h;
}
