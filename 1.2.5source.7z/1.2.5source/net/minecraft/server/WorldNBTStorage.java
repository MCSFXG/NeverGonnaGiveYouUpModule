// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldNBTStorage.java

package net.minecraft.server;

import java.io.*;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.craftbukkit.entity.CraftPlayer;

// Referenced classes of package net.minecraft.server:
//            WorldConlictException, WorldData, NBTTagCompound, EntityPlayer, 
//            PlayerFileData, IDataManager, NBTCompressedStreamTools, EntityHuman, 
//            WorldProvider, IChunkLoader

public class WorldNBTStorage
    implements PlayerFileData, IDataManager
{

    public WorldNBTStorage(File file1, String s, boolean flag)
    {
        uuid = null;
        baseDir = new File(file1, s);
        baseDir.mkdirs();
        playerDir = new File(baseDir, "players");
        dataDir = new File(baseDir, "data");
        dataDir.mkdirs();
        f = s;
        if(flag)
            playerDir.mkdirs();
        f();
    }

    private void f()
    {
        DataOutputStream dataoutputstream;
        File file1 = new File(baseDir, "session.lock");
        dataoutputstream = new DataOutputStream(new FileOutputStream(file1));
        dataoutputstream.writeLong(sessionId);
        dataoutputstream.close();
        break MISSING_BLOCK_LABEL_70;
        Exception exception;
        exception;
        dataoutputstream.close();
        throw exception;
        IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
        throw new RuntimeException("Failed to check session lock, aborting");
    }

    public File getDirectory()
    {
        return baseDir;
    }

    public void checkSession()
    {
        DataInputStream datainputstream;
        File file1 = new File(baseDir, "session.lock");
        datainputstream = new DataInputStream(new FileInputStream(file1));
        if(datainputstream.readLong() != sessionId)
            throw new WorldConlictException("The save is being accessed from another location, aborting");
        datainputstream.close();
        break MISSING_BLOCK_LABEL_80;
        Exception exception;
        exception;
        datainputstream.close();
        throw exception;
        IOException ioexception;
        ioexception;
        throw new WorldConlictException("Failed to check session lock, aborting");
    }

    public IChunkLoader createChunkLoader(WorldProvider worldprovider)
    {
        throw new RuntimeException("Old Chunk Storage is no longer supported.");
    }

    public WorldData getWorldData()
    {
        File file1 = new File(baseDir, "level.dat");
        if(file1.exists())
            try
            {
                NBTTagCompound nbttagcompound = NBTCompressedStreamTools.a(new FileInputStream(file1));
                NBTTagCompound nbttagcompound1 = nbttagcompound.getCompound("Data");
                return new WorldData(nbttagcompound1);
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
        file1 = new File(baseDir, "level.dat_old");
        if(file1.exists())
            try
            {
                NBTTagCompound nbttagcompound = NBTCompressedStreamTools.a(new FileInputStream(file1));
                NBTTagCompound nbttagcompound1 = nbttagcompound.getCompound("Data");
                return new WorldData(nbttagcompound1);
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
        return null;
    }

    public void saveWorldData(WorldData worlddata, List list)
    {
        NBTTagCompound nbttagcompound = worlddata.a(list);
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.set("Data", nbttagcompound);
        try
        {
            File file1 = new File(baseDir, "level.dat_new");
            File file2 = new File(baseDir, "level.dat_old");
            File file3 = new File(baseDir, "level.dat");
            NBTCompressedStreamTools.a(nbttagcompound1, new FileOutputStream(file1));
            if(file2.exists())
                file2.delete();
            file3.renameTo(file2);
            if(file3.exists())
                file3.delete();
            file1.renameTo(file3);
            if(file1.exists())
                file1.delete();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public void saveWorldData(WorldData worlddata)
    {
        NBTTagCompound nbttagcompound = worlddata.a();
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.set("Data", nbttagcompound);
        try
        {
            File file1 = new File(baseDir, "level.dat_new");
            File file2 = new File(baseDir, "level.dat_old");
            File file3 = new File(baseDir, "level.dat");
            NBTCompressedStreamTools.a(nbttagcompound1, new FileOutputStream(file1));
            if(file2.exists())
                file2.delete();
            file3.renameTo(file2);
            if(file3.exists())
                file3.delete();
            file1.renameTo(file3);
            if(file1.exists())
                file1.delete();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public void save(EntityHuman entityhuman)
    {
        try
        {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            entityhuman.d(nbttagcompound);
            File file1 = new File(playerDir, (new StringBuilder()).append(entityhuman.name).append(".dat~").toString());
            File file2 = new File(playerDir, (new StringBuilder()).append(entityhuman.name).append(".dat").toString());
            NBTCompressedStreamTools.a(nbttagcompound, new FileOutputStream(file1));
            if(file2.exists())
                file2.delete();
            file1.renameTo(file2);
        }
        catch(Exception exception)
        {
            log.warning((new StringBuilder()).append("Failed to save player data for ").append(entityhuman.name).toString());
        }
    }

    public void load(EntityHuman entityhuman)
    {
        NBTTagCompound nbttagcompound = getPlayerData(entityhuman.name);
        if(nbttagcompound != null)
        {
            if(entityhuman instanceof EntityPlayer)
            {
                CraftPlayer player = (CraftPlayer)entityhuman.bukkitEntity;
                player.setFirstPlayed((new File(playerDir, (new StringBuilder()).append(entityhuman.name).append(".dat").toString())).lastModified());
            }
            entityhuman.e(nbttagcompound);
        }
    }

    public NBTTagCompound getPlayerData(String s)
    {
        try
        {
            File file1 = new File(playerDir, (new StringBuilder()).append(s).append(".dat").toString());
            if(file1.exists())
                return NBTCompressedStreamTools.a(new FileInputStream(file1));
        }
        catch(Exception exception)
        {
            log.warning((new StringBuilder()).append("Failed to load player data for ").append(s).toString());
        }
        return null;
    }

    public PlayerFileData getPlayerFileData()
    {
        return this;
    }

    public String[] getSeenPlayers()
    {
        return playerDir.list();
    }

    public void e()
    {
    }

    public File getDataFile(String s)
    {
        return new File(dataDir, (new StringBuilder()).append(s).append(".dat").toString());
    }

    public UUID getUUID()
    {
        if(uuid != null)
            return uuid;
        try
        {
            File file1 = new File(baseDir, "uid.dat");
            if(!file1.exists())
            {
                DataOutputStream dos = new DataOutputStream(new FileOutputStream(file1));
                uuid = UUID.randomUUID();
                dos.writeLong(uuid.getMostSignificantBits());
                dos.writeLong(uuid.getLeastSignificantBits());
                dos.close();
            } else
            {
                DataInputStream dis = new DataInputStream(new FileInputStream(file1));
                uuid = new UUID(dis.readLong(), dis.readLong());
                dis.close();
            }
            return uuid;
        }
        catch(IOException ex)
        {
            return null;
        }
    }

    public File getPlayerDir()
    {
        return playerDir;
    }

    private static final Logger log = Logger.getLogger("Minecraft");
    private final File baseDir;
    private final File playerDir;
    private final File dataDir;
    private final long sessionId = System.currentTimeMillis();
    private final String f;
    private UUID uuid;

}
