// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Packet24MobSpawn.java

package net.minecraft.server;

import java.io.*;
import java.util.List;
import org.bukkit.util.NumberConversions;

// Referenced classes of package net.minecraft.server:
//            Packet, EntityLiving, EntityTypes, DataWatcher, 
//            NetHandler, Entity

public class Packet24MobSpawn extends Packet
{

    public Packet24MobSpawn()
    {
    }

    public Packet24MobSpawn(EntityLiving entityliving)
    {
        a = entityliving.id;
        b = (byte)EntityTypes.a(entityliving);
        c = entityliving.size.getXZCoord(entityliving.locX);
        d = NumberConversions.floor(entityliving.locY * 32D);
        e = entityliving.size.getXZCoord(entityliving.locZ);
        f = (byte)(int)((entityliving.yaw * 256F) / 360F);
        g = (byte)(int)((entityliving.pitch * 256F) / 360F);
        h = (byte)(int)((entityliving.X * 256F) / 360F);
        i = entityliving.getDataWatcher();
    }

    public void a(DataInputStream datainputstream)
        throws IOException
    {
        a = datainputstream.readInt();
        b = datainputstream.readByte() & 0xff;
        c = datainputstream.readInt();
        d = datainputstream.readInt();
        e = datainputstream.readInt();
        f = datainputstream.readByte();
        g = datainputstream.readByte();
        h = datainputstream.readByte();
        q = DataWatcher.a(datainputstream);
    }

    public void a(DataOutputStream dataoutputstream)
        throws IOException
    {
        dataoutputstream.writeInt(a);
        dataoutputstream.writeByte(b & 0xff);
        dataoutputstream.writeInt(c);
        dataoutputstream.writeInt(d);
        dataoutputstream.writeInt(e);
        dataoutputstream.writeByte(f);
        dataoutputstream.writeByte(g);
        dataoutputstream.writeByte(h);
        i.a(dataoutputstream);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 20;
    }

    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public byte f;
    public byte g;
    public byte h;
    private DataWatcher i;
    private List q;
}
