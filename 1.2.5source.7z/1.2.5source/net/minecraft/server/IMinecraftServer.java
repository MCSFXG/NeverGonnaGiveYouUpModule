// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public interface IMinecraftServer
{

    public abstract int getProperty(String s, int i);

    public abstract String a(String s, String s1);

    public abstract void a(String s, Object obj);

    public abstract void c();

    public abstract String getPropertiesFile();

    public abstract String getMotd();

    public abstract int getPort();

    public abstract String getServerAddress();

    public abstract String getVersion();

    public abstract int getPlayerCount();

    public abstract int getMaxPlayers();

    public abstract String[] getPlayers();

    public abstract String getWorldName();

    public abstract String getPlugins();

    public abstract void o();

    public abstract String d(String s);

    public abstract boolean isDebugging();

    public abstract void sendMessage(String s);

    public abstract void warning(String s);

    public abstract void severe(String s);

    public abstract void debug(String s);
}
