// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, World, MathHelper, 
//            VillageCollection, Village, VillageDoor, Navigation

public class PathfinderGoalRestrictOpenDoor extends PathfinderGoal
{

    public PathfinderGoalRestrictOpenDoor(EntityCreature entitycreature)
    {
        a = entitycreature;
    }

    public boolean a()
    {
        if(a.world.e())
            return false;
        Village village = a.world.villages.getClosestVillage(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ), 16);
        if(village == null)
            return false;
        b = village.b(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ));
        if(b == null)
            return false;
        else
            return (double)b.b(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ)) < 2.25D;
    }

    public boolean b()
    {
        if(a.world.e())
            return false;
        else
            return !b.g && b.a(MathHelper.floor(a.locX), MathHelper.floor(a.locZ));
    }

    public void c()
    {
        a.al().b(false);
        a.al().c(false);
    }

    public void d()
    {
        a.al().b(true);
        a.al().c(true);
        b = null;
    }

    public void e()
    {
        b.e();
    }

    private EntityCreature a;
    private VillageDoor b;
}
