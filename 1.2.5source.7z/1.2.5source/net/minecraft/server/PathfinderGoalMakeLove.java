// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityVillager, World, MathHelper, 
//            VillageCollection, AxisAlignedBB, ControllerLook, Navigation, 
//            Village, EntityLiving

public class PathfinderGoalMakeLove extends PathfinderGoal
{

    public PathfinderGoalMakeLove(EntityVillager entityvillager)
    {
        e = 0;
        b = entityvillager;
        d = entityvillager.world;
        a(3);
    }

    public boolean a()
    {
        if(b.getAge() != 0)
            return false;
        if(b.an().nextInt(500) != 0)
            return false;
        a = d.villages.getClosestVillage(MathHelper.floor(b.locX), MathHelper.floor(b.locY), MathHelper.floor(b.locZ), 0);
        if(a == null)
            return false;
        if(!f())
            return false;
        Entity entity = d.a(net/minecraft/server/EntityVillager, b.boundingBox.grow(8D, 3D, 8D), b);
        if(entity == null)
            return false;
        c = (EntityVillager)entity;
        return c.getAge() == 0;
    }

    public void c()
    {
        e = 300;
        b.a(true);
    }

    public void d()
    {
        a = null;
        c = null;
        b.a(false);
    }

    public boolean b()
    {
        return e >= 0 && f() && b.getAge() == 0;
    }

    public void e()
    {
        e--;
        b.getControllerLook().a(c, 10F, 30F);
        if(b.j(c) > 2.25D)
            b.al().a(c, 0.25F);
        else
        if(e == 0 && c.A())
            i();
        if(b.an().nextInt(35) == 0)
            a(b);
    }

    private boolean f()
    {
        int j = (int)((double)(float)a.getDoorCount() * 0.34999999999999998D);
        return a.getPopulationCount() < j;
    }

    private void i()
    {
        EntityVillager entityvillager = new EntityVillager(d);
        c.setAge(6000);
        b.setAge(6000);
        entityvillager.setAge(-24000);
        entityvillager.setProfession(b.an().nextInt(5));
        entityvillager.setPositionRotation(b.locX, b.locY, b.locZ, 0.0F, 0.0F);
        d.addEntity(entityvillager);
        a(entityvillager);
    }

    private void a(EntityLiving entityliving)
    {
        Random random = entityliving.an();
        for(int j = 0; j < 5; j++)
        {
            double d1 = random.nextGaussian() * 0.02D;
            double d2 = random.nextGaussian() * 0.02D;
            double d3 = random.nextGaussian() * 0.02D;
            d.a("heart", (entityliving.locX + (double)(random.nextFloat() * entityliving.width * 2.0F)) - (double)entityliving.width, entityliving.locY + 1.0D + (double)(random.nextFloat() * entityliving.length), (entityliving.locZ + (double)(random.nextFloat() * entityliving.width * 2.0F)) - (double)entityliving.width, d1, d2, d3);
        }

    }

    private EntityVillager b;
    private EntityVillager c;
    private World d;
    private int e;
    Village a;
}
