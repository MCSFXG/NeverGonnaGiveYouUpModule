// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            WorldMap

public class WorldMapDecoration
{

    public WorldMapDecoration(WorldMap worldmap, byte byte0, byte byte1, byte byte2, byte byte3)
    {
        e = worldmap;
        super();
        type = byte0;
        locX = byte1;
        locY = byte2;
        rotation = byte3;
    }

    public byte type;
    public byte locX;
    public byte locY;
    public byte rotation;
    final WorldMap e;
}
