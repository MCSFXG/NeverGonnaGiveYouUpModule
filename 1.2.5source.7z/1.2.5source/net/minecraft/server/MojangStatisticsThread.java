// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            MojangStatisticsGenerator, HttpUtilities

class MojangStatisticsThread extends Thread
{

    MojangStatisticsThread(MojangStatisticsGenerator mojangstatisticsgenerator, String s)
    {
        a = mojangstatisticsgenerator;
        super(s);
    }

    public void run()
    {
        HttpUtilities.a(MojangStatisticsGenerator.a(a), MojangStatisticsGenerator.b(a), true);
    }

    final MojangStatisticsGenerator a;
}
