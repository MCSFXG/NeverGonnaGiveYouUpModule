// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenNetherPiece, StructureBoundingBox, StructurePiece, Block, 
//            World

public class WorldGenNetherPiece4 extends WorldGenNetherPiece
{

    public WorldGenNetherPiece4(int i, Random random, StructureBoundingBox structureboundingbox, int j)
    {
        super(i);
        h = j;
        g = structureboundingbox;
        a = random.nextInt();
    }

    public void a(StructurePiece structurepiece, List list, Random random)
    {
    }

    public static WorldGenNetherPiece4 a(List list, Random random, int i, int j, int k, int l, int i1)
    {
        StructureBoundingBox structureboundingbox = StructureBoundingBox.a(i, j, k, -1, -3, 0, 5, 10, 8, l);
        if(!a(structureboundingbox) || StructurePiece.a(list, structureboundingbox) != null)
            return null;
        else
            return new WorldGenNetherPiece4(i1, random, structureboundingbox, l);
    }

    public boolean a(World world, Random random, StructureBoundingBox structureboundingbox)
    {
        Random random1 = new Random(a);
        for(int i = 0; i <= 4; i++)
        {
            for(int i1 = 3; i1 <= 4; i1++)
            {
                int l1 = random1.nextInt(8);
                a(world, structureboundingbox, i, i1, 0, i, i1, l1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            }

        }

        int j = random1.nextInt(8);
        a(world, structureboundingbox, 0, 5, 0, 0, 5, j, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
        j = random1.nextInt(8);
        a(world, structureboundingbox, 4, 5, 0, 4, 5, j, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
        for(int k = 0; k <= 4; k++)
        {
            int j1 = random1.nextInt(5);
            a(world, structureboundingbox, k, 2, 0, k, 2, j1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
        }

        for(int l = 0; l <= 4; l++)
        {
            for(int k1 = 0; k1 <= 1; k1++)
            {
                int i2 = random1.nextInt(3);
                a(world, structureboundingbox, l, k1, 0, l, k1, i2, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            }

        }

        return true;
    }

    private int a;
}
