// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType

public class EnchantmentWaterWorker extends Enchantment
{

    public EnchantmentWaterWorker(int i, int j)
    {
        super(i, j, EnchantmentSlotType.ARMOR_HEAD);
        a("waterWorker");
    }

    public int a(int i)
    {
        return 1;
    }

    public int b(int i)
    {
        return a(i) + 40;
    }

    public int getMaxLevel()
    {
        return 1;
    }
}
