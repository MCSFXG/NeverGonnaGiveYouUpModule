// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, World, EntityDamageSource, Entity, 
//            AxisAlignedBB, DamageSource, MathHelper, Block, 
//            Facing, BlockMonsterEggs, MonsterType, NBTTagCompound

public class EntitySilverfish extends EntityMonster
{

    public EntitySilverfish(World world)
    {
        super(world);
        texture = "/mob/silverfish.png";
        b(0.3F, 0.7F);
        bb = 0.6F;
        damage = 1;
    }

    public int getMaxHealth()
    {
        return 8;
    }

    protected boolean g_()
    {
        return false;
    }

    protected Entity findTarget()
    {
        double d = 8D;
        return world.findNearbyVulnerablePlayer(this, d);
    }

    protected String i()
    {
        return "mob.silverfish.say";
    }

    protected String j()
    {
        return "mob.silverfish.hit";
    }

    protected String k()
    {
        return "mob.silverfish.kill";
    }

    public boolean damageEntity(DamageSource damagesource, int l)
    {
        if(a <= 0 && (damagesource instanceof EntityDamageSource))
            a = 20;
        return super.damageEntity(damagesource, l);
    }

    protected void a(Entity entity, float f)
    {
        if(attackTicks <= 0 && f < 1.2F && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            attackTicks = 20;
            entity.damageEntity(DamageSource.mobAttack(this), damage);
        }
    }

    protected void a(int l, int i1, int j1, int k1)
    {
        world.makeSound(this, "mob.silverfish.step", 1.0F, 1.0F);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int getLootId()
    {
        return 0;
    }

    public void F_()
    {
        V = yaw;
        super.F_();
    }

    protected void d_()
    {
        super.d_();
        if(world.isStatic)
            return;
        if(a > 0)
        {
            a--;
            if(a == 0)
            {
                int l = MathHelper.floor(locX);
                int j1 = MathHelper.floor(locY);
                int l1 = MathHelper.floor(locZ);
                boolean flag = false;
                for(int k2 = 0; !flag && k2 <= 5 && k2 >= -5; k2 = k2 > 0 ? 0 - k2 : 1 - k2)
                {
                    for(int i3 = 0; !flag && i3 <= 10 && i3 >= -10; i3 = i3 > 0 ? 0 - i3 : 1 - i3)
                    {
                        for(int j3 = 0; !flag && j3 <= 10 && j3 >= -10; j3 = j3 > 0 ? 0 - j3 : 1 - j3)
                        {
                            int k3 = world.getTypeId(l + i3, j1 + k2, l1 + j3);
                            if(k3 != Block.MONSTER_EGGS.id)
                                continue;
                            world.triggerEffect(2001, l + i3, j1 + k2, l1 + j3, Block.MONSTER_EGGS.id + (world.getData(l + i3, j1 + k2, l1 + j3) << 12));
                            world.setTypeId(l + i3, j1 + k2, l1 + j3, 0);
                            Block.MONSTER_EGGS.postBreak(world, l + i3, j1 + k2, l1 + j3, 0);
                            if(!random.nextBoolean())
                                continue;
                            flag = true;
                            break;
                        }

                    }

                }

            }
        }
        if(target == null && !H())
        {
            int i1 = MathHelper.floor(locX);
            int k1 = MathHelper.floor(locY + 0.5D);
            int i2 = MathHelper.floor(locZ);
            int j2 = random.nextInt(6);
            int l2 = world.getTypeId(i1 + Facing.b[j2], k1 + Facing.c[j2], i2 + Facing.d[j2]);
            if(BlockMonsterEggs.d(l2))
            {
                world.setTypeIdAndData(i1 + Facing.b[j2], k1 + Facing.c[j2], i2 + Facing.d[j2], Block.MONSTER_EGGS.id, BlockMonsterEggs.e(l2));
                aC();
                die();
            } else
            {
                G();
            }
        } else
        if(target != null && !H())
            target = null;
    }

    public float a(int l, int i1, int j1)
    {
        if(world.getTypeId(l, i1 - 1, j1) == Block.STONE.id)
            return 10F;
        else
            return super.a(l, i1, j1);
    }

    protected boolean C()
    {
        return true;
    }

    public boolean canSpawn()
    {
        if(super.canSpawn())
        {
            EntityHuman entityhuman = world.findNearbyPlayer(this, 5D);
            return entityhuman == null;
        } else
        {
            return false;
        }
    }

    public MonsterType getMonsterType()
    {
        return MonsterType.ARTHROPOD;
    }

    private int a;
}
