// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldGenerator.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.BlockChangeDelegate;

// Referenced classes of package net.minecraft.server:
//            World, Chunk

public abstract class WorldGenerator
{

    public WorldGenerator()
    {
        a = false;
    }

    public WorldGenerator(boolean flag)
    {
        a = flag;
    }

    public abstract boolean a(World world, Random random, int i, int j, int k);

    public void a(double d, double d3, double d4)
    {
    }

    protected void setType(BlockChangeDelegate world, int i, int j, int k, int l)
    {
        setTypeAndData(world, i, j, k, l, 0);
    }

    protected void setTypeAndData(BlockChangeDelegate world, int i, int j, int k, int l, int i1)
    {
        if(a)
            world.setTypeIdAndData(i, j, k, l, i1);
        else
        if((world instanceof World) && ((World)world).getChunkAtWorldCoords(i, k).seenByPlayer)
        {
            if(world.setRawTypeIdAndData(i, j, k, l, i1))
                ((World)world).notify(i, j, k);
        } else
        {
            world.setRawTypeIdAndData(i, j, k, l, i1);
        }
    }

    private final boolean a;
}
