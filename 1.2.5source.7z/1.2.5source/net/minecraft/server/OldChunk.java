// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            OldNibbleArray, NBTTagList

public class OldChunk
{

    public OldChunk(int i1, int j1)
    {
        k = i1;
        l = j1;
    }

    public long a;
    public boolean b;
    public byte c[];
    public OldNibbleArray d;
    public OldNibbleArray e;
    public OldNibbleArray f;
    public byte g[];
    public NBTTagList h;
    public NBTTagList i;
    public NBTTagList j;
    public final int k;
    public final int l;
}
