// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class OldNibbleArray
{

    public OldNibbleArray(byte abyte0[], int i)
    {
        a = abyte0;
        b = i;
        c = i + 4;
    }

    public int a(int i, int j, int k)
    {
        int l = i << c | k << b | j;
        int i1 = l >> 1;
        int j1 = l & 1;
        if(j1 == 0)
            return a[i1] & 0xf;
        else
            return a[i1] >> 4 & 0xf;
    }

    public final byte a[];
    private final int b;
    private final int c;
}
