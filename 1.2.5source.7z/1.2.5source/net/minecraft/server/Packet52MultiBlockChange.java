// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;

// Referenced classes of package net.minecraft.server:
//            Packet, World, Chunk, NetHandler

public class Packet52MultiBlockChange extends Packet
{

    public Packet52MultiBlockChange()
    {
        lowPriority = true;
    }

    public Packet52MultiBlockChange(int i, int j, short aword0[], int k, World world)
    {
        lowPriority = true;
        a = i;
        b = j;
        d = k;
        int l = 4 * k;
        Chunk chunk = world.getChunkAt(i, j);
        try
        {
            if(k >= 64)
            {
                System.out.println((new StringBuilder()).append("ChunkTilesUpdatePacket compress ").append(k).toString());
                if(e.length < l)
                    e = new byte[l];
            } else
            {
                ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(l);
                DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);
                for(int i1 = 0; i1 < k; i1++)
                {
                    int j1 = aword0[i1] >> 12 & 0xf;
                    int k1 = aword0[i1] >> 8 & 0xf;
                    int l1 = aword0[i1] & 0xff;
                    dataoutputstream.writeShort(aword0[i1]);
                    dataoutputstream.writeShort((short)((chunk.getTypeId(j1, l1, k1) & 0xfff) << 4 | chunk.getData(j1, l1, k1) & 0xf));
                }

                c = bytearrayoutputstream.toByteArray();
                if(c.length != l)
                    throw new RuntimeException((new StringBuilder()).append("Expected length ").append(l).append(" doesn't match received length ").append(c.length).toString());
            }
        }
        catch(IOException ioexception)
        {
            System.err.println(ioexception.getMessage());
            c = null;
        }
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readInt();
        b = datainputstream.readInt();
        d = datainputstream.readShort() & 0xffff;
        int i = datainputstream.readInt();
        if(i > 0)
        {
            c = new byte[i];
            datainputstream.readFully(c);
        }
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeInt(a);
        dataoutputstream.writeInt(b);
        dataoutputstream.writeShort((short)d);
        if(c != null)
        {
            dataoutputstream.writeInt(c.length);
            dataoutputstream.write(c);
        } else
        {
            dataoutputstream.writeInt(0);
        }
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 10 + d * 4;
    }

    public int a;
    public int b;
    public byte c[];
    public int d;
    private static byte e[] = new byte[0];

}
