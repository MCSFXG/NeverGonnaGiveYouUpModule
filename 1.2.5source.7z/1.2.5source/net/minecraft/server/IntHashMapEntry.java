// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            IntHashMap

class IntHashMapEntry
{

    IntHashMapEntry(int i, int j, Object obj, IntHashMapEntry inthashmapentry)
    {
        b = obj;
        c = inthashmapentry;
        a = j;
        d = i;
    }

    public final int a()
    {
        return a;
    }

    public final Object b()
    {
        return b;
    }

    public final boolean equals(Object obj)
    {
        if(!(obj instanceof IntHashMapEntry))
            return false;
        IntHashMapEntry inthashmapentry = (IntHashMapEntry)obj;
        Integer integer = Integer.valueOf(a());
        Integer integer1 = Integer.valueOf(inthashmapentry.a());
        if(integer == integer1 || integer != null && integer.equals(integer1))
        {
            Object obj1 = b();
            Object obj2 = inthashmapentry.b();
            if(obj1 == obj2 || obj1 != null && obj1.equals(obj2))
                return true;
        }
        return false;
    }

    public final int hashCode()
    {
        return IntHashMap.f(a);
    }

    public final String toString()
    {
        return (new StringBuilder()).append(a()).append("=").append(b()).toString();
    }

    final int a;
    Object b;
    IntHashMapEntry c;
    final int d;
}
