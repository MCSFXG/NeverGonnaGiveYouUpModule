// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, World, MathHelper, 
//            VillageCollection, Navigation, VillageDoor, Vec3D, 
//            RandomPositionGenerator, Village, PathEntity

public class PathfinderGoalMoveThroughVillage extends PathfinderGoal
{

    public PathfinderGoalMoveThroughVillage(EntityCreature entitycreature, float f1, boolean flag)
    {
        f = new ArrayList();
        a = entitycreature;
        b = f1;
        e = flag;
        a(1);
    }

    public boolean a()
    {
        f();
        if(e && a.world.e())
            return false;
        Village village = a.world.villages.getClosestVillage(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ), 0);
        if(village == null)
            return false;
        d = a(village);
        if(d == null)
            return false;
        boolean flag = a.al().b();
        a.al().b(false);
        c = a.al().a(d.locX, d.locY, d.locZ);
        a.al().b(flag);
        if(c != null)
            return true;
        Vec3D vec3d = RandomPositionGenerator.a(a, 10, 7, Vec3D.create(d.locX, d.locY, d.locZ));
        if(vec3d == null)
        {
            return false;
        } else
        {
            a.al().b(false);
            c = a.al().a(vec3d.a, vec3d.b, vec3d.c);
            a.al().b(flag);
            return c != null;
        }
    }

    public boolean b()
    {
        if(a.al().e())
        {
            return false;
        } else
        {
            float f1 = a.width + 4F;
            return a.e(d.locX, d.locY, d.locZ) > (double)(f1 * f1);
        }
    }

    public void c()
    {
        a.al().a(c, b);
    }

    public void d()
    {
        if(a.al().e() || a.e(d.locX, d.locY, d.locZ) < 16D)
            f.add(d);
    }

    private VillageDoor a(Village village)
    {
        VillageDoor villagedoor = null;
        int i = 0x7fffffff;
        List list = village.getDoors();
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            VillageDoor villagedoor1 = (VillageDoor)iterator.next();
            int j = villagedoor1.a(MathHelper.floor(a.locX), MathHelper.floor(a.locY), MathHelper.floor(a.locZ));
            if(j < i && !a(villagedoor1))
            {
                villagedoor = villagedoor1;
                i = j;
            }
        } while(true);
        return villagedoor;
    }

    private boolean a(VillageDoor villagedoor)
    {
        for(Iterator iterator = f.iterator(); iterator.hasNext();)
        {
            VillageDoor villagedoor1 = (VillageDoor)iterator.next();
            if(villagedoor.locX == villagedoor1.locX && villagedoor.locY == villagedoor1.locY && villagedoor.locZ == villagedoor1.locZ)
                return true;
        }

        return false;
    }

    private void f()
    {
        if(f.size() > 15)
            f.remove(0);
    }

    private EntityCreature a;
    private float b;
    private PathEntity c;
    private VillageDoor d;
    private boolean e;
    private List f;
}
