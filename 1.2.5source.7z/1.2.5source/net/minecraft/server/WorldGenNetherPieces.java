// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenNetherPieceWeight, WorldGenNetherPiece2, WorldGenNetherPiece9, WorldGenNetherPiece11, 
//            WorldGenNetherPiece7, WorldGenNetherPiece12, WorldGenNetherPiece10, WorldGenNetherPiece8, 
//            WorldGenNetherPiece1, WorldGenNetherPiece5, WorldGenNetherPiece14, WorldGenNetherPiece6, 
//            WorldGenNetherPiece13, WorldGenNetherPiece3, WorldGenNetherPiece

public class WorldGenNetherPieces
{

    public WorldGenNetherPieces()
    {
    }

    private static WorldGenNetherPiece b(WorldGenNetherPieceWeight worldgennetherpieceweight, List list, Random random, int i, int j, int k, int l, int i1)
    {
        Class class1 = worldgennetherpieceweight.a;
        Object obj = null;
        if(class1 == net/minecraft/server/WorldGenNetherPiece2)
            obj = WorldGenNetherPiece2.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece9)
            obj = WorldGenNetherPiece9.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece11)
            obj = WorldGenNetherPiece11.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece7)
            obj = WorldGenNetherPiece7.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece12)
            obj = WorldGenNetherPiece12.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece10)
            obj = WorldGenNetherPiece10.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece8)
            obj = WorldGenNetherPiece8.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece1)
            obj = WorldGenNetherPiece1.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece5)
            obj = WorldGenNetherPiece5.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece14)
            obj = WorldGenNetherPiece14.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece6)
            obj = WorldGenNetherPiece6.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece13)
            obj = WorldGenNetherPiece13.a(list, random, i, j, k, l, i1);
        else
        if(class1 == net/minecraft/server/WorldGenNetherPiece3)
            obj = WorldGenNetherPiece3.a(list, random, i, j, k, l, i1);
        return ((WorldGenNetherPiece) (obj));
    }

    static WorldGenNetherPiece a(WorldGenNetherPieceWeight worldgennetherpieceweight, List list, Random random, int i, int j, int k, int l, int i1)
    {
        return b(worldgennetherpieceweight, list, random, i, j, k, l, i1);
    }

    static WorldGenNetherPieceWeight[] a()
    {
        return a;
    }

    static WorldGenNetherPieceWeight[] b()
    {
        return b;
    }

    private static final WorldGenNetherPieceWeight a[] = {
        new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece2, 30, 0, true), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece9, 10, 4), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece11, 10, 4), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece7, 10, 3), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece12, 5, 2), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece10, 5, 1)
    };
    private static final WorldGenNetherPieceWeight b[] = {
        new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece8, 25, 0, true), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece13, 15, 5), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece1, 5, 10), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece5, 5, 10), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece14, 10, 3, true), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece6, 7, 2), new WorldGenNetherPieceWeight(net/minecraft/server/WorldGenNetherPiece3, 5, 2)
    };

}
