// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityIronGolem, World, EntityVillager, 
//            AxisAlignedBB, ControllerLook

public class PathfinderGoalOfferFlower extends PathfinderGoal
{

    public PathfinderGoalOfferFlower(EntityIronGolem entityirongolem)
    {
        a = entityirongolem;
        a(3);
    }

    public boolean a()
    {
        if(!a.world.e())
            return false;
        if(a.an().nextInt(8000) != 0)
        {
            return false;
        } else
        {
            b = (EntityVillager)a.world.a(net/minecraft/server/EntityVillager, a.boundingBox.grow(6D, 2D, 6D), a);
            return b != null;
        }
    }

    public boolean b()
    {
        return c > 0;
    }

    public void c()
    {
        c = 400;
        a.a(true);
    }

    public void d()
    {
        a.a(false);
        b = null;
    }

    public void e()
    {
        a.getControllerLook().a(b, 30F, 30F);
        c--;
    }

    private EntityIronGolem a;
    private EntityVillager b;
    private int c;
}
