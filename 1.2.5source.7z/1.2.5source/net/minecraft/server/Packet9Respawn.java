// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler, WorldType

public class Packet9Respawn extends Packet
{

    public Packet9Respawn()
    {
    }

    public Packet9Respawn(int i, byte byte0, WorldType worldtype, int j, int k)
    {
        a = i;
        b = byte0;
        c = j;
        d = k;
        e = worldtype;
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readInt();
        b = datainputstream.readByte();
        d = datainputstream.readByte();
        c = datainputstream.readShort();
        String s = a(datainputstream, 16);
        e = WorldType.getType(s);
        if(e == null)
            e = WorldType.NORMAL;
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeInt(a);
        dataoutputstream.writeByte(b);
        dataoutputstream.writeByte(d);
        dataoutputstream.writeShort(c);
        a(e.name(), dataoutputstream);
    }

    public int a()
    {
        return 8 + e.name().length();
    }

    public int a;
    public int b;
    public int c;
    public int d;
    public WorldType e;
}
