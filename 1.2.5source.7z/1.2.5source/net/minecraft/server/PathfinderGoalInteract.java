// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoalLookAtPlayer, EntityLiving

public class PathfinderGoalInteract extends PathfinderGoalLookAtPlayer
{

    public PathfinderGoalInteract(EntityLiving entityliving, Class class1, float f)
    {
        super(entityliving, class1, f);
        a(3);
    }

    public PathfinderGoalInteract(EntityLiving entityliving, Class class1, float f, float f1)
    {
        super(entityliving, class1, f, f1);
        a(3);
    }
}
