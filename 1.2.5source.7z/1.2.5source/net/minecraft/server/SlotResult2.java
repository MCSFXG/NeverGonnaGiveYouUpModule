// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Slot, ItemStack, EntityHuman, Item, 
//            AchievementList, IInventory

public class SlotResult2 extends Slot
{

    public SlotResult2(EntityHuman entityhuman, IInventory iinventory, int i, int j, int k)
    {
        super(iinventory, i, j, k);
        a = entityhuman;
    }

    public boolean isAllowed(ItemStack itemstack)
    {
        return false;
    }

    public ItemStack a(int i)
    {
        if(c())
            f += Math.min(i, getItem().count);
        return super.a(i);
    }

    public void c(ItemStack itemstack)
    {
        b(itemstack);
        super.c(itemstack);
    }

    protected void a(ItemStack itemstack, int i)
    {
        f += i;
        b(itemstack);
    }

    protected void b(ItemStack itemstack)
    {
        itemstack.a(a.world, a, f);
        f = 0;
        if(itemstack.id == Item.IRON_INGOT.id)
            a.a(AchievementList.k, 1);
        if(itemstack.id == Item.COOKED_FISH.id)
            a.a(AchievementList.p, 1);
    }

    private EntityHuman a;
    private int f;
}
