// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityZombie.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, PathfinderGoalFloat, PathfinderGoalBreakDoor, PathfinderGoalMeleeAttack, 
//            EntityHuman, EntityVillager, PathfinderGoalMoveTowardsRestriction, PathfinderGoalMoveThroughVillage, 
//            PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, PathfinderGoalRandomLookaround, PathfinderGoalHurtByTarget, 
//            PathfinderGoalNearestAttackableTarget, ItemStack, Navigation, PathfinderGoalSelector, 
//            World, MathHelper, Item, MonsterType

public class EntityZombie extends EntityMonster
{

    public EntityZombie(World world)
    {
        super(world);
        texture = "/mob/zombie.png";
        bb = 0.23F;
        damage = 4;
        al().b(true);
        goalSelector.a(0, new PathfinderGoalFloat(this));
        goalSelector.a(1, new PathfinderGoalBreakDoor(this));
        goalSelector.a(2, new PathfinderGoalMeleeAttack(this, net/minecraft/server/EntityHuman, bb, false));
        goalSelector.a(3, new PathfinderGoalMeleeAttack(this, net/minecraft/server/EntityVillager, bb, true));
        goalSelector.a(4, new PathfinderGoalMoveTowardsRestriction(this, bb));
        goalSelector.a(5, new PathfinderGoalMoveThroughVillage(this, bb, false));
        goalSelector.a(6, new PathfinderGoalRandomStroll(this, bb));
        goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 8F));
        goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
        targetSelector.a(1, new PathfinderGoalHurtByTarget(this, false));
        targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, net/minecraft/server/EntityHuman, 16F, 0, true));
        targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, net/minecraft/server/EntityVillager, 16F, 0, false));
    }

    public int getMaxHealth()
    {
        return 20;
    }

    public int T()
    {
        return 2;
    }

    protected boolean c_()
    {
        return true;
    }

    public void e()
    {
        if(world.e() && !world.isStatic)
        {
            float f = b(1.0F);
            if(f > 0.5F && world.isChunkLoaded(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) && random.nextFloat() * 30F < (f - 0.4F) * 2.0F)
            {
                EntityCombustEvent event = new EntityCombustEvent(getBukkitEntity(), 8);
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    setOnFire(event.getDuration());
            }
        }
        super.e();
    }

    protected String i()
    {
        return "mob.zombie";
    }

    protected String j()
    {
        return "mob.zombiehurt";
    }

    protected String k()
    {
        return "mob.zombiedeath";
    }

    protected int getLootId()
    {
        return Item.ROTTEN_FLESH.id;
    }

    public MonsterType getMonsterType()
    {
        return MonsterType.UNDEAD;
    }

    protected ItemStack b(int i)
    {
        switch(random.nextInt(4))
        {
        case 0: // '\0'
            return new ItemStack(Item.IRON_SWORD.id, 1, 0);

        case 1: // '\001'
            return new ItemStack(Item.IRON_HELMET.id, 1, 0);

        case 2: // '\002'
            return new ItemStack(Item.IRON_INGOT.id, 1, 0);

        case 3: // '\003'
            return new ItemStack(Item.IRON_SPADE.id, 1, 0);
        }
        return null;
    }
}
