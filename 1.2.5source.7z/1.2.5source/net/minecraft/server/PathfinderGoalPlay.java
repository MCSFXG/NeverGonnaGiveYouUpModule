// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityVillager, AxisAlignedBB, World, 
//            Entity, RandomPositionGenerator, Navigation, Vec3D, 
//            EntityLiving

public class PathfinderGoalPlay extends PathfinderGoal
{

    public PathfinderGoalPlay(EntityVillager entityvillager, float f)
    {
        a = entityvillager;
        c = f;
        a(1);
    }

    public boolean a()
    {
        if(a.getAge() >= 0)
            return false;
        if(a.an().nextInt(400) != 0)
            return false;
        List list = a.world.a(net/minecraft/server/EntityVillager, a.boundingBox.grow(6D, 3D, 6D));
        double d1 = 1.7976931348623157E+308D;
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Entity entity = (Entity)iterator.next();
            if(entity != a)
            {
                EntityVillager entityvillager = (EntityVillager)entity;
                if(!entityvillager.C() && entityvillager.getAge() < 0)
                {
                    double d2 = entityvillager.j(a);
                    if(d2 <= d1)
                    {
                        d1 = d2;
                        b = entityvillager;
                    }
                }
            }
        } while(true);
        if(b == null)
        {
            Vec3D vec3d = RandomPositionGenerator.a(a, 16, 3);
            if(vec3d == null)
                return false;
        }
        return true;
    }

    public boolean b()
    {
        return d > 0;
    }

    public void c()
    {
        if(b != null)
            a.b(true);
        d = 1000;
    }

    public void d()
    {
        a.b(false);
        b = null;
    }

    public void e()
    {
        d--;
        if(b != null)
        {
            if(a.j(b) > 4D)
                a.al().a(b, c);
        } else
        if(a.al().e())
        {
            Vec3D vec3d = RandomPositionGenerator.a(a, 16, 3);
            if(vec3d == null)
                return;
            a.al().a(vec3d.a, vec3d.b, vec3d.c, c);
        }
    }

    private EntityVillager a;
    private EntityLiving b;
    private float c;
    private int d;
}
