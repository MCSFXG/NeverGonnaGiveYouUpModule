// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityAgeable.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityCreature, DataWatcher, NBTTagCompound, World

public abstract class EntityAgeable extends EntityCreature
{

    public EntityAgeable(World world)
    {
        super(world);
        ageLocked = false;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(12, new Integer(0));
    }

    public int getAge()
    {
        return datawatcher.getInt(12);
    }

    public void setAge(int i)
    {
        datawatcher.watch(12, Integer.valueOf(i));
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setInt("Age", getAge());
        nbttagcompound.setBoolean("AgeLocked", ageLocked);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setAge(nbttagcompound.getInt("Age"));
        ageLocked = nbttagcompound.getBoolean("AgeLocked");
    }

    public void e()
    {
        super.e();
        int i = getAge();
        if(ageLocked)
            return;
        if(i < 0)
        {
            i++;
            setAge(i);
        } else
        if(i > 0)
        {
            i--;
            setAge(i);
        }
    }

    public boolean isBaby()
    {
        return getAge() < 0;
    }

    public boolean ageLocked;
}
