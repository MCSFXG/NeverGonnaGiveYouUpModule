// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPotion.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.entity.CraftLivingEntity;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.PotionSplashEvent;

// Referenced classes of package net.minecraft.server:
//            EntityProjectile, EntityLiving, Entity, MobEffect, 
//            EntityPlayer, World, Item, ItemPotion, 
//            AxisAlignedBB, MovingObjectPosition, MobEffectList

public class EntityPotion extends EntityProjectile
{

    public EntityPotion(World world)
    {
        super(world);
    }

    public EntityPotion(World world, EntityLiving entityliving, int i)
    {
        super(world, entityliving);
        d = i;
    }

    public EntityPotion(World world, double d0, double d1, double d2, 
            int i)
    {
        super(world, d0, d1, d2);
        d = i;
    }

    protected float e()
    {
        return 0.05F;
    }

    protected float c()
    {
        return 0.5F;
    }

    protected float d()
    {
        return -20F;
    }

    public int getPotionValue()
    {
        return d;
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(!world.isStatic)
        {
            List list = Item.POTION.b(d);
            if(list != null && !list.isEmpty())
            {
                AxisAlignedBB axisalignedbb = boundingBox.grow(4D, 2D, 4D);
                List list1 = world.a(net/minecraft/server/EntityLiving, axisalignedbb);
                if(list1 != null && !list1.isEmpty())
                {
                    Iterator iterator = list1.iterator();
                    HashMap affected = new HashMap();
                    do
                    {
                        if(!iterator.hasNext())
                            break;
                        Entity entity = (Entity)iterator.next();
                        double d0 = j(entity);
                        if(d0 < 16D)
                        {
                            double d1 = 1.0D - Math.sqrt(d0) / 4D;
                            if(entity == movingobjectposition.entity)
                                d1 = 1.0D;
                            affected.put((LivingEntity)entity.getBukkitEntity(), Double.valueOf(d1));
                        }
                    } while(true);
                    PotionSplashEvent event = CraftEventFactory.callPotionSplashEvent(this, affected);
                    if(!event.isCancelled())
                    {
                        for(Iterator i$ = event.getAffectedEntities().iterator(); i$.hasNext();)
                        {
                            LivingEntity victim = (LivingEntity)i$.next();
                            if(victim instanceof CraftLivingEntity)
                            {
                                EntityLiving entity = ((CraftLivingEntity)victim).getHandle();
                                double d1 = event.getIntensity(victim);
                                Iterator iterator1 = list.iterator();
                                while(iterator1.hasNext()) 
                                {
                                    MobEffect mobeffect = (MobEffect)iterator1.next();
                                    int i = mobeffect.getEffectId();
                                    if(world.pvpMode || !(entity instanceof EntityPlayer) || entity == shooter || i != 2 && i != 4 && i != 7 && i != 15 && i != 17 && i != 18 && i != 19)
                                        if(MobEffectList.byId[i].isInstant())
                                        {
                                            MobEffectList.byId[i].applyInstantEffect(shooter, entity, mobeffect.getAmplifier(), d1, this);
                                        } else
                                        {
                                            int j = (int)(d1 * (double)mobeffect.getDuration() + 0.5D);
                                            if(j > 20)
                                                entity.addEffect(new MobEffect(i, j, mobeffect.getAmplifier()));
                                        }
                                }
                            }
                        }

                    }
                }
            }
            world.triggerEffect(2002, (int)Math.round(locX), (int)Math.round(locY), (int)Math.round(locZ), d);
            die();
        }
    }

    private int d;
}
