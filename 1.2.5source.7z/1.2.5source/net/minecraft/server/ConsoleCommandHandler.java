// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.server:
//            ServerCommand, ICommandListener, MinecraftServer, ServerConfigurationManager, 
//            WorldServer, EntityPlayer, NetServerHandler, Item, 
//            ItemStack, WorldSettings, ItemInWorldManager, Packet70Bed, 
//            Packet3Chat, PropertyManager

public class ConsoleCommandHandler
{

    public ConsoleCommandHandler(MinecraftServer minecraftserver)
    {
        server = minecraftserver;
    }

    public synchronized void handle(ServerCommand servercommand)
    {
        String s = servercommand.command;
        String as[] = s.split(" ");
        String s1 = as[0];
        String s2 = s.substring(s1.length()).trim();
        ICommandListener icommandlistener = servercommand.source;
        String s3 = icommandlistener.getName();
        ServerConfigurationManager serverconfigurationmanager = server.serverConfigurationManager;
        if(s1.equalsIgnoreCase("help") || s1.equalsIgnoreCase("?"))
            a(icommandlistener);
        else
        if(s1.equalsIgnoreCase("list"))
            icommandlistener.sendMessage((new StringBuilder()).append("Connected players: ").append(serverconfigurationmanager.c()).toString());
        else
        if(s1.equalsIgnoreCase("stop"))
        {
            print(s3, "Stopping the server..");
            server.safeShutdown();
        } else
        if(s1.equalsIgnoreCase("save-all"))
        {
            print(s3, "Forcing save..");
            if(serverconfigurationmanager != null)
                serverconfigurationmanager.savePlayers();
            for(int i = 0; i < server.worldServer.length; i++)
            {
                WorldServer worldserver = server.worldServer[i];
                boolean flag = worldserver.savingDisabled;
                worldserver.savingDisabled = false;
                worldserver.save(true, null);
                worldserver.savingDisabled = flag;
            }

            print(s3, "Save complete.");
        } else
        if(s1.equalsIgnoreCase("save-off"))
        {
            print(s3, "Disabling level saving..");
            for(int j = 0; j < server.worldServer.length; j++)
            {
                WorldServer worldserver1 = server.worldServer[j];
                worldserver1.savingDisabled = true;
            }

        } else
        if(s1.equalsIgnoreCase("save-on"))
        {
            print(s3, "Enabling level saving..");
            for(int k = 0; k < server.worldServer.length; k++)
            {
                WorldServer worldserver2 = server.worldServer[k];
                worldserver2.savingDisabled = false;
            }

        } else
        if(s1.equalsIgnoreCase("op"))
        {
            serverconfigurationmanager.addOp(s2);
            print(s3, (new StringBuilder()).append("Opping ").append(s2).toString());
            serverconfigurationmanager.a(s2, "\247eYou are now op!");
        } else
        if(s1.equalsIgnoreCase("deop"))
        {
            String s4 = s2;
            serverconfigurationmanager.removeOp(s4);
            serverconfigurationmanager.a(s4, "\247eYou are no longer op!");
            print(s3, (new StringBuilder()).append("De-opping ").append(s4).toString());
        } else
        if(s1.equalsIgnoreCase("ban-ip"))
        {
            String s5 = s2;
            serverconfigurationmanager.addIpBan(s5);
            print(s3, (new StringBuilder()).append("Banning ip ").append(s5).toString());
        } else
        if(s1.equalsIgnoreCase("pardon-ip"))
        {
            String s6 = s2;
            serverconfigurationmanager.removeIpBan(s6);
            print(s3, (new StringBuilder()).append("Pardoning ip ").append(s6).toString());
        } else
        if(s1.equalsIgnoreCase("ban"))
        {
            String s7 = s2;
            serverconfigurationmanager.addUserBan(s7);
            print(s3, (new StringBuilder()).append("Banning ").append(s7).toString());
            EntityPlayer entityplayer1 = serverconfigurationmanager.i(s7);
            if(entityplayer1 != null)
                entityplayer1.netServerHandler.disconnect("Banned by admin");
        } else
        if(s1.equalsIgnoreCase("pardon"))
        {
            String s8 = s2;
            serverconfigurationmanager.removeUserBan(s8);
            print(s3, (new StringBuilder()).append("Pardoning ").append(s8).toString());
        } else
        if(s1.equalsIgnoreCase("kick"))
        {
            String s9 = s2;
            EntityPlayer entityplayer2 = null;
            for(int i1 = 0; i1 < serverconfigurationmanager.players.size(); i1++)
            {
                EntityPlayer entityplayer7 = (EntityPlayer)serverconfigurationmanager.players.get(i1);
                if(entityplayer7.name.equalsIgnoreCase(s9))
                    entityplayer2 = entityplayer7;
            }

            if(entityplayer2 != null)
            {
                entityplayer2.netServerHandler.disconnect("Kicked by admin");
                print(s3, (new StringBuilder()).append("Kicking ").append(entityplayer2.name).toString());
            } else
            {
                icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s9).append(". No kick.").toString());
            }
        } else
        if(s1.equalsIgnoreCase("tp"))
        {
            if(as.length == 3)
            {
                EntityPlayer entityplayer = serverconfigurationmanager.i(as[1]);
                EntityPlayer entityplayer3 = serverconfigurationmanager.i(as[2]);
                if(entityplayer == null)
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(as[1]).append(". No tp.").toString());
                else
                if(entityplayer3 == null)
                    icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(as[2]).append(". No tp.").toString());
                else
                if(entityplayer.dimension != entityplayer3.dimension)
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("User ").append(as[1]).append(" and ").append(as[2]).append(" are in different dimensions. No tp.").toString());
                } else
                {
                    entityplayer.netServerHandler.a(entityplayer3.locX, entityplayer3.locY, entityplayer3.locZ, entityplayer3.yaw, entityplayer3.pitch);
                    print(s3, (new StringBuilder()).append("Teleporting ").append(as[1]).append(" to ").append(as[2]).append(".").toString());
                }
            } else
            {
                icommandlistener.sendMessage("Syntax error, please provide a source and a target.");
            }
        } else
        if(s1.equalsIgnoreCase("give"))
        {
            if(as.length != 3 && as.length != 4 && as.length != 5)
                return;
            String s10 = as[1];
            EntityPlayer entityplayer4 = serverconfigurationmanager.i(s10);
            if(entityplayer4 != null)
                try
                {
                    int j1 = Integer.parseInt(as[2]);
                    if(Item.byId[j1] != null)
                    {
                        print(s3, (new StringBuilder()).append("Giving ").append(entityplayer4.name).append(" some ").append(j1).toString());
                        int k2 = 1;
                        int l2 = 0;
                        if(as.length > 3)
                            k2 = a(as[3], 1);
                        if(as.length > 4)
                            l2 = a(as[4], 1);
                        if(k2 < 1)
                            k2 = 1;
                        if(k2 > 64)
                            k2 = 64;
                        entityplayer4.drop(new ItemStack(j1, k2, l2));
                    } else
                    {
                        icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(j1).toString());
                    }
                }
                catch(NumberFormatException numberformatexception1)
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("There's no item with id ").append(as[2]).toString());
                }
            else
                icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s10).toString());
        } else
        if(s1.equalsIgnoreCase("xp"))
        {
            if(as.length != 3)
                return;
            String s11 = as[1];
            EntityPlayer entityplayer5 = serverconfigurationmanager.i(s11);
            if(entityplayer5 != null)
                try
                {
                    int k1 = Integer.parseInt(as[2]);
                    k1 = k1 <= 5000 ? k1 : 5000;
                    print(s3, (new StringBuilder()).append("Giving ").append(k1).append(" orbs to ").append(entityplayer5.name).toString());
                    entityplayer5.giveExp(k1);
                }
                catch(NumberFormatException numberformatexception2)
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("Invalid orb count: ").append(as[2]).toString());
                }
            else
                icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s11).toString());
        } else
        if(s1.equalsIgnoreCase("gamemode"))
        {
            if(as.length != 3)
                return;
            String s12 = as[1];
            EntityPlayer entityplayer6 = serverconfigurationmanager.i(s12);
            if(entityplayer6 != null)
                try
                {
                    int l1 = Integer.parseInt(as[2]);
                    l1 = WorldSettings.a(l1);
                    if(entityplayer6.itemInWorldManager.getGameMode() != l1)
                    {
                        print(s3, (new StringBuilder()).append("Setting ").append(entityplayer6.name).append(" to game mode ").append(l1).toString());
                        entityplayer6.itemInWorldManager.setGameMode(l1);
                        entityplayer6.netServerHandler.sendPacket(new Packet70Bed(3, l1));
                    } else
                    {
                        print(s3, (new StringBuilder()).append(entityplayer6.name).append(" already has game mode ").append(l1).toString());
                    }
                }
                catch(NumberFormatException numberformatexception3)
                {
                    icommandlistener.sendMessage((new StringBuilder()).append("There's no game mode with id ").append(as[2]).toString());
                }
            else
                icommandlistener.sendMessage((new StringBuilder()).append("Can't find user ").append(s12).toString());
        } else
        if(s1.equalsIgnoreCase("time"))
        {
            if(as.length != 3)
                return;
            String s13 = as[1];
            try
            {
                int l = Integer.parseInt(as[2]);
                if("add".equalsIgnoreCase(s13))
                {
                    for(int i2 = 0; i2 < server.worldServer.length; i2++)
                    {
                        WorldServer worldserver3 = server.worldServer[i2];
                        worldserver3.setTimeAndFixTicklists(worldserver3.getTime() + (long)l);
                    }

                    print(s3, (new StringBuilder()).append("Added ").append(l).append(" to time").toString());
                } else
                if("set".equalsIgnoreCase(s13))
                {
                    for(int j2 = 0; j2 < server.worldServer.length; j2++)
                    {
                        WorldServer worldserver4 = server.worldServer[j2];
                        worldserver4.setTimeAndFixTicklists(l);
                    }

                    print(s3, (new StringBuilder()).append("Set time to ").append(l).toString());
                } else
                {
                    icommandlistener.sendMessage("Unknown method, use either \"add\" or \"set\"");
                }
            }
            catch(NumberFormatException numberformatexception)
            {
                icommandlistener.sendMessage((new StringBuilder()).append("Unable to convert time value, ").append(as[2]).toString());
            }
        } else
        if(s1.equalsIgnoreCase("say") && s2.length() > 0)
        {
            a.info((new StringBuilder()).append("[").append(s3).append("] ").append(s2).toString());
            serverconfigurationmanager.sendAll(new Packet3Chat((new StringBuilder()).append("\247d[Server] ").append(s2).toString()));
        } else
        if(s1.equalsIgnoreCase("tell"))
        {
            if(as.length >= 3)
            {
                s = s.substring(s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();
                a.info((new StringBuilder()).append("[").append(s3).append("->").append(as[1]).append("] ").append(s).toString());
                s = (new StringBuilder()).append("\2477").append(s3).append(" whispers ").append(s).toString();
                a.info(s);
                if(!serverconfigurationmanager.a(as[1], new Packet3Chat(s)))
                    icommandlistener.sendMessage("There's no player by that name online.");
            }
        } else
        if(s1.equalsIgnoreCase("whitelist"))
            a(s3, s, icommandlistener);
        else
        if(s1.equalsIgnoreCase("toggledownfall"))
        {
            server.worldServer[0].j();
            icommandlistener.sendMessage("Toggling rain and snow, hold on...");
        } else
        if(s1.equalsIgnoreCase("banlist"))
        {
            if(as.length == 2)
            {
                if(as[1].equals("ips"))
                    icommandlistener.sendMessage((new StringBuilder()).append("IP Ban list:").append(a(server.q(), ", ")).toString());
            } else
            {
                icommandlistener.sendMessage((new StringBuilder()).append("Ban list:").append(a(server.r(), ", ")).toString());
            }
        } else
        {
            a.info("Unknown console command. Type \"help\" for help.");
        }
    }

    private void a(String s, String s1, ICommandListener icommandlistener)
    {
        String as[] = s1.split(" ");
        if(as.length < 2)
            return;
        String s2 = as[1].toLowerCase();
        if("on".equals(s2))
        {
            print(s, "Turned on white-listing");
            server.propertyManager.setBoolean("white-list", true);
        } else
        if("off".equals(s2))
        {
            print(s, "Turned off white-listing");
            server.propertyManager.setBoolean("white-list", false);
        } else
        if("list".equals(s2))
        {
            Set set = server.serverConfigurationManager.getWhitelisted();
            String s5 = "";
            for(Iterator iterator = set.iterator(); iterator.hasNext();)
            {
                String s6 = (String)iterator.next();
                s5 = (new StringBuilder()).append(s5).append(s6).append(" ").toString();
            }

            icommandlistener.sendMessage((new StringBuilder()).append("White-listed players: ").append(s5).toString());
        } else
        if("add".equals(s2) && as.length == 3)
        {
            String s3 = as[2].toLowerCase();
            server.serverConfigurationManager.addWhitelist(s3);
            print(s, (new StringBuilder()).append("Added ").append(s3).append(" to white-list").toString());
        } else
        if("remove".equals(s2) && as.length == 3)
        {
            String s4 = as[2].toLowerCase();
            server.serverConfigurationManager.removeWhitelist(s4);
            print(s, (new StringBuilder()).append("Removed ").append(s4).append(" from white-list").toString());
        } else
        if("reload".equals(s2))
        {
            server.serverConfigurationManager.reloadWhitelist();
            print(s, "Reloaded white-list from file");
        }
    }

    private void a(ICommandListener icommandlistener)
    {
        icommandlistener.sendMessage("To run the server without a gui, start it like this:");
        icommandlistener.sendMessage("   java -Xmx1024M -Xms1024M -jar minecraft_server.jar nogui");
        icommandlistener.sendMessage("Console commands:");
        icommandlistener.sendMessage("   help  or  ?               shows this message");
        icommandlistener.sendMessage("   kick <player>             removes a player from the server");
        icommandlistener.sendMessage("   ban <player>              bans a player from the server");
        icommandlistener.sendMessage("   pardon <player>           pardons a banned player so that they can connect again");
        icommandlistener.sendMessage("   ban-ip <ip>               bans an IP address from the server");
        icommandlistener.sendMessage("   pardon-ip <ip>            pardons a banned IP address so that they can connect again");
        icommandlistener.sendMessage("   op <player>               turns a player into an op");
        icommandlistener.sendMessage("   deop <player>             removes op status from a player");
        icommandlistener.sendMessage("   tp <player1> <player2>    moves one player to the same location as another player");
        icommandlistener.sendMessage("   give <player> <id> [num]  gives a player a resource");
        icommandlistener.sendMessage("   tell <player> <message>   sends a private message to a player");
        icommandlistener.sendMessage("   stop                      gracefully stops the server");
        icommandlistener.sendMessage("   save-all                  forces a server-wide level save");
        icommandlistener.sendMessage("   save-off                  disables terrain saving (useful for backup scripts)");
        icommandlistener.sendMessage("   save-on                   re-enables terrain saving");
        icommandlistener.sendMessage("   list                      lists all currently connected players");
        icommandlistener.sendMessage("   say <message>             broadcasts a message to all players");
        icommandlistener.sendMessage("   time <add|set> <amount>   adds to or sets the world time (0-24000)");
        icommandlistener.sendMessage("   gamemode <player> <mode>  sets player's game mode (0 or 1)");
        icommandlistener.sendMessage("   toggledownfall            toggles rain on or off");
        icommandlistener.sendMessage("   xp <player> <amount>      gives the player the amount of xp (0-5000)");
    }

    private void print(String s, String s1)
    {
        String s2 = (new StringBuilder()).append(s).append(": ").append(s1).toString();
        server.serverConfigurationManager.j((new StringBuilder()).append("\2477(").append(s2).append(")").toString());
        a.info(s2);
    }

    private int a(String s, int i)
    {
        try
        {
            return Integer.parseInt(s);
        }
        catch(NumberFormatException numberformatexception)
        {
            return i;
        }
    }

    private String a(String as[], String s)
    {
        int i = as.length;
        if(0 == i)
            return "";
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(as[0]);
        for(int j = 1; j < i; j++)
            stringbuilder.append(s).append(as[j]);

        return stringbuilder.toString();
    }

    private static Logger a = Logger.getLogger("Minecraft");
    private MinecraftServer server;

}
