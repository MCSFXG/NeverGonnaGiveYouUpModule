// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityIronGolem.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.inventory.CraftItemStack;

// Referenced classes of package net.minecraft.server:
//            EntityGolem, PathfinderGoalMeleeAttack, PathfinderGoalMoveTowardsTarget, PathfinderGoalMoveThroughVillage, 
//            PathfinderGoalMoveTowardsRestriction, PathfinderGoalOfferFlower, PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, 
//            EntityHuman, PathfinderGoalRandomLookaround, PathfinderGoalDefendVillage, PathfinderGoalHurtByTarget, 
//            PathfinderGoalNearestAttackableTarget, EntityMonster, Navigation, PathfinderGoalSelector, 
//            DataWatcher, World, MathHelper, VillageCollection, 
//            Village, ChunkCoordinates, AxisAlignedBB, NBTTagCompound, 
//            DamageSource, Entity, Block, BlockFlower, 
//            Item

public class EntityIronGolem extends EntityGolem
{

    public EntityIronGolem(World world)
    {
        super(world);
        b = 0;
        a = null;
        texture = "/mob/villager_golem.png";
        b(1.4F, 2.9F);
        al().a(true);
        goalSelector.a(1, new PathfinderGoalMeleeAttack(this, 0.25F, true));
        goalSelector.a(2, new PathfinderGoalMoveTowardsTarget(this, 0.22F, 32F));
        goalSelector.a(3, new PathfinderGoalMoveThroughVillage(this, 0.16F, true));
        goalSelector.a(4, new PathfinderGoalMoveTowardsRestriction(this, 0.16F));
        goalSelector.a(5, new PathfinderGoalOfferFlower(this));
        goalSelector.a(6, new PathfinderGoalRandomStroll(this, 0.16F));
        goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 6F));
        goalSelector.a(8, new PathfinderGoalRandomLookaround(this));
        targetSelector.a(1, new PathfinderGoalDefendVillage(this));
        targetSelector.a(2, new PathfinderGoalHurtByTarget(this, false));
        targetSelector.a(3, new PathfinderGoalNearestAttackableTarget(this, net/minecraft/server/EntityMonster, 16F, 0, false, true));
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
    }

    public boolean c_()
    {
        return true;
    }

    protected void g()
    {
        if(--b <= 0)
        {
            b = 70 + random.nextInt(50);
            a = world.villages.getClosestVillage(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ), 32);
            if(a == null)
            {
                ax();
            } else
            {
                ChunkCoordinates chunkcoordinates = a.getCenter();
                b(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, a.getSize());
            }
        }
        super.g();
    }

    public int getMaxHealth()
    {
        return 100;
    }

    protected int b_(int i)
    {
        return i;
    }

    public void e()
    {
        super.e();
        if(c > 0)
            c--;
        if(g > 0)
            g--;
        if(motX * motX + motZ * motZ > 2.5000002779052011E-007D && random.nextInt(5) == 0)
        {
            int i = MathHelper.floor(locX);
            int j = MathHelper.floor(locY - 0.20000000298023224D - (double)height);
            int k = MathHelper.floor(locZ);
            int l = world.getTypeId(i, j, k);
            if(l > 0)
                world.a((new StringBuilder()).append("tilecrack_").append(l).toString(), locX + ((double)random.nextFloat() - 0.5D) * (double)width, boundingBox.b + 0.10000000000000001D, locZ + ((double)random.nextFloat() - 0.5D) * (double)width, 4D * ((double)random.nextFloat() - 0.5D), 0.5D, ((double)random.nextFloat() - 0.5D) * 4D);
        }
    }

    public boolean a(Class oclass)
    {
        return !n_() || !net/minecraft/server/EntityHuman.isAssignableFrom(oclass) ? super.a(oclass) : false;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setBoolean("PlayerCreated", n_());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        b(nbttagcompound.getBoolean("PlayerCreated"));
    }

    public boolean a(Entity entity)
    {
        c = 10;
        world.broadcastEntityEffect(this, (byte)4);
        boolean flag = entity.damageEntity(DamageSource.mobAttack(this), 7 + random.nextInt(15));
        if(flag)
            entity.motY += 0.40000000596046448D;
        world.makeSound(this, "mob.irongolem.throw", 1.0F, 1.0F);
        return flag;
    }

    public Village l_()
    {
        return a;
    }

    public void a(boolean flag)
    {
        g = flag ? 400 : 0;
        world.broadcastEntityEffect(this, (byte)11);
    }

    protected String i()
    {
        return "none";
    }

    protected String j()
    {
        return "mob.irongolem.hit";
    }

    protected String k()
    {
        return "mob.irongolem.death";
    }

    protected void a(int i, int j, int k, int l)
    {
        world.makeSound(this, "mob.irongolem.walk", 1.0F, 1.0F);
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = random.nextInt(3);
        int k;
        for(k = 0; k < j; k++)
            loot.add(new CraftItemStack(Block.RED_ROSE.id, 1));

        k = 3 + random.nextInt(3);
        for(int l = 0; l < k; l++)
            loot.add(new CraftItemStack(Item.IRON_INGOT.id, 1));

        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public int m_()
    {
        return g;
    }

    public boolean n_()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    public void b(boolean flag)
    {
        byte b0 = datawatcher.getByte(16);
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)(b0 | 1)));
        else
            datawatcher.watch(16, Byte.valueOf((byte)(b0 & -2)));
    }

    private int b;
    Village a;
    private int c;
    private int g;
}
