// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Path, IntHashMap, PathPoint, Entity, 
//            AxisAlignedBB, MathHelper, IBlockAccess, Block, 
//            Material, PathEntity

public class Pathfinder
{

    public Pathfinder(IBlockAccess iblockaccess, boolean flag, boolean flag1, boolean flag2, boolean flag3)
    {
        b = new Path();
        c = new IntHashMap();
        d = new PathPoint[32];
        a = iblockaccess;
        e = flag;
        f = flag1;
        g = flag2;
        h = flag3;
    }

    public PathEntity a(Entity entity, Entity entity1, float f1)
    {
        return a(entity, entity1.locX, entity1.boundingBox.b, entity1.locZ, f1);
    }

    public PathEntity a(Entity entity, int i, int j, int k, float f1)
    {
        return a(entity, (float)i + 0.5F, (float)j + 0.5F, (float)k + 0.5F, f1);
    }

    private PathEntity a(Entity entity, double d1, double d2, double d3, 
            float f1)
    {
        b.a();
        c.a();
        boolean flag = g;
        int i = MathHelper.floor(entity.boundingBox.b + 0.5D);
        if(h && entity.aU())
        {
            i = (int)entity.boundingBox.b;
            for(int j = a.getTypeId(MathHelper.floor(entity.locX), i, MathHelper.floor(entity.locZ)); j == Block.WATER.id || j == Block.STATIONARY_WATER.id; j = a.getTypeId(MathHelper.floor(entity.locX), i, MathHelper.floor(entity.locZ)))
                i++;

            flag = g;
            g = false;
        } else
        {
            i = MathHelper.floor(entity.boundingBox.b + 0.5D);
        }
        PathPoint pathpoint = a(MathHelper.floor(entity.boundingBox.a), i, MathHelper.floor(entity.boundingBox.c));
        PathPoint pathpoint1 = a(MathHelper.floor(d1 - (double)(entity.width / 2.0F)), MathHelper.floor(d2), MathHelper.floor(d3 - (double)(entity.width / 2.0F)));
        PathPoint pathpoint2 = new PathPoint(MathHelper.d(entity.width + 1.0F), MathHelper.d(entity.length + 1.0F), MathHelper.d(entity.width + 1.0F));
        PathEntity pathentity = a(entity, pathpoint, pathpoint1, pathpoint2, f1);
        g = flag;
        return pathentity;
    }

    private PathEntity a(Entity entity, PathPoint pathpoint, PathPoint pathpoint1, PathPoint pathpoint2, float f1)
    {
        pathpoint.e = 0.0F;
        pathpoint.f = pathpoint.a(pathpoint1);
        pathpoint.g = pathpoint.f;
        b.a();
        b.a(pathpoint);
        PathPoint pathpoint3 = pathpoint;
        while(!b.c()) 
        {
            PathPoint pathpoint4 = b.b();
            if(pathpoint4.equals(pathpoint1))
                return a(pathpoint, pathpoint1);
            if(pathpoint4.a(pathpoint1) < pathpoint3.a(pathpoint1))
                pathpoint3 = pathpoint4;
            pathpoint4.i = true;
            int i = b(entity, pathpoint4, pathpoint2, pathpoint1, f1);
            int j = 0;
            while(j < i) 
            {
                PathPoint pathpoint5 = d[j];
                float f2 = pathpoint4.e + pathpoint4.a(pathpoint5);
                if(!pathpoint5.a() || f2 < pathpoint5.e)
                {
                    pathpoint5.h = pathpoint4;
                    pathpoint5.e = f2;
                    pathpoint5.f = pathpoint5.a(pathpoint1);
                    if(pathpoint5.a())
                    {
                        b.a(pathpoint5, pathpoint5.e + pathpoint5.f);
                    } else
                    {
                        pathpoint5.g = pathpoint5.e + pathpoint5.f;
                        b.a(pathpoint5);
                    }
                }
                j++;
            }
        }
        if(pathpoint3 == pathpoint)
            return null;
        else
            return a(pathpoint, pathpoint3);
    }

    private int b(Entity entity, PathPoint pathpoint, PathPoint pathpoint1, PathPoint pathpoint2, float f1)
    {
        int i = 0;
        int j = 0;
        if(a(entity, pathpoint.a, pathpoint.b + 1, pathpoint.c, pathpoint1) == 1)
            j = 1;
        PathPoint pathpoint3 = a(entity, pathpoint.a, pathpoint.b, pathpoint.c + 1, pathpoint1, j);
        PathPoint pathpoint4 = a(entity, pathpoint.a - 1, pathpoint.b, pathpoint.c, pathpoint1, j);
        PathPoint pathpoint5 = a(entity, pathpoint.a + 1, pathpoint.b, pathpoint.c, pathpoint1, j);
        PathPoint pathpoint6 = a(entity, pathpoint.a, pathpoint.b, pathpoint.c - 1, pathpoint1, j);
        if(pathpoint3 != null && !pathpoint3.i && pathpoint3.a(pathpoint2) < f1)
            d[i++] = pathpoint3;
        if(pathpoint4 != null && !pathpoint4.i && pathpoint4.a(pathpoint2) < f1)
            d[i++] = pathpoint4;
        if(pathpoint5 != null && !pathpoint5.i && pathpoint5.a(pathpoint2) < f1)
            d[i++] = pathpoint5;
        if(pathpoint6 != null && !pathpoint6.i && pathpoint6.a(pathpoint2) < f1)
            d[i++] = pathpoint6;
        return i;
    }

    private PathPoint a(Entity entity, int i, int j, int k, PathPoint pathpoint, int l)
    {
        PathPoint pathpoint1 = null;
        int i1 = a(entity, i, j, k, pathpoint);
        if(i1 == 2)
            return a(i, j, k);
        if(i1 == 1)
            pathpoint1 = a(i, j, k);
        if(pathpoint1 == null && l > 0 && i1 != -3 && i1 != -4 && a(entity, i, j + l, k, pathpoint) == 1)
        {
            pathpoint1 = a(i, j + l, k);
            j += l;
        }
        if(pathpoint1 != null)
        {
            int j1 = 0;
            int k1 = 0;
            do
            {
                if(j <= 0)
                    break;
                k1 = a(entity, i, j - 1, k, pathpoint);
                if(g && k1 == -1)
                    return null;
                if(k1 != 1)
                    break;
                if(++j1 >= 4)
                    return null;
                if(--j > 0)
                    pathpoint1 = a(i, j, k);
            } while(true);
            if(k1 == -2)
                return null;
        }
        return pathpoint1;
    }

    private final PathPoint a(int i, int j, int k)
    {
        int l = PathPoint.a(i, j, k);
        PathPoint pathpoint = (PathPoint)c.get(l);
        if(pathpoint == null)
        {
            pathpoint = new PathPoint(i, j, k);
            c.a(l, pathpoint);
        }
        return pathpoint;
    }

    private int a(Entity entity, int i, int j, int k, PathPoint pathpoint)
    {
        boolean flag = false;
        for(int l = i; l < i + pathpoint.a; l++)
        {
            for(int i1 = j; i1 < j + pathpoint.b; i1++)
            {
                for(int j1 = k; j1 < k + pathpoint.c; j1++)
                {
                    int k1 = a.getTypeId(l, i1, j1);
                    if(k1 <= 0)
                        continue;
                    if(k1 == Block.TRAP_DOOR.id)
                        flag = true;
                    else
                    if(k1 == Block.WATER.id || k1 == Block.STATIONARY_WATER.id)
                    {
                        if(!g)
                            flag = true;
                        else
                            return -1;
                    } else
                    if(!e && k1 == Block.WOODEN_DOOR.id)
                        return 0;
                    Block block = Block.byId[k1];
                    if(block.b(a, l, i1, j1) || f && k1 == Block.WOODEN_DOOR.id)
                        continue;
                    if(k1 == Block.FENCE.id || k1 == Block.FENCE_GATE.id)
                        return -3;
                    if(k1 == Block.TRAP_DOOR.id)
                        return -4;
                    Material material = block.material;
                    if(material == Material.LAVA)
                    {
                        if(!entity.aV())
                            return -2;
                    } else
                    {
                        return 0;
                    }
                }

            }

        }

        return flag ? 2 : 1;
    }

    private PathEntity a(PathPoint pathpoint, PathPoint pathpoint1)
    {
        int i = 1;
        for(PathPoint pathpoint2 = pathpoint1; pathpoint2.h != null; pathpoint2 = pathpoint2.h)
            i++;

        PathPoint apathpoint[] = new PathPoint[i];
        PathPoint pathpoint3 = pathpoint1;
        for(apathpoint[--i] = pathpoint3; pathpoint3.h != null; apathpoint[--i] = pathpoint3)
            pathpoint3 = pathpoint3.h;

        return new PathEntity(apathpoint);
    }

    private IBlockAccess a;
    private Path b;
    private IntHashMap c;
    private PathPoint d[];
    private boolean e;
    private boolean f;
    private boolean g;
    private boolean h;
}
