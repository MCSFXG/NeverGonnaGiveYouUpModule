// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Entity, MathHelper, World, EntityItem, 
//            ItemStack, Item, NBTTagCompound, EntityHuman

public class EntityEnderSignal extends Entity
{

    public EntityEnderSignal(World world)
    {
        super(world);
        a = 0;
        b(0.25F, 0.25F);
    }

    protected void b()
    {
    }

    public EntityEnderSignal(World world, double d1, double d2, double d3)
    {
        super(world);
        a = 0;
        e = 0;
        b(0.25F, 0.25F);
        setPosition(d1, d2, d3);
        height = 0.0F;
    }

    public void a(double d1, int i, double d2)
    {
        double d3 = d1 - locX;
        double d4 = d2 - locZ;
        float f1 = MathHelper.sqrt(d3 * d3 + d4 * d4);
        if(f1 > 12F)
        {
            b = locX + (d3 / (double)f1) * 12D;
            d = locZ + (d4 / (double)f1) * 12D;
            c = locY + 8D;
        } else
        {
            b = d1;
            c = i;
            d = d2;
        }
        e = 0;
        f = random.nextInt(5) > 0;
    }

    public void F_()
    {
        bL = locX;
        bM = locY;
        bN = locZ;
        super.F_();
        locX += motX;
        locY += motY;
        locZ += motZ;
        float f1 = MathHelper.sqrt(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for(pitch = (float)((Math.atan2(motY, f1) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F);
        for(; pitch - lastPitch >= 180F; lastPitch += 360F);
        for(; yaw - lastYaw < -180F; lastYaw -= 360F);
        for(; yaw - lastYaw >= 180F; lastYaw += 360F);
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        if(!world.isStatic)
        {
            double d1 = b - locX;
            double d2 = d - locZ;
            float f2 = (float)Math.sqrt(d1 * d1 + d2 * d2);
            float f3 = (float)Math.atan2(d2, d1);
            double d3 = (double)f1 + (double)(f2 - f1) * 0.0025000000000000001D;
            if(f2 < 1.0F)
            {
                d3 *= 0.80000000000000004D;
                motY *= 0.80000000000000004D;
            }
            motX = Math.cos(f3) * d3;
            motZ = Math.sin(f3) * d3;
            if(locY < c)
                motY = motY + (1.0D - motY) * 0.014999999664723873D;
            else
                motY = motY + (-1D - motY) * 0.014999999664723873D;
        }
        float f4 = 0.25F;
        if(aU())
        {
            for(int i = 0; i < 4; i++)
                world.a("bubble", locX - motX * (double)f4, locY - motY * (double)f4, locZ - motZ * (double)f4, motX, motY, motZ);

        } else
        {
            world.a("portal", ((locX - motX * (double)f4) + random.nextDouble() * 0.59999999999999998D) - 0.29999999999999999D, locY - motY * (double)f4 - 0.5D, ((locZ - motZ * (double)f4) + random.nextDouble() * 0.59999999999999998D) - 0.29999999999999999D, motX, motY, motZ);
        }
        if(!world.isStatic)
        {
            setPosition(locX, locY, locZ);
            e++;
            if(e > 80 && !world.isStatic)
            {
                die();
                if(f)
                    world.addEntity(new EntityItem(world, locX, locY, locZ, new ItemStack(Item.EYE_OF_ENDER)));
                else
                    world.triggerEffect(2003, (int)Math.round(locX), (int)Math.round(locY), (int)Math.round(locZ), 0);
            }
        }
    }

    public void b(NBTTagCompound nbttagcompound)
    {
    }

    public void a(NBTTagCompound nbttagcompound)
    {
    }

    public void a_(EntityHuman entityhuman)
    {
    }

    public float b(float f1)
    {
        return 1.0F;
    }

    public boolean k_()
    {
        return false;
    }

    public int a;
    private double b;
    private double c;
    private double d;
    private int e;
    private boolean f;
}
