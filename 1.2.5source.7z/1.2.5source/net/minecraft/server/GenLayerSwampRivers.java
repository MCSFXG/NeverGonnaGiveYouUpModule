// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            GenLayer, IntCache, BiomeBase

public class GenLayerSwampRivers extends GenLayer
{

    public GenLayerSwampRivers(long l, GenLayer genlayer)
    {
        super(l);
        a = genlayer;
    }

    public int[] a(int i, int j, int k, int l)
    {
        int ai[] = a.a(i - 1, j - 1, k + 2, l + 2);
        int ai1[] = IntCache.a(k * l);
        for(int i1 = 0; i1 < l; i1++)
        {
            for(int j1 = 0; j1 < k; j1++)
            {
                a(j1 + i, i1 + j);
                int k1 = ai[j1 + 1 + (i1 + 1) * (k + 2)];
                if(k1 == BiomeBase.SWAMPLAND.id && a(6) == 0)
                {
                    ai1[j1 + i1 * k] = BiomeBase.RIVER.id;
                    continue;
                }
                if((k1 == BiomeBase.JUNGLE.id || k1 == BiomeBase.JUNGLE_HILLS.id) && a(8) == 0)
                    ai1[j1 + i1 * k] = BiomeBase.RIVER.id;
                else
                    ai1[j1 + i1 * k] = k1;
            }

        }

        return ai1;
    }
}
