// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTTagEnd, NBTTagByte, NBTTagShort, NBTTagInt, 
//            NBTTagLong, NBTTagFloat, NBTTagDouble, NBTTagByteArray, 
//            NBTTagIntArray, NBTTagString, NBTTagList, NBTTagCompound

public abstract class NBTBase
{

    abstract void write(DataOutput dataoutput);

    abstract void load(DataInput datainput);

    public abstract byte getTypeId();

    protected NBTBase(String s)
    {
        if(s == null)
            name = "";
        else
            name = s;
    }

    public NBTBase setName(String s)
    {
        if(s == null)
            name = "";
        else
            name = s;
        return this;
    }

    public String getName()
    {
        if(name == null)
            return "";
        else
            return name;
    }

    public static NBTBase b(DataInput datainput)
    {
        byte byte0 = datainput.readByte();
        if(byte0 == 0)
        {
            return new NBTTagEnd();
        } else
        {
            String s = datainput.readUTF();
            NBTBase nbtbase = createTag(byte0, s);
            nbtbase.load(datainput);
            return nbtbase;
        }
    }

    public static void a(NBTBase nbtbase, DataOutput dataoutput)
    {
        dataoutput.writeByte(nbtbase.getTypeId());
        if(nbtbase.getTypeId() == 0)
        {
            return;
        } else
        {
            dataoutput.writeUTF(nbtbase.getName());
            nbtbase.write(dataoutput);
            return;
        }
    }

    public static NBTBase createTag(byte byte0, String s)
    {
        switch(byte0)
        {
        case 0: // '\0'
            return new NBTTagEnd();

        case 1: // '\001'
            return new NBTTagByte(s);

        case 2: // '\002'
            return new NBTTagShort(s);

        case 3: // '\003'
            return new NBTTagInt(s);

        case 4: // '\004'
            return new NBTTagLong(s);

        case 5: // '\005'
            return new NBTTagFloat(s);

        case 6: // '\006'
            return new NBTTagDouble(s);

        case 7: // '\007'
            return new NBTTagByteArray(s);

        case 11: // '\013'
            return new NBTTagIntArray(s);

        case 8: // '\b'
            return new NBTTagString(s);

        case 9: // '\t'
            return new NBTTagList(s);

        case 10: // '\n'
            return new NBTTagCompound(s);
        }
        return null;
    }

    public static String getTagName(byte byte0)
    {
        switch(byte0)
        {
        case 0: // '\0'
            return "TAG_End";

        case 1: // '\001'
            return "TAG_Byte";

        case 2: // '\002'
            return "TAG_Short";

        case 3: // '\003'
            return "TAG_Int";

        case 4: // '\004'
            return "TAG_Long";

        case 5: // '\005'
            return "TAG_Float";

        case 6: // '\006'
            return "TAG_Double";

        case 7: // '\007'
            return "TAG_Byte_Array";

        case 11: // '\013'
            return "TAG_Int_Array";

        case 8: // '\b'
            return "TAG_String";

        case 9: // '\t'
            return "TAG_List";

        case 10: // '\n'
            return "TAG_Compound";
        }
        return "UNKNOWN";
    }

    public abstract NBTBase clone();

    public boolean equals(Object obj)
    {
        if(obj == null || !(obj instanceof NBTBase))
            return false;
        NBTBase nbtbase = (NBTBase)obj;
        if(getTypeId() != nbtbase.getTypeId())
            return false;
        if(name == null && nbtbase.name != null || name != null && nbtbase.name == null)
            return false;
        return name == null || name.equals(nbtbase.name);
    }

    public int hashCode()
    {
        return name.hashCode() ^ getTypeId();
    }

    private String name;
}
