// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathPoint, Entity, Vec3D

public class PathEntity
{

    public PathEntity(PathPoint apathpoint[])
    {
        a = apathpoint;
        c = apathpoint.length;
    }

    public void a()
    {
        b++;
    }

    public boolean b()
    {
        return b >= c;
    }

    public PathPoint c()
    {
        if(c > 0)
            return a[c - 1];
        else
            return null;
    }

    public PathPoint a(int i)
    {
        return a[i];
    }

    public int d()
    {
        return c;
    }

    public void b(int i)
    {
        c = i;
    }

    public int e()
    {
        return b;
    }

    public void c(int i)
    {
        b = i;
    }

    public Vec3D a(Entity entity, int i)
    {
        double d1 = (double)a[i].a + (double)(int)(entity.width + 1.0F) * 0.5D;
        double d2 = a[i].b;
        double d3 = (double)a[i].c + (double)(int)(entity.width + 1.0F) * 0.5D;
        return Vec3D.create(d1, d2, d3);
    }

    public Vec3D a(Entity entity)
    {
        return a(entity, b);
    }

    public boolean a(PathEntity pathentity)
    {
        if(pathentity == null)
            return false;
        if(pathentity.a.length != a.length)
            return false;
        for(int i = 0; i < a.length; i++)
            if(a[i].a != pathentity.a[i].a || a[i].b != pathentity.a[i].b || a[i].c != pathentity.a[i].c)
                return false;

        return true;
    }

    public boolean a(Vec3D vec3d)
    {
        PathPoint pathpoint = c();
        if(pathpoint == null)
            return false;
        else
            return pathpoint.a == (int)vec3d.a && pathpoint.c == (int)vec3d.c;
    }

    private final PathPoint a[];
    private int b;
    private int c;
}
