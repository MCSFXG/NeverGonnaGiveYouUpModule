// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            WorldProvider, WorldChunkManagerHell, BiomeBase, ChunkProviderTheEnd, 
//            World, Block, Material, ChunkCoordinates, 
//            IChunkProvider

public class WorldProviderTheEnd extends WorldProvider
{

    public WorldProviderTheEnd()
    {
    }

    public void a()
    {
        c = new WorldChunkManagerHell(BiomeBase.SKY, 0.5F, 0.0F);
        dimension = 1;
        e = true;
    }

    public IChunkProvider getChunkProvider()
    {
        return new ChunkProviderTheEnd(a, a.getSeed());
    }

    public float a(long l, float f)
    {
        return 0.0F;
    }

    public boolean c()
    {
        return false;
    }

    public boolean d()
    {
        return false;
    }

    public boolean canSpawn(int i, int j)
    {
        int k = a.b(i, j);
        if(k == 0)
            return false;
        else
            return Block.byId[k].material.isSolid();
    }

    public ChunkCoordinates e()
    {
        return new ChunkCoordinates(100, 50, 0);
    }

    public int getSeaLevel()
    {
        return 50;
    }
}
