// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockFire.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.block.*;
import org.bukkit.material.MaterialData;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Block, WorldProviderTheEnd, Material, BlockLeaves, 
//            BlockLongGrass, World, IBlockAccess, WorldProvider, 
//            BlockPortal, AxisAlignedBB

public class BlockFire extends net.minecraft.server.Block
{

    protected BlockFire(int i, int j)
    {
        super(i, j, Material.FIRE);
        a = new int[256];
        b = new int[256];
        a(true);
    }

    public void k()
    {
        a(Block.WOOD.id, 5, 20);
        a(Block.FENCE.id, 5, 20);
        a(Block.WOOD_STAIRS.id, 5, 20);
        a(Block.LOG.id, 5, 5);
        a(Block.LEAVES.id, 30, 60);
        a(Block.BOOKSHELF.id, 30, 20);
        a(Block.TNT.id, 15, 100);
        a(Block.LONG_GRASS.id, 60, 100);
        a(Block.WOOL.id, 30, 60);
        a(Block.VINE.id, 15, 100);
    }

    private void a(int i, int j, int k)
    {
        a[i] = j;
        b[i] = k;
    }

    public AxisAlignedBB e(net.minecraft.server.World world, int i, int j, int l)
    {
        return null;
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public int c()
    {
        return 3;
    }

    public int a(Random random)
    {
        return 0;
    }

    public int d()
    {
        return 30;
    }

    public void a(net.minecraft.server.World world, int i, int j, int k, Random random)
    {
        boolean flag = world.getTypeId(i, j - 1, k) == Block.NETHERRACK.id;
        if((world.worldProvider instanceof WorldProviderTheEnd) && world.getTypeId(i, j - 1, k) == Block.BEDROCK.id)
            flag = true;
        if(!canPlace(world, i, j, k))
            fireExtinguished(world, i, j, k);
        if(!flag && world.x() && (world.y(i, j, k) || world.y(i - 1, j, k) || world.y(i + 1, j, k) || world.y(i, j, k - 1) || world.y(i, j, k + 1)))
        {
            fireExtinguished(world, i, j, k);
        } else
        {
            int l = world.getData(i, j, k);
            if(l < 15)
                world.setRawData(i, j, k, l + random.nextInt(3) / 2);
            world.c(i, j, k, id, d() + random.nextInt(10));
            if(!flag && !g(world, i, j, k))
            {
                if(!world.e(i, j - 1, k) || l > 3)
                    fireExtinguished(world, i, j, k);
            } else
            if(!flag && !c(world, i, j - 1, k) && l == 15 && random.nextInt(4) == 0)
            {
                fireExtinguished(world, i, j, k);
            } else
            {
                boolean flag1 = world.z(i, j, k);
                byte b0 = 0;
                if(flag1)
                    b0 = -50;
                a(world, i + 1, j, k, 300 + b0, random, l);
                a(world, i - 1, j, k, 300 + b0, random, l);
                a(world, i, j - 1, k, 250 + b0, random, l);
                a(world, i, j + 1, k, 250 + b0, random, l);
                a(world, i, j, k - 1, 300 + b0, random, l);
                a(world, i, j, k + 1, 300 + b0, random, l);
                Server server = world.getServer();
                World bworld = world.getWorld();
                org.bukkit.event.block.BlockIgniteEvent.IgniteCause igniteCause = org.bukkit.event.block.BlockIgniteEvent.IgniteCause.SPREAD;
                Block fromBlock = bworld.getBlockAt(i, j, k);
                for(int i1 = i - 1; i1 <= i + 1; i1++)
                {
                    for(int j1 = k - 1; j1 <= k + 1; j1++)
                    {
                        for(int k1 = j - 1; k1 <= j + 4; k1++)
                        {
                            if(i1 == i && k1 == j && j1 == k)
                                continue;
                            int l1 = 100;
                            if(k1 > j + 1)
                                l1 += (k1 - (j + 1)) * 100;
                            int i2 = h(world, i1, k1, j1);
                            if(i2 <= 0)
                                continue;
                            int j2 = (i2 + 40) / (l + 30);
                            if(flag1)
                                j2 /= 2;
                            if(j2 <= 0 || random.nextInt(l1) > j2 || world.x() && world.y(i1, k1, j1) || world.y(i1 - 1, k1, k) || world.y(i1 + 1, k1, j1) || world.y(i1, k1, j1 - 1) || world.y(i1, k1, j1 + 1))
                                continue;
                            int k2 = l + random.nextInt(5) / 4;
                            if(k2 > 15)
                                k2 = 15;
                            Block block = bworld.getBlockAt(i1, k1, j1);
                            if(block.getTypeId() == Block.FIRE.id)
                                continue;
                            BlockIgniteEvent event = new BlockIgniteEvent(block, igniteCause, null);
                            server.getPluginManager().callEvent(event);
                            if(event.isCancelled())
                                continue;
                            BlockState blockState = bworld.getBlockAt(i1, k1, j1).getState();
                            blockState.setTypeId(id);
                            blockState.setData(new MaterialData(id, (byte)k2));
                            BlockSpreadEvent spreadEvent = new BlockSpreadEvent(blockState.getBlock(), fromBlock, blockState);
                            server.getPluginManager().callEvent(spreadEvent);
                            if(!spreadEvent.isCancelled())
                                blockState.update(true);
                        }

                    }

                }

            }
        }
    }

    private void a(net.minecraft.server.World world, int i, int j, int k, int l, Random random, int i1)
    {
        int j1 = b[world.getTypeId(i, j, k)];
        if(random.nextInt(l) < j1)
        {
            boolean flag = world.getTypeId(i, j, k) == Block.TNT.id;
            Block theBlock = world.getWorld().getBlockAt(i, j, k);
            BlockBurnEvent event = new BlockBurnEvent(theBlock);
            world.getServer().getPluginManager().callEvent(event);
            if(event.isCancelled())
                return;
            if(random.nextInt(i1 + 10) < 5 && !world.y(i, j, k))
            {
                int k1 = i1 + random.nextInt(5) / 4;
                if(k1 > 15)
                    k1 = 15;
                world.setTypeIdAndData(i, j, k, id, k1);
            } else
            {
                world.setTypeId(i, j, k, 0);
            }
            if(flag)
                Block.TNT.postBreak(world, i, j, k, 1);
        }
    }

    private boolean g(net.minecraft.server.World world, int i, int j, int k)
    {
        return c(world, i + 1, j, k) ? true : c(world, i - 1, j, k) ? true : c(world, i, j - 1, k) ? true : c(world, i, j + 1, k) ? true : c(world, i, j, k - 1) ? true : c(world, i, j, k + 1);
    }

    private int h(net.minecraft.server.World world, int i, int j, int k)
    {
        byte b0 = 0;
        if(!world.isEmpty(i, j, k))
        {
            return 0;
        } else
        {
            int l = f(world, i + 1, j, k, b0);
            l = f(world, i - 1, j, k, l);
            l = f(world, i, j - 1, k, l);
            l = f(world, i, j + 1, k, l);
            l = f(world, i, j, k - 1, l);
            l = f(world, i, j, k + 1, l);
            return l;
        }
    }

    public boolean E_()
    {
        return false;
    }

    public boolean c(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return a[iblockaccess.getTypeId(i, j, k)] > 0;
    }

    public int f(net.minecraft.server.World world, int i, int j, int k, int l)
    {
        int i1 = a[world.getTypeId(i, j, k)];
        return i1 <= l ? l : i1;
    }

    public boolean canPlace(net.minecraft.server.World world, int i, int j, int k)
    {
        return world.e(i, j - 1, k) || g(world, i, j, k);
    }

    public void doPhysics(net.minecraft.server.World world, int i, int j, int k, int l)
    {
        if(!world.e(i, j - 1, k) && !g(world, i, j, k))
            fireExtinguished(world, i, j, k);
    }

    public void onPlace(net.minecraft.server.World world, int i, int j, int k)
    {
        if(world.worldProvider.dimension > 0 || world.getTypeId(i, j - 1, k) != Block.OBSIDIAN.id || !Block.PORTAL.b_(world, i, j, k))
            if(!world.e(i, j - 1, k) && !g(world, i, j, k))
                fireExtinguished(world, i, j, k);
            else
                world.c(i, j, k, id, d() + world.random.nextInt(10));
    }

    private void fireExtinguished(net.minecraft.server.World world, int x, int y, int z)
    {
        if(!CraftEventFactory.callBlockFadeEvent(world.getWorld().getBlockAt(x, y, z), 0).isCancelled())
            world.setTypeId(x, y, z, 0);
    }

    private int a[];
    private int b[];
}
