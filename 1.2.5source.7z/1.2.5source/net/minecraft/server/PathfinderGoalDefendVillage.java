// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoalTarget, EntityIronGolem, Village, EntityLiving

public class PathfinderGoalDefendVillage extends PathfinderGoalTarget
{

    public PathfinderGoalDefendVillage(EntityIronGolem entityirongolem)
    {
        super(entityirongolem, 16F, false, true);
        a = entityirongolem;
        a(1);
    }

    public boolean a()
    {
        Village village = a.l_();
        if(village == null)
        {
            return false;
        } else
        {
            b = village.b(a);
            return a(b, false);
        }
    }

    public void c()
    {
        a.b(b);
        super.c();
    }

    EntityIronGolem a;
    EntityLiving b;
}
