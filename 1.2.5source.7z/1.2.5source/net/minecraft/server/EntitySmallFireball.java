// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySmallFireball.java

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.entity.Projectile;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityFireball, World, MovingObjectPosition, Entity, 
//            DamageSource, Block, BlockFire, EntityLiving

public class EntitySmallFireball extends EntityFireball
{

    public EntitySmallFireball(World world)
    {
        super(world);
        b(0.3125F, 0.3125F);
    }

    public EntitySmallFireball(World world, EntityLiving entityliving, double d0, double d1, double d2)
    {
        super(world, entityliving, d0, d1, d2);
        b(0.3125F, 0.3125F);
    }

    public EntitySmallFireball(World world, double d0, double d1, double d2, 
            double d3, double d4, double d5)
    {
        super(world, d0, d1, d2, d3, d4, d5);
        b(0.3125F, 0.3125F);
    }

    protected void a(MovingObjectPosition movingobjectposition)
    {
        if(!world.isStatic)
        {
            if(movingobjectposition.entity != null)
            {
                if(!movingobjectposition.entity.isFireproof() && movingobjectposition.entity.damageEntity(DamageSource.fireball(this, shooter), 5))
                {
                    EntityCombustByEntityEvent event = new EntityCombustByEntityEvent((Projectile)getBukkitEntity(), movingobjectposition.entity.getBukkitEntity(), 5);
                    movingobjectposition.entity.world.getServer().getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                        movingobjectposition.entity.setOnFire(event.getDuration());
                }
            } else
            {
                int i = movingobjectposition.b;
                int j = movingobjectposition.c;
                int k = movingobjectposition.d;
                switch(movingobjectposition.face)
                {
                case 0: // '\0'
                    j--;
                    break;

                case 1: // '\001'
                    j++;
                    break;

                case 2: // '\002'
                    k--;
                    break;

                case 3: // '\003'
                    k++;
                    break;

                case 4: // '\004'
                    i--;
                    break;

                case 5: // '\005'
                    i++;
                    break;
                }
                if(world.isEmpty(i, j, k))
                {
                    org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
                    BlockIgniteEvent event = new BlockIgniteEvent(block, org.bukkit.event.block.BlockIgniteEvent.IgniteCause.FIREBALL, null);
                    world.getServer().getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                        world.setTypeId(i, j, k, Block.FIRE.id);
                }
            }
            die();
        }
    }

    public boolean o_()
    {
        return false;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        return false;
    }
}
