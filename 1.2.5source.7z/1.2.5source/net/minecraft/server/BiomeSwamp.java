// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BiomeBase, BiomeDecorator, WorldGenerator

public class BiomeSwamp extends BiomeBase
{

    protected BiomeSwamp(int i)
    {
        super(i);
        I.z = 2;
        I.A = -999;
        I.C = 1;
        I.D = 8;
        I.E = 10;
        I.I = 1;
        I.y = 4;
        H = 0xe0ffae;
    }

    public WorldGenerator a(Random random)
    {
        return Q;
    }
}
