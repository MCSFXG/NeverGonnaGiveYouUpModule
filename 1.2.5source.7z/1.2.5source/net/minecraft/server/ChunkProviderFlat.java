// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            IChunkProvider, WorldGenVillage, Block, BlockGrass, 
//            Chunk, World, WorldChunkManager, BiomeBase, 
//            IProgressUpdate, EnumCreatureType, ChunkPosition

public class ChunkProviderFlat
    implements IChunkProvider
{

    public ChunkProviderFlat(World world, long l, boolean flag)
    {
        d = new WorldGenVillage(1);
        a = world;
        c = flag;
        b = new Random(l);
    }

    private void a(byte abyte0[])
    {
        int i = abyte0.length / 256;
        for(int j = 0; j < 16; j++)
        {
            for(int k = 0; k < 16; k++)
            {
                for(int l = 0; l < i; l++)
                {
                    int i1 = 0;
                    if(l == 0)
                        i1 = Block.BEDROCK.id;
                    else
                    if(l <= 2)
                        i1 = Block.DIRT.id;
                    else
                    if(l == 3)
                        i1 = Block.GRASS.id;
                    abyte0[j << 11 | k << 7 | l] = (byte)i1;
                }

            }

        }

    }

    public Chunk getChunkAt(int i, int j)
    {
        return getOrCreateChunk(i, j);
    }

    public Chunk getOrCreateChunk(int i, int j)
    {
        byte abyte0[] = new byte[32768];
        a(abyte0);
        Chunk chunk = new Chunk(a, abyte0, i, j);
        if(c)
            d.a(this, a, i, j, abyte0);
        BiomeBase abiomebase[] = a.getWorldChunkManager().getBiomeBlock(null, i * 16, j * 16, 16, 16);
        byte abyte1[] = chunk.l();
        for(int k = 0; k < abyte1.length; k++)
            abyte1[k] = (byte)abiomebase[k].id;

        chunk.initLighting();
        return chunk;
    }

    public boolean isChunkLoaded(int i, int j)
    {
        return true;
    }

    public void getChunkAt(IChunkProvider ichunkprovider, int i, int j)
    {
        b.setSeed(a.getSeed());
        long l = (b.nextLong() / 2L) * 2L + 1L;
        long l1 = (b.nextLong() / 2L) * 2L + 1L;
        b.setSeed((long)i * l + (long)j * l1 ^ a.getSeed());
        if(c)
            d.a(a, b, i, j);
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unloadChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public List getMobsFor(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        BiomeBase biomebase = a.getBiome(i, k);
        if(biomebase == null)
            return null;
        else
            return biomebase.getMobs(enumcreaturetype);
    }

    public ChunkPosition findNearestMapFeature(World world, String s, int i, int j, int k)
    {
        return null;
    }

    private World a;
    private Random b;
    private final boolean c;
    private WorldGenVillage d;
}
