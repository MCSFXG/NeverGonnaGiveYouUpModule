// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityAgeable, IAnimal, World, EntityHuman, 
//            Entity, Block, BlockGrass, NBTTagCompound, 
//            AxisAlignedBB, MathHelper, ItemStack, Item, 
//            PlayerInventory, PlayerAbilities, DamageSource

public abstract class EntityAnimal extends EntityAgeable
    implements IAnimal
{

    public EntityAnimal(World world)
    {
        super(world);
        b = 0;
    }

    protected void g()
    {
        if(getAge() != 0)
            love = 0;
        super.g();
    }

    public void e()
    {
        super.e();
        if(getAge() != 0)
            love = 0;
        if(love > 0)
        {
            love--;
            String s = "heart";
            if(love % 10 == 0)
            {
                double d = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                world.a(s, (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + 0.5D + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, d, d1, d2);
            }
        } else
        {
            b = 0;
        }
    }

    protected void a(Entity entity, float f)
    {
        if(entity instanceof EntityHuman)
        {
            if(f < 3F)
            {
                double d = entity.locX - locX;
                double d1 = entity.locZ - locZ;
                yaw = (float)((Math.atan2(d1, d) * 180D) / 3.1415927410125732D) - 90F;
                e = true;
            }
            EntityHuman entityhuman = (EntityHuman)entity;
            if(entityhuman.U() == null || !a(entityhuman.U()))
                target = null;
        } else
        if(entity instanceof EntityAnimal)
        {
            EntityAnimal entityanimal = (EntityAnimal)entity;
            if(getAge() > 0 && entityanimal.getAge() < 0)
            {
                if((double)f < 2.5D)
                    e = true;
            } else
            if(love > 0 && entityanimal.love > 0)
            {
                if(entityanimal.target == null)
                    entityanimal.target = this;
                if(entityanimal.target == this && (double)f < 3.5D)
                {
                    entityanimal.love++;
                    love++;
                    b++;
                    if(b % 4 == 0)
                        world.a("heart", (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + 0.5D + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, 0.0D, 0.0D, 0.0D);
                    if(b == 60)
                        c((EntityAnimal)entity);
                } else
                {
                    b = 0;
                }
            } else
            {
                b = 0;
                target = null;
            }
        }
    }

    private void c(EntityAnimal entityanimal)
    {
        EntityAnimal entityanimal1 = createChild(entityanimal);
        if(entityanimal1 != null)
        {
            setAge(6000);
            entityanimal.setAge(6000);
            love = 0;
            b = 0;
            target = null;
            entityanimal.target = null;
            entityanimal.b = 0;
            entityanimal.love = 0;
            entityanimal1.setAge(-24000);
            entityanimal1.setPositionRotation(locX, locY, locZ, yaw, pitch);
            for(int i = 0; i < 7; i++)
            {
                double d = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                world.a("heart", (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + 0.5D + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, d, d1, d2);
            }

            world.addEntity(entityanimal1);
        }
    }

    public abstract EntityAnimal createChild(EntityAnimal entityanimal);

    protected void b(Entity entity, float f)
    {
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        f = 60;
        target = null;
        love = 0;
        return super.damageEntity(damagesource, i);
    }

    public float a(int i, int j, int k)
    {
        if(world.getTypeId(i, j - 1, k) == Block.GRASS.id)
            return 10F;
        else
            return world.p(i, j, k) - 0.5F;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setInt("InLove", love);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        love = nbttagcompound.getInt("InLove");
    }

    protected Entity findTarget()
    {
        if(this.f > 0)
            return null;
        float f = 8F;
        if(love > 0)
        {
            List list = world.a(getClass(), boundingBox.grow(f, f, f));
            for(int i = 0; i < list.size(); i++)
            {
                EntityAnimal entityanimal = (EntityAnimal)list.get(i);
                if(entityanimal != this && entityanimal.love > 0)
                    return entityanimal;
            }

        } else
        if(getAge() == 0)
        {
            List list1 = world.a(net/minecraft/server/EntityHuman, boundingBox.grow(f, f, f));
            for(int j = 0; j < list1.size(); j++)
            {
                EntityHuman entityhuman = (EntityHuman)list1.get(j);
                if(entityhuman.U() != null && a(entityhuman.U()))
                    return entityhuman;
            }

        } else
        if(getAge() > 0)
        {
            List list2 = world.a(getClass(), boundingBox.grow(f, f, f));
            for(int k = 0; k < list2.size(); k++)
            {
                EntityAnimal entityanimal1 = (EntityAnimal)list2.get(k);
                if(entityanimal1 != this && entityanimal1.getAge() < 0)
                    return entityanimal1;
            }

        }
        return null;
    }

    public boolean canSpawn()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        return world.getTypeId(i, j - 1, k) == Block.GRASS.id && world.m(i, j, k) > 8 && super.canSpawn();
    }

    public int m()
    {
        return 120;
    }

    protected boolean n()
    {
        return false;
    }

    protected int getExpValue(EntityHuman entityhuman)
    {
        return 1 + world.random.nextInt(3);
    }

    public boolean a(ItemStack itemstack)
    {
        return itemstack.id == Item.WHEAT.id;
    }

    public boolean b(EntityHuman entityhuman)
    {
        ItemStack itemstack = entityhuman.inventory.getItemInHand();
        if(itemstack != null && a(itemstack) && getAge() == 0)
        {
            if(!entityhuman.abilities.canInstantlyBuild)
            {
                itemstack.count--;
                if(itemstack.count <= 0)
                    entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, null);
            }
            love = 600;
            target = null;
            for(int i = 0; i < 7; i++)
            {
                double d = random.nextGaussian() * 0.02D;
                double d1 = random.nextGaussian() * 0.02D;
                double d2 = random.nextGaussian() * 0.02D;
                world.a("heart", (locX + (double)(random.nextFloat() * width * 2.0F)) - (double)width, locY + 0.5D + (double)(random.nextFloat() * length), (locZ + (double)(random.nextFloat() * width * 2.0F)) - (double)width, d, d1, d2);
            }

            return true;
        } else
        {
            return super.b(entityhuman);
        }
    }

    public boolean r_()
    {
        return love > 0;
    }

    public void s_()
    {
        love = 0;
    }

    public boolean mate(EntityAnimal entityanimal)
    {
        if(entityanimal == this)
            return false;
        if(entityanimal.getClass() != getClass())
            return false;
        else
            return r_() && entityanimal.r_();
    }

    private int love;
    private int b;
}
