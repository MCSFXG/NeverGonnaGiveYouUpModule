// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagList extends NBTBase
{

    public NBTTagList()
    {
        super("");
        list = new ArrayList();
    }

    public NBTTagList(String s)
    {
        super(s);
        list = new ArrayList();
    }

    void write(DataOutput dataoutput)
    {
        if(list.size() > 0)
            type = ((NBTBase)list.get(0)).getTypeId();
        else
            type = 1;
        dataoutput.writeByte(type);
        dataoutput.writeInt(list.size());
        for(int i = 0; i < list.size(); i++)
            ((NBTBase)list.get(i)).write(dataoutput);

    }

    void load(DataInput datainput)
    {
        type = datainput.readByte();
        int i = datainput.readInt();
        list = new ArrayList();
        for(int j = 0; j < i; j++)
        {
            NBTBase nbtbase = NBTBase.createTag(type, null);
            nbtbase.load(datainput);
            list.add(nbtbase);
        }

    }

    public byte getTypeId()
    {
        return 9;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(list.size()).append(" entries of type ").append(NBTBase.getTagName(type)).toString();
    }

    public void add(NBTBase nbtbase)
    {
        type = nbtbase.getTypeId();
        list.add(nbtbase);
    }

    public NBTBase get(int i)
    {
        return (NBTBase)list.get(i);
    }

    public int size()
    {
        return list.size();
    }

    public NBTBase clone()
    {
        NBTTagList nbttaglist = new NBTTagList(getName());
        nbttaglist.type = type;
        NBTBase nbtbase1;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); nbttaglist.list.add(nbtbase1))
        {
            NBTBase nbtbase = (NBTBase)iterator.next();
            nbtbase1 = nbtbase.clone();
        }

        return nbttaglist;
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagList nbttaglist = (NBTTagList)obj;
            if(type == nbttaglist.type)
                return list.equals(nbttaglist.list);
        }
        return false;
    }

    public int hashCode()
    {
        return super.hashCode() ^ list.hashCode();
    }

    private List list;
    private byte type;
}
