// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public abstract class PathfinderGoal
{

    public PathfinderGoal()
    {
        a = 0;
    }

    public abstract boolean a();

    public boolean b()
    {
        return a();
    }

    public boolean g()
    {
        return true;
    }

    public void c()
    {
    }

    public void d()
    {
    }

    public void e()
    {
    }

    public void a(int i)
    {
        a = i;
    }

    public int h()
    {
        return a;
    }

    private int a;
}
