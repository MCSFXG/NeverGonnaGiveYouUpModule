// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenerator, World, Block, Direction, 
//            Facing

public class WorldGenVines extends WorldGenerator
{

    public WorldGenVines()
    {
    }

    public boolean a(World world, Random random, int i, int j, int k)
    {
        int l = i;
        int i1 = k;
label0:
        for(; j < 128; j++)
        {
            if(world.isEmpty(i, j, k))
            {
                int j1 = 2;
                do
                {
                    if(j1 > 5)
                        continue label0;
                    if(Block.VINE.canPlace(world, i, j, k, j1))
                    {
                        world.setRawTypeIdAndData(i, j, k, Block.VINE.id, 1 << Direction.d[Facing.OPPOSITE_FACING[j1]]);
                        continue label0;
                    }
                    j1++;
                } while(true);
            }
            i = (l + random.nextInt(4)) - random.nextInt(4);
            k = (i1 + random.nextInt(4)) - random.nextInt(4);
        }

        return true;
    }
}
