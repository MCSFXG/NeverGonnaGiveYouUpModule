// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPigZombie.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityZombie, EntityHuman, Entity, ItemStack, 
//            World, NBTTagCompound, DamageSource, AxisAlignedBB, 
//            Item, EnchantmentManager

public class EntityPigZombie extends EntityZombie
{

    public EntityPigZombie(World world)
    {
        super(world);
        angerLevel = 0;
        soundDelay = 0;
        texture = "/mob/pigzombie.png";
        bb = 0.5F;
        damage = 5;
        fireProof = true;
    }

    protected boolean c_()
    {
        return false;
    }

    public void F_()
    {
        bb = target == null ? 0.5F : 0.95F;
        if(soundDelay > 0 && --soundDelay == 0)
            world.makeSound(this, "mob.zombiepig.zpigangry", p() * 2.0F, ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
        super.F_();
    }

    public boolean canSpawn()
    {
        return world.difficulty > 0 && world.containsEntity(boundingBox) && world.getCubes(this, boundingBox).size() == 0 && !world.containsLiquid(boundingBox);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setShort("Anger", (short)angerLevel);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        angerLevel = nbttagcompound.getShort("Anger");
    }

    protected Entity findTarget()
    {
        return angerLevel != 0 ? super.findTarget() : null;
    }

    public void e()
    {
        super.e();
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        Entity entity = damagesource.getEntity();
        if(entity instanceof EntityHuman)
        {
            List list = world.getEntities(this, boundingBox.grow(32D, 32D, 32D));
            for(int j = 0; j < list.size(); j++)
            {
                Entity entity1 = (Entity)list.get(j);
                if(entity1 instanceof EntityPigZombie)
                {
                    EntityPigZombie entitypigzombie = (EntityPigZombie)entity1;
                    entitypigzombie.e(entity);
                }
            }

            e(entity);
        }
        return super.damageEntity(damagesource, i);
    }

    private void e(Entity entity)
    {
        org.bukkit.entity.Entity bukkitTarget = entity != null ? entity.getBukkitEntity() : null;
        EntityTargetEvent event = new EntityTargetEvent(getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.PIG_ZOMBIE_TARGET);
        world.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled())
            return;
        if(event.getTarget() == null)
        {
            target = null;
            return;
        } else
        {
            entity = ((CraftEntity)event.getTarget()).getHandle();
            target = entity;
            angerLevel = 400 + random.nextInt(400);
            soundDelay = random.nextInt(40);
            return;
        }
    }

    protected String i()
    {
        return "mob.zombiepig.zpig";
    }

    protected String j()
    {
        return "mob.zombiepig.zpighurt";
    }

    protected String k()
    {
        return "mob.zombiepig.zpigdeath";
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = random.nextInt(2 + i);
        if(j > 0)
            loot.add(new CraftItemStack(Item.ROTTEN_FLESH.id, j));
        j = random.nextInt(2 + i);
        if(j > 0)
            loot.add(new CraftItemStack(Item.GOLD_NUGGET.id, j));
        if(lastDamageByPlayerTime > 0)
        {
            int k = random.nextInt(200) - i;
            if(k < 5)
            {
                ItemStack itemstack = b(k > 0 ? 0 : 1);
                if(itemstack != null)
                    loot.add(new CraftItemStack(itemstack));
            }
        }
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    protected ItemStack b(int i)
    {
        if(i > 0)
        {
            ItemStack itemstack = new ItemStack(Item.GOLD_SWORD);
            EnchantmentManager.a(random, itemstack, 5);
            return itemstack;
        }
        int j = random.nextInt(3);
        if(j == 0)
            return new ItemStack(Item.GOLD_INGOT.id, 1, 0);
        if(j == 1)
            return new ItemStack(Item.GOLD_SWORD.id, 1, 0);
        if(j == 2)
            return new ItemStack(Item.GOLD_HELMET.id, 1, 0);
        else
            return null;
    }

    protected int getLootId()
    {
        return Item.ROTTEN_FLESH.id;
    }

    public int angerLevel;
    private int soundDelay;
    private static final ItemStack g;

    static 
    {
        g = new ItemStack(Item.GOLD_SWORD, 1);
    }
}
