// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            DamageSource, EntityHuman, Entity, LocaleI18n

public class EntityDamageSource extends DamageSource
{

    public EntityDamageSource(String s, Entity entity)
    {
        super(s);
        a = entity;
    }

    public Entity getEntity()
    {
        return a;
    }

    public String getLocalizedDeathMessage(EntityHuman entityhuman)
    {
        return LocaleI18n.get((new StringBuilder()).append("death.").append(translationIndex).toString(), new Object[] {
            entityhuman.name, a.getLocalizedName()
        });
    }

    protected Entity a;
}
