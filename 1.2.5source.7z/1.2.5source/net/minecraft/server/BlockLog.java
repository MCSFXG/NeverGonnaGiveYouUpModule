// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, BlockLeaves, 
//            EntityHuman

public class BlockLog extends Block
{

    protected BlockLog(int i)
    {
        super(i, Material.WOOD);
        textureId = 20;
    }

    public int a(Random random)
    {
        return 1;
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.LOG.id;
    }

    public void a(World world, EntityHuman entityhuman, int i, int j, int k, int l)
    {
        super.a(world, entityhuman, i, j, k, l);
    }

    public void remove(World world, int i, int j, int k)
    {
        byte byte0 = 4;
        int l = byte0 + 1;
        if(world.a(i - l, j - l, k - l, i + l, j + l, k + l))
        {
            for(int i1 = -byte0; i1 <= byte0; i1++)
            {
                for(int j1 = -byte0; j1 <= byte0; j1++)
                {
                    for(int k1 = -byte0; k1 <= byte0; k1++)
                    {
                        int l1 = world.getTypeId(i + i1, j + j1, k + k1);
                        if(l1 != Block.LEAVES.id)
                            continue;
                        int i2 = world.getData(i + i1, j + j1, k + k1);
                        if((i2 & 8) == 0)
                            world.setRawData(i + i1, j + j1, k + k1, i2 | 8);
                    }

                }

            }

        }
    }

    public int a(int i, int j)
    {
        if(i == 1)
            return 21;
        if(i == 0)
            return 21;
        if(j == 1)
            return 116;
        if(j == 2)
            return 117;
        return j != 3 ? 20 : 153;
    }

    protected int getDropData(int i)
    {
        return i;
    }
}
