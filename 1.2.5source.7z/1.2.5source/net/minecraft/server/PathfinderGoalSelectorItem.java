// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, PathfinderGoalSelector

class PathfinderGoalSelectorItem
{

    public PathfinderGoalSelectorItem(PathfinderGoalSelector pathfindergoalselector, int i, PathfinderGoal pathfindergoal)
    {
        c = pathfindergoalselector;
        super();
        b = i;
        a = pathfindergoal;
    }

    public PathfinderGoal a;
    public int b;
    final PathfinderGoalSelector c;
}
