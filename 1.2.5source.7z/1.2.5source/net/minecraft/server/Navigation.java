// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Vec3D, MathHelper, World, PathEntity, 
//            EntityLiving, ControllerMove, PathPoint, AxisAlignedBB, 
//            Block, Material

public class Navigation
{

    public Navigation(EntityLiving entityliving, World world, float f1)
    {
        f = false;
        i = Vec3D.a(0.0D, 0.0D, 0.0D);
        j = true;
        k = false;
        l = false;
        m = false;
        a = entityliving;
        b = world;
        e = f1;
    }

    public void a(boolean flag)
    {
        l = flag;
    }

    public boolean a()
    {
        return l;
    }

    public void b(boolean flag)
    {
        k = flag;
    }

    public void c(boolean flag)
    {
        j = flag;
    }

    public boolean b()
    {
        return k;
    }

    public void d(boolean flag)
    {
        f = flag;
    }

    public void a(float f1)
    {
        d = f1;
    }

    public void e(boolean flag)
    {
        m = flag;
    }

    public PathEntity a(double d1, double d2, double d3)
    {
        if(!j())
            return null;
        else
            return b.a(a, MathHelper.floor(d1), (int)d2, MathHelper.floor(d3), e, j, k, l, m);
    }

    public boolean a(double d1, double d2, double d3, float f1)
    {
        PathEntity pathentity = a(MathHelper.floor(d1), (int)d2, MathHelper.floor(d3));
        return a(pathentity, f1);
    }

    public PathEntity a(EntityLiving entityliving)
    {
        if(!j())
            return null;
        else
            return b.findPath(a, entityliving, e, j, k, l, m);
    }

    public boolean a(EntityLiving entityliving, float f1)
    {
        PathEntity pathentity = a(entityliving);
        if(pathentity != null)
            return a(pathentity, f1);
        else
            return false;
    }

    public boolean a(PathEntity pathentity, float f1)
    {
        if(pathentity == null)
        {
            c = null;
            return false;
        }
        if(!pathentity.a(c))
            c = pathentity;
        if(f)
            l();
        if(c.d() == 0)
        {
            return false;
        } else
        {
            d = f1;
            Vec3D vec3d = h();
            h = g;
            i.a = vec3d.a;
            i.b = vec3d.b;
            i.c = vec3d.c;
            return true;
        }
    }

    public PathEntity c()
    {
        return c;
    }

    public void d()
    {
        g++;
        if(e())
            return;
        if(j())
            g();
        if(e())
            return;
        Vec3D vec3d = c.a(a);
        if(vec3d == null)
        {
            return;
        } else
        {
            a.getControllerMove().a(vec3d.a, vec3d.b, vec3d.c, d);
            return;
        }
    }

    private void g()
    {
        Vec3D vec3d = h();
        int i1 = c.d();
        float f1 = c.e();
        do
        {
            if(f1 >= c.d())
                break;
            if(c.a(f1).b != (int)vec3d.b)
            {
                i1 = f1;
                break;
            }
            f1++;
        } while(true);
        f1 = a.width * a.width;
        for(int j1 = c.e(); j1 < i1; j1++)
            if(vec3d.distanceSquared(c.a(a, j1)) < (double)f1)
                c.c(j1 + 1);

        int k1 = (int)Math.ceil(a.width);
        int l1 = (int)a.length + 1;
        int i2 = k1;
        int j2 = i1 - 1;
        do
        {
            if(j2 < c.e())
                break;
            if(a(vec3d, c.a(a, j2), k1, l1, i2))
            {
                c.c(j2);
                break;
            }
            j2--;
        } while(true);
        if(g - h > 100)
        {
            if(vec3d.distanceSquared(i) < 2.25D)
                f();
            h = g;
            i.a = vec3d.a;
            i.b = vec3d.b;
            i.c = vec3d.c;
        }
    }

    public boolean e()
    {
        return c == null || c.b();
    }

    public void f()
    {
        c = null;
    }

    private Vec3D h()
    {
        return Vec3D.create(a.locX, i(), a.locZ);
    }

    private int i()
    {
        if(!a.aU() || !m)
            return (int)(a.boundingBox.b + 0.5D);
        int i1 = (int)a.boundingBox.b;
        int j1 = b.getTypeId(MathHelper.floor(a.locX), i1, MathHelper.floor(a.locZ));
        int k1 = 0;
        while(j1 == Block.WATER.id || j1 == Block.STATIONARY_WATER.id) 
        {
            i1++;
            j1 = b.getTypeId(MathHelper.floor(a.locX), i1, MathHelper.floor(a.locZ));
            if(++k1 > 16)
                return (int)a.boundingBox.b;
        }
        return i1;
    }

    private boolean j()
    {
        return a.onGround || m && k();
    }

    private boolean k()
    {
        return a.aU() || a.aV();
    }

    private void l()
    {
        if(b.isChunkLoaded(MathHelper.floor(a.locX), (int)(a.boundingBox.b + 0.5D), MathHelper.floor(a.locZ)))
            return;
        for(int i1 = 0; i1 < c.d(); i1++)
        {
            PathPoint pathpoint = c.a(i1);
            if(b.isChunkLoaded(pathpoint.a, pathpoint.b, pathpoint.c))
            {
                c.b(i1 - 1);
                return;
            }
        }

    }

    private boolean a(Vec3D vec3d, Vec3D vec3d1, int i1, int j1, int k1)
    {
        int l1 = MathHelper.floor(vec3d.a);
        int i2 = MathHelper.floor(vec3d.c);
        double d1 = vec3d1.a - vec3d.a;
        double d2 = vec3d1.c - vec3d.c;
        double d3 = d1 * d1 + d2 * d2;
        if(d3 < 1E-008D)
            return false;
        double d4 = 1.0D / Math.sqrt(d3);
        d1 *= d4;
        d2 *= d4;
        i1 += 2;
        k1 += 2;
        if(!a(l1, (int)vec3d.b, i2, i1, j1, k1, vec3d, d1, d2))
            return false;
        i1 -= 2;
        k1 -= 2;
        double d5 = 1.0D / Math.abs(d1);
        double d6 = 1.0D / Math.abs(d2);
        double d7 = (double)(l1 * 1) - vec3d.a;
        double d8 = (double)(i2 * 1) - vec3d.c;
        if(d1 >= 0.0D)
            d7++;
        if(d2 >= 0.0D)
            d8++;
        d7 /= d1;
        d8 /= d2;
        byte byte0 = ((byte)(d1 >= 0.0D ? 1 : -1));
        byte byte1 = ((byte)(d2 >= 0.0D ? 1 : -1));
        int j2 = MathHelper.floor(vec3d1.a);
        int k2 = MathHelper.floor(vec3d1.c);
        int l2 = j2 - l1;
        for(int i3 = k2 - i2; l2 * byte0 > 0 || i3 * byte1 > 0;)
        {
            if(d7 < d8)
            {
                d7 += d5;
                l1 += byte0;
                l2 = j2 - l1;
            } else
            {
                d8 += d6;
                i2 += byte1;
                i3 = k2 - i2;
            }
            if(!a(l1, (int)vec3d.b, i2, i1, j1, k1, vec3d, d1, d2))
                return false;
        }

        return true;
    }

    private boolean a(int i1, int j1, int k1, int l1, int i2, int j2, Vec3D vec3d, 
            double d1, double d2)
    {
        int k2 = i1 - l1 / 2;
        int l2 = k1 - j2 / 2;
        if(!b(k2, j1, l2, l1, i2, j2, vec3d, d1, d2))
            return false;
        for(int i3 = k2; i3 < k2 + l1; i3++)
        {
            for(int j3 = l2; j3 < l2 + j2; j3++)
            {
                double d3 = ((double)i3 + 0.5D) - vec3d.a;
                double d4 = ((double)j3 + 0.5D) - vec3d.c;
                if(d3 * d1 + d4 * d2 < 0.0D)
                    continue;
                int k3 = b.getTypeId(i3, j1 - 1, j3);
                if(k3 <= 0)
                    return false;
                Material material = Block.byId[k3].material;
                if(material == Material.WATER && !a.aU())
                    return false;
                if(material == Material.LAVA)
                    return false;
            }

        }

        return true;
    }

    private boolean b(int i1, int j1, int k1, int l1, int i2, int j2, Vec3D vec3d, 
            double d1, double d2)
    {
        for(int k2 = i1; k2 < i1 + l1; k2++)
        {
            for(int l2 = j1; l2 < j1 + i2; l2++)
            {
                for(int i3 = k1; i3 < k1 + j2; i3++)
                {
                    double d3 = ((double)k2 + 0.5D) - vec3d.a;
                    double d4 = ((double)i3 + 0.5D) - vec3d.c;
                    if(d3 * d1 + d4 * d2 < 0.0D)
                        continue;
                    int j3 = b.getTypeId(k2, l2, i3);
                    if(j3 > 0 && !Block.byId[j3].b(b, k2, l2, i3))
                        return false;
                }

            }

        }

        return true;
    }

    private EntityLiving a;
    private World b;
    private PathEntity c;
    private float d;
    private float e;
    private boolean f;
    private int g;
    private int h;
    private Vec3D i;
    private boolean j;
    private boolean k;
    private boolean l;
    private boolean m;
}
