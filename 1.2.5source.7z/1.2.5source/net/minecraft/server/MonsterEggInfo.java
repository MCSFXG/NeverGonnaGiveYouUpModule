// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class MonsterEggInfo
{

    public MonsterEggInfo(int i, int j, int k)
    {
        a = i;
        b = j;
        c = k;
    }

    public int a;
    public int b;
    public int c;
}
