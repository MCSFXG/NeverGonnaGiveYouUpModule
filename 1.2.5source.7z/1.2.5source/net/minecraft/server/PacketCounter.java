// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

public class PacketCounter
{

    public PacketCounter()
    {
    }

    public static void a(int i, long l)
    {
        if(!a)
            return;
        synchronized(d)
        {
            if(b.containsKey(Integer.valueOf(i)))
            {
                b.put(Integer.valueOf(i), Long.valueOf(((Long)b.get(Integer.valueOf(i))).longValue() + 1L));
                c.put(Integer.valueOf(i), Long.valueOf(((Long)c.get(Integer.valueOf(i))).longValue() + l));
            } else
            {
                b.put(Integer.valueOf(i), Long.valueOf(1L));
                c.put(Integer.valueOf(i), Long.valueOf(l));
            }
        }
    }

    public static boolean a = true;
    private static final Map b = new HashMap();
    private static final Map c = new HashMap();
    private static final Object d = new Object();

}
