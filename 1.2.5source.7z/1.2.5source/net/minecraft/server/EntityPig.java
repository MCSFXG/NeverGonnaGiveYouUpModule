// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPig.java

package net.minecraft.server;

import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.PigZapEvent;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, PathfinderGoalFloat, PathfinderGoalPanic, PathfinderGoalBreed, 
//            PathfinderGoalTempt, PathfinderGoalFollowParent, PathfinderGoalRandomStroll, PathfinderGoalLookAtPlayer, 
//            EntityHuman, PathfinderGoalRandomLookaround, EntityPigZombie, Navigation, 
//            PathfinderGoalSelector, Item, DataWatcher, NBTTagCompound, 
//            World, AchievementList, EntityWeatherLighting

public class EntityPig extends EntityAnimal
{

    public EntityPig(World world)
    {
        super(world);
        texture = "/mob/pig.png";
        b(0.9F, 0.9F);
        al().a(true);
        float f = 0.25F;
        goalSelector.a(0, new PathfinderGoalFloat(this));
        goalSelector.a(1, new PathfinderGoalPanic(this, 0.38F));
        goalSelector.a(2, new PathfinderGoalBreed(this, f));
        goalSelector.a(3, new PathfinderGoalTempt(this, 0.25F, Item.WHEAT.id, false));
        goalSelector.a(4, new PathfinderGoalFollowParent(this, 0.28F));
        goalSelector.a(5, new PathfinderGoalRandomStroll(this, f));
        goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 6F));
        goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
    }

    public boolean c_()
    {
        return true;
    }

    public int getMaxHealth()
    {
        return 10;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)0));
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setBoolean("Saddle", hasSaddle());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setSaddle(nbttagcompound.getBoolean("Saddle"));
    }

    protected String i()
    {
        return "mob.pig";
    }

    protected String j()
    {
        return "mob.pig";
    }

    protected String k()
    {
        return "mob.pigdeath";
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(super.b(entityhuman))
            return true;
        if(hasSaddle() && !world.isStatic && (passenger == null || passenger == entityhuman))
        {
            entityhuman.mount(this);
            return true;
        } else
        {
            return false;
        }
    }

    protected int getLootId()
    {
        return isBurning() ? Item.GRILLED_PORK.id : Item.PORK.id;
    }

    public boolean hasSaddle()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    public void setSaddle(boolean flag)
    {
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)1));
        else
            datawatcher.watch(16, Byte.valueOf((byte)0));
    }

    public void a(EntityWeatherLighting entityweatherlighting)
    {
        if(!world.isStatic)
        {
            EntityPigZombie entitypigzombie = new EntityPigZombie(world);
            if(CraftEventFactory.callPigZapEvent(this, entityweatherlighting, entitypigzombie).isCancelled())
                return;
            entitypigzombie.setPositionRotation(locX, locY, locZ, yaw, pitch);
            world.addEntity(entitypigzombie, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.LIGHTNING);
            die();
        }
    }

    protected void a(float f)
    {
        super.a(f);
        if(f > 5F && (passenger instanceof EntityHuman))
            ((EntityHuman)passenger).a(AchievementList.u);
    }

    public EntityAnimal createChild(EntityAnimal entityanimal)
    {
        return new EntityPig(world);
    }
}
