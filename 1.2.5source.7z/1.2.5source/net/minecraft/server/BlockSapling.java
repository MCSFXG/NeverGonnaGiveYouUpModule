// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockSapling.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.*;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.util.StructureGrowDelegate;
import org.bukkit.entity.Player;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            BlockFlower, WorldGenTaiga2, WorldGenForest, WorldGenMegaTree, 
//            WorldGenTrees, WorldGenBigTree, World, ItemStack

public class BlockSapling extends BlockFlower
{
    public static interface TreeGenerator
    {

        public abstract boolean a(World world, Random random, int i, int j, int k);

        public abstract boolean generate(BlockChangeDelegate blockchangedelegate, Random random, int i, int j, int k);
    }


    protected BlockSapling(int i, int j)
    {
        super(i, j);
        float f = 0.4F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
    }

    public void a(World world, int i, int j, int k, Random random)
    {
        if(!world.isStatic)
        {
            super.a(world, i, j, k, random);
            if(world.getLightLevel(i, j + 1, k) >= 9 && random.nextInt(7) == 0)
            {
                int l = world.getData(i, j, k);
                if((l & 8) == 0)
                    world.setData(i, j, k, l | 8);
                else
                    grow(world, i, j, k, random, false, null, null);
            }
        }
    }

    public int a(int i, int j)
    {
        j &= 3;
        return j != 1 ? j != 2 ? j != 3 ? super.a(i, j) : 30 : 79 : 63;
    }

    public void grow(World world, int i, int j, int k, Random random, boolean bonemeal, Player player, 
            ItemStack itemstack)
    {
        int l = world.getData(i, j, k) & 3;
        int i1 = 0;
        int j1 = 0;
        StructureGrowDelegate delegate = new StructureGrowDelegate(world);
        TreeType treeType = null;
        TreeGenerator gen = null;
        boolean grownTree = false;
        boolean flag = false;
        if(l == 1)
        {
            treeType = TreeType.REDWOOD;
            gen = new WorldGenTaiga2(false);
        } else
        if(l == 2)
        {
            treeType = TreeType.BIRCH;
            gen = new WorldGenForest(false);
        } else
        if(l == 3)
        {
            i1 = 0;
            do
            {
                if(i1 < -1)
                    break;
                j1 = 0;
                do
                {
                    if(j1 < -1)
                        break;
                    if(f(world, i + i1, j, k + j1, 3) && f(world, i + i1 + 1, j, k + j1, 3) && f(world, i + i1, j, k + j1 + 1, 3) && f(world, i + i1 + 1, j, k + j1 + 1, 3))
                    {
                        treeType = TreeType.JUNGLE;
                        gen = new WorldGenMegaTree(false, 10 + random.nextInt(20), 3, 3);
                        flag = true;
                        break;
                    }
                    j1--;
                } while(true);
                if(gen != null)
                    break;
                i1--;
            } while(true);
            if(gen == null)
            {
                j1 = 0;
                i1 = 0;
                treeType = TreeType.SMALL_JUNGLE;
                gen = new WorldGenTrees(false, 4 + random.nextInt(7), 3, 3, false);
            }
        } else
        {
            treeType = TreeType.TREE;
            gen = new WorldGenTrees(false);
            if(random.nextInt(10) == 0)
            {
                treeType = TreeType.BIG_TREE;
                gen = new WorldGenBigTree(false);
            }
        }
        if(flag)
        {
            world.setRawTypeId(i + i1, j, k + j1, 0);
            world.setRawTypeId(i + i1 + 1, j, k + j1, 0);
            world.setRawTypeId(i + i1, j, k + j1 + 1, 0);
            world.setRawTypeId(i + i1 + 1, j, k + j1 + 1, 0);
        } else
        {
            world.setRawTypeId(i, j, k, 0);
        }
        grownTree = gen.generate(delegate, random, i + i1, j, k + j1);
        if(grownTree)
        {
            Location location = new Location(world.getWorld(), i, j, k);
            StructureGrowEvent event = new StructureGrowEvent(location, treeType, bonemeal, player, delegate.getBlocks());
            Bukkit.getPluginManager().callEvent(event);
            if(event.isCancelled())
            {
                grownTree = false;
            } else
            {
                BlockState state;
                for(Iterator i$ = event.getBlocks().iterator(); i$.hasNext(); state.update(true))
                    state = (BlockState)i$.next();

                if(event.isFromBonemeal() && itemstack != null)
                    itemstack.count--;
            }
        }
        if(!grownTree)
            if(flag)
            {
                world.setRawTypeIdAndData(i + i1, j, k + j1, id, l);
                world.setRawTypeIdAndData(i + i1 + 1, j, k + j1, id, l);
                world.setRawTypeIdAndData(i + i1, j, k + j1 + 1, id, l);
                world.setRawTypeIdAndData(i + i1 + 1, j, k + j1 + 1, id, l);
            } else
            {
                world.setRawTypeIdAndData(i, j, k, id, l);
            }
    }

    public boolean f(World world, int i, int j, int k, int l)
    {
        return world.getTypeId(i, j, k) == id && (world.getData(i, j, k) & 3) == l;
    }

    protected int getDropData(int i)
    {
        return i & 3;
    }
}
