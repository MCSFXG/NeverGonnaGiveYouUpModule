// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.Arrays;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagIntArray extends NBTBase
{

    public NBTTagIntArray(String s)
    {
        super(s);
    }

    public NBTTagIntArray(String s, int ai[])
    {
        super(s);
        data = ai;
    }

    void write(DataOutput dataoutput)
    {
        dataoutput.writeInt(data.length);
        for(int i = 0; i < data.length; i++)
            dataoutput.writeInt(data[i]);

    }

    void load(DataInput datainput)
    {
        int i = datainput.readInt();
        data = new int[i];
        for(int j = 0; j < i; j++)
            data[j] = datainput.readInt();

    }

    public byte getTypeId()
    {
        return 11;
    }

    public String toString()
    {
        return (new StringBuilder()).append("[").append(data.length).append(" bytes]").toString();
    }

    public NBTBase clone()
    {
        int ai[] = new int[data.length];
        System.arraycopy(data, 0, ai, 0, data.length);
        return new NBTTagIntArray(getName(), ai);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagIntArray nbttagintarray = (NBTTagIntArray)obj;
            return data == null && nbttagintarray.data == null || data != null && data.equals(nbttagintarray.data);
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        return super.hashCode() ^ Arrays.hashCode(data);
    }

    public int data[];
}
