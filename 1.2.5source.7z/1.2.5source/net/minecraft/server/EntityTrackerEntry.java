// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityTrackerEntry.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.util.NumberConversions;
import org.bukkit.util.Vector;

// Referenced classes of package net.minecraft.server:
//            Packet33RelEntityMoveLook, Packet31RelEntityMove, Packet32EntityLook, EntityPlayer, 
//            Packet34EntityTeleport, Packet28EntityVelocity, Packet, Packet40EntityMetadata, 
//            Packet35EntityHeadRotation, Packet29DestroyEntity, Packet5EntityEquipment, EntityHuman, 
//            Packet17EntityLocationAction, EntityLiving, MobEffect, Packet41MobEffect, 
//            EntityItem, Packet21PickupSpawn, Packet20NamedEntitySpawn, EntityMinecart, 
//            Packet23VehicleSpawn, EntityBoat, IAnimal, Packet24MobSpawn, 
//            EntityEnderDragon, EntityFishingHook, EntityArrow, EntitySnowball, 
//            EntityPotion, EntityThrownExpBottle, EntityEnderPearl, EntityEnderSignal, 
//            EntitySmallFireball, EntityFireball, EntityEgg, EntityTNTPrimed, 
//            EntityEnderCrystal, EntityFallingBlock, EntityPainting, Packet25EntityPainting, 
//            EntityExperienceOrb, Packet26AddExpOrb, Entity, MathHelper, 
//            DataWatcher, World, NetServerHandler, Block

public class EntityTrackerEntry
{

    public EntityTrackerEntry(Entity entity, int i, int j, boolean flag)
    {
        m = 0;
        s = false;
        u = 0;
        n = false;
        trackedPlayers = new HashSet();
        tracker = entity;
        b = i;
        c = j;
        isMoving = flag;
        xLoc = MathHelper.floor(entity.locX * 32D);
        yLoc = MathHelper.floor(entity.locY * 32D);
        zLoc = MathHelper.floor(entity.locZ * 32D);
        yRot = MathHelper.d((entity.yaw * 256F) / 360F);
        xRot = MathHelper.d((entity.pitch * 256F) / 360F);
        this.i = MathHelper.d((entity.ar() * 256F) / 360F);
    }

    public boolean equals(Object object)
    {
        return (object instanceof EntityTrackerEntry) ? ((EntityTrackerEntry)object).tracker.id == tracker.id : false;
    }

    public int hashCode()
    {
        return tracker.id;
    }

    public void track(List list)
    {
        n = false;
        if(!s || tracker.e(p, q, r) > 16D)
        {
            p = tracker.locX;
            q = tracker.locY;
            r = tracker.locZ;
            s = true;
            n = true;
            scanPlayers(list);
        }
        u++;
        if(m++ % c == 0 || tracker.ce)
        {
            int i = tracker.size.getXZCoord(tracker.locX);
            int j = NumberConversions.floor(tracker.locY * 32D);
            int k = tracker.size.getXZCoord(tracker.locZ);
            int l = MathHelper.d((tracker.yaw * 256F) / 360F);
            int i1 = MathHelper.d((tracker.pitch * 256F) / 360F);
            int j1 = i - xLoc;
            int k1 = j - yLoc;
            int l1 = k - zLoc;
            Object object = null;
            boolean flag = Math.abs(j1) >= 4 || Math.abs(k1) >= 4 || Math.abs(l1) >= 4;
            boolean flag1 = Math.abs(l - yRot) >= 4 || Math.abs(i1 - xRot) >= 4;
            if(flag)
            {
                xLoc = i;
                yLoc = j;
                zLoc = k;
            }
            if(flag1)
            {
                yRot = l;
                xRot = i1;
            }
            if(j1 >= -128 && j1 < 128 && k1 >= -128 && k1 < 128 && l1 >= -128 && l1 < 128 && u <= 400)
            {
                if(flag && flag1)
                    object = new Packet33RelEntityMoveLook(tracker.id, (byte)j1, (byte)k1, (byte)l1, (byte)l, (byte)i1);
                else
                if(flag)
                    object = new Packet31RelEntityMove(tracker.id, (byte)j1, (byte)k1, (byte)l1);
                else
                if(flag1)
                    object = new Packet32EntityLook(tracker.id, (byte)l, (byte)i1);
            } else
            {
                u = 0;
                if(tracker instanceof EntityPlayer)
                    scanPlayers(new ArrayList(trackedPlayers));
                object = new Packet34EntityTeleport(tracker.id, i, j, k, (byte)l, (byte)i1);
            }
            if(isMoving)
            {
                double d0 = tracker.motX - this.j;
                double d1 = tracker.motY - this.k;
                double d2 = tracker.motZ - this.l;
                double d3 = 0.02D;
                double d4 = d0 * d0 + d1 * d1 + d2 * d2;
                if(d4 > d3 * d3 || d4 > 0.0D && tracker.motX == 0.0D && tracker.motY == 0.0D && tracker.motZ == 0.0D)
                {
                    this.j = tracker.motX;
                    this.k = tracker.motY;
                    this.l = tracker.motZ;
                    broadcast(new Packet28EntityVelocity(tracker.id, this.j, this.k, this.l));
                }
            }
            if(object != null)
                broadcast((Packet)object);
            DataWatcher datawatcher = tracker.getDataWatcher();
            if(datawatcher.a())
                broadcastIncludingSelf(new Packet40EntityMetadata(tracker.id, datawatcher));
            int i2 = MathHelper.d((tracker.ar() * 256F) / 360F);
            if(Math.abs(i2 - this.i) >= 4)
            {
                broadcast(new Packet35EntityHeadRotation(tracker.id, (byte)i2));
                this.i = i2;
            }
        }
        tracker.ce = false;
        if(tracker.velocityChanged)
        {
            boolean cancelled = false;
            if(tracker instanceof EntityPlayer)
            {
                Player player = (Player)tracker.getBukkitEntity();
                Vector velocity = player.getVelocity();
                PlayerVelocityEvent event = new PlayerVelocityEvent(player, velocity);
                tracker.world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled())
                    cancelled = true;
                else
                if(!velocity.equals(event.getVelocity()))
                    player.setVelocity(velocity);
            }
            if(!cancelled)
                broadcastIncludingSelf(new Packet28EntityVelocity(tracker));
            tracker.velocityChanged = false;
        }
    }

    public void broadcast(Packet packet)
    {
        EntityPlayer entityplayer;
        for(Iterator iterator = trackedPlayers.iterator(); iterator.hasNext(); entityplayer.netServerHandler.sendPacket(packet))
            entityplayer = (EntityPlayer)iterator.next();

    }

    public void broadcastIncludingSelf(Packet packet)
    {
        broadcast(packet);
        if(tracker instanceof EntityPlayer)
            ((EntityPlayer)tracker).netServerHandler.sendPacket(packet);
    }

    public void a()
    {
        broadcast(new Packet29DestroyEntity(tracker.id));
    }

    public void a(EntityPlayer entityplayer)
    {
        if(trackedPlayers.contains(entityplayer))
            trackedPlayers.remove(entityplayer);
    }

    public void updatePlayer(EntityPlayer entityplayer)
    {
        if(entityplayer != tracker)
        {
            double d0 = entityplayer.locX - (double)(xLoc / 32);
            double d1 = entityplayer.locZ - (double)(zLoc / 32);
            if(d0 >= (double)(-b) && d0 <= (double)b && d1 >= (double)(-b) && d1 <= (double)b)
            {
                if(!trackedPlayers.contains(entityplayer))
                {
                    if(tracker instanceof EntityPlayer)
                    {
                        Player player = ((EntityPlayer)tracker).getBukkitEntity();
                        if(!entityplayer.getBukkitEntity().canSee(player))
                            return;
                    }
                    trackedPlayers.add(entityplayer);
                    entityplayer.netServerHandler.sendPacket(b());
                    if(isMoving)
                        entityplayer.netServerHandler.sendPacket(new Packet28EntityVelocity(tracker.id, tracker.motX, tracker.motY, tracker.motZ));
                    ItemStack aitemstack[] = tracker.getEquipment();
                    if(aitemstack != null)
                    {
                        for(int i = 0; i < aitemstack.length; i++)
                            entityplayer.netServerHandler.sendPacket(new Packet5EntityEquipment(tracker.id, i, aitemstack[i]));

                    }
                    if(tracker instanceof EntityHuman)
                    {
                        EntityHuman entityhuman = (EntityHuman)tracker;
                        if(entityhuman.isSleeping())
                            entityplayer.netServerHandler.sendPacket(new Packet17EntityLocationAction(tracker, 0, MathHelper.floor(tracker.locX), MathHelper.floor(tracker.locY), MathHelper.floor(tracker.locZ)));
                    }
                    this.i = MathHelper.d((tracker.ar() * 256F) / 360F);
                    broadcast(new Packet35EntityHeadRotation(tracker.id, (byte)this.i));
                    if(tracker instanceof EntityLiving)
                    {
                        EntityLiving entityliving = (EntityLiving)tracker;
                        MobEffect mobeffect;
                        for(Iterator iterator = entityliving.getEffects().iterator(); iterator.hasNext(); entityplayer.netServerHandler.sendPacket(new Packet41MobEffect(tracker.id, mobeffect)))
                            mobeffect = (MobEffect)iterator.next();

                    }
                }
            } else
            if(trackedPlayers.contains(entityplayer))
            {
                trackedPlayers.remove(entityplayer);
                entityplayer.netServerHandler.sendPacket(new Packet29DestroyEntity(tracker.id));
            }
        }
    }

    public void scanPlayers(List list)
    {
        for(int i = 0; i < list.size(); i++)
            updatePlayer((EntityPlayer)list.get(i));

    }

    private Packet b()
    {
        if(tracker.dead)
            return null;
        if(tracker instanceof EntityItem)
        {
            EntityItem entityitem = (EntityItem)tracker;
            Packet21PickupSpawn packet21pickupspawn = new Packet21PickupSpawn(entityitem);
            entityitem.locX = (double)packet21pickupspawn.b / 32D;
            entityitem.locY = (double)packet21pickupspawn.c / 32D;
            entityitem.locZ = (double)packet21pickupspawn.d / 32D;
            return packet21pickupspawn;
        }
        if(tracker instanceof EntityPlayer)
            return new Packet20NamedEntitySpawn((EntityHuman)tracker);
        if(tracker instanceof EntityMinecart)
        {
            EntityMinecart entityminecart = (EntityMinecart)tracker;
            if(entityminecart.type == 0)
                return new Packet23VehicleSpawn(tracker, 10);
            if(entityminecart.type == 1)
                return new Packet23VehicleSpawn(tracker, 11);
            if(entityminecart.type == 2)
                return new Packet23VehicleSpawn(tracker, 12);
        }
        if(tracker instanceof EntityBoat)
            return new Packet23VehicleSpawn(tracker, 1);
        if(tracker instanceof IAnimal)
            return new Packet24MobSpawn((EntityLiving)tracker);
        if(tracker instanceof EntityEnderDragon)
            return new Packet24MobSpawn((EntityLiving)tracker);
        if(tracker instanceof EntityFishingHook)
            return new Packet23VehicleSpawn(tracker, 90);
        if(tracker instanceof EntityArrow)
        {
            Entity entity = ((EntityArrow)tracker).shooter;
            return new Packet23VehicleSpawn(tracker, 60, entity == null ? tracker.id : entity.id);
        }
        if(tracker instanceof EntitySnowball)
            return new Packet23VehicleSpawn(tracker, 61);
        if(tracker instanceof EntityPotion)
            return new Packet23VehicleSpawn(tracker, 73, ((EntityPotion)tracker).getPotionValue());
        if(tracker instanceof EntityThrownExpBottle)
            return new Packet23VehicleSpawn(tracker, 75);
        if(tracker instanceof EntityEnderPearl)
            return new Packet23VehicleSpawn(tracker, 65);
        if(tracker instanceof EntityEnderSignal)
            return new Packet23VehicleSpawn(tracker, 72);
        if(tracker instanceof EntitySmallFireball)
        {
            EntitySmallFireball entitysmallfireball = (EntitySmallFireball)tracker;
            Packet23VehicleSpawn packet23vehiclespawn = null;
            if(entitysmallfireball.shooter != null)
                packet23vehiclespawn = new Packet23VehicleSpawn(tracker, 64, entitysmallfireball.shooter.id);
            else
                packet23vehiclespawn = new Packet23VehicleSpawn(tracker, 64, 0);
            packet23vehiclespawn.e = (int)(entitysmallfireball.dirX * 8000D);
            packet23vehiclespawn.f = (int)(entitysmallfireball.dirY * 8000D);
            packet23vehiclespawn.g = (int)(entitysmallfireball.dirZ * 8000D);
            return packet23vehiclespawn;
        }
        if(tracker instanceof EntityFireball)
        {
            EntityFireball entityfireball = (EntityFireball)tracker;
            Packet23VehicleSpawn packet23vehiclespawn = null;
            if(entityfireball.shooter != null)
                packet23vehiclespawn = new Packet23VehicleSpawn(tracker, 63, ((EntityFireball)tracker).shooter.id);
            else
                packet23vehiclespawn = new Packet23VehicleSpawn(tracker, 63, 0);
            packet23vehiclespawn.e = (int)(entityfireball.dirX * 8000D);
            packet23vehiclespawn.f = (int)(entityfireball.dirY * 8000D);
            packet23vehiclespawn.g = (int)(entityfireball.dirZ * 8000D);
            return packet23vehiclespawn;
        }
        if(tracker instanceof EntityEgg)
            return new Packet23VehicleSpawn(tracker, 62);
        if(tracker instanceof EntityTNTPrimed)
            return new Packet23VehicleSpawn(tracker, 50);
        if(tracker instanceof EntityEnderCrystal)
            return new Packet23VehicleSpawn(tracker, 51);
        if(tracker instanceof EntityFallingBlock)
        {
            EntityFallingBlock entityfallingblock = (EntityFallingBlock)tracker;
            if(entityfallingblock.id == Block.SAND.id)
                return new Packet23VehicleSpawn(tracker, 70);
            if(entityfallingblock.id == Block.GRAVEL.id)
                return new Packet23VehicleSpawn(tracker, 71);
            if(entityfallingblock.id == Block.DRAGON_EGG.id)
                return new Packet23VehicleSpawn(tracker, 74);
        }
        if(tracker instanceof EntityPainting)
            return new Packet25EntityPainting((EntityPainting)tracker);
        if(tracker instanceof EntityExperienceOrb)
            return new Packet26AddExpOrb((EntityExperienceOrb)tracker);
        else
            throw new IllegalArgumentException((new StringBuilder()).append("Don't know how to add ").append(tracker.getClass()).append("!").toString());
    }

    public void clear(EntityPlayer entityplayer)
    {
        if(trackedPlayers.contains(entityplayer))
        {
            trackedPlayers.remove(entityplayer);
            entityplayer.netServerHandler.sendPacket(new Packet29DestroyEntity(tracker.id));
        }
    }

    public Entity tracker;
    public int b;
    public int c;
    public int xLoc;
    public int yLoc;
    public int zLoc;
    public int yRot;
    public int xRot;
    public int i;
    public double j;
    public double k;
    public double l;
    public int m;
    private double p;
    private double q;
    private double r;
    private boolean s;
    private boolean isMoving;
    private int u;
    public boolean n;
    public Set trackedPlayers;
}
