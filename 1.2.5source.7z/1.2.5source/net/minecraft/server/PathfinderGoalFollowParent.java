// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Iterator;
import java.util.List;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityAnimal, AxisAlignedBB, World, 
//            Entity, Navigation

public class PathfinderGoalFollowParent extends PathfinderGoal
{

    public PathfinderGoalFollowParent(EntityAnimal entityanimal, float f)
    {
        a = entityanimal;
        c = f;
    }

    public boolean a()
    {
        if(a.getAge() >= 0)
            return false;
        List list = a.world.a(a.getClass(), a.boundingBox.grow(8D, 4D, 8D));
        EntityAnimal entityanimal = null;
        double d1 = 1.7976931348623157E+308D;
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Entity entity = (Entity)iterator.next();
            EntityAnimal entityanimal1 = (EntityAnimal)entity;
            if(entityanimal1.getAge() >= 0)
            {
                double d2 = a.j(entityanimal1);
                if(d2 <= d1)
                {
                    d1 = d2;
                    entityanimal = entityanimal1;
                }
            }
        } while(true);
        if(entityanimal == null)
            return false;
        if(d1 < 9D)
        {
            return false;
        } else
        {
            b = entityanimal;
            return true;
        }
    }

    public boolean b()
    {
        if(!b.isAlive())
            return false;
        double d1 = a.j(b);
        return d1 >= 9D && d1 <= 256D;
    }

    public void c()
    {
        d = 0;
    }

    public void d()
    {
        b = null;
    }

    public void e()
    {
        if(--d > 0)
        {
            return;
        } else
        {
            d = 10;
            a.al().a(b, c);
            return;
        }
    }

    EntityAnimal a;
    EntityAnimal b;
    float c;
    private int d;
}
