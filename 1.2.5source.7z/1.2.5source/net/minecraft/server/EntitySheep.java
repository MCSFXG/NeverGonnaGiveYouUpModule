// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySheep.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Material;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.entity.SheepRegrowWoolEvent;
import org.bukkit.event.player.PlayerShearEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, PathfinderGoalEatTile, PathfinderGoalFloat, PathfinderGoalPanic, 
//            PathfinderGoalBreed, PathfinderGoalTempt, PathfinderGoalFollowParent, PathfinderGoalRandomStroll, 
//            PathfinderGoalLookAtPlayer, EntityHuman, PathfinderGoalRandomLookaround, ItemStack, 
//            Navigation, PathfinderGoalSelector, Item, World, 
//            DataWatcher, Block, PlayerInventory, ItemShears, 
//            EntityItem, NBTTagCompound

public class EntitySheep extends EntityAnimal
{

    public EntitySheep(World world)
    {
        super(world);
        c = new PathfinderGoalEatTile(this);
        texture = "/mob/sheep.png";
        b(0.9F, 1.3F);
        float f = 0.23F;
        al().a(true);
        goalSelector.a(0, new PathfinderGoalFloat(this));
        goalSelector.a(1, new PathfinderGoalPanic(this, 0.38F));
        goalSelector.a(2, new PathfinderGoalBreed(this, f));
        goalSelector.a(3, new PathfinderGoalTempt(this, 0.25F, Item.WHEAT.id, false));
        goalSelector.a(4, new PathfinderGoalFollowParent(this, 0.25F));
        goalSelector.a(5, c);
        goalSelector.a(6, new PathfinderGoalRandomStroll(this, f));
        goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, net/minecraft/server/EntityHuman, 6F));
        goalSelector.a(8, new PathfinderGoalRandomLookaround(this));
    }

    protected boolean c_()
    {
        return true;
    }

    protected void z_()
    {
        b = c.f();
        super.z_();
    }

    public void e()
    {
        if(world.isStatic)
            b = Math.max(0, b - 1);
        super.e();
    }

    public int getMaxHealth()
    {
        return 8;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Byte((byte)0));
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        if(!isSheared())
            loot.add(new ItemStack(Material.WOOL, 1, (short)0, Byte.valueOf((byte)getColor())));
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    protected int getLootId()
    {
        return Block.WOOL.id;
    }

    public boolean b(EntityHuman entityhuman)
    {
        net.minecraft.server.ItemStack itemstack = entityhuman.inventory.getItemInHand();
        if(itemstack != null && itemstack.id == Item.SHEARS.id && !isSheared() && !isBaby())
        {
            if(!world.isStatic)
            {
                PlayerShearEntityEvent event = new PlayerShearEntityEvent((Player)entityhuman.getBukkitEntity(), getBukkitEntity());
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled())
                    return false;
                setSheared(true);
                int i = 1 + random.nextInt(3);
                for(int j = 0; j < i; j++)
                {
                    EntityItem entityitem = a(new net.minecraft.server.ItemStack(Block.WOOL.id, 1, getColor()), 1.0F);
                    entityitem.motY += random.nextFloat() * 0.05F;
                    entityitem.motX += (random.nextFloat() - random.nextFloat()) * 0.1F;
                    entityitem.motZ += (random.nextFloat() - random.nextFloat()) * 0.1F;
                }

            }
            itemstack.damage(1, entityhuman);
        }
        return super.b(entityhuman);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setBoolean("Sheared", isSheared());
        nbttagcompound.setByte("Color", (byte)getColor());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setSheared(nbttagcompound.getBoolean("Sheared"));
        setColor(nbttagcompound.getByte("Color"));
    }

    protected String i()
    {
        return "mob.sheep";
    }

    protected String j()
    {
        return "mob.sheep";
    }

    protected String k()
    {
        return "mob.sheep";
    }

    public int getColor()
    {
        return datawatcher.getByte(16) & 0xf;
    }

    public void setColor(int i)
    {
        byte b0 = datawatcher.getByte(16);
        datawatcher.watch(16, Byte.valueOf((byte)(b0 & 0xf0 | i & 0xf)));
    }

    public boolean isSheared()
    {
        return (datawatcher.getByte(16) & 0x10) != 0;
    }

    public void setSheared(boolean flag)
    {
        byte b0 = datawatcher.getByte(16);
        if(flag)
            datawatcher.watch(16, Byte.valueOf((byte)(b0 | 0x10)));
        else
            datawatcher.watch(16, Byte.valueOf((byte)(b0 & 0xffffffef)));
    }

    public static int a(Random random)
    {
        int i = random.nextInt(100);
        return i >= 5 ? i >= 10 ? i >= 15 ? i >= 18 ? ((byte)(random.nextInt(500) != 0 ? 0 : 6)) : 12 : 8 : 7 : 15;
    }

    public EntityAnimal createChild(EntityAnimal entityanimal)
    {
        EntitySheep entitysheep = (EntitySheep)entityanimal;
        EntitySheep entitysheep1 = new EntitySheep(world);
        if(random.nextBoolean())
            entitysheep1.setColor(getColor());
        else
            entitysheep1.setColor(entitysheep.getColor());
        return entitysheep1;
    }

    public void z()
    {
        SheepRegrowWoolEvent event = new SheepRegrowWoolEvent((Sheep)getBukkitEntity());
        world.getServer().getPluginManager().callEvent(event);
        if(!event.isCancelled())
            setSheared(false);
        if(isBaby())
        {
            int i = getAge() + 1200;
            if(i > 0)
                i = 0;
            setAge(i);
        }
    }

    public static final float a[][] = {
        {
            1.0F, 1.0F, 1.0F
        }, {
            0.95F, 0.7F, 0.2F
        }, {
            0.9F, 0.5F, 0.85F
        }, {
            0.6F, 0.7F, 0.95F
        }, {
            0.9F, 0.9F, 0.2F
        }, {
            0.5F, 0.8F, 0.1F
        }, {
            0.95F, 0.7F, 0.8F
        }, {
            0.3F, 0.3F, 0.3F
        }, {
            0.6F, 0.6F, 0.6F
        }, {
            0.3F, 0.6F, 0.7F
        }, {
            0.7F, 0.4F, 0.9F
        }, {
            0.2F, 0.4F, 0.8F
        }, {
            0.5F, 0.4F, 0.3F
        }, {
            0.4F, 0.5F, 0.2F
        }, {
            0.8F, 0.3F, 0.3F
        }, {
            0.1F, 0.1F, 0.1F
        }
    };
    private int b;
    private PathfinderGoalEatTile c;

}
