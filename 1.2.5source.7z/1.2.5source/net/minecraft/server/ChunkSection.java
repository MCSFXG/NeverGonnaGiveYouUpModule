// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ChunkSection.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            NibbleArray, Block

public class ChunkSection
{

    public ChunkSection(int i)
    {
        a = i;
        d = new byte[4096];
        f = new NibbleArray(d.length, 4);
        h = new NibbleArray(d.length, 4);
        g = new NibbleArray(d.length, 4);
    }

    public ChunkSection(int y, byte blkData[], byte extBlkData[])
    {
        a = y;
        d = blkData;
        if(extBlkData != null)
            e = new NibbleArray(extBlkData, 4);
        f = new NibbleArray(d.length, 4);
        h = new NibbleArray(d.length, 4);
        g = new NibbleArray(d.length, 4);
        d();
    }

    public int a(int i, int j, int k)
    {
        int l = d[j << 8 | k << 4 | i] & 0xff;
        return e == null ? l : e.a(i, j, k) << 8 | l;
    }

    public void a(int i, int j, int k, int l)
    {
        int i1 = d[j << 8 | k << 4 | i] & 0xff;
        if(e != null)
            i1 |= e.a(i, j, k) << 8;
        if(i1 == 0 && l != 0)
        {
            b++;
            if(Block.byId[l] != null && Block.byId[l].n())
                c++;
        } else
        if(i1 != 0 && l == 0)
        {
            b--;
            if(Block.byId[i1] != null && Block.byId[i1].n())
                c--;
        } else
        if(Block.byId[i1] != null && Block.byId[i1].n() && (Block.byId[l] == null || !Block.byId[l].n()))
            c--;
        else
        if((Block.byId[i1] == null || !Block.byId[i1].n()) && Block.byId[l] != null && Block.byId[l].n())
            c++;
        d[j << 8 | k << 4 | i] = (byte)(l & 0xff);
        if(l > 255)
        {
            if(e == null)
                e = new NibbleArray(d.length, 4);
            e.a(i, j, k, (l & 0xf00) >> 8);
        } else
        if(e != null)
            e.a(i, j, k, 0);
    }

    public int b(int i, int j, int k)
    {
        return f.a(i, j, k);
    }

    public void b(int i, int j, int k, int l)
    {
        f.a(i, j, k, l);
    }

    public boolean a()
    {
        return b == 0;
    }

    public boolean b()
    {
        return c > 0;
    }

    public int c()
    {
        return a;
    }

    public void c(int i, int j, int k, int l)
    {
        h.a(i, j, k, l);
    }

    public int c(int i, int j, int k)
    {
        return h.a(i, j, k);
    }

    public void d(int i, int j, int k, int l)
    {
        g.a(i, j, k, l);
    }

    public int d(int i, int j, int k)
    {
        return g.a(i, j, k);
    }

    public void d()
    {
        b = 0;
        c = 0;
        for(int i = 0; i < 16; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                for(int k = 0; k < 16; k++)
                {
                    int l = a(i, j, k);
                    if(l <= 0)
                        continue;
                    if(Block.byId[l] == null)
                    {
                        d[j << 8 | k << 4 | i] = 0;
                        if(e != null)
                            e.a(i, j, k, 0);
                        continue;
                    }
                    b++;
                    if(Block.byId[l].n())
                        c++;
                }

            }

        }

    }

    public void e()
    {
    }

    public int f()
    {
        return b;
    }

    public byte[] g()
    {
        return d;
    }

    public NibbleArray h()
    {
        return e;
    }

    public NibbleArray i()
    {
        return f;
    }

    public NibbleArray j()
    {
        return g;
    }

    public NibbleArray k()
    {
        return h;
    }

    public void a(byte abyte[])
    {
        d = abyte;
    }

    public void a(NibbleArray nibblearray)
    {
        e = nibblearray;
    }

    public void b(NibbleArray nibblearray)
    {
        f = nibblearray;
    }

    public void c(NibbleArray nibblearray)
    {
        g = nibblearray;
    }

    public void d(NibbleArray nibblearray)
    {
        h = nibblearray;
    }

    private int a;
    private int b;
    private int c;
    private byte d[];
    private NibbleArray e;
    private NibbleArray f;
    private NibbleArray g;
    private NibbleArray h;
}
