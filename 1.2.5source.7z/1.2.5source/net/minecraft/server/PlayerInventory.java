// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PlayerInventory.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            ItemStack, NBTTagCompound, ItemArmor, IInventory, 
//            EntityHuman, PlayerAbilities, NBTTagList, Block, 
//            Material, Entity

public class PlayerInventory
    implements IInventory
{

    public ItemStack[] getContents()
    {
        return items;
    }

    public ItemStack[] getArmorContents()
    {
        return armor;
    }

    public void onOpen(CraftHumanEntity who)
    {
        transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        transaction.remove(who);
    }

    public List getViewers()
    {
        return transaction;
    }

    public InventoryHolder getOwner()
    {
        return player.getBukkitEntity();
    }

    public void setMaxStackSize(int size)
    {
        maxStack = size;
    }

    public PlayerInventory(EntityHuman entityhuman)
    {
        items = new ItemStack[36];
        armor = new ItemStack[4];
        itemInHandIndex = 0;
        e = false;
        transaction = new ArrayList();
        maxStack = 64;
        player = entityhuman;
    }

    public ItemStack getItemInHand()
    {
        return itemInHandIndex >= 9 || itemInHandIndex < 0 ? null : items[itemInHandIndex];
    }

    public static int getHotbarSize()
    {
        return 9;
    }

    private int f(int i)
    {
        for(int j = 0; j < items.length; j++)
            if(items[j] != null && items[j].id == i)
                return j;

        return -1;
    }

    private int firstPartial(ItemStack itemstack)
    {
        for(int i = 0; i < items.length; i++)
            if(items[i] != null && items[i].id == itemstack.id && items[i].isStackable() && items[i].count < items[i].getMaxStackSize() && items[i].count < getMaxStackSize() && (!items[i].usesData() || items[i].getData() == itemstack.getData()) && ItemStack.equals(items[i], itemstack))
                return i;

        return -1;
    }

    public int canHold(ItemStack itemstack)
    {
        int remains = itemstack.count;
        for(int i = 0; i < items.length; i++)
        {
            if(items[i] == null)
                return itemstack.count;
            if(items[i] != null && items[i].id == itemstack.id && items[i].isStackable() && items[i].count < items[i].getMaxStackSize() && items[i].count < getMaxStackSize() && (!items[i].usesData() || items[i].getData() == itemstack.getData()))
                remains -= (items[i].getMaxStackSize() >= getMaxStackSize() ? getMaxStackSize() : items[i].getMaxStackSize()) - items[i].count;
            if(remains <= 0)
                return itemstack.count;
        }

        return itemstack.count - remains;
    }

    private int m()
    {
        for(int i = 0; i < items.length; i++)
            if(items[i] == null)
                return i;

        return -1;
    }

    private int e(ItemStack itemstack)
    {
        int i = itemstack.id;
        int j = itemstack.count;
        int k;
        if(itemstack.getMaxStackSize() == 1)
        {
            k = m();
            if(k < 0)
                return j;
            if(items[k] == null)
                items[k] = ItemStack.b(itemstack);
            return 0;
        }
        k = firstPartial(itemstack);
        if(k < 0)
            k = m();
        if(k < 0)
            return j;
        if(items[k] == null)
        {
            items[k] = new ItemStack(i, 0, itemstack.getData());
            if(itemstack.hasTag())
                items[k].setTag((NBTTagCompound)itemstack.getTag().clone());
        }
        int l = j;
        if(j > items[k].getMaxStackSize() - items[k].count)
            l = items[k].getMaxStackSize() - items[k].count;
        if(l > getMaxStackSize() - items[k].count)
            l = getMaxStackSize() - items[k].count;
        if(l == 0)
        {
            return j;
        } else
        {
            j -= l;
            items[k].count += l;
            items[k].b = 5;
            return j;
        }
    }

    public void i()
    {
        for(int i = 0; i < items.length; i++)
            if(items[i] != null)
                items[i].a(player.world, player, i, itemInHandIndex == i);

    }

    public boolean c(int i)
    {
        int j = f(i);
        if(j < 0)
            return false;
        if(--items[j].count <= 0)
            items[j] = null;
        return true;
    }

    public boolean d(int i)
    {
        int j = f(i);
        return j >= 0;
    }

    public boolean pickup(ItemStack itemstack)
    {
        int i;
        if(itemstack.f())
        {
            i = m();
            if(i >= 0)
            {
                items[i] = ItemStack.b(itemstack);
                items[i].b = 5;
                itemstack.count = 0;
                return true;
            }
            if(player.abilities.canInstantlyBuild)
            {
                itemstack.count = 0;
                return true;
            } else
            {
                return false;
            }
        }
        do
        {
            i = itemstack.count;
            itemstack.count = e(itemstack);
        } while(itemstack.count > 0 && itemstack.count < i);
        if(itemstack.count == i && player.abilities.canInstantlyBuild)
        {
            itemstack.count = 0;
            return true;
        } else
        {
            return itemstack.count < i;
        }
    }

    public ItemStack splitStack(int i, int j)
    {
        ItemStack aitemstack[] = items;
        if(i >= items.length)
        {
            aitemstack = armor;
            i -= items.length;
        }
        if(aitemstack[i] != null)
        {
            ItemStack itemstack;
            if(aitemstack[i].count <= j)
            {
                itemstack = aitemstack[i];
                aitemstack[i] = null;
                return itemstack;
            }
            itemstack = aitemstack[i].a(j);
            if(aitemstack[i].count == 0)
                aitemstack[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public ItemStack splitWithoutUpdate(int i)
    {
        ItemStack aitemstack[] = items;
        if(i >= items.length)
        {
            aitemstack = armor;
            i -= items.length;
        }
        if(aitemstack[i] != null)
        {
            ItemStack itemstack = aitemstack[i];
            aitemstack[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        ItemStack aitemstack[] = items;
        if(i >= aitemstack.length)
        {
            i -= aitemstack.length;
            aitemstack = armor;
        }
        aitemstack[i] = itemstack;
    }

    public float a(Block block)
    {
        float f = 1.0F;
        if(items[itemInHandIndex] != null)
            f *= items[itemInHandIndex].a(block);
        return f;
    }

    public NBTTagList a(NBTTagList nbttaglist)
    {
        for(int i = 0; i < items.length; i++)
            if(items[i] != null)
            {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Slot", (byte)i);
                items[i].save(nbttagcompound);
                nbttaglist.add(nbttagcompound);
            }

        for(int i = 0; i < armor.length; i++)
            if(armor[i] != null)
            {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Slot", (byte)(i + 100));
                armor[i].save(nbttagcompound);
                nbttaglist.add(nbttagcompound);
            }

        return nbttaglist;
    }

    public void b(NBTTagList nbttaglist)
    {
        items = new ItemStack[36];
        armor = new ItemStack[4];
        for(int i = 0; i < nbttaglist.size(); i++)
        {
            NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.get(i);
            int j = nbttagcompound.getByte("Slot") & 0xff;
            ItemStack itemstack = ItemStack.a(nbttagcompound);
            if(itemstack == null)
                continue;
            if(j >= 0 && j < items.length)
                items[j] = itemstack;
            if(j >= 100 && j < armor.length + 100)
                armor[j - 100] = itemstack;
        }

    }

    public int getSize()
    {
        return items.length + 4;
    }

    public ItemStack getItem(int i)
    {
        ItemStack aitemstack[] = items;
        if(i >= aitemstack.length)
        {
            i -= aitemstack.length;
            aitemstack = armor;
        }
        return aitemstack[i];
    }

    public String getName()
    {
        return "container.inventory";
    }

    public int getMaxStackSize()
    {
        return maxStack;
    }

    public int a(Entity entity)
    {
        ItemStack itemstack = getItem(itemInHandIndex);
        return itemstack == null ? 1 : itemstack.a(entity);
    }

    public boolean b(Block block)
    {
        if(block == null)
            return false;
        if(block.material.isAlwaysDestroyable())
        {
            return true;
        } else
        {
            ItemStack itemstack = getItem(itemInHandIndex);
            return itemstack == null ? false : itemstack.b(block);
        }
    }

    public int j()
    {
        int i = 0;
        for(int j = 0; j < armor.length; j++)
            if(armor[j] != null && (armor[j].getItem() instanceof ItemArmor))
            {
                int k = ((ItemArmor)armor[j].getItem()).b;
                i += k;
            }

        return i;
    }

    public void e(int i)
    {
        i /= 4;
        if(i < 1)
            i = 1;
        for(int j = 0; j < armor.length; j++)
        {
            if(armor[j] == null || !(armor[j].getItem() instanceof ItemArmor))
                continue;
            armor[j].damage(i, player);
            if(armor[j].count == 0)
            {
                armor[j].a(player);
                armor[j] = null;
            }
        }

    }

    public void k()
    {
        for(int i = 0; i < items.length; i++)
            if(items[i] != null)
            {
                player.a(items[i], true);
                items[i] = null;
            }

        for(int i = 0; i < armor.length; i++)
            if(armor[i] != null)
            {
                player.a(armor[i], true);
                armor[i] = null;
            }

    }

    public void update()
    {
        e = true;
    }

    public void setCarried(ItemStack itemstack)
    {
        f = itemstack;
        player.carriedChanged(itemstack);
    }

    public ItemStack getCarried()
    {
        if(f != null && f.count == 0)
            setCarried(null);
        return f;
    }

    public boolean a(EntityHuman entityhuman)
    {
        return player.dead ? false : entityhuman.j(player) <= 64D;
    }

    public boolean c(ItemStack itemstack)
    {
        for(int i = 0; i < armor.length; i++)
            if(armor[i] != null && armor[i].c(itemstack))
                return true;

        for(int i = 0; i < items.length; i++)
            if(items[i] != null && items[i].c(itemstack))
                return true;

        return false;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    public void a(PlayerInventory playerinventory)
    {
        for(int i = 0; i < items.length; i++)
            items[i] = ItemStack.b(playerinventory.items[i]);

        for(int i = 0; i < armor.length; i++)
            armor[i] = ItemStack.b(playerinventory.armor[i]);

    }

    public ItemStack items[];
    public ItemStack armor[];
    public int itemInHandIndex;
    public EntityHuman player;
    private ItemStack f;
    public boolean e;
    public List transaction;
    private int maxStack;
}
