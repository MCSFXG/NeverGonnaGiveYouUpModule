// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            LocaleLanguage

public class LocaleI18n
{

    public LocaleI18n()
    {
    }

    public static String get(String s)
    {
        return a.b(s);
    }

    public static transient String get(String s, Object aobj[])
    {
        return a.a(s, aobj);
    }

    private static LocaleLanguage a = LocaleLanguage.a();

}
