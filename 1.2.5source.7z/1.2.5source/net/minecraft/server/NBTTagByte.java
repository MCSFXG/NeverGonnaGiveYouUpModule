// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagByte extends NBTBase
{

    public NBTTagByte(String s)
    {
        super(s);
    }

    public NBTTagByte(String s, byte byte0)
    {
        super(s);
        data = byte0;
    }

    void write(DataOutput dataoutput)
    {
        dataoutput.writeByte(data);
    }

    void load(DataInput datainput)
    {
        data = datainput.readByte();
    }

    public byte getTypeId()
    {
        return 1;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(data).toString();
    }

    public NBTBase clone()
    {
        return new NBTTagByte(getName(), data);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagByte nbttagbyte = (NBTTagByte)obj;
            return data == nbttagbyte.data;
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        return super.hashCode() ^ data;
    }

    public byte data;
}
