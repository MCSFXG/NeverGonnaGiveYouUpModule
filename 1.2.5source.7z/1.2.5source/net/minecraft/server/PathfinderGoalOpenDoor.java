// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoalDoorInteract, EntityLiving, BlockDoor

public class PathfinderGoalOpenDoor extends PathfinderGoalDoorInteract
{

    public PathfinderGoalOpenDoor(EntityLiving entityliving, boolean flag)
    {
        super(entityliving);
        a = entityliving;
        i = flag;
    }

    public boolean b()
    {
        return i && j > 0 && super.b();
    }

    public void c()
    {
        j = 20;
        e.setDoor(a.world, b, c, d, true);
    }

    public void d()
    {
        if(i)
            e.setDoor(a.world, b, c, d, false);
    }

    public void e()
    {
        j--;
        super.e();
    }

    boolean i;
    int j;
}
