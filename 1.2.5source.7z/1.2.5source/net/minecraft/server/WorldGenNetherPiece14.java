// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            WorldGenNetherPiece, WorldGenNetherPiece15, StructureBoundingBox, StructurePiece, 
//            Block, World

public class WorldGenNetherPiece14 extends WorldGenNetherPiece
{

    public WorldGenNetherPiece14(int i, Random random, StructureBoundingBox structureboundingbox, int j)
    {
        super(i);
        h = j;
        g = structureboundingbox;
    }

    public void a(StructurePiece structurepiece, List list, Random random)
    {
        a((WorldGenNetherPiece15)structurepiece, list, random, 1, 0, true);
    }

    public static WorldGenNetherPiece14 a(List list, Random random, int i, int j, int k, int l, int i1)
    {
        StructureBoundingBox structureboundingbox = StructureBoundingBox.a(i, j, k, -1, -7, 0, 5, 14, 10, l);
        if(!a(structureboundingbox) || StructurePiece.a(list, structureboundingbox) != null)
            return null;
        else
            return new WorldGenNetherPiece14(i1, random, structureboundingbox, l);
    }

    public boolean a(World world, Random random, StructureBoundingBox structureboundingbox)
    {
        int i = c(Block.NETHER_BRICK_STAIRS.id, 2);
        for(int j = 0; j <= 9; j++)
        {
            int k = Math.max(1, 7 - j);
            int l = Math.min(Math.max(k + 5, 14 - j), 13);
            int i1 = j;
            a(world, structureboundingbox, 0, 0, i1, 4, k, i1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            a(world, structureboundingbox, 1, k + 1, i1, 3, l - 1, i1, 0, 0, false);
            if(j <= 6)
            {
                a(world, Block.NETHER_BRICK_STAIRS.id, i, 1, k + 1, i1, structureboundingbox);
                a(world, Block.NETHER_BRICK_STAIRS.id, i, 2, k + 1, i1, structureboundingbox);
                a(world, Block.NETHER_BRICK_STAIRS.id, i, 3, k + 1, i1, structureboundingbox);
            }
            a(world, structureboundingbox, 0, l, i1, 4, l, i1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            a(world, structureboundingbox, 0, k + 1, i1, 0, l - 1, i1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            a(world, structureboundingbox, 4, k + 1, i1, 4, l - 1, i1, Block.NETHER_BRICK.id, Block.NETHER_BRICK.id, false);
            if((j & 1) == 0)
            {
                a(world, structureboundingbox, 0, k + 2, i1, 0, k + 3, i1, Block.NETHER_FENCE.id, Block.NETHER_FENCE.id, false);
                a(world, structureboundingbox, 4, k + 2, i1, 4, k + 3, i1, Block.NETHER_FENCE.id, Block.NETHER_FENCE.id, false);
            }
            for(int j1 = 0; j1 <= 4; j1++)
                b(world, Block.NETHER_BRICK.id, 0, j1, -1, i1, structureboundingbox);

        }

        return true;
    }
}
