// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Entity, EntityLiving, AxisAlignedBB, MathHelper, 
//            Navigation

public class ControllerLook
{

    public ControllerLook(EntityLiving entityliving)
    {
        d = false;
        a = entityliving;
    }

    public void a(Entity entity, float f1, float f2)
    {
        e = entity.locX;
        if(entity instanceof EntityLiving)
            f = entity.locY + (double)((EntityLiving)entity).getHeadHeight();
        else
            f = (entity.boundingBox.b + entity.boundingBox.e) / 2D;
        g = entity.locZ;
        b = f1;
        c = f2;
        d = true;
    }

    public void a(double d1, double d2, double d3, float f1, 
            float f2)
    {
        e = d1;
        f = d2;
        g = d3;
        b = f1;
        c = f2;
        d = true;
    }

    public void a()
    {
        a.pitch = 0.0F;
        if(d)
        {
            d = false;
            double d1 = e - a.locX;
            double d2 = f - (a.locY + (double)a.getHeadHeight());
            double d3 = g - a.locZ;
            double d4 = MathHelper.sqrt(d1 * d1 + d3 * d3);
            float f1 = (float)((Math.atan2(d3, d1) * 180D) / 3.1415927410125732D) - 90F;
            float f2 = (float)(-((Math.atan2(d2, d4) * 180D) / 3.1415927410125732D));
            a.pitch = a(a.pitch, f2, c);
            a.X = a(a.X, f1, b);
        } else
        {
            a.X = a(a.X, a.V, 10F);
        }
        float f3;
        for(f3 = a.X - a.V; f3 < -180F; f3 += 360F);
        for(; f3 >= 180F; f3 -= 360F);
        if(!a.al().e())
        {
            if(f3 < -75F)
                a.X = a.V - 75F;
            if(f3 > 75F)
                a.X = a.V + 75F;
        }
    }

    private float a(float f1, float f2, float f3)
    {
        float f4;
        for(f4 = f2 - f1; f4 < -180F; f4 += 360F);
        for(; f4 >= 180F; f4 -= 360F);
        if(f4 > f3)
            f4 = f3;
        if(f4 < -f3)
            f4 = -f3;
        return f1 + f4;
    }

    private EntityLiving a;
    private float b;
    private float c;
    private boolean d;
    private double e;
    private double f;
    private double g;
}
