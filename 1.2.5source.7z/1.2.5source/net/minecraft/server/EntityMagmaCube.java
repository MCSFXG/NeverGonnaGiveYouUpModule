// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityMagmaCube.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.inventory.ItemStack;

// Referenced classes of package net.minecraft.server:
//            EntitySlime, World, Item

public class EntityMagmaCube extends EntitySlime
{

    public EntityMagmaCube(World world)
    {
        super(world);
        texture = "/mob/lava.png";
        fireProof = true;
        al = 0.2F;
    }

    public boolean canSpawn()
    {
        return world.difficulty > 0 && world.containsEntity(boundingBox) && world.getCubes(this, boundingBox).size() == 0 && !world.containsLiquid(boundingBox);
    }

    public int T()
    {
        return getSize() * 3;
    }

    public float b(float f)
    {
        return 1.0F;
    }

    protected String A()
    {
        return "flame";
    }

    protected EntitySlime C()
    {
        return new EntityMagmaCube(world);
    }

    protected int getLootId()
    {
        return Item.MAGMA_CREAM.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int j = getLootId();
        if(j > 0 && getSize() > 1)
        {
            int k = random.nextInt(4) - 2;
            if(i > 0)
                k += random.nextInt(i + 1);
            if(k > 0)
                loot.add(new ItemStack(j, k));
        }
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public boolean isBurning()
    {
        return false;
    }

    protected int E()
    {
        return super.E() * 4;
    }

    protected void F()
    {
        a *= 0.9F;
    }

    protected void ac()
    {
        motY = 0.42F + (float)getSize() * 0.1F;
        ce = true;
    }

    protected void a(float f1)
    {
    }

    protected boolean G()
    {
        return true;
    }

    protected int H()
    {
        return super.H() + 2;
    }

    protected String j()
    {
        return "mob.slime";
    }

    protected String k()
    {
        return "mob.slime";
    }

    protected String I()
    {
        return getSize() <= 1 ? "mob.magmacube.small" : "mob.magmacube.big";
    }

    public boolean aV()
    {
        return false;
    }

    protected boolean K()
    {
        return true;
    }
}
