// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PlayerInstance.java

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            ChunkCoordIntPair, Packet50PreChunk, EntityPlayer, Packet53BlockChange, 
//            Packet51MapChunk, TileEntity, Packet52MultiBlockChange, PlayerManager, 
//            WorldServer, ChunkProviderServer, NetServerHandler, LongHashMap, 
//            Packet

class PlayerInstance
{

    public PlayerInstance(PlayerManager playermanager, int i, int j)
    {
        playerManager = playermanager;
        b = new ArrayList();
        dirtyBlocks = new short[64];
        dirtyCount = 0;
        chunkX = i;
        chunkZ = j;
        location = new ChunkCoordIntPair(i, j);
        playermanager.a().chunkProviderServer.getChunkAt(i, j);
    }

    public void a(EntityPlayer entityplayer)
    {
        if(b.contains(entityplayer))
            throw new IllegalStateException((new StringBuilder()).append("Failed to add player. ").append(entityplayer).append(" already is in chunk ").append(chunkX).append(", ").append(chunkZ).toString());
        if(entityplayer.playerChunkCoordIntPairs.add(location))
            entityplayer.netServerHandler.sendPacket(new Packet50PreChunk(location.x, location.z, true));
        b.add(entityplayer);
        entityplayer.chunkCoordIntPairQueue.add(location);
    }

    public void b(EntityPlayer entityplayer)
    {
        if(b.contains(entityplayer))
        {
            b.remove(entityplayer);
            if(b.size() == 0)
            {
                long i = (long)chunkX + 0x7fffffffL | (long)chunkZ + 0x7fffffffL << 32;
                PlayerManager.a(playerManager).remove(i);
                if(dirtyCount > 0)
                    PlayerManager.b(playerManager).remove(this);
                playerManager.a().chunkProviderServer.queueUnload(chunkX, chunkZ);
            }
            entityplayer.chunkCoordIntPairQueue.remove(location);
            if(entityplayer.playerChunkCoordIntPairs.remove(location))
                entityplayer.netServerHandler.sendPacket(new Packet50PreChunk(chunkX, chunkZ, false));
        }
    }

    public void a(int i, int j, int k)
    {
        if(dirtyCount == 0)
            PlayerManager.b(playerManager).add(this);
        h |= 1 << (j >> 4);
        if(dirtyCount < 64)
        {
            short short1 = (short)(i << 12 | k << 8 | j);
            for(int l = 0; l < dirtyCount; l++)
                if(dirtyBlocks[l] == short1)
                    return;

            dirtyBlocks[dirtyCount++] = short1;
        }
    }

    public void sendAll(Packet packet)
    {
        for(int i = 0; i < b.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)b.get(i);
            if(entityplayer.playerChunkCoordIntPairs.contains(location) && !entityplayer.chunkCoordIntPairQueue.contains(location))
                entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public void a()
    {
        WorldServer worldserver = playerManager.a();
        if(dirtyCount != 0)
        {
            if(dirtyCount == 1)
            {
                int i = chunkX * 16 + (dirtyBlocks[0] >> 12 & 0xf);
                int j = dirtyBlocks[0] & 0xff;
                int k = chunkZ * 16 + (dirtyBlocks[0] >> 8 & 0xf);
                sendAll(new Packet53BlockChange(i, j, k, worldserver));
                if(worldserver.isTileEntity(i, j, k))
                    sendTileEntity(worldserver.getTileEntity(i, j, k));
            } else
            if(dirtyCount == 64)
            {
                int i = chunkX * 16;
                int j = chunkZ * 16;
                sendAll(new Packet51MapChunk(worldserver.getChunkAt(chunkX, chunkZ), false, h));
                for(int k = 0; k < 16; k++)
                    if((h & 1 << k) != 0)
                    {
                        int l = k << 4;
                        List list = worldserver.getTileEntities(i, l, j, i + 16, l + 16, j + 16);
                        for(int i1 = 0; i1 < list.size(); i1++)
                            sendTileEntity((TileEntity)list.get(i1));

                    }

            } else
            {
                sendAll(new Packet52MultiBlockChange(chunkX, chunkZ, dirtyBlocks, dirtyCount, worldserver));
                for(int i = 0; i < dirtyCount; i++)
                {
                    int j = chunkX * 16 + (dirtyBlocks[i] >> 12 & 0xf);
                    int k = dirtyBlocks[i] & 0xff;
                    int l = chunkZ * 16 + (dirtyBlocks[i] >> 8 & 0xf);
                    if(worldserver.isTileEntity(j, k, l))
                        sendTileEntity(worldserver.getTileEntity(j, k, l));
                }

            }
            dirtyCount = 0;
            h = 0;
        }
    }

    private void sendTileEntity(TileEntity tileentity)
    {
        if(tileentity != null)
        {
            Packet packet = tileentity.d();
            if(packet != null)
                sendAll(packet);
        }
    }

    private List b;
    private int chunkX;
    private int chunkZ;
    private ChunkCoordIntPair location;
    private short dirtyBlocks[];
    private int dirtyCount;
    private int h;
    final PlayerManager playerManager;
}
