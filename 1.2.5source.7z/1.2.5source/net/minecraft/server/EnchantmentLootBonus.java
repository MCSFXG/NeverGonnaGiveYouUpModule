// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType

public class EnchantmentLootBonus extends Enchantment
{

    protected EnchantmentLootBonus(int i, int j, EnchantmentSlotType enchantmentslottype)
    {
        super(i, j, enchantmentslottype);
        a("lootBonus");
        if(enchantmentslottype == EnchantmentSlotType.DIGGER)
            a("lootBonusDigger");
    }

    public int a(int i)
    {
        return 20 + (i - 1) * 12;
    }

    public int b(int i)
    {
        return super.a(i) + 50;
    }

    public int getMaxLevel()
    {
        return 3;
    }

    public boolean a(Enchantment enchantment)
    {
        return super.a(enchantment) && enchantment.id != SILK_TOUCH.id;
    }
}
