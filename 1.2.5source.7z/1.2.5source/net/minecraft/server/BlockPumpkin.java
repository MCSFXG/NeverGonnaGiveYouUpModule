// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BlockPumpkin.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.util.BlockStateListPopulator;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            BlockDirectional, EntitySnowman, EntityIronGolem, Material, 
//            World, Block, EntityLiving, MathHelper

public class BlockPumpkin extends BlockDirectional
{

    protected BlockPumpkin(int i, int j, boolean flag)
    {
        super(i, Material.PUMPKIN);
        textureId = j;
        a(true);
        a = flag;
    }

    public int a(int i, int j)
    {
        if(i == 1)
            return textureId;
        if(i == 0)
            return textureId;
        int k = textureId + 1 + 16;
        if(a)
            k++;
        return j != 2 || i != 2 ? j != 3 || i != 5 ? j != 0 || i != 3 ? j != 1 || i != 4 ? textureId + 16 : k : k : k : k;
    }

    public int a(int i)
    {
        return i != 1 ? i != 0 ? i != 3 ? textureId + 16 : textureId + 1 + 16 : textureId : textureId;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);
        if(world.suppressPhysics)
            return;
        if(world.getTypeId(i, j - 1, k) == Block.SNOW_BLOCK.id && world.getTypeId(i, j - 2, k) == Block.SNOW_BLOCK.id)
        {
            if(!world.isStatic)
            {
                BlockStateListPopulator blockList = new BlockStateListPopulator(world.getWorld());
                blockList.setTypeId(i, j, k, 0);
                blockList.setTypeId(i, j - 1, k, 0);
                blockList.setTypeId(i, j - 2, k, 0);
                EntitySnowman entitysnowman = new EntitySnowman(world);
                entitysnowman.setPositionRotation((double)i + 0.5D, (double)j - 1.95D, (double)k + 0.5D, 0.0F, 0.0F);
                if(world.addEntity(entitysnowman, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.BUILD_SNOWMAN))
                    blockList.updateList();
            }
            for(int l = 0; l < 120; l++)
                world.a("snowshovel", (double)i + world.random.nextDouble(), (double)(j - 2) + world.random.nextDouble() * 2.5D, (double)k + world.random.nextDouble(), 0.0D, 0.0D, 0.0D);

        } else
        if(world.getTypeId(i, j - 1, k) == Block.IRON_BLOCK.id && world.getTypeId(i, j - 2, k) == Block.IRON_BLOCK.id)
        {
            boolean flag = world.getTypeId(i - 1, j - 1, k) == Block.IRON_BLOCK.id && world.getTypeId(i + 1, j - 1, k) == Block.IRON_BLOCK.id;
            boolean flag1 = world.getTypeId(i, j - 1, k - 1) == Block.IRON_BLOCK.id && world.getTypeId(i, j - 1, k + 1) == Block.IRON_BLOCK.id;
            if(flag || flag1)
            {
                BlockStateListPopulator blockList = new BlockStateListPopulator(world.getWorld());
                blockList.setTypeId(i, j, k, 0);
                blockList.setTypeId(i, j - 1, k, 0);
                blockList.setTypeId(i, j - 2, k, 0);
                if(flag)
                {
                    blockList.setTypeId(i - 1, j - 1, k, 0);
                    blockList.setTypeId(i + 1, j - 1, k, 0);
                } else
                {
                    blockList.setTypeId(i, j - 1, k - 1, 0);
                    blockList.setTypeId(i, j - 1, k + 1, 0);
                }
                EntityIronGolem entityirongolem = new EntityIronGolem(world);
                entityirongolem.b(true);
                entityirongolem.setPositionRotation((double)i + 0.5D, (double)j - 1.95D, (double)k + 0.5D, 0.0F, 0.0F);
                if(world.addEntity(entityirongolem, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.BUILD_IRONGOLEM))
                {
                    for(int i1 = 0; i1 < 120; i1++)
                        world.a("snowballpoof", (double)i + world.random.nextDouble(), (double)(j - 2) + world.random.nextDouble() * 3.8999999999999999D, (double)k + world.random.nextDouble(), 0.0D, 0.0D, 0.0D);

                    blockList.updateList();
                }
            }
        }
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j, k);
        return (l == 0 || Block.byId[l].material.isReplacable()) && world.e(i, j - 1, k);
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving)
    {
        int l = MathHelper.floor((double)((entityliving.yaw * 4F) / 360F) + 2.5D) & 3;
        world.setData(i, j, k, l);
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if(Block.byId[l] != null && Block.byId[l].isPowerSource())
        {
            Block block = world.getWorld().getBlockAt(i, j, k);
            int power = block.getBlockPower();
            BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, power, power);
            world.getServer().getPluginManager().callEvent(eventRedstone);
        }
    }

    private boolean a;
}
