// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerEnchantTableInventory.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ContainerEnchantTableSubcontainer, ContainerEnchantTable

public class ContainerEnchantTableInventory extends ContainerEnchantTableSubcontainer
{

    ContainerEnchantTableInventory(ContainerEnchantTable containerenchanttable, String s, int i)
    {
        super(s, i);
        enchantTable = containerenchanttable;
        super.setMaxStackSize(1);
    }

    public int getMaxStackSize()
    {
        return super.getMaxStackSize();
    }

    public void update()
    {
        super.update();
        enchantTable.a(this);
    }

    public final ContainerEnchantTable enchantTable;
}
