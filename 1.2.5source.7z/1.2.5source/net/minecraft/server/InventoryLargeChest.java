// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   InventoryLargeChest.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            ItemStack, IInventory, EntityHuman

public class InventoryLargeChest
    implements IInventory
{

    public ItemStack[] getContents()
    {
        ItemStack result[] = new ItemStack[getSize()];
        for(int i = 0; i < result.length; i++)
            result[i] = getItem(i);

        return result;
    }

    public void onOpen(CraftHumanEntity who)
    {
        left.onOpen(who);
        right.onOpen(who);
        transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        left.onClose(who);
        right.onClose(who);
        transaction.remove(who);
    }

    public List getViewers()
    {
        return transaction;
    }

    public InventoryHolder getOwner()
    {
        return null;
    }

    public void setMaxStackSize(int size)
    {
        left.setMaxStackSize(size);
        right.setMaxStackSize(size);
    }

    public InventoryLargeChest(String s, IInventory iinventory, IInventory iinventory1)
    {
        transaction = new ArrayList();
        a = s;
        if(iinventory == null)
            iinventory = iinventory1;
        if(iinventory1 == null)
            iinventory1 = iinventory;
        left = iinventory;
        right = iinventory1;
    }

    public int getSize()
    {
        return left.getSize() + right.getSize();
    }

    public String getName()
    {
        return a;
    }

    public ItemStack getItem(int i)
    {
        return i < left.getSize() ? left.getItem(i) : right.getItem(i - left.getSize());
    }

    public ItemStack splitStack(int i, int j)
    {
        return i < left.getSize() ? left.splitStack(i, j) : right.splitStack(i - left.getSize(), j);
    }

    public ItemStack splitWithoutUpdate(int i)
    {
        return i < left.getSize() ? left.splitWithoutUpdate(i) : right.splitWithoutUpdate(i - left.getSize());
    }

    public void setItem(int i, ItemStack itemstack)
    {
        if(i >= left.getSize())
            right.setItem(i - left.getSize(), itemstack);
        else
            left.setItem(i, itemstack);
    }

    public int getMaxStackSize()
    {
        return Math.min(left.getMaxStackSize(), right.getMaxStackSize());
    }

    public void update()
    {
        left.update();
        right.update();
    }

    public boolean a(EntityHuman entityhuman)
    {
        return left.a(entityhuman) && right.a(entityhuman);
    }

    public void f()
    {
        left.f();
        right.f();
    }

    public void g()
    {
        left.g();
        right.g();
    }

    private String a;
    public IInventory left;
    public IInventory right;
    public List transaction;
}
