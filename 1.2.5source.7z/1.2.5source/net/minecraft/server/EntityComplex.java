// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityComplex.java

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            EntityLiving, World, EntityComplexPart, DamageSource

public class EntityComplex extends EntityLiving
{

    public EntityComplex(World world)
    {
        super(world);
        t = 100;
    }

    public int getMaxHealth()
    {
        return t;
    }

    public boolean a(EntityComplexPart entitycomplexpart, DamageSource damagesource, int i)
    {
        return damageEntity(damagesource, i);
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        return false;
    }

    public boolean dealDamage(DamageSource damagesource, int i)
    {
        return super.damageEntity(damagesource, i);
    }

    protected int t;
}
