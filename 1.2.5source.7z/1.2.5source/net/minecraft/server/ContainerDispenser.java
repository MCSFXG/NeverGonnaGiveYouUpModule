// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerDispenser.java

package net.minecraft.server;

import java.util.List;
import org.bukkit.craftbukkit.inventory.CraftInventory;
import org.bukkit.craftbukkit.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

// Referenced classes of package net.minecraft.server:
//            Container, PlayerInventory, Slot, ItemStack, 
//            TileEntityDispenser, EntityHuman, IInventory

public class ContainerDispenser extends Container
{

    public ContainerDispenser(IInventory iinventory, TileEntityDispenser tileentitydispenser)
    {
        bukkitEntity = null;
        items = tileentitydispenser;
        player = (PlayerInventory)iinventory;
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 3; j++)
                a(new Slot(tileentitydispenser, j + i * 3, 62 + j * 18, 17 + i * 18));

        }

        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 9; j++)
                a(new Slot(iinventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));

        }

        for(int i = 0; i < 9; i++)
            a(new Slot(iinventory, i, 8 + i * 18, 142));

    }

    public boolean b(EntityHuman entityhuman)
    {
        if(!checkReachable)
            return true;
        else
            return items.a(entityhuman);
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i < 9)
            {
                if(!a(itemstack1, 9, 45, true))
                    return null;
            } else
            if(!a(itemstack1, 0, 9, false))
                return null;
            if(itemstack1.count == 0)
                slot.set((ItemStack)null);
            else
                slot.d();
            if(itemstack1.count == itemstack.count)
                return null;
            slot.c(itemstack1);
        }
        return itemstack;
    }

    public CraftInventoryView getBukkitView()
    {
        if(bukkitEntity != null)
        {
            return bukkitEntity;
        } else
        {
            CraftInventory inventory = new CraftInventory(items);
            bukkitEntity = new CraftInventoryView(player.player.getBukkitEntity(), inventory, this);
            return bukkitEntity;
        }
    }

    public volatile InventoryView getBukkitView()
    {
        return getBukkitView();
    }

    public TileEntityDispenser items;
    private CraftInventoryView bukkitEntity;
    private PlayerInventory player;
}
