// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityEnderDragon.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.PortalType;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.util.BlockStateListPopulator;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityComplex, EntityComplexPart, EntityEnderCrystal, Entity, 
//            EntityLiving, EntityHuman, EntityExperienceOrb, Packet53BlockChange, 
//            EntityPlayer, DataWatcher, World, MathHelper, 
//            AxisAlignedBB, Vec3D, DamageSource, Block, 
//            BlockEnderPortal, NetServerHandler

public class EntityEnderDragon extends EntityComplex
{

    public EntityEnderDragon(World world)
    {
        super(world);
        d = new double[64][3];
        e = -1;
        n = 0.0F;
        o = 0.0F;
        p = false;
        q = false;
        r = 0;
        s = null;
        children = (new EntityComplexPart[] {
            g = new EntityComplexPart(this, "head", 6F, 6F), h = new EntityComplexPart(this, "body", 8F, 8F), i = new EntityComplexPart(this, "tail", 4F, 4F), j = new EntityComplexPart(this, "tail", 4F, 4F), k = new EntityComplexPart(this, "tail", 4F, 4F), l = new EntityComplexPart(this, "wing", 4F, 4F), m = new EntityComplexPart(this, "wing", 4F, 4F)
        });
        t = 200;
        setHealth(t);
        texture = "/mob/enderdragon/ender.png";
        b(16F, 8F);
        bQ = true;
        fireProof = true;
        b = 100D;
        cd = true;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Integer(t));
    }

    public double[] a(int i, float f)
    {
        if(health <= 0)
            f = 0.0F;
        f = 1.0F - f;
        int j = e - i * 1 & 0x3f;
        int k = e - i * 1 - 1 & 0x3f;
        double adouble[] = new double[3];
        double d0 = d[j][0];
        double d1;
        for(d1 = d[k][0] - d0; d1 < -180D; d1 += 360D);
        for(; d1 >= 180D; d1 -= 360D);
        adouble[0] = d0 + d1 * (double)f;
        d0 = d[j][1];
        d1 = d[k][1] - d0;
        adouble[1] = d0 + d1 * (double)f;
        adouble[2] = d[j][2] + (d[k][2] - d[j][2]) * (double)f;
        return adouble;
    }

    public void e()
    {
        n = o;
        if(!world.isStatic)
            datawatcher.watch(16, Integer.valueOf(health));
        if(health <= 0)
        {
            float f = (random.nextFloat() - 0.5F) * 8F;
            float d05 = (random.nextFloat() - 0.5F) * 4F;
            float f1 = (random.nextFloat() - 0.5F) * 8F;
            world.a("largeexplode", locX + (double)f, locY + 2D + (double)d05, locZ + (double)f1, 0.0D, 0.0D, 0.0D);
        } else
        {
            A();
            float f = 0.2F / (MathHelper.sqrt(motX * motX + motZ * motZ) * 10F + 1.0F);
            f *= (float)Math.pow(2D, motY);
            if(q)
                o += f * 0.5F;
            else
                o += f;
            for(; yaw >= 180F; yaw -= 360F);
            for(; yaw < -180F; yaw += 360F);
            if(e < 0)
            {
                for(int i = 0; i < d.length; i++)
                {
                    d[i][0] = yaw;
                    d[i][1] = locY;
                }

            }
            if(++e == d.length)
                e = 0;
            d[e][0] = yaw;
            d[e][1] = locY;
            float f3;
            if(world.isStatic)
            {
                if(aN > 0)
                {
                    double d0 = locX + (aO - locX) / (double)aN;
                    double d1 = locY + (aP - locY) / (double)aN;
                    double d2 = locZ + (aQ - locZ) / (double)aN;
                    double d3;
                    for(d3 = aR - (double)yaw; d3 < -180D; d3 += 360D);
                    for(; d3 >= 180D; d3 -= 360D);
                    yaw = (float)((double)yaw + d3 / (double)aN);
                    pitch = (float)((double)pitch + (aS - (double)pitch) / (double)aN);
                    aN--;
                    setPosition(d0, d1, d2);
                    c(yaw, pitch);
                }
            } else
            {
                double d0 = a - locX;
                double d1 = b - locY;
                double d2 = c - locZ;
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                if(u != null)
                {
                    a = u.locX;
                    c = u.locZ;
                    double d4 = a - locX;
                    double d5 = c - locZ;
                    double d6 = Math.sqrt(d4 * d4 + d5 * d5);
                    double d7 = (0.40000000596046448D + d6 / 80D) - 1.0D;
                    if(d7 > 10D)
                        d7 = 10D;
                    b = u.boundingBox.b + d7;
                } else
                {
                    a += random.nextGaussian() * 2D;
                    c += random.nextGaussian() * 2D;
                }
                if(p || d3 < 100D || d3 > 22500D || positionChanged || bz)
                    E();
                d1 /= MathHelper.sqrt(d0 * d0 + d2 * d2);
                f3 = 0.6F;
                if(d1 < (double)(-f3))
                    d1 = -f3;
                if(d1 > (double)f3)
                    d1 = f3;
                motY += d1 * 0.10000000149011612D;
                for(; yaw < -180F; yaw += 360F);
                for(; yaw >= 180F; yaw -= 360F);
                double d8 = 180D - (Math.atan2(d0, d2) * 180D) / 3.1415927410125732D;
                double d9;
                for(d9 = d8 - (double)yaw; d9 < -180D; d9 += 360D);
                for(; d9 >= 180D; d9 -= 360D);
                if(d9 > 50D)
                    d9 = 50D;
                if(d9 < -50D)
                    d9 = -50D;
                Vec3D vec3d = Vec3D.create(a - locX, b - locY, c - locZ).b();
                Vec3D vec3d1 = Vec3D.create(MathHelper.sin((yaw * 3.141593F) / 180F), motY, -MathHelper.cos((yaw * 3.141593F) / 180F)).b();
                float f4 = (float)(vec3d1.a(vec3d) + 0.5D) / 1.5F;
                if(f4 < 0.0F)
                    f4 = 0.0F;
                aY *= 0.8F;
                float f5 = MathHelper.sqrt(motX * motX + motZ * motZ) * 1.0F + 1.0F;
                double d10 = Math.sqrt(motX * motX + motZ * motZ) * 1.0D + 1.0D;
                if(d10 > 40D)
                    d10 = 40D;
                aY = (float)((double)aY + d9 * (0.69999998807907104D / d10 / (double)f5));
                yaw += aY * 0.1F;
                float f6 = (float)(2D / (d10 + 1.0D));
                float f7 = 0.06F;
                a(0.0F, -1F, f7 * (f4 * f6 + (1.0F - f6)));
                if(q)
                    move(motX * 0.80000001192092896D, motY * 0.80000001192092896D, motZ * 0.80000001192092896D);
                else
                    move(motX, motY, motZ);
                Vec3D vec3d2 = Vec3D.create(motX, motY, motZ).b();
                float f8 = (float)(vec3d2.a(vec3d1) + 1.0D) / 2.0F;
                f8 = 0.8F + 0.15F * f8;
                motX *= f8;
                motZ *= f8;
                motY *= 0.9100000262260437D;
            }
            V = yaw;
            g.width = g.length = 3F;
            this.i.width = this.i.length = 2.0F;
            this.j.width = this.j.length = 2.0F;
            k.width = k.length = 2.0F;
            h.length = 3F;
            h.width = 5F;
            l.length = 2.0F;
            l.width = 4F;
            m.length = 3F;
            m.width = 4F;
            float d05 = (((float)(a(5, 1.0F)[1] - a(10, 1.0F)[1]) * 10F) / 180F) * 3.141593F;
            float f1 = MathHelper.cos(d05);
            float f9 = -MathHelper.sin(d05);
            float f10 = (yaw * 3.141593F) / 180F;
            float f11 = MathHelper.sin(f10);
            float f12 = MathHelper.cos(f10);
            h.F_();
            h.setPositionRotation(locX + (double)(f11 * 0.5F), locY, locZ - (double)(f12 * 0.5F), 0.0F, 0.0F);
            l.F_();
            l.setPositionRotation(locX + (double)(f12 * 4.5F), locY + 2D, locZ + (double)(f11 * 4.5F), 0.0F, 0.0F);
            m.F_();
            m.setPositionRotation(locX - (double)(f12 * 4.5F), locY + 2D, locZ - (double)(f11 * 4.5F), 0.0F, 0.0F);
            if(!world.isStatic)
                C();
            if(!world.isStatic && at == 0)
            {
                a(world.getEntities(this, l.boundingBox.grow(4D, 2D, 4D).d(0.0D, -2D, 0.0D)));
                a(world.getEntities(this, m.boundingBox.grow(4D, 2D, 4D).d(0.0D, -2D, 0.0D)));
                b(world.getEntities(this, g.boundingBox.grow(1.0D, 1.0D, 1.0D)));
            }
            double adouble[] = a(5, 1.0F);
            double adouble1[] = a(0, 1.0F);
            f3 = MathHelper.sin((yaw * 3.141593F) / 180F - aY * 0.01F);
            float f13 = MathHelper.cos((yaw * 3.141593F) / 180F - aY * 0.01F);
            g.F_();
            g.setPositionRotation(locX + (double)(f3 * 5.5F * f1), locY + (adouble1[1] - adouble[1]) * 1.0D + (double)(f9 * 5.5F), locZ - (double)(f13 * 5.5F * f1), 0.0F, 0.0F);
            for(int j = 0; j < 3; j++)
            {
                EntityComplexPart entitycomplexpart = null;
                if(j == 0)
                    entitycomplexpart = this.i;
                if(j == 1)
                    entitycomplexpart = this.j;
                if(j == 2)
                    entitycomplexpart = k;
                double adouble2[] = a(12 + j * 2, 1.0F);
                float f14 = (yaw * 3.141593F) / 180F + ((a(adouble2[0] - adouble[0]) * 3.141593F) / 180F) * 1.0F;
                float f15 = MathHelper.sin(f14);
                float f16 = MathHelper.cos(f14);
                float f17 = 1.5F;
                float f18 = (float)(j + 1) * 2.0F;
                entitycomplexpart.F_();
                entitycomplexpart.setPositionRotation(locX - (double)((f11 * f17 + f15 * f18) * f1), ((locY + (adouble2[1] - adouble[1]) * 1.0D) - (double)((f18 + f17) * f9)) + 1.5D, locZ + (double)((f12 * f17 + f16 * f18) * f1), 0.0F, 0.0F);
            }

            if(!world.isStatic)
                q = a(g.boundingBox) | a(h.boundingBox);
        }
    }

    private void A()
    {
        if(s != null)
            if(s.dead)
            {
                if(!world.isStatic)
                    a(g, DamageSource.EXPLOSION, 10);
                s = null;
            } else
            if(ticksLived % 10 == 0 && health < t)
            {
                EntityRegainHealthEvent event = new EntityRegainHealthEvent(getBukkitEntity(), 1, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.ENDER_CRYSTAL);
                world.getServer().getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    health += event.getAmount();
            }
        if(random.nextInt(10) == 0)
        {
            float f = 32F;
            List list = world.a(net/minecraft/server/EntityEnderCrystal, boundingBox.grow(f, f, f));
            EntityEnderCrystal entityendercrystal = null;
            double d0 = 1.7976931348623157E+308D;
            Iterator iterator = list.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                net.minecraft.server.Entity entity = (net.minecraft.server.Entity)iterator.next();
                double d1 = entity.j(this);
                if(d1 < d0)
                {
                    d0 = d1;
                    entityendercrystal = (EntityEnderCrystal)entity;
                }
            } while(true);
            s = entityendercrystal;
        }
    }

    private void C()
    {
    }

    private void a(List list)
    {
        double d0 = (h.boundingBox.a + h.boundingBox.d) / 2D;
        double d1 = (h.boundingBox.c + h.boundingBox.f) / 2D;
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            net.minecraft.server.Entity entity = (net.minecraft.server.Entity)iterator.next();
            if(entity instanceof EntityLiving)
            {
                double d2 = entity.locX - d0;
                double d3 = entity.locZ - d1;
                double d4 = d2 * d2 + d3 * d3;
                entity.b_((d2 / d4) * 4D, 0.20000000298023224D, (d3 / d4) * 4D);
            }
        } while(true);
    }

    private void b(List list)
    {
        for(int i = 0; i < list.size(); i++)
        {
            net.minecraft.server.Entity entity = (net.minecraft.server.Entity)list.get(i);
            if(!(entity instanceof EntityLiving))
                continue;
            if(!(entity instanceof EntityHuman))
            {
                EntityDamageByEntityEvent damageEvent = new EntityDamageByEntityEvent(getBukkitEntity(), entity.getBukkitEntity(), org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK, 10);
                Bukkit.getPluginManager().callEvent(damageEvent);
                if(!damageEvent.isCancelled())
                    entity.damageEntity(DamageSource.mobAttack(this), damageEvent.getDamage());
            } else
            {
                entity.damageEntity(DamageSource.mobAttack(this), 10);
            }
        }

    }

    private void E()
    {
        p = false;
        if(random.nextInt(2) == 0 && world.players.size() > 0)
        {
            u = (net.minecraft.server.Entity)world.players.get(random.nextInt(world.players.size()));
        } else
        {
            boolean flag = false;
            do
            {
                a = 0.0D;
                b = 70F + random.nextFloat() * 50F;
                c = 0.0D;
                a += random.nextFloat() * 120F - 60F;
                c += random.nextFloat() * 120F - 60F;
                double d0 = locX - a;
                double d1 = locY - b;
                double d2 = locZ - c;
                flag = d0 * d0 + d1 * d1 + d2 * d2 > 100D;
            } while(!flag);
            u = null;
        }
    }

    private float a(double d0)
    {
        for(; d0 >= 180D; d0 -= 360D);
        for(; d0 < -180D; d0 += 360D);
        return (float)d0;
    }

    private boolean a(AxisAlignedBB axisalignedbb)
    {
        int i = MathHelper.floor(axisalignedbb.a);
        int j = MathHelper.floor(axisalignedbb.b);
        int k = MathHelper.floor(axisalignedbb.c);
        int l = MathHelper.floor(axisalignedbb.d);
        int i1 = MathHelper.floor(axisalignedbb.e);
        int j1 = MathHelper.floor(axisalignedbb.f);
        boolean flag = false;
        boolean flag1 = false;
        List destroyedBlocks = new ArrayList();
        CraftWorld craftWorld = world.getWorld();
        for(int k1 = i; k1 <= l; k1++)
        {
            for(int l1 = j; l1 <= i1; l1++)
            {
                for(int i2 = k; i2 <= j1; i2++)
                {
                    int j2 = world.getTypeId(k1, l1, i2);
                    if(j2 == 0)
                        continue;
                    if(j2 != Block.OBSIDIAN.id && j2 != Block.WHITESTONE.id && j2 != Block.BEDROCK.id)
                    {
                        flag1 = true;
                        destroyedBlocks.add(craftWorld.getBlockAt(k1, l1, i2));
                    } else
                    {
                        flag = true;
                    }
                }

            }

        }

        if(flag1)
        {
            Entity bukkitEntity = getBukkitEntity();
            EntityExplodeEvent event = new EntityExplodeEvent(bukkitEntity, bukkitEntity.getLocation(), destroyedBlocks, 0.0F);
            Bukkit.getPluginManager().callEvent(event);
            if(event.isCancelled())
                return flag;
            Block block;
            for(Iterator i$ = event.blockList().iterator(); i$.hasNext(); craftWorld.explodeBlock(block, event.getYield()))
                block = (Block)i$.next();

            double d0 = axisalignedbb.a + (axisalignedbb.d - axisalignedbb.a) * (double)random.nextFloat();
            double d1 = axisalignedbb.b + (axisalignedbb.e - axisalignedbb.b) * (double)random.nextFloat();
            double d2 = axisalignedbb.c + (axisalignedbb.f - axisalignedbb.c) * (double)random.nextFloat();
            world.a("largeexplode", d0, d1, d2, 0.0D, 0.0D, 0.0D);
        }
        return flag;
    }

    public boolean a(EntityComplexPart entitycomplexpart, DamageSource damagesource, int i)
    {
        if(entitycomplexpart != g)
            i = i / 4 + 1;
        float f = (yaw * 3.141593F) / 180F;
        float f1 = MathHelper.sin(f);
        float f2 = MathHelper.cos(f);
        a = locX + (double)(f1 * 5F) + (double)((random.nextFloat() - 0.5F) * 2.0F);
        b = locY + (double)(random.nextFloat() * 3F) + 1.0D;
        c = (locZ - (double)(f2 * 5F)) + (double)((random.nextFloat() - 0.5F) * 2.0F);
        u = null;
        if((damagesource.getEntity() instanceof EntityHuman) || damagesource == DamageSource.EXPLOSION)
            dealDamage(damagesource, i);
        return true;
    }

    protected void aB()
    {
        r++;
        if(r >= 180 && r <= 200)
        {
            float f = (random.nextFloat() - 0.5F) * 8F;
            float f1 = (random.nextFloat() - 0.5F) * 4F;
            float f2 = (random.nextFloat() - 0.5F) * 8F;
            world.a("hugeexplosion", locX + (double)f, locY + 2D + (double)f1, locZ + (double)f2, 0.0D, 0.0D, 0.0D);
        }
        if(!world.isStatic && r > 150 && r % 5 == 0)
        {
            for(int i = expToDrop / 20; i > 0;)
            {
                int j = EntityExperienceOrb.getOrbValue(i);
                i -= j;
                world.addEntity(new EntityExperienceOrb(world, locX, locY, locZ, j));
            }

        }
        move(0.0D, 0.10000000149011612D, 0.0D);
        V = yaw += 20F;
        if(r == 200)
        {
            for(int i = expToDrop - 10 * (expToDrop / 20); i > 0;)
            {
                int j = EntityExperienceOrb.getOrbValue(i);
                i -= j;
                world.addEntity(new EntityExperienceOrb(world, locX, locY, locZ, j));
            }

            a(MathHelper.floor(locX), MathHelper.floor(locZ));
            aH();
            die();
        }
    }

    private void a(int i, int j)
    {
        byte b0 = 64;
        BlockEnderPortal.a = true;
        byte b1 = 4;
        BlockStateListPopulator world = new BlockStateListPopulator(this.world.getWorld());
        for(int k = b0 - 1; k <= b0 + 32; k++)
        {
            for(int l = i - b1; l <= i + b1; l++)
            {
                for(int i1 = j - b1; i1 <= j + b1; i1++)
                {
                    double d0 = l - i;
                    double d1 = i1 - j;
                    double d2 = MathHelper.sqrt(d0 * d0 + d1 * d1);
                    if(d2 > (double)b1 - 0.5D)
                        continue;
                    if(k < b0)
                    {
                        if(d2 <= (double)(b1 - 1) - 0.5D)
                            world.setTypeId(l, k, i1, Block.BEDROCK.id);
                        continue;
                    }
                    if(k > b0)
                    {
                        world.setTypeId(l, k, i1, 0);
                        continue;
                    }
                    if(d2 > (double)(b1 - 1) - 0.5D)
                        world.setTypeId(l, k, i1, Block.BEDROCK.id);
                    else
                        world.setTypeId(l, k, i1, Block.ENDER_PORTAL.id);
                }

            }

        }

        world.setTypeId(i, b0 + 0, j, Block.BEDROCK.id);
        world.setTypeId(i, b0 + 1, j, Block.BEDROCK.id);
        world.setTypeId(i, b0 + 2, j, Block.BEDROCK.id);
        world.setTypeId(i - 1, b0 + 2, j, Block.TORCH.id);
        world.setTypeId(i + 1, b0 + 2, j, Block.TORCH.id);
        world.setTypeId(i, b0 + 2, j - 1, Block.TORCH.id);
        world.setTypeId(i, b0 + 2, j + 1, Block.TORCH.id);
        world.setTypeId(i, b0 + 3, j, Block.BEDROCK.id);
        world.setTypeId(i, b0 + 4, j, Block.DRAGON_EGG.id);
        EntityCreatePortalEvent event = new EntityCreatePortalEvent((LivingEntity)getBukkitEntity(), Collections.unmodifiableList(world.getList()), PortalType.ENDER);
        this.world.getServer().getPluginManager().callEvent(event);
        if(!event.isCancelled())
        {
            BlockState state;
            for(Iterator i$ = event.getBlocks().iterator(); i$.hasNext(); state.update(true))
                state = (BlockState)i$.next();

        } else
        {
            for(Iterator i$ = event.getBlocks().iterator(); i$.hasNext();)
            {
                BlockState state = (BlockState)i$.next();
                Packet53BlockChange packet = new Packet53BlockChange(state.getX(), state.getY(), state.getZ(), this.world);
                Iterator it = this.world.players.iterator();
                while(it.hasNext()) 
                {
                    EntityHuman entity = (EntityHuman)it.next();
                    if(entity instanceof EntityPlayer)
                        ((EntityPlayer)entity).netServerHandler.sendPacket(packet);
                }
            }

        }
        BlockEnderPortal.a = false;
    }

    protected void aG()
    {
    }

    public net.minecraft.server.Entity[] bb()
    {
        return children;
    }

    public boolean o_()
    {
        return false;
    }

    public int getExpReward()
    {
        return 20000;
    }

    public double a;
    public double b;
    public double c;
    public double d[][];
    public int e;
    public EntityComplexPart children[];
    public EntityComplexPart g;
    public EntityComplexPart h;
    public EntityComplexPart i;
    public EntityComplexPart j;
    public EntityComplexPart k;
    public EntityComplexPart l;
    public EntityComplexPart m;
    public float n;
    public float o;
    public boolean p;
    public boolean q;
    private net.minecraft.server.Entity u;
    public int r;
    public EntityEnderCrystal s;
}
