// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PathfinderGoalMeleeAttack.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityLiving, Navigation, MathHelper, 
//            ControllerLook, EntitySenses, AxisAlignedBB, World, 
//            PathEntity

public class PathfinderGoalMeleeAttack extends PathfinderGoal
{

    public PathfinderGoalMeleeAttack(EntityLiving entityliving, Class oclass, float f, boolean flag)
    {
        this(entityliving, f, flag);
        h = oclass;
    }

    public PathfinderGoalMeleeAttack(EntityLiving entityliving, float f, boolean flag)
    {
        d = 0;
        b = entityliving;
        a = entityliving.world;
        e = f;
        this.f = flag;
        a(3);
    }

    public boolean a()
    {
        EntityLiving entityliving = b.at();
        if(entityliving == null)
            return false;
        if(h != null && !h.isAssignableFrom(entityliving.getClass()))
        {
            return false;
        } else
        {
            c = entityliving;
            g = b.al().a(c);
            return g != null;
        }
    }

    public boolean b()
    {
        EntityLiving entityliving = b.at();
        return entityliving != null ? c.isAlive() ? f ? b.e(MathHelper.floor(c.locX), MathHelper.floor(c.locY), MathHelper.floor(c.locZ)) : !b.al().e() : false : false;
    }

    public void c()
    {
        b.al().a(g, e);
        i = 0;
    }

    public void d()
    {
        org.bukkit.event.entity.EntityTargetEvent.TargetReason reason = c.isAlive() ? org.bukkit.event.entity.EntityTargetEvent.TargetReason.FORGOT_TARGET : org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_DIED;
        CraftEventFactory.callEntityTargetEvent(b, null, reason);
        c = null;
        b.al().f();
    }

    public void e()
    {
        b.getControllerLook().a(c, 30F, 30F);
        if((f || b.am().canSee(c)) && --i <= 0)
        {
            i = 4 + b.an().nextInt(7);
            b.al().a(c, e);
        }
        d = Math.max(d - 1, 0);
        double d0 = b.width * 2.0F * b.width * 2.0F;
        if(b.e(c.locX, c.boundingBox.b, c.locZ) <= d0 && d <= 0)
        {
            d = 20;
            b.a(c);
        }
    }

    World a;
    EntityLiving b;
    EntityLiving c;
    int d;
    float e;
    boolean f;
    PathEntity g;
    Class h;
    private int i;
}
