// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Iterator;
import java.util.List;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoalTarget, EntityLiving, AxisAlignedBB, World, 
//            Entity

public class PathfinderGoalHurtByTarget extends PathfinderGoalTarget
{

    public PathfinderGoalHurtByTarget(EntityLiving entityliving, boolean flag)
    {
        super(entityliving, 16F, false);
        a = flag;
        a(1);
    }

    public boolean a()
    {
        return a(c.ao(), true);
    }

    public void c()
    {
        c.b(c.ao());
        if(a)
        {
            List list = c.world.a(c.getClass(), AxisAlignedBB.b(c.locX, c.locY, c.locZ, c.locX + 1.0D, c.locY + 1.0D, c.locZ + 1.0D).grow(d, 4D, d));
            Iterator iterator = list.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                Entity entity = (Entity)iterator.next();
                EntityLiving entityliving = (EntityLiving)entity;
                if(c != entityliving && entityliving.at() == null)
                    entityliving.b(c.ao());
            } while(true);
        }
        super.c();
    }

    boolean a;
}
