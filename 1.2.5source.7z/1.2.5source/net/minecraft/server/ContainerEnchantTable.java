// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContainerEnchantTable.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.inventory.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.inventory.InventoryView;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Container, ContainerEnchantTableInventory, SlotEnchant, Slot, 
//            ICrafting, EnchantmentInstance, ItemStack, PlayerInventory, 
//            EntityHuman, IInventory, World, Block, 
//            EnchantmentManager, PlayerAbilities, Enchantment

public class ContainerEnchantTable extends Container
{

    public ContainerEnchantTable(PlayerInventory playerinventory, World world, int i, int j, int k)
    {
        enchantSlots = new ContainerEnchantTableInventory(this, "Enchant", 1);
        this.l = new Random();
        costs = new int[3];
        bukkitEntity = null;
        this.world = world;
        x = i;
        y = j;
        z = k;
        a(new SlotEnchant(this, enchantSlots, 0, 25, 47));
        for(int l = 0; l < 3; l++)
        {
            for(int i1 = 0; i1 < 9; i1++)
                a(new Slot(playerinventory, i1 + l * 9 + 9, 8 + i1 * 18, 84 + l * 18));

        }

        for(int l = 0; l < 9; l++)
            a(new Slot(playerinventory, l, 8 + l * 18, 142));

        player = (Player)playerinventory.player.bukkitEntity;
        enchantSlots.player = player;
    }

    public void addSlotListener(ICrafting icrafting)
    {
        super.addSlotListener(icrafting);
        icrafting.setContainerData(this, 0, costs[0]);
        icrafting.setContainerData(this, 1, costs[1]);
        icrafting.setContainerData(this, 2, costs[2]);
    }

    public void a()
    {
        super.a();
        for(int i = 0; i < listeners.size(); i++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i);
            icrafting.setContainerData(this, 0, costs[0]);
            icrafting.setContainerData(this, 1, costs[1]);
            icrafting.setContainerData(this, 2, costs[2]);
        }

    }

    public void a(IInventory iinventory)
    {
        if(iinventory == enchantSlots)
        {
            ItemStack itemstack = iinventory.getItem(0);
            if(itemstack != null && itemstack.q())
            {
                b = l.nextLong();
                if(!world.isStatic)
                {
                    int i = 0;
                    for(int j = -1; j <= 1; j++)
                    {
                        for(int k = -1; k <= 1; k++)
                        {
                            if(j == 0 && k == 0 || !world.isEmpty(x + k, y, z + j) || !world.isEmpty(x + k, y + 1, z + j))
                                continue;
                            if(world.getTypeId(x + k * 2, y, z + j * 2) == Block.BOOKSHELF.id)
                                i++;
                            if(world.getTypeId(x + k * 2, y + 1, z + j * 2) == Block.BOOKSHELF.id)
                                i++;
                            if(k == 0 || j == 0)
                                continue;
                            if(world.getTypeId(x + k * 2, y, z + j) == Block.BOOKSHELF.id)
                                i++;
                            if(world.getTypeId(x + k * 2, y + 1, z + j) == Block.BOOKSHELF.id)
                                i++;
                            if(world.getTypeId(x + k, y, z + j * 2) == Block.BOOKSHELF.id)
                                i++;
                            if(world.getTypeId(x + k, y + 1, z + j * 2) == Block.BOOKSHELF.id)
                                i++;
                        }

                    }

                    for(int j = 0; j < 3; j++)
                        costs[j] = EnchantmentManager.a(l, j, i, itemstack);

                    CraftItemStack item = new CraftItemStack(itemstack);
                    PrepareItemEnchantEvent event = new PrepareItemEnchantEvent(player, getBukkitView(), world.getWorld().getBlockAt(x, y, z), item, costs, i);
                    world.getServer().getPluginManager().callEvent(event);
                    if(event.isCancelled())
                    {
                        for(i = 0; i < 3; i++)
                            costs[i] = 0;

                        return;
                    }
                    a();
                }
            } else
            {
                for(int i = 0; i < 3; i++)
                    costs[i] = 0;

            }
        }
    }

    public boolean a(EntityHuman entityhuman, int i)
    {
        ItemStack itemstack = enchantSlots.getItem(0);
        if(costs[i] > 0 && itemstack != null && (entityhuman.expLevel >= costs[i] || entityhuman.abilities.canInstantlyBuild))
        {
            if(!world.isStatic)
            {
                List list = EnchantmentManager.b(l, itemstack, costs[i]);
                if(list != null)
                {
                    Map enchants = new HashMap();
                    EnchantmentInstance instance;
                    for(Iterator i$ = list.iterator(); i$.hasNext(); enchants.put(Enchantment.getById(instance.enchantment.id), Integer.valueOf(instance.level)))
                    {
                        Object obj = i$.next();
                        instance = (EnchantmentInstance)obj;
                    }

                    CraftItemStack item = new CraftItemStack(itemstack);
                    EnchantItemEvent event = new EnchantItemEvent((Player)entityhuman.bukkitEntity, getBukkitView(), world.getWorld().getBlockAt(x, y, z), item, costs[i], enchants, i);
                    world.getServer().getPluginManager().callEvent(event);
                    int level = event.getExpLevelCost();
                    if(event.isCancelled() || level > entityhuman.expLevel && !entityhuman.abilities.canInstantlyBuild || enchants.isEmpty())
                        return false;
                    entityhuman.levelDown(level);
                    for(Iterator i$ = event.getEnchantsToAdd().entrySet().iterator(); i$.hasNext();)
                    {
                        java.util.Map.Entry entry = (java.util.Map.Entry)i$.next();
                        try
                        {
                            item.addEnchantment((Enchantment)entry.getKey(), ((Integer)entry.getValue()).intValue());
                        }
                        catch(IllegalArgumentException e) { }
                    }

                    a(((IInventory) (enchantSlots)));
                }
            }
            return true;
        } else
        {
            return false;
        }
    }

    public void a(EntityHuman entityhuman)
    {
        super.a(entityhuman);
        if(!world.isStatic)
        {
            ItemStack itemstack = enchantSlots.splitWithoutUpdate(0);
            if(itemstack != null)
                entityhuman.drop(itemstack);
        }
    }

    public boolean b(EntityHuman entityhuman)
    {
        if(!checkReachable)
            return true;
        else
            return world.getTypeId(x, y, z) == Block.ENCHANTMENT_TABLE.id ? entityhuman.e((double)x + 0.5D, (double)y + 0.5D, (double)z + 0.5D) <= 64D : false;
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if(slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if(i != 0)
                return null;
            if(!a(itemstack1, 1, 37, true))
                return null;
            if(itemstack1.count == 0)
                slot.set((ItemStack)null);
            else
                slot.d();
            if(itemstack1.count == itemstack.count)
                return null;
            slot.c(itemstack1);
        }
        return itemstack;
    }

    public CraftInventoryView getBukkitView()
    {
        if(bukkitEntity != null)
        {
            return bukkitEntity;
        } else
        {
            CraftInventoryEnchanting inventory = new CraftInventoryEnchanting(enchantSlots);
            bukkitEntity = new CraftInventoryView(player, inventory, this);
            return bukkitEntity;
        }
    }

    public volatile InventoryView getBukkitView()
    {
        return getBukkitView();
    }

    public ContainerEnchantTableInventory enchantSlots;
    private World world;
    private int x;
    private int y;
    private int z;
    private Random l;
    public long b;
    public int costs[];
    private CraftInventoryView bukkitEntity;
    private Player player;
}
