// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPainting.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Painting;
import org.bukkit.event.painting.PaintingBreakByEntityEvent;
import org.bukkit.event.painting.PaintingBreakEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            Entity, EnumArt, EntityItem, ItemStack, 
//            AxisAlignedBB, World, Material, Item, 
//            MathHelper, DamageSource, NBTTagCompound

public class EntityPainting extends Entity
{

    public EntityPainting(World world)
    {
        super(world);
        f = 0;
        direction = 0;
        height = 0.0F;
        b(0.5F, 0.5F);
        art = EnumArt.values()[random.nextInt(EnumArt.values().length)];
    }

    public EntityPainting(World world, int i, int j, int k, int l)
    {
        this(world);
        x = i;
        y = j;
        z = k;
        ArrayList arraylist = new ArrayList();
        EnumArt aenumart[] = EnumArt.values();
        int i1 = aenumart.length;
        for(int j1 = 0; j1 < i1; j1++)
        {
            EnumArt enumart = aenumart[j1];
            art = enumart;
            setDirection(l);
            if(survives())
                arraylist.add(enumart);
        }

        if(arraylist.size() > 0)
            art = (EnumArt)arraylist.get(random.nextInt(arraylist.size()));
        setDirection(l);
    }

    protected void b()
    {
    }

    public void setDirection(int i)
    {
        direction = i;
        lastYaw = yaw = i * 90;
        float f = art.B;
        float f1 = art.C;
        float f2 = art.B;
        if(i != 0 && i != 2)
            f = 0.5F;
        else
            f2 = 0.5F;
        f /= 32F;
        f1 /= 32F;
        f2 /= 32F;
        float f3 = (float)x + 0.5F;
        float f4 = (float)y + 0.5F;
        float f5 = (float)z + 0.5F;
        float f6 = 0.5625F;
        if(i == 0)
            f5 -= f6;
        if(i == 1)
            f3 -= f6;
        if(i == 2)
            f5 += f6;
        if(i == 3)
            f3 += f6;
        if(i == 0)
            f3 -= c(art.B);
        if(i == 1)
            f5 += c(art.B);
        if(i == 2)
            f3 += c(art.B);
        if(i == 3)
            f5 -= c(art.B);
        f4 += c(art.C);
        setPosition(f3, f4, f5);
        float f7 = -0.00625F;
        boundingBox.c(f3 - f - f7, f4 - f1 - f7, f5 - f2 - f7, f3 + f + f7, f4 + f1 + f7, f5 + f2 + f7);
    }

    private float c(int i)
    {
        return i != 32 ? i != 64 ? 0.0F : 0.5F : 0.5F;
    }

    public void F_()
    {
        if(f++ == 100 && !world.isStatic)
        {
            f = 0;
            if(!dead && !survives())
            {
                Material material = world.getMaterial((int)locX, (int)locY, (int)locZ);
                org.bukkit.event.painting.PaintingBreakEvent.RemoveCause cause;
                if(material.equals(Material.WATER))
                    cause = org.bukkit.event.painting.PaintingBreakEvent.RemoveCause.WATER;
                else
                if(!material.equals(Material.AIR))
                    cause = org.bukkit.event.painting.PaintingBreakEvent.RemoveCause.OBSTRUCTION;
                else
                    cause = org.bukkit.event.painting.PaintingBreakEvent.RemoveCause.PHYSICS;
                PaintingBreakEvent event = new PaintingBreakEvent((Painting)getBukkitEntity(), cause);
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled() || dead)
                    return;
                die();
                world.addEntity(new EntityItem(world, locX, locY, locZ, new ItemStack(Item.PAINTING)));
            }
        }
    }

    public boolean survives()
    {
        if(world.getCubes(this, boundingBox).size() > 0)
            return false;
        int i = art.B / 16;
        int j = art.C / 16;
        int k = x;
        int l = y;
        int i1 = z;
        if(direction == 0)
            k = MathHelper.floor(locX - (double)((float)art.B / 32F));
        if(direction == 1)
            i1 = MathHelper.floor(locZ - (double)((float)art.B / 32F));
        if(direction == 2)
            k = MathHelper.floor(locX - (double)((float)art.B / 32F));
        if(direction == 3)
            i1 = MathHelper.floor(locZ - (double)((float)art.B / 32F));
        l = MathHelper.floor(locY - (double)((float)art.C / 32F));
        for(int k1 = 0; k1 < i; k1++)
        {
            for(int j1 = 0; j1 < j; j1++)
            {
                Material material;
                if(direction != 0 && direction != 2)
                    material = world.getMaterial(x, l + j1, i1 + k1);
                else
                    material = world.getMaterial(k + k1, l + j1, z);
                if(!material.isBuildable())
                    return false;
            }

        }

        List list = world.getEntities(this, boundingBox);
        for(int j1 = 0; j1 < list.size(); j1++)
            if(list.get(j1) instanceof EntityPainting)
                return false;

        return true;
    }

    public boolean o_()
    {
        return true;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(!dead && !world.isStatic)
        {
            PaintingBreakEvent event = null;
            if(damagesource.getEntity() != null)
                event = new PaintingBreakByEntityEvent((Painting)getBukkitEntity(), damagesource.getEntity() != null ? damagesource.getEntity().getBukkitEntity() : null);
            else
            if(damagesource == DamageSource.FIRE)
                event = new PaintingBreakEvent((Painting)getBukkitEntity(), org.bukkit.event.painting.PaintingBreakEvent.RemoveCause.FIRE);
            if(event != null)
            {
                world.getServer().getPluginManager().callEvent(event);
                if(event.isCancelled())
                    return true;
            }
            if(dead)
                return true;
            die();
            aW();
            world.addEntity(new EntityItem(world, locX, locY, locZ, new ItemStack(Item.PAINTING)));
        }
        return true;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setByte("Dir", (byte)direction);
        nbttagcompound.setString("Motive", art.A);
        nbttagcompound.setInt("TileX", x);
        nbttagcompound.setInt("TileY", y);
        nbttagcompound.setInt("TileZ", z);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        direction = nbttagcompound.getByte("Dir");
        x = nbttagcompound.getInt("TileX");
        y = nbttagcompound.getInt("TileY");
        z = nbttagcompound.getInt("TileZ");
        String s = nbttagcompound.getString("Motive");
        EnumArt aenumart[] = EnumArt.values();
        int i = aenumart.length;
        for(int j = 0; j < i; j++)
        {
            EnumArt enumart = aenumart[j];
            if(enumart.A.equals(s))
                art = enumart;
        }

        if(art == null)
            art = EnumArt.KEBAB;
        setDirection(direction);
    }

    public void move(double d0, double d1, double d2)
    {
        if(!world.isStatic && !dead && d0 * d0 + d1 * d1 + d2 * d2 > 0.0D)
        {
            if(dead)
                return;
            die();
            world.addEntity(new EntityItem(world, locX, locY, locZ, new ItemStack(Item.PAINTING)));
        }
    }

    public void b_(double d, double d3, double d4)
    {
    }

    private int f;
    public int direction;
    public int x;
    public int y;
    public int z;
    public EnumArt art;
}
