// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, EntityLiving, Vec3D, 
//            RandomPositionGenerator, Navigation

public class PathfinderGoalMoveTowardsTarget extends PathfinderGoal
{

    public PathfinderGoalMoveTowardsTarget(EntityCreature entitycreature, float f1, float f2)
    {
        a = entitycreature;
        f = f1;
        g = f2;
        a(1);
    }

    public boolean a()
    {
        b = a.at();
        if(b == null)
            return false;
        if(b.j(a) > (double)(g * g))
            return false;
        Vec3D vec3d = RandomPositionGenerator.a(a, 16, 7, Vec3D.create(b.locX, b.locY, b.locZ));
        if(vec3d == null)
        {
            return false;
        } else
        {
            c = vec3d.a;
            d = vec3d.b;
            e = vec3d.c;
            return true;
        }
    }

    public boolean b()
    {
        return !a.al().e() && b.isAlive() && b.j(a) < (double)(g * g);
    }

    public void d()
    {
        b = null;
    }

    public void c()
    {
        a.al().a(c, d, e, f);
    }

    private EntityCreature a;
    private EntityLiving b;
    private double c;
    private double d;
    private double e;
    private float f;
    private float g;
}
