// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

// Referenced classes of package net.minecraft.server:
//            NBTBase

public class NBTTagShort extends NBTBase
{

    public NBTTagShort(String s)
    {
        super(s);
    }

    public NBTTagShort(String s, short word0)
    {
        super(s);
        data = word0;
    }

    void write(DataOutput dataoutput)
    {
        dataoutput.writeShort(data);
    }

    void load(DataInput datainput)
    {
        data = datainput.readShort();
    }

    public byte getTypeId()
    {
        return 2;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(data).toString();
    }

    public NBTBase clone()
    {
        return new NBTTagShort(getName(), data);
    }

    public boolean equals(Object obj)
    {
        if(super.equals(obj))
        {
            NBTTagShort nbttagshort = (NBTTagShort)obj;
            return data == nbttagshort.data;
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        return super.hashCode() ^ data;
    }

    public short data;
}
