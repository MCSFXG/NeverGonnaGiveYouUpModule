// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPlayer.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.*;
import org.bukkit.craftbukkit.*;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.InventoryView;

// Referenced classes of package net.minecraft.server:
//            EntityHuman, ItemStack, WorldServer, ItemInWorldManager, 
//            Packet5EntityEquipment, Packet3Chat, EntityDamageSource, EntityArrow, 
//            ItemWorldMapBase, ChunkCoordIntPair, Packet51MapChunk, TileEntity, 
//            Packet8UpdateHealth, Packet43SetExperience, Packet70Bed, EntityItem, 
//            Packet22Collect, EntityExperienceOrb, Packet18ArmAnimation, Packet17EntityLocationAction, 
//            Packet39AttachEntity, ContainerWorkbench, Packet100OpenWindow, ContainerEnchantTable, 
//            ContainerChest, ContainerFurnace, ContainerDispenser, ContainerBrewingStand, 
//            SlotResult, Packet103SetSlot, Packet104WindowItems, Packet105CraftProgressBar, 
//            Packet101CloseWindow, Packet200Statistic, Packet38EntityStatus, Packet41MobEffect, 
//            Packet42RemoveMobEffect, Packet202Abilities, FoodMetaData, ICrafting, 
//            World, ChunkCoordinates, WorldProvider, NBTTagCompound, 
//            Container, MinecraftServer, EntityTracker, PlayerInventory, 
//            DamageSource, ServerConfigurationManager, Item, NetServerHandler, 
//            Chunk, AchievementList, Entity, EnumBedResult, 
//            IInventory, TileEntityFurnace, TileEntityDispenser, TileEntityBrewingStand, 
//            Slot, Statistic, LocaleLanguage, EnumAnimation, 
//            MobEffect

public class EntityPlayer extends EntityHuman
    implements ICrafting
{

    public EntityPlayer(MinecraftServer minecraftserver, World world, String s, ItemInWorldManager iteminworldmanager)
    {
        super(world);
        chunkCoordIntPairQueue = new LinkedList();
        playerChunkCoordIntPairs = new HashSet();
        cf = 0xfa0a1f01;
        cg = 0xfa0a1f01;
        ch = true;
        lastSentExp = 0xfa0a1f01;
        invulnerableTicks = 60;
        containerCounter = 0;
        viewingCredits = false;
        newExp = 0;
        newLevel = 0;
        newTotalExp = 0;
        keepLevel = false;
        timeOffset = 0L;
        relativeTime = true;
        iteminworldmanager.player = this;
        itemInWorldManager = iteminworldmanager;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        int i = chunkcoordinates.x;
        int j = chunkcoordinates.z;
        int k = chunkcoordinates.y;
        if(!world.worldProvider.e)
        {
            i += random.nextInt(20) - 10;
            k = world.g(i, j);
            j += random.nextInt(20) - 10;
        }
        setPositionRotation((double)i + 0.5D, k, (double)j + 0.5D, 0.0F, 0.0F);
        server = minecraftserver;
        bP = 0.0F;
        name = s;
        height = 0.0F;
        displayName = name;
        listName = name;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        if(nbttagcompound.hasKey("playerGameType"))
            itemInWorldManager.setGameMode(nbttagcompound.getInt("playerGameType"));
        getBukkitEntity().readExtraData(nbttagcompound);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setInt("playerGameType", itemInWorldManager.getGameMode());
        getBukkitEntity().setExtraData(nbttagcompound);
    }

    public void spawnIn(World world)
    {
        super.spawnIn(world);
        if(world == null)
        {
            dead = false;
            ChunkCoordinates position = null;
            if(spawnWorld != null && !spawnWorld.equals(""))
            {
                CraftWorld cworld = (CraftWorld)Bukkit.getServer().getWorld(spawnWorld);
                if(cworld != null && getBed() != null)
                {
                    world = cworld.getHandle();
                    position = EntityHuman.getBed(cworld.getHandle(), getBed());
                }
            }
            if(world == null || position == null)
            {
                world = ((CraftWorld)Bukkit.getServer().getWorlds().get(0)).getHandle();
                position = world.getSpawn();
            }
            this.world = world;
            setPosition((double)position.x + 0.5D, position.y, (double)position.z + 0.5D);
        }
        dimension = ((WorldServer)this.world).dimension;
        int oldMode = itemInWorldManager.getGameMode();
        itemInWorldManager = new ItemInWorldManager((WorldServer)world);
        itemInWorldManager.player = this;
        itemInWorldManager.setGameMode(oldMode);
    }

    public void levelDown(int i)
    {
        super.levelDown(i);
        lastSentExp = -1;
    }

    public void syncInventory()
    {
        activeContainer.addSlotListener(this);
    }

    public ItemStack[] getEquipment()
    {
        return ck;
    }

    protected void A()
    {
        height = 0.0F;
    }

    public float getHeadHeight()
    {
        return 1.62F;
    }

    public void F_()
    {
        itemInWorldManager.c();
        invulnerableTicks--;
        activeContainer.a();
        for(int i = 0; i < 5; i++)
        {
            ItemStack itemstack = c(i);
            if(itemstack != ck[i])
            {
                server.getTracker(dimension).a(this, new Packet5EntityEquipment(id, i, itemstack));
                ck[i] = itemstack;
            }
        }

    }

    public ItemStack c(int i)
    {
        return i != 0 ? inventory.armor[i - 1] : inventory.getItemInHand();
    }

    public void die(DamageSource damagesource)
    {
        List loot = new ArrayList();
        for(int i = 0; i < inventory.items.length; i++)
            if(inventory.items[i] != null)
                loot.add(new CraftItemStack(inventory.items[i]));

        for(int i = 0; i < inventory.armor.length; i++)
            if(inventory.armor[i] != null)
                loot.add(new CraftItemStack(inventory.armor[i]));

        PlayerDeathEvent event = CraftEventFactory.callPlayerDeathEvent(this, loot, damagesource.getLocalizedDeathMessage(this));
        String deathMessage = event.getDeathMessage();
        if(deathMessage != null && deathMessage.length() > 0)
            server.serverConfigurationManager.sendAll(new Packet3Chat(event.getDeathMessage()));
        for(int i = 0; i < inventory.items.length; i++)
            inventory.items[i] = null;

        for(int i = 0; i < inventory.armor.length; i++)
            inventory.armor[i] = null;

        closeInventory();
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if(invulnerableTicks > 0)
            return false;
        if(!world.pvpMode && (damagesource instanceof EntityDamageSource))
        {
            net.minecraft.server.Entity entity = damagesource.getEntity();
            if(entity instanceof EntityHuman)
                return false;
            if(entity instanceof EntityArrow)
            {
                EntityArrow entityarrow = (EntityArrow)entity;
                if(entityarrow.shooter instanceof EntityHuman)
                    return false;
            }
        }
        return super.damageEntity(damagesource, i);
    }

    protected boolean C()
    {
        return server.pvpMode;
    }

    public void heal(int i)
    {
        super.heal(i);
    }

    public void a(boolean flag)
    {
        super.F_();
        for(int i = 0; i < inventory.getSize(); i++)
        {
            ItemStack itemstack = inventory.getItem(i);
            if(itemstack == null || !Item.byId[itemstack.id].t_() || netServerHandler.lowPriorityCount() > 2)
                continue;
            Packet packet = ((ItemWorldMapBase)Item.byId[itemstack.id]).c(itemstack, world, this);
            if(packet != null)
                netServerHandler.sendPacket(packet);
        }

        if(flag && !chunkCoordIntPairQueue.isEmpty())
        {
            ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)chunkCoordIntPairQueue.get(0);
            double d0 = chunkcoordintpair.a(this);
            for(int j = 0; j < chunkCoordIntPairQueue.size(); j++)
            {
                ChunkCoordIntPair chunkcoordintpair1 = (ChunkCoordIntPair)chunkCoordIntPairQueue.get(j);
                double d1 = chunkcoordintpair1.a(this);
                if(d1 < d0)
                {
                    chunkcoordintpair = chunkcoordintpair1;
                    d0 = d1;
                }
            }

            if(chunkcoordintpair != null)
            {
                boolean flag1 = false;
                if(netServerHandler.lowPriorityCount() + ChunkCompressionThread.getPlayerQueueSize(this) < 4)
                    flag1 = true;
                if(flag1)
                {
                    WorldServer worldserver = server.getWorldServer(dimension);
                    if(worldserver.isLoaded(chunkcoordintpair.x << 4, 0, chunkcoordintpair.z << 4))
                    {
                        Chunk chunk = worldserver.getChunkAt(chunkcoordintpair.x, chunkcoordintpair.z);
                        if(chunk.done)
                        {
                            chunkCoordIntPairQueue.remove(chunkcoordintpair);
                            netServerHandler.sendPacket(new Packet51MapChunk(worldserver.getChunkAt(chunkcoordintpair.x, chunkcoordintpair.z), true, 0));
                            List list = worldserver.getTileEntities(chunkcoordintpair.x * 16, 0, chunkcoordintpair.z * 16, chunkcoordintpair.x * 16 + 16, 256, chunkcoordintpair.z * 16 + 16);
                            for(int k = 0; k < list.size(); k++)
                                a((TileEntity)list.get(k));

                        }
                    }
                }
            }
        }
        if(J)
        {
            if(activeContainer != defaultContainer)
                closeInventory();
            if(vehicle != null)
            {
                mount(vehicle);
            } else
            {
                K += 0.0125F;
                if(K >= 1.0F)
                {
                    K = 1.0F;
                    I = 10;
                    boolean flag2 = false;
                    byte b0;
                    if(dimension == -1)
                        b0 = 0;
                    else
                        b0 = -1;
                    server.serverConfigurationManager.changeDimension(this, b0);
                    lastSentExp = -1;
                    cf = -1;
                    cg = -1;
                    a(((Statistic) (AchievementList.x)));
                }
            }
            J = false;
        } else
        {
            if(K > 0.0F)
                K -= 0.05F;
            if(K < 0.0F)
                K = 0.0F;
        }
        if(I > 0)
            I--;
        if(getHealth() != cf || cg != foodData.a() || (foodData.c() == 0.0F) != ch)
        {
            netServerHandler.sendPacket(new Packet8UpdateHealth(getHealth(), foodData.a(), foodData.c()));
            cf = getHealth();
            cg = foodData.a();
            ch = foodData.c() == 0.0F;
        }
        if(expTotal != lastSentExp)
        {
            lastSentExp = expTotal;
            netServerHandler.sendPacket(new Packet43SetExperience(exp, expTotal, expLevel));
        }
        if(oldLevel == -1)
            oldLevel = expLevel;
        if(oldLevel != expLevel)
        {
            CraftEventFactory.callPlayerLevelChangeEvent(world.getServer().getPlayer(this), oldLevel, expLevel);
            oldLevel = expLevel;
        }
    }

    public void e(int i)
    {
        if(dimension == 1 && i == 1)
        {
            a(AchievementList.C);
            world.kill(this);
            viewingCredits = true;
            netServerHandler.sendPacket(new Packet70Bed(4, 0));
        } else
        {
            a(AchievementList.B);
            server.serverConfigurationManager.changeDimension(this, 1);
            lastSentExp = -1;
            cf = -1;
            cg = -1;
        }
    }

    private void a(TileEntity tileentity)
    {
        if(tileentity != null)
        {
            Packet packet = tileentity.d();
            if(packet != null)
                netServerHandler.sendPacket(packet);
        }
    }

    public void receive(net.minecraft.server.Entity entity, int i)
    {
        if(!entity.dead)
        {
            EntityTracker entitytracker = server.getTracker(dimension);
            if(entity instanceof EntityItem)
                entitytracker.a(entity, new Packet22Collect(entity.id, id));
            if(entity instanceof EntityArrow)
                entitytracker.a(entity, new Packet22Collect(entity.id, id));
            if(entity instanceof EntityExperienceOrb)
                entitytracker.a(entity, new Packet22Collect(entity.id, id));
        }
        super.receive(entity, i);
        activeContainer.a();
    }

    public void C_()
    {
        if(!t)
        {
            u = -1;
            t = true;
            EntityTracker entitytracker = server.getTracker(dimension);
            entitytracker.a(this, new Packet18ArmAnimation(this, 1));
        }
    }

    public void E()
    {
    }

    public EnumBedResult a(int i, int j, int k)
    {
        EnumBedResult enumbedresult = super.a(i, j, k);
        if(enumbedresult == EnumBedResult.OK)
        {
            EntityTracker entitytracker = server.getTracker(dimension);
            Packet17EntityLocationAction packet17entitylocationaction = new Packet17EntityLocationAction(this, 0, i, j, k);
            entitytracker.a(this, packet17entitylocationaction);
            netServerHandler.a(locX, locY, locZ, yaw, pitch);
            netServerHandler.sendPacket(packet17entitylocationaction);
        }
        return enumbedresult;
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        if(isSleeping())
        {
            EntityTracker entitytracker = server.getTracker(dimension);
            entitytracker.sendPacketToEntity(this, new Packet18ArmAnimation(this, 3));
        }
        super.a(flag, flag1, flag2);
        if(netServerHandler != null)
            netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    public void mount(net.minecraft.server.Entity entity)
    {
        setPassengerOf(entity);
    }

    public void setPassengerOf(net.minecraft.server.Entity entity)
    {
        super.setPassengerOf(entity);
        netServerHandler.sendPacket(new Packet39AttachEntity(this, vehicle));
        netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    protected void a(double d1, boolean flag1)
    {
    }

    public void b(double d0, boolean flag)
    {
        super.a(d0, flag);
    }

    public int nextContainerCounter()
    {
        containerCounter = containerCounter % 100 + 1;
        return containerCounter;
    }

    public void startCrafting(int i, int j, int k)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerWorkbench(inventory, world, i, j, k));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 1, "Crafting", 9));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void startEnchanting(int i, int j, int k)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerEnchantTable(inventory, world, i, j, k));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 4, "Enchanting", 9));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void openContainer(IInventory iinventory)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerChest(inventory, iinventory));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 0, iinventory.getName(), iinventory.getSize()));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void openFurnace(TileEntityFurnace tileentityfurnace)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerFurnace(inventory, tileentityfurnace));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 2, tileentityfurnace.getName(), tileentityfurnace.getSize()));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void openDispenser(TileEntityDispenser tileentitydispenser)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerDispenser(inventory, tileentitydispenser));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 3, tileentitydispenser.getName(), tileentitydispenser.getSize()));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void openBrewingStand(TileEntityBrewingStand tileentitybrewingstand)
    {
        Container container = CraftEventFactory.callInventoryOpenEvent(this, new ContainerBrewingStand(inventory, tileentitybrewingstand));
        if(container == null)
        {
            return;
        } else
        {
            nextContainerCounter();
            netServerHandler.sendPacket(new Packet100OpenWindow(containerCounter, 5, tileentitybrewingstand.getName(), tileentitybrewingstand.getSize()));
            activeContainer = container;
            activeContainer.windowId = containerCounter;
            activeContainer.addSlotListener(this);
            return;
        }
    }

    public void a(Container container, int i, ItemStack itemstack)
    {
        if(!(container.getSlot(i) instanceof SlotResult) && !h)
            netServerHandler.sendPacket(new Packet103SetSlot(container.windowId, i, itemstack));
    }

    public void updateInventory(Container container)
    {
        a(container, container.b());
    }

    public void a(Container container, List list)
    {
        netServerHandler.sendPacket(new Packet104WindowItems(container.windowId, list));
        netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.getCarried()));
        if(EnumSet.of(InventoryType.CRAFTING, InventoryType.WORKBENCH).contains(container.getBukkitView().getType()))
            netServerHandler.sendPacket(new Packet103SetSlot(container.windowId, 0, container.getSlot(0).getItem()));
    }

    public void setContainerData(Container container, int i, int j)
    {
        netServerHandler.sendPacket(new Packet105CraftProgressBar(container.windowId, i, j));
    }

    public void carriedChanged(ItemStack itemstack1)
    {
    }

    public void closeInventory()
    {
        netServerHandler.sendPacket(new Packet101CloseWindow(activeContainer.windowId));
        H();
    }

    public void broadcastCarriedItem()
    {
        if(!h)
            netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.getCarried()));
    }

    public void H()
    {
        activeContainer.a(this);
        activeContainer = defaultContainer;
    }

    public void a(Statistic statistic, int i)
    {
        if(statistic != null && !statistic.f)
        {
            for(; i > 100; i -= 100)
                netServerHandler.sendPacket(new Packet200Statistic(statistic.e, 100));

            netServerHandler.sendPacket(new Packet200Statistic(statistic.e, i));
        }
    }

    public void I()
    {
        if(vehicle != null)
            mount(vehicle);
        if(passenger != null)
            passenger.mount(this);
        if(sleeping)
            a(true, false, false);
    }

    public void D_()
    {
        cf = 0xfa0a1f01;
        lastSentExp = -1;
    }

    public void a(String s)
    {
        LocaleLanguage localelanguage = LocaleLanguage.a();
        String s1 = localelanguage.b(s);
        netServerHandler.sendPacket(new Packet3Chat(s1));
    }

    protected void K()
    {
        netServerHandler.sendPacket(new Packet38EntityStatus(id, (byte)9));
        super.K();
    }

    public void a(ItemStack itemstack, int i)
    {
        super.a(itemstack, i);
        if(itemstack != null && itemstack.getItem() != null && itemstack.getItem().d(itemstack) == EnumAnimation.b)
        {
            EntityTracker entitytracker = server.getTracker(dimension);
            entitytracker.sendPacketToEntity(this, new Packet18ArmAnimation(this, 5));
        }
    }

    protected void b(MobEffect mobeffect)
    {
        super.b(mobeffect);
        netServerHandler.sendPacket(new Packet41MobEffect(id, mobeffect));
    }

    protected void c(MobEffect mobeffect)
    {
        super.c(mobeffect);
        netServerHandler.sendPacket(new Packet41MobEffect(id, mobeffect));
    }

    protected void d(MobEffect mobeffect)
    {
        super.d(mobeffect);
        netServerHandler.sendPacket(new Packet42RemoveMobEffect(id, mobeffect));
    }

    public void enderTeleportTo(double d0, double d1, double d2)
    {
        netServerHandler.a(d0, d1, d2, yaw, pitch);
    }

    public void c(net.minecraft.server.Entity entity)
    {
        EntityTracker entitytracker = server.getTracker(dimension);
        entitytracker.sendPacketToEntity(this, new Packet18ArmAnimation(entity, 6));
    }

    public void d(net.minecraft.server.Entity entity)
    {
        EntityTracker entitytracker = server.getTracker(dimension);
        entitytracker.sendPacketToEntity(this, new Packet18ArmAnimation(entity, 7));
    }

    public void updateAbilities()
    {
        if(netServerHandler != null)
            netServerHandler.sendPacket(new Packet202Abilities(abilities));
    }

    public long getPlayerTime()
    {
        if(relativeTime)
            return world.getTime() + timeOffset;
        else
            return (world.getTime() - world.getTime() % 24000L) + timeOffset;
    }

    public String toString()
    {
        return (new StringBuilder()).append(super.toString()).append("(").append(name).append(" at ").append(locX).append(",").append(locY).append(",").append(locZ).append(")").toString();
    }

    public void reset()
    {
        float exp = 0.0F;
        if(keepLevel)
        {
            exp = this.exp;
            newTotalExp = expTotal;
            newLevel = expLevel;
        }
        health = 20;
        fireTicks = 0;
        fallDistance = 0.0F;
        foodData = new FoodMetaData();
        expLevel = newLevel;
        expTotal = newTotalExp;
        this.exp = 0.0F;
        deathTicks = 0;
        effects.clear();
        activeContainer = defaultContainer;
        lastSentExp = -1;
        if(keepLevel)
            this.exp = exp;
        else
            giveExp(newExp);
        keepLevel = false;
    }

    public CraftPlayer getBukkitEntity()
    {
        return (CraftPlayer)super.getBukkitEntity();
    }

    public volatile HumanEntity getBukkitEntity()
    {
        return getBukkitEntity();
    }

    public volatile Entity getBukkitEntity()
    {
        return getBukkitEntity();
    }

    public NetServerHandler netServerHandler;
    public MinecraftServer server;
    public ItemInWorldManager itemInWorldManager;
    public double d;
    public double e;
    public List chunkCoordIntPairQueue;
    public Set playerChunkCoordIntPairs;
    private int cf;
    private int cg;
    private boolean ch;
    public int lastSentExp;
    public int invulnerableTicks;
    private ItemStack ck[] = {
        null, null, null, null, null
    };
    private int containerCounter;
    public boolean h;
    public int ping;
    public boolean viewingCredits;
    public String displayName;
    public String listName;
    public Location compassTarget;
    public int newExp;
    public int newLevel;
    public int newTotalExp;
    public boolean keepLevel;
    public long timeOffset;
    public boolean relativeTime;
}
