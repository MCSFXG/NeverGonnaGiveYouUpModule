// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MobEffectList.java

package net.minecraft.server;

import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.craftbukkit.potion.CraftPotionEffectType;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.potion.PotionEffectType;

// Referenced classes of package net.minecraft.server:
//            EntityHuman, InstantMobEffect, EntityLiving, DamageSource, 
//            EntityPotion

public class MobEffectList
{

    protected MobEffectList(int i, boolean flag, int j)
    {
        I = "";
        J = -1;
        id = i;
        byId[i] = this;
        K = flag;
        if(flag)
            L = 0.5D;
        else
            L = 1.0D;
        N = j;
        PotionEffectType.registerPotionEffectType(new CraftPotionEffectType(this));
    }

    protected MobEffectList a(int i, int j)
    {
        J = i + j * 8;
        return this;
    }

    public int getId()
    {
        return id;
    }

    public void tick(EntityLiving entityliving, int i)
    {
        if(id == REGENERATION.id)
        {
            if(entityliving.getHealth() < entityliving.getMaxHealth())
                entityliving.heal(1, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.MAGIC_REGEN);
        } else
        if(id == POISON.id)
        {
            if(entityliving.getHealth() > 1)
            {
                EntityDamageEvent event = CraftEventFactory.callEntityDamageEvent(null, entityliving, org.bukkit.event.entity.EntityDamageEvent.DamageCause.POISON, 1);
                if(!event.isCancelled() && event.getDamage() > 0)
                    entityliving.damageEntity(DamageSource.MAGIC, event.getDamage());
            }
        } else
        if(id == HUNGER.id && (entityliving instanceof EntityHuman))
            ((EntityHuman)entityliving).c(0.025F * (float)(i + 1));
        else
        if((id != HEAL.id || entityliving.aN()) && (id != HARM.id || !entityliving.aN()))
        {
            if(id == HARM.id && !entityliving.aN() || id == HEAL.id && entityliving.aN())
            {
                EntityDamageEvent event = CraftEventFactory.callEntityDamageEvent(null, entityliving, org.bukkit.event.entity.EntityDamageEvent.DamageCause.MAGIC, 6 << i);
                if(!event.isCancelled() && event.getDamage() > 0)
                    entityliving.damageEntity(DamageSource.MAGIC, event.getDamage());
            }
        } else
        {
            entityliving.heal(6 << i, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.MAGIC);
        }
    }

    public void applyInstantEffect(EntityLiving entityliving, EntityLiving entityliving1, int i, double d0)
    {
        applyInstantEffect(entityliving, entityliving1, i, d0, null);
    }

    public void applyInstantEffect(EntityLiving entityliving, EntityLiving entityliving1, int i, double d0, EntityPotion potion)
    {
        if((id != HEAL.id || entityliving1.aN()) && (id != HARM.id || !entityliving1.aN()))
        {
            if(id == HARM.id && !entityliving1.aN() || id == HEAL.id && entityliving1.aN())
            {
                int j = (int)(d0 * (double)(6 << i) + 0.5D);
                if(entityliving == null)
                    entityliving1.damageEntity(DamageSource.MAGIC, j);
                else
                    entityliving1.damageEntity(DamageSource.b(((Entity) (potion == null ? ((Entity) (entityliving1)) : ((Entity) (potion)))), entityliving), j);
            }
        } else
        {
            int j = (int)(d0 * (double)(6 << i) + 0.5D);
            entityliving1.heal(j, org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason.MAGIC);
        }
    }

    public boolean isInstant()
    {
        return false;
    }

    public boolean b(int i, int j)
    {
        if(id != REGENERATION.id && id != POISON.id)
        {
            return id == HUNGER.id;
        } else
        {
            int k = 25 >> j;
            return k <= 0 ? true : i % k == 0;
        }
    }

    public MobEffectList a(String s)
    {
        I = s;
        return this;
    }

    public String c()
    {
        return I;
    }

    protected MobEffectList a(double d0)
    {
        L = d0;
        return this;
    }

    public double getDurationModifier()
    {
        return L;
    }

    public MobEffectList e()
    {
        M = true;
        return this;
    }

    public boolean f()
    {
        return M;
    }

    public int g()
    {
        return N;
    }

    public static final MobEffectList byId[] = new MobEffectList[32];
    public static final MobEffectList b = null;
    public static final MobEffectList FASTER_MOVEMENT = (new MobEffectList(1, false, 0x7cafc6)).a("potion.moveSpeed").a(0, 0);
    public static final MobEffectList SLOWER_MOVEMENT = (new MobEffectList(2, true, 0x5a6c81)).a("potion.moveSlowdown").a(1, 0);
    public static final MobEffectList FASTER_DIG = (new MobEffectList(3, false, 0xd9c043)).a("potion.digSpeed").a(2, 0).a(1.5D);
    public static final MobEffectList SLOWER_DIG = (new MobEffectList(4, true, 0x4a4217)).a("potion.digSlowDown").a(3, 0);
    public static final MobEffectList INCREASE_DAMAGE = (new MobEffectList(5, false, 0x932423)).a("potion.damageBoost").a(4, 0);
    public static final MobEffectList HEAL = (new InstantMobEffect(6, false, 0xf82423)).a("potion.heal");
    public static final MobEffectList HARM = (new InstantMobEffect(7, true, 0x430a09)).a("potion.harm");
    public static final MobEffectList JUMP = (new MobEffectList(8, false, 0x786297)).a("potion.jump").a(2, 1);
    public static final MobEffectList CONFUSION = (new MobEffectList(9, true, 0x551d4a)).a("potion.confusion").a(3, 1).a(0.25D);
    public static final MobEffectList REGENERATION = (new MobEffectList(10, false, 0xcd5cab)).a("potion.regeneration").a(7, 0).a(0.25D);
    public static final MobEffectList RESISTANCE = (new MobEffectList(11, false, 0x99453a)).a("potion.resistance").a(6, 1);
    public static final MobEffectList FIRE_RESISTANCE = (new MobEffectList(12, false, 0xe49a3a)).a("potion.fireResistance").a(7, 1);
    public static final MobEffectList WATER_BREATHING = (new MobEffectList(13, false, 0x2e5299)).a("potion.waterBreathing").a(0, 2);
    public static final MobEffectList INVISIBILITY = (new MobEffectList(14, false, 0x7f8392)).a("potion.invisibility").a(0, 1).e();
    public static final MobEffectList BLINDNESS = (new MobEffectList(15, true, 0x1f1f23)).a("potion.blindness").a(5, 1).a(0.25D);
    public static final MobEffectList NIGHT_VISION = (new MobEffectList(16, false, 0x1f1fa1)).a("potion.nightVision").a(4, 1).e();
    public static final MobEffectList HUNGER = (new MobEffectList(17, true, 0x587653)).a("potion.hunger").a(1, 1);
    public static final MobEffectList WEAKNESS = (new MobEffectList(18, true, 0x484d48)).a("potion.weakness").a(5, 0);
    public static final MobEffectList POISON = (new MobEffectList(19, true, 0x4e9331)).a("potion.poison").a(6, 0).a(0.25D);
    public static final MobEffectList v = null;
    public static final MobEffectList w = null;
    public static final MobEffectList x = null;
    public static final MobEffectList y = null;
    public static final MobEffectList z = null;
    public static final MobEffectList A = null;
    public static final MobEffectList B = null;
    public static final MobEffectList C = null;
    public static final MobEffectList D = null;
    public static final MobEffectList E = null;
    public static final MobEffectList F = null;
    public static final MobEffectList G = null;
    public final int id;
    private String I;
    private int J;
    private final boolean K;
    private double L;
    private boolean M;
    private final int N;

}
