// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Item, EnumToolMaterial, ItemStack, Block, 
//            EntityLiving, Entity

public class ItemTool extends Item
{

    protected ItemTool(int i, int j, EnumToolMaterial enumtoolmaterial, Block ablock[])
    {
        super(i);
        a = 4F;
        b = enumtoolmaterial;
        bU = ablock;
        maxStackSize = 1;
        setMaxDurability(enumtoolmaterial.a());
        a = enumtoolmaterial.b();
        bV = j + enumtoolmaterial.c();
    }

    public float getDestroySpeed(ItemStack itemstack, Block block)
    {
        for(int i = 0; i < bU.length; i++)
            if(bU[i] == block)
                return a;

        return 1.0F;
    }

    public boolean a(ItemStack itemstack, EntityLiving entityliving, EntityLiving entityliving1)
    {
        itemstack.damage(2, entityliving1);
        return true;
    }

    public boolean a(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
    {
        itemstack.damage(1, entityliving);
        return true;
    }

    public int a(Entity entity)
    {
        return bV;
    }

    public int c()
    {
        return b.e();
    }

    private Block bU[];
    protected float a;
    private int bV;
    protected EnumToolMaterial b;
}
