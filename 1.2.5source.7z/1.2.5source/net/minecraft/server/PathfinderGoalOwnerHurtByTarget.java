// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoalTarget, EntityTameableAnimal, EntityLiving

public class PathfinderGoalOwnerHurtByTarget extends PathfinderGoalTarget
{

    public PathfinderGoalOwnerHurtByTarget(EntityTameableAnimal entitytameableanimal)
    {
        super(entitytameableanimal, 32F, false);
        a = entitytameableanimal;
        a(1);
    }

    public boolean a()
    {
        if(!a.isTamed())
            return false;
        EntityLiving entityliving = a.getOwner();
        if(entityliving == null)
        {
            return false;
        } else
        {
            b = entityliving.ao();
            return a(b, false);
        }
    }

    public void c()
    {
        c.b(b);
        super.c();
    }

    EntityTameableAnimal a;
    EntityLiving b;
}
