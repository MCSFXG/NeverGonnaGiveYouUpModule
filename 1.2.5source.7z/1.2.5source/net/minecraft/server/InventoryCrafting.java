// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   InventoryCrafting.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            ItemStack, IInventory, EntityHuman, Container, 
//            CraftingRecipe

public class InventoryCrafting
    implements IInventory
{

    public ItemStack[] getContents()
    {
        return items;
    }

    public void onOpen(CraftHumanEntity who)
    {
        transaction.add(who);
    }

    public InventoryType getInvType()
    {
        return items.length != 4 ? InventoryType.WORKBENCH : InventoryType.CRAFTING;
    }

    public void onClose(CraftHumanEntity who)
    {
        transaction.remove(who);
    }

    public List getViewers()
    {
        return transaction;
    }

    public InventoryHolder getOwner()
    {
        return owner.getBukkitEntity();
    }

    public void setMaxStackSize(int size)
    {
        maxStack = size;
        resultInventory.setMaxStackSize(size);
    }

    public InventoryCrafting(Container container, int i, int j, EntityHuman player)
    {
        this(container, i, j);
        owner = player;
    }

    public InventoryCrafting(Container container, int i, int j)
    {
        transaction = new ArrayList();
        maxStack = 64;
        int k = i * j;
        items = new ItemStack[k];
        c = container;
        b = i;
    }

    public int getSize()
    {
        return items.length;
    }

    public ItemStack getItem(int i)
    {
        return i < getSize() ? items[i] : null;
    }

    public ItemStack b(int i, int j)
    {
        if(i >= 0 && i < b)
        {
            int k = i + j * b;
            return getItem(k);
        } else
        {
            return null;
        }
    }

    public String getName()
    {
        return "container.crafting";
    }

    public ItemStack splitWithoutUpdate(int i)
    {
        if(items[i] != null)
        {
            ItemStack itemstack = items[i];
            items[i] = null;
            return itemstack;
        } else
        {
            return null;
        }
    }

    public ItemStack splitStack(int i, int j)
    {
        if(items[i] != null)
        {
            ItemStack itemstack;
            if(items[i].count <= j)
            {
                itemstack = items[i];
                items[i] = null;
                c.a(this);
                return itemstack;
            }
            itemstack = items[i].a(j);
            if(items[i].count == 0)
                items[i] = null;
            c.a(this);
            return itemstack;
        } else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        items[i] = itemstack;
        c.a(this);
    }

    public int getMaxStackSize()
    {
        return maxStack;
    }

    public void update()
    {
    }

    public boolean a(EntityHuman entityhuman)
    {
        return true;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    private ItemStack items[];
    private int b;
    private Container c;
    public List transaction;
    public CraftingRecipe currentRecipe;
    public IInventory resultInventory;
    private EntityHuman owner;
    private int maxStack;
}
