// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            NBTTagCompound, OldChunk, OldNibbleArray, NBTTagList, 
//            NibbleArray, WorldChunkManager, BiomeBase

public class OldChunkLoader
{

    public OldChunkLoader()
    {
    }

    public static OldChunk a(NBTTagCompound nbttagcompound)
    {
        int i = nbttagcompound.getInt("xPos");
        int j = nbttagcompound.getInt("zPos");
        OldChunk oldchunk = new OldChunk(i, j);
        oldchunk.g = nbttagcompound.getByteArray("Blocks");
        oldchunk.f = new OldNibbleArray(nbttagcompound.getByteArray("Data"), 7);
        oldchunk.e = new OldNibbleArray(nbttagcompound.getByteArray("SkyLight"), 7);
        oldchunk.d = new OldNibbleArray(nbttagcompound.getByteArray("BlockLight"), 7);
        oldchunk.c = nbttagcompound.getByteArray("HeightMap");
        oldchunk.b = nbttagcompound.getBoolean("TerrainPopulated");
        oldchunk.h = nbttagcompound.getList("Entities");
        oldchunk.i = nbttagcompound.getList("TileEntities");
        oldchunk.j = nbttagcompound.getList("TileTicks");
        try
        {
            oldchunk.a = nbttagcompound.getLong("LastUpdate");
        }
        catch(ClassCastException classcastexception)
        {
            oldchunk.a = nbttagcompound.getInt("LastUpdate");
        }
        return oldchunk;
    }

    public static void a(OldChunk oldchunk, NBTTagCompound nbttagcompound, WorldChunkManager worldchunkmanager)
    {
        nbttagcompound.setInt("xPos", oldchunk.k);
        nbttagcompound.setInt("zPos", oldchunk.l);
        nbttagcompound.setLong("LastUpdate", oldchunk.a);
        int ai[] = new int[oldchunk.c.length];
        for(int i = 0; i < oldchunk.c.length; i++)
            ai[i] = oldchunk.c[i];

        nbttagcompound.setIntArray("HeightMap", ai);
        nbttagcompound.setBoolean("TerrainPopulated", oldchunk.b);
        NBTTagList nbttaglist = new NBTTagList("Sections");
        for(int j = 0; j < 8; j++)
        {
            boolean flag = true;
            for(int l = 0; l < 16 && flag; l++)
            {
label0:
                for(int j1 = 0; j1 < 16 && flag; j1++)
                {
                    int k1 = 0;
                    do
                    {
                        if(k1 >= 16)
                            continue label0;
                        int l1 = l << 11 | k1 << 7 | j1 + (j << 4);
                        byte byte0 = oldchunk.g[l1];
                        if(byte0 != 0)
                        {
                            flag = false;
                            continue label0;
                        }
                        k1++;
                    } while(true);
                }

            }

            if(flag)
                continue;
            byte abyte1[] = new byte[4096];
            NibbleArray nibblearray = new NibbleArray(abyte1.length, 4);
            NibbleArray nibblearray1 = new NibbleArray(abyte1.length, 4);
            NibbleArray nibblearray2 = new NibbleArray(abyte1.length, 4);
            for(int i2 = 0; i2 < 16; i2++)
            {
                for(int j2 = 0; j2 < 16; j2++)
                {
                    for(int k2 = 0; k2 < 16; k2++)
                    {
                        int l2 = i2 << 11 | k2 << 7 | j2 + (j << 4);
                        byte byte1 = oldchunk.g[l2];
                        abyte1[j2 << 8 | k2 << 4 | i2] = (byte)(byte1 & 0xff);
                        nibblearray.a(i2, j2, k2, oldchunk.f.a(i2, j2 + (j << 4), k2));
                        nibblearray1.a(i2, j2, k2, oldchunk.e.a(i2, j2 + (j << 4), k2));
                        nibblearray2.a(i2, j2, k2, oldchunk.d.a(i2, j2 + (j << 4), k2));
                    }

                }

            }

            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound1.setByte("Y", (byte)(j & 0xff));
            nbttagcompound1.setByteArray("Blocks", abyte1);
            nbttagcompound1.setByteArray("Data", nibblearray.a);
            nbttagcompound1.setByteArray("SkyLight", nibblearray1.a);
            nbttagcompound1.setByteArray("BlockLight", nibblearray2.a);
            nbttaglist.add(nbttagcompound1);
        }

        nbttagcompound.set("Sections", nbttaglist);
        byte abyte0[] = new byte[256];
        for(int k = 0; k < 16; k++)
        {
            for(int i1 = 0; i1 < 16; i1++)
                abyte0[i1 << 4 | k] = (byte)(worldchunkmanager.getBiome(oldchunk.k << 4 | k, oldchunk.l << 4 | i1).id & 0xff);

        }

        nbttagcompound.setByteArray("Biomes", abyte0);
        nbttagcompound.set("Entities", oldchunk.h);
        nbttagcompound.set("TileEntities", oldchunk.i);
        if(oldchunk.j != null)
            nbttagcompound.set("TileTicks", oldchunk.j);
    }
}
