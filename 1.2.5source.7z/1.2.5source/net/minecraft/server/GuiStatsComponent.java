// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.awt.*;
import java.text.DecimalFormat;
import javax.swing.JComponent;
import javax.swing.Timer;

// Referenced classes of package net.minecraft.server:
//            GuiStatsListener, NetworkManager, MinecraftServer, WorldServer, 
//            ChunkProviderServer

public class GuiStatsComponent extends JComponent
{

    public GuiStatsComponent(MinecraftServer minecraftserver)
    {
        b = new int[256];
        c = 0;
        d = new String[10];
        e = minecraftserver;
        setPreferredSize(new Dimension(356, 246));
        setMinimumSize(new Dimension(356, 246));
        setMaximumSize(new Dimension(356, 246));
        (new Timer(500, new GuiStatsListener(this))).start();
        setBackground(Color.BLACK);
    }

    private void a()
    {
        int i;
        long l = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.gc();
        d[0] = (new StringBuilder()).append("Memory use: ").append(l / 1024L / 1024L).append(" mb (").append((Runtime.getRuntime().freeMemory() * 100L) / Runtime.getRuntime().maxMemory()).append("% free)").toString();
        d[1] = (new StringBuilder()).append("Threads: ").append(NetworkManager.b).append(" + ").append(NetworkManager.c).toString();
        d[2] = (new StringBuilder()).append("Avg tick: ").append(a.format(a(e.f) * 9.9999999999999995E-007D)).append(" ms").toString();
        d[3] = (new StringBuilder()).append("Avg sent: ").append((int)a(e.u)).append(", Avg size: ").append((int)a(e.v)).toString();
        d[4] = (new StringBuilder()).append("Avg rec: ").append((int)a(e.w)).append(", Avg size: ").append((int)a(e.x)).toString();
        if(e.worldServer == null)
            break MISSING_BLOCK_LABEL_446;
        i = 0;
_L3:
        if(i >= e.worldServer.length) goto _L2; else goto _L1
_L1:
        d[5 + i] = (new StringBuilder()).append("Lvl ").append(i).append(" tick: ").append(a.format(a(e.g[i]) * 9.9999999999999995E-007D)).append(" ms").toString();
        if(e.worldServer[i] == null || e.worldServer[i].chunkProviderServer == null)
            continue; /* Loop/switch isn't completed */
        new StringBuilder();
        d;
        5 + i;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        ", ";
        append();
        e.worldServer[i].chunkProviderServer.d();
        append();
        toString();
        JVM INSTR aastore ;
        i++;
          goto _L3
_L2:
        b[c++ & 0xff] = (int)((a(e.v) * 100D) / 12500D);
        repaint();
        return;
    }

    private double a(long al[])
    {
        long l = 0L;
        for(int i = 0; i < al.length; i++)
            l += al[i];

        return (double)l / (double)al.length;
    }

    public void paint(Graphics g)
    {
        g.setColor(new Color(0xffffff));
        g.fillRect(0, 0, 356, 246);
        for(int i = 0; i < 256; i++)
        {
            int k = b[i + c & 0xff];
            g.setColor(new Color(k + 28 << 16));
            g.fillRect(i, 100 - k, 1, k);
        }

        g.setColor(Color.BLACK);
        for(int j = 0; j < d.length; j++)
        {
            String s = d[j];
            if(s != null)
                g.drawString(s, 32, 116 + j * 16);
        }

    }

    static void a(GuiStatsComponent guistatscomponent)
    {
        guistatscomponent.a();
    }

    private static final DecimalFormat a = new DecimalFormat("########0.000");
    private int b[];
    private int c;
    private String d[];
    private final MinecraftServer e;

}
