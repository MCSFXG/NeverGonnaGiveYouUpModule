// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Enchantment, EnchantmentSlotType, DamageSource

public class EnchantmentProtection extends Enchantment
{

    public EnchantmentProtection(int i, int j, int k)
    {
        super(i, j, EnchantmentSlotType.ARMOR);
        a = k;
        if(k == 2)
            slot = EnchantmentSlotType.ARMOR_FEET;
    }

    public int a(int i)
    {
        return B[a] + (i - 1) * C[a];
    }

    public int b(int i)
    {
        return a(i) + D[a];
    }

    public int getMaxLevel()
    {
        return 4;
    }

    public int a(int i, DamageSource damagesource)
    {
        if(damagesource.ignoresInvulnerability())
            return 0;
        int j = (6 + i * i) / 2;
        if(a == 0)
            return j;
        if(a == 1 && damagesource.k())
            return j;
        if(a == 2 && damagesource == DamageSource.FALL)
            return j * 2;
        if(a == 3 && damagesource == DamageSource.EXPLOSION)
            return j;
        if(a == 4 && damagesource.c())
            return j;
        else
            return 0;
    }

    public boolean a(Enchantment enchantment)
    {
        if(enchantment instanceof EnchantmentProtection)
        {
            EnchantmentProtection enchantmentprotection = (EnchantmentProtection)enchantment;
            if(enchantmentprotection.a == a)
                return false;
            return a == 2 || enchantmentprotection.a == 2;
        } else
        {
            return super.a(enchantment);
        }
    }

    private static final String A[] = {
        "all", "fire", "fall", "explosion", "projectile"
    };
    private static final int B[] = {
        1, 10, 5, 5, 3
    };
    private static final int C[] = {
        16, 8, 6, 8, 6
    };
    private static final int D[] = {
        20, 12, 10, 12, 15
    };
    public final int a;

}
