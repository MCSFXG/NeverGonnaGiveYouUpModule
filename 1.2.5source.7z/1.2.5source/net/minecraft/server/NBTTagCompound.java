// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NBTTagCompound.java

package net.minecraft.server;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.server:
//            NBTBase, NBTTagByte, NBTTagShort, NBTTagInt, 
//            NBTTagLong, NBTTagFloat, NBTTagDouble, NBTTagString, 
//            NBTTagByteArray, NBTTagIntArray, NBTTagList

public class NBTTagCompound extends NBTBase
{

    public NBTTagCompound()
    {
        super("");
        map = new HashMap();
    }

    public NBTTagCompound(String s)
    {
        super(s);
        map = new HashMap();
    }

    void write(DataOutput dataoutput)
    {
        NBTBase nbtbase;
        for(Iterator iterator = map.values().iterator(); iterator.hasNext(); NBTBase.a(nbtbase, dataoutput))
            nbtbase = (NBTBase)iterator.next();

        try
        {
            dataoutput.writeByte(0);
        }
        catch(IOException ex)
        {
            Logger.getLogger(net/minecraft/server/NBTTagCompound.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void remove(String name)
    {
        map.remove(name);
    }

    void load(DataInput datainput)
    {
        map.clear();
        NBTBase nbtbase;
        for(; (nbtbase = NBTBase.b(datainput)).getTypeId() != 0; map.put(nbtbase.getName(), nbtbase));
    }

    public Collection d()
    {
        return map.values();
    }

    public byte getTypeId()
    {
        return 10;
    }

    public void set(String s, NBTBase nbtbase)
    {
        map.put(s, nbtbase.setName(s));
    }

    public void setByte(String s, byte b0)
    {
        map.put(s, new NBTTagByte(s, b0));
    }

    public void setShort(String s, short short1)
    {
        map.put(s, new NBTTagShort(s, short1));
    }

    public void setInt(String s, int i)
    {
        map.put(s, new NBTTagInt(s, i));
    }

    public void setLong(String s, long i)
    {
        map.put(s, new NBTTagLong(s, i));
    }

    public void setFloat(String s, float f)
    {
        map.put(s, new NBTTagFloat(s, f));
    }

    public void setDouble(String s, double d0)
    {
        map.put(s, new NBTTagDouble(s, d0));
    }

    public void setString(String s, String s1)
    {
        map.put(s, new NBTTagString(s, s1));
    }

    public void setByteArray(String s, byte abyte[])
    {
        map.put(s, new NBTTagByteArray(s, abyte));
    }

    public void setIntArray(String s, int aint[])
    {
        map.put(s, new NBTTagIntArray(s, aint));
    }

    public void setCompound(String s, NBTTagCompound nbttagcompound)
    {
        map.put(s, nbttagcompound.setName(s));
    }

    public void setBoolean(String s, boolean flag)
    {
        setByte(s, (byte)(flag ? 1 : 0));
    }

    public NBTBase get(String s)
    {
        return (NBTBase)map.get(s);
    }

    public boolean hasKey(String s)
    {
        return map.containsKey(s);
    }

    public byte getByte(String s)
    {
        return map.containsKey(s) ? ((NBTTagByte)map.get(s)).data : 0;
    }

    public short getShort(String s)
    {
        return map.containsKey(s) ? ((NBTTagShort)map.get(s)).data : 0;
    }

    public int getInt(String s)
    {
        return map.containsKey(s) ? ((NBTTagInt)map.get(s)).data : 0;
    }

    public long getLong(String s)
    {
        return map.containsKey(s) ? ((NBTTagLong)map.get(s)).data : 0L;
    }

    public float getFloat(String s)
    {
        return map.containsKey(s) ? ((NBTTagFloat)map.get(s)).data : 0.0F;
    }

    public double getDouble(String s)
    {
        return map.containsKey(s) ? ((NBTTagDouble)map.get(s)).data : 0.0D;
    }

    public String getString(String s)
    {
        return map.containsKey(s) ? ((NBTTagString)map.get(s)).data : "";
    }

    public byte[] getByteArray(String s)
    {
        return map.containsKey(s) ? ((NBTTagByteArray)map.get(s)).data : new byte[0];
    }

    public int[] getIntArray(String s)
    {
        return map.containsKey(s) ? ((NBTTagIntArray)map.get(s)).data : new int[0];
    }

    public NBTTagCompound getCompound(String s)
    {
        return map.containsKey(s) ? (NBTTagCompound)map.get(s) : new NBTTagCompound(s);
    }

    public NBTTagList getList(String s)
    {
        return map.containsKey(s) ? (NBTTagList)map.get(s) : new NBTTagList(s);
    }

    public boolean getBoolean(String s)
    {
        return getByte(s) != 0;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(map.size()).append(" entries").toString();
    }

    public NBTBase clone()
    {
        NBTTagCompound nbttagcompound = new NBTTagCompound(getName());
        String s;
        for(Iterator iterator = map.keySet().iterator(); iterator.hasNext(); nbttagcompound.set(s, ((NBTBase)map.get(s)).clone()))
            s = (String)iterator.next();

        return nbttagcompound;
    }

    public boolean equals(Object object)
    {
        if(super.equals(object))
        {
            NBTTagCompound nbttagcompound = (NBTTagCompound)object;
            return map.entrySet().equals(nbttagcompound.map.entrySet());
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        return super.hashCode() ^ map.hashCode();
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    private Map map;
}
