// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PathfinderGoalSelector.java

package net.minecraft.server;

import java.io.PrintStream;
import org.bukkit.craftbukkit.util.UnsafeList;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoalSelectorItem, PathfinderGoal

public class PathfinderGoalSelector
{

    public PathfinderGoalSelector()
    {
        a = new UnsafeList(16);
        b = new UnsafeList(16);
    }

    public void a(int i, PathfinderGoal pathfindergoal)
    {
        a.add(new PathfinderGoalSelectorItem(this, i, pathfindergoal));
    }

    public void a()
    {
        for(int i = 0; i < a.size(); i++)
        {
            PathfinderGoalSelectorItem pathfindergoalselectoritem = (PathfinderGoalSelectorItem)a.unsafeGet(i);
            boolean flag = b.contains(pathfindergoalselectoritem);
            if(flag)
            {
                if(a(pathfindergoalselectoritem) && pathfindergoalselectoritem.a.b())
                    continue;
                pathfindergoalselectoritem.a.d();
                b.remove(pathfindergoalselectoritem);
            }
            if(a(pathfindergoalselectoritem) && pathfindergoalselectoritem.a.a())
            {
                pathfindergoalselectoritem.a.c();
                b.add(pathfindergoalselectoritem);
            }
        }

        boolean flag1 = false;
        if(flag1 && b.size() > 0)
            System.out.println("Running: ");
        for(int i = 0; i < b.size(); i++)
        {
            PathfinderGoalSelectorItem pathfindergoalselectoritem1 = (PathfinderGoalSelectorItem)b.unsafeGet(i);
            pathfindergoalselectoritem1.a.e();
            if(flag1)
                System.out.println(pathfindergoalselectoritem1.a.toString());
        }

    }

    private boolean a(PathfinderGoalSelectorItem pathfindergoalselectoritem)
    {
        for(int i = 0; i < a.size(); i++)
        {
            PathfinderGoalSelectorItem pathfindergoalselectoritem1 = (PathfinderGoalSelectorItem)a.unsafeGet(i);
            if(pathfindergoalselectoritem1 == pathfindergoalselectoritem)
                continue;
            if(pathfindergoalselectoritem.b >= pathfindergoalselectoritem1.b)
            {
                if(!a(pathfindergoalselectoritem, pathfindergoalselectoritem1) && b.contains(pathfindergoalselectoritem1))
                    return false;
                continue;
            }
            if(!pathfindergoalselectoritem1.a.g() && b.contains(pathfindergoalselectoritem1))
                return false;
        }

        return true;
    }

    private boolean a(PathfinderGoalSelectorItem pathfindergoalselectoritem, PathfinderGoalSelectorItem pathfindergoalselectoritem1)
    {
        return (pathfindergoalselectoritem.a.h() & pathfindergoalselectoritem1.a.h()) == 0;
    }

    private UnsafeList a;
    private UnsafeList b;
}
