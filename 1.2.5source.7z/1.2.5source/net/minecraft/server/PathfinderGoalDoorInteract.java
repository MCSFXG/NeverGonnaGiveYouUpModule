// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityLiving, Navigation, PathEntity, 
//            PathPoint, MathHelper, World, Block, 
//            BlockDoor

public abstract class PathfinderGoalDoorInteract extends PathfinderGoal
{

    public PathfinderGoalDoorInteract(EntityLiving entityliving)
    {
        a = entityliving;
    }

    public boolean a()
    {
        if(!a.positionChanged)
            return false;
        Navigation navigation = a.al();
        PathEntity pathentity = navigation.c();
        if(pathentity == null || pathentity.b() || !navigation.b())
            return false;
        for(int i = 0; i < Math.min(pathentity.e() + 2, pathentity.d()); i++)
        {
            PathPoint pathpoint = pathentity.a(i);
            b = pathpoint.a;
            c = pathpoint.b + 1;
            d = pathpoint.c;
            if(a.e(b, a.locY, d) > 2.25D)
                continue;
            e = a(b, c, d);
            if(e != null)
                return true;
        }

        b = MathHelper.floor(a.locX);
        c = MathHelper.floor(a.locY + 1.0D);
        d = MathHelper.floor(a.locZ);
        e = a(b, c, d);
        return e != null;
    }

    public boolean b()
    {
        return !f;
    }

    public void c()
    {
        f = false;
        g = (float)((double)((float)b + 0.5F) - a.locX);
        h = (float)((double)((float)d + 0.5F) - a.locZ);
    }

    public void e()
    {
        float f1 = (float)((double)((float)b + 0.5F) - a.locX);
        float f2 = (float)((double)((float)d + 0.5F) - a.locZ);
        float f3 = g * f1 + h * f2;
        if(f3 < 0.0F)
            f = true;
    }

    private BlockDoor a(int i, int j, int k)
    {
        int l = a.world.getTypeId(i, j, k);
        if(l != Block.WOODEN_DOOR.id)
        {
            return null;
        } else
        {
            BlockDoor blockdoor = (BlockDoor)Block.byId[l];
            return blockdoor;
        }
    }

    protected EntityLiving a;
    protected int b;
    protected int c;
    protected int d;
    protected BlockDoor e;
    boolean f;
    float g;
    float h;
}
