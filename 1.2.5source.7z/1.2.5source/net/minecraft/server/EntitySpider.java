// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntitySpider.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, DataWatcher, World, Entity, 
//            MathHelper, Item, MonsterType, MobEffect, 
//            MobEffectList, NBTTagCompound

public class EntitySpider extends EntityMonster
{

    public EntitySpider(World world)
    {
        super(world);
        texture = "/mob/spider.png";
        b(1.4F, 0.9F);
        bb = 0.8F;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Byte((byte)0));
    }

    public void e()
    {
        super.e();
    }

    public void F_()
    {
        super.F_();
        if(!world.isStatic)
            a(positionChanged);
    }

    public int getMaxHealth()
    {
        return 16;
    }

    public double x_()
    {
        return (double)length * 0.75D - 0.5D;
    }

    protected boolean g_()
    {
        return false;
    }

    protected Entity findTarget()
    {
        float f = b(1.0F);
        if(f < 0.5F)
        {
            double d0 = 16D;
            return world.findNearbyVulnerablePlayer(this, d0);
        } else
        {
            return null;
        }
    }

    protected String i()
    {
        return "mob.spider";
    }

    protected String j()
    {
        return "mob.spider";
    }

    protected String k()
    {
        return "mob.spiderdeath";
    }

    protected void a(Entity entity, float f)
    {
        float f1 = b(1.0F);
        if(f1 > 0.5F && random.nextInt(100) == 0)
        {
            EntityTargetEvent event = new EntityTargetEvent(getBukkitEntity(), null, org.bukkit.event.entity.EntityTargetEvent.TargetReason.FORGOT_TARGET);
            world.getServer().getPluginManager().callEvent(event);
            if(!event.isCancelled())
            {
                if(event.getTarget() == null)
                    target = null;
                else
                    target = ((CraftEntity)event.getTarget()).getHandle();
                return;
            }
        } else
        if(f > 2.0F && f < 6F && random.nextInt(10) == 0)
        {
            if(onGround)
            {
                double d0 = entity.locX - locX;
                double d1 = entity.locZ - locZ;
                float f2 = MathHelper.sqrt(d0 * d0 + d1 * d1);
                motX = (d0 / (double)f2) * 0.5D * 0.80000001192092896D + motX * 0.20000000298023224D;
                motZ = (d1 / (double)f2) * 0.5D * 0.80000001192092896D + motZ * 0.20000000298023224D;
                motY = 0.40000000596046448D;
            }
        } else
        {
            super.a(entity, f);
        }
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    protected int getLootId()
    {
        return Item.STRING.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        List loot = new ArrayList();
        int k = random.nextInt(3);
        if(i > 0)
            k += random.nextInt(i + 1);
        if(k > 0)
            loot.add(new ItemStack(Item.STRING.id, k));
        if(flag && (random.nextInt(3) == 0 || random.nextInt(1 + i) > 0))
            loot.add(new ItemStack(Item.SPIDER_EYE.id, 1));
        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public boolean t()
    {
        return w();
    }

    public void u()
    {
    }

    public MonsterType getMonsterType()
    {
        return MonsterType.ARTHROPOD;
    }

    public boolean a(MobEffect mobeffect)
    {
        return mobeffect.getEffectId() != MobEffectList.POISON.id ? super.a(mobeffect) : false;
    }

    public boolean w()
    {
        return (datawatcher.getByte(16) & 1) != 0;
    }

    public void a(boolean flag)
    {
        byte b0 = datawatcher.getByte(16);
        if(flag)
            b0 |= 1;
        else
            b0 &= 0xfe;
        datawatcher.watch(16, Byte.valueOf(b0));
    }
}
