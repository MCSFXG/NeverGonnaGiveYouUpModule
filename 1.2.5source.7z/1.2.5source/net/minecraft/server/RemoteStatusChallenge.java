// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.net.DatagramPacket;
import java.util.Date;
import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            RemoteStatusListener

class RemoteStatusChallenge
{

    public RemoteStatusChallenge(RemoteStatusListener remotestatuslistener, DatagramPacket datagrampacket)
    {
        a = remotestatuslistener;
        super();
        time = (new Date()).getTime();
        byte abyte0[] = datagrampacket.getData();
        identity = new byte[4];
        identity[0] = abyte0[3];
        identity[1] = abyte0[4];
        identity[2] = abyte0[5];
        identity[3] = abyte0[6];
        f = new String(identity);
        token = (new Random()).nextInt(0x1000000);
        response = String.format("\t%s%d\0", new Object[] {
            f, Integer.valueOf(token)
        }).getBytes();
    }

    public Boolean isExpired(long l)
    {
        return Boolean.valueOf(time < l);
    }

    public int getToken()
    {
        return token;
    }

    public byte[] getChallengeResponse()
    {
        return response;
    }

    public byte[] getIdentityToken()
    {
        return identity;
    }

    private long time;
    private int token;
    private byte identity[];
    private byte response[];
    private String f;
    final RemoteStatusListener a;
}
