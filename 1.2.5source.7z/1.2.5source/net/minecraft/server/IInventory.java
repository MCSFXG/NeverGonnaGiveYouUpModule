// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IInventory.java

package net.minecraft.server;

import java.util.List;
import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.inventory.InventoryHolder;

// Referenced classes of package net.minecraft.server:
//            ItemStack, EntityHuman

public interface IInventory
{

    public abstract int getSize();

    public abstract ItemStack getItem(int i);

    public abstract ItemStack splitStack(int i, int j);

    public abstract ItemStack splitWithoutUpdate(int i);

    public abstract void setItem(int i, ItemStack itemstack);

    public abstract String getName();

    public abstract int getMaxStackSize();

    public abstract void update();

    public abstract boolean a(EntityHuman entityhuman);

    public abstract void f();

    public abstract void g();

    public abstract ItemStack[] getContents();

    public abstract void onOpen(CraftHumanEntity crafthumanentity);

    public abstract void onClose(CraftHumanEntity crafthumanentity);

    public abstract List getViewers();

    public abstract InventoryHolder getOwner();

    public abstract void setMaxStackSize(int i);

    public static final int MAX_STACK = 64;
}
