// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityLiving, Navigation, ControllerJump

public class PathfinderGoalFloat extends PathfinderGoal
{

    public PathfinderGoalFloat(EntityLiving entityliving)
    {
        a = entityliving;
        a(4);
        entityliving.al().e(true);
    }

    public boolean a()
    {
        return a.aU() || a.aV();
    }

    public void e()
    {
        if(a.an().nextFloat() < 0.8F)
            a.getControllerJump().a();
    }

    private EntityLiving a;
}
