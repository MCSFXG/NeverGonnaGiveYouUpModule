// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            NBTTagCompound

public class PlayerAbilities
{

    public PlayerAbilities()
    {
        isInvulnerable = false;
        isFlying = false;
        canFly = false;
        canInstantlyBuild = false;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.setBoolean("invulnerable", isInvulnerable);
        nbttagcompound1.setBoolean("flying", isFlying);
        nbttagcompound1.setBoolean("mayfly", canFly);
        nbttagcompound1.setBoolean("instabuild", canInstantlyBuild);
        nbttagcompound.set("abilities", nbttagcompound1);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        if(nbttagcompound.hasKey("abilities"))
        {
            NBTTagCompound nbttagcompound1 = nbttagcompound.getCompound("abilities");
            isInvulnerable = nbttagcompound1.getBoolean("invulnerable");
            isFlying = nbttagcompound1.getBoolean("flying");
            canFly = nbttagcompound1.getBoolean("mayfly");
            canInstantlyBuild = nbttagcompound1.getBoolean("instabuild");
        }
    }

    public boolean isInvulnerable;
    public boolean isFlying;
    public boolean canFly;
    public boolean canInstantlyBuild;
}
