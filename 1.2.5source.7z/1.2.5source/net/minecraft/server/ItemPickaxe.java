// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            ItemTool, Block, EnumToolMaterial, Material, 
//            ItemStack

public class ItemPickaxe extends ItemTool
{

    protected ItemPickaxe(int i, EnumToolMaterial enumtoolmaterial)
    {
        super(i, 2, enumtoolmaterial, bU);
    }

    public boolean canDestroySpecialBlock(Block block)
    {
        if(block == Block.OBSIDIAN)
            return b.d() == 3;
        if(block == Block.DIAMOND_BLOCK || block == Block.DIAMOND_ORE)
            return b.d() >= 2;
        if(block == Block.GOLD_BLOCK || block == Block.GOLD_ORE)
            return b.d() >= 2;
        if(block == Block.IRON_BLOCK || block == Block.IRON_ORE)
            return b.d() >= 1;
        if(block == Block.LAPIS_BLOCK || block == Block.LAPIS_ORE)
            return b.d() >= 1;
        if(block == Block.REDSTONE_ORE || block == Block.GLOWING_REDSTONE_ORE)
            return b.d() >= 2;
        if(block.material == Material.STONE)
            return true;
        return block.material == Material.ORE;
    }

    public float getDestroySpeed(ItemStack itemstack, Block block)
    {
        if(block != null && (block.material == Material.ORE || block.material == Material.STONE))
            return a;
        else
            return super.getDestroySpeed(itemstack, block);
    }

    private static Block bU[];

    static 
    {
        bU = (new Block[] {
            Block.COBBLESTONE, Block.DOUBLE_STEP, Block.STEP, Block.STONE, Block.SANDSTONE, Block.MOSSY_COBBLESTONE, Block.IRON_ORE, Block.IRON_BLOCK, Block.COAL_ORE, Block.GOLD_BLOCK, 
            Block.GOLD_ORE, Block.DIAMOND_ORE, Block.DIAMOND_BLOCK, Block.ICE, Block.NETHERRACK, Block.LAPIS_ORE, Block.LAPIS_BLOCK, Block.REDSTONE_ORE, Block.GLOWING_REDSTONE_ORE, Block.RAILS, 
            Block.DETECTOR_RAIL, Block.GOLDEN_RAIL
        });
    }
}
