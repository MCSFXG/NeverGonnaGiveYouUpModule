// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, RandomPositionGenerator, Vec3D, 
//            Navigation

public class PathfinderGoalPanic extends PathfinderGoal
{

    public PathfinderGoalPanic(EntityCreature entitycreature, float f)
    {
        a = entitycreature;
        b = f;
        a(1);
    }

    public boolean a()
    {
        if(a.ao() == null)
            return false;
        Vec3D vec3d = RandomPositionGenerator.a(a, 5, 4);
        if(vec3d == null)
        {
            return false;
        } else
        {
            c = vec3d.a;
            d = vec3d.b;
            e = vec3d.c;
            return true;
        }
    }

    public void c()
    {
        a.al().a(c, d, e, b);
    }

    public boolean b()
    {
        return !a.al().e();
    }

    private EntityCreature a;
    private float b;
    private double c;
    private double d;
    private double e;
}
