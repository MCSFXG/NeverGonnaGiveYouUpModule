// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler

public class Packet132TileEntityData extends Packet
{

    public Packet132TileEntityData()
    {
        lowPriority = true;
    }

    public Packet132TileEntityData(int i, int j, int k, int l, int i1)
    {
        lowPriority = true;
        a = i;
        b = j;
        c = k;
        d = l;
        e = i1;
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readInt();
        b = datainputstream.readShort();
        c = datainputstream.readInt();
        d = datainputstream.readByte();
        e = datainputstream.readInt();
        f = datainputstream.readInt();
        g = datainputstream.readInt();
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeInt(a);
        dataoutputstream.writeShort(b);
        dataoutputstream.writeInt(c);
        dataoutputstream.writeByte((byte)d);
        dataoutputstream.writeInt(e);
        dataoutputstream.writeInt(f);
        dataoutputstream.writeInt(g);
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public int a()
    {
        return 25;
    }

    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
}
