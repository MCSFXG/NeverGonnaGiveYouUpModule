// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            PathfinderGoal, EntityCreature, ChunkCoordinates, Vec3D, 
//            RandomPositionGenerator, Navigation

public class PathfinderGoalMoveTowardsRestriction extends PathfinderGoal
{

    public PathfinderGoalMoveTowardsRestriction(EntityCreature entitycreature, float f)
    {
        a = entitycreature;
        e = f;
        a(1);
    }

    public boolean a()
    {
        if(a.au())
            return false;
        ChunkCoordinates chunkcoordinates = a.av();
        Vec3D vec3d = RandomPositionGenerator.a(a, 16, 7, Vec3D.create(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z));
        if(vec3d == null)
        {
            return false;
        } else
        {
            b = vec3d.a;
            c = vec3d.b;
            d = vec3d.c;
            return true;
        }
    }

    public boolean b()
    {
        return !a.al().e();
    }

    public void c()
    {
        a.al().a(b, c, d, e);
    }

    private EntityCreature a;
    private double b;
    private double c;
    private double d;
    private float e;
}
