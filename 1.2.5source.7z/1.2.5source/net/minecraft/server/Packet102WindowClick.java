// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;

// Referenced classes of package net.minecraft.server:
//            Packet, NetHandler, ItemStack

public class Packet102WindowClick extends Packet
{

    public Packet102WindowClick()
    {
    }

    public void handle(NetHandler nethandler)
    {
        nethandler.a(this);
    }

    public void a(DataInputStream datainputstream)
    {
        a = datainputstream.readByte();
        slot = datainputstream.readShort();
        button = datainputstream.readByte();
        d = datainputstream.readShort();
        shift = datainputstream.readBoolean();
        item = b(datainputstream);
    }

    public void a(DataOutputStream dataoutputstream)
    {
        dataoutputstream.writeByte(a);
        dataoutputstream.writeShort(slot);
        dataoutputstream.writeByte(button);
        dataoutputstream.writeShort(d);
        dataoutputstream.writeBoolean(shift);
        a(item, dataoutputstream);
    }

    public int a()
    {
        return 11;
    }

    public int a;
    public int slot;
    public int button;
    public short d;
    public ItemStack item;
    public boolean shift;
}
