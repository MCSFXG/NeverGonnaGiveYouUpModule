// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Slot, ICrafting, ItemStack, EntityHuman, 
//            InventoryPlayer, IInventory

public abstract class Container
{

    public Container()
    {
        d = new ArrayList();
        e = new ArrayList();
        f = 0;
        a = 0;
        g = new ArrayList();
        b = new HashSet();
    }

    protected void a(Slot slot)
    {
        slot.a = e.size();
        e.add(slot);
        d.add(null);
    }

    public void a(ICrafting icrafting)
    {
        if(g.contains(icrafting))
        {
            throw new IllegalArgumentException("Listener already listening");
        } else
        {
            g.add(icrafting);
            icrafting.a(this, b());
            a();
            return;
        }
    }

    public List b()
    {
        ArrayList arraylist = new ArrayList();
        for(int i = 0; i < e.size(); i++)
            arraylist.add(((Slot)e.get(i)).getItem());

        return arraylist;
    }

    public void a()
    {
        for(int i = 0; i < e.size(); i++)
        {
            ItemStack itemstack = ((Slot)e.get(i)).getItem();
            ItemStack itemstack1 = (ItemStack)d.get(i);
            if(ItemStack.equals(itemstack1, itemstack))
                continue;
            itemstack1 = itemstack != null ? itemstack.j() : null;
            d.set(i, itemstack1);
            for(int j = 0; j < g.size(); j++)
                ((ICrafting)g.get(j)).a(this, i, itemstack1);

        }

    }

    public Slot a(IInventory iinventory, int i)
    {
        for(int j = 0; j < e.size(); j++)
        {
            Slot slot = (Slot)e.get(j);
            if(slot.a(iinventory, i))
                return slot;
        }

        return null;
    }

    public Slot b(int i)
    {
        return (Slot)e.get(i);
    }

    public ItemStack a(int i)
    {
        Slot slot = (Slot)e.get(i);
        if(slot != null)
            return slot.getItem();
        else
            return null;
    }

    public ItemStack a(int i, int j, boolean flag, EntityHuman entityhuman)
    {
        ItemStack itemstack = null;
        if(j == 0 || j == 1)
        {
            InventoryPlayer inventoryplayer = entityhuman.inventory;
            if(i == -999)
            {
                if(inventoryplayer.j() != null && i == -999)
                {
                    if(j == 0)
                    {
                        entityhuman.b(inventoryplayer.j());
                        inventoryplayer.b(null);
                    }
                    if(j == 1)
                    {
                        entityhuman.b(inventoryplayer.j().a(1));
                        if(inventoryplayer.j().count == 0)
                            inventoryplayer.b(null);
                    }
                }
            } else
            if(flag)
            {
                ItemStack itemstack1 = a(i);
                if(itemstack1 != null)
                {
                    int k = itemstack1.count;
                    itemstack = itemstack1.j();
                    Slot slot1 = (Slot)e.get(i);
                    if(slot1 != null && slot1.getItem() != null)
                    {
                        int l = slot1.getItem().count;
                        if(l < k)
                            a(i, j, flag, entityhuman);
                    }
                }
            } else
            {
                Slot slot = (Slot)e.get(i);
                if(slot != null)
                {
                    slot.c();
                    ItemStack itemstack2 = slot.getItem();
                    ItemStack itemstack3 = inventoryplayer.j();
                    if(itemstack2 != null)
                        itemstack = itemstack2.j();
                    if(itemstack2 == null)
                    {
                        if(itemstack3 != null && slot.isAllowed(itemstack3))
                        {
                            int i1 = j != 0 ? 1 : itemstack3.count;
                            if(i1 > slot.d())
                                i1 = slot.d();
                            slot.c(itemstack3.a(i1));
                            if(itemstack3.count == 0)
                                inventoryplayer.b(null);
                        }
                    } else
                    if(itemstack3 == null)
                    {
                        int j1 = j != 0 ? (itemstack2.count + 1) / 2 : itemstack2.count;
                        ItemStack itemstack5 = slot.a(j1);
                        inventoryplayer.b(itemstack5);
                        if(itemstack2.count == 0)
                            slot.c(null);
                        slot.a(inventoryplayer.j());
                    } else
                    if(slot.isAllowed(itemstack3))
                    {
                        if(itemstack2.id != itemstack3.id || itemstack2.e() && itemstack2.getData() != itemstack3.getData())
                        {
                            if(itemstack3.count <= slot.d())
                            {
                                ItemStack itemstack4 = itemstack2;
                                slot.c(itemstack3);
                                inventoryplayer.b(itemstack4);
                            }
                        } else
                        {
                            int k1 = j != 0 ? 1 : itemstack3.count;
                            if(k1 > slot.d() - itemstack2.count)
                                k1 = slot.d() - itemstack2.count;
                            if(k1 > itemstack3.b() - itemstack2.count)
                                k1 = itemstack3.b() - itemstack2.count;
                            itemstack3.a(k1);
                            if(itemstack3.count == 0)
                                inventoryplayer.b(null);
                            itemstack2.count += k1;
                        }
                    } else
                    if(itemstack2.id == itemstack3.id && itemstack3.b() > 1 && (!itemstack2.e() || itemstack2.getData() == itemstack3.getData()))
                    {
                        int l1 = itemstack2.count;
                        if(l1 > 0 && l1 + itemstack3.count <= itemstack3.b())
                        {
                            itemstack3.count += l1;
                            itemstack2.a(l1);
                            if(itemstack2.count == 0)
                                slot.c(null);
                            slot.a(inventoryplayer.j());
                        }
                    }
                }
            }
        }
        return itemstack;
    }

    public void a(EntityHuman entityhuman)
    {
        InventoryPlayer inventoryplayer = entityhuman.inventory;
        if(inventoryplayer.j() != null)
        {
            entityhuman.b(inventoryplayer.j());
            inventoryplayer.b(null);
        }
    }

    public void a(IInventory iinventory)
    {
        a();
    }

    public boolean c(EntityHuman entityhuman)
    {
        return !b.contains(entityhuman);
    }

    public void a(EntityHuman entityhuman, boolean flag)
    {
        if(flag)
            b.remove(entityhuman);
        else
            b.add(entityhuman);
    }

    public abstract boolean b(EntityHuman entityhuman);

    protected void a(ItemStack itemstack, int i, int j, boolean flag)
    {
        int k = i;
        if(flag)
            k = j - 1;
        if(itemstack.c())
            while(itemstack.count > 0 && (!flag && k < j || flag && k >= i)) 
            {
                Slot slot = (Slot)e.get(k);
                ItemStack itemstack1 = slot.getItem();
                if(itemstack1 != null && itemstack1.id == itemstack.id && (!itemstack.e() || itemstack.getData() == itemstack1.getData()))
                {
                    int i1 = itemstack1.count + itemstack.count;
                    if(i1 <= itemstack.b())
                    {
                        itemstack.count = 0;
                        itemstack1.count = i1;
                        slot.c();
                    } else
                    if(itemstack1.count < itemstack.b())
                    {
                        itemstack.count -= itemstack.b() - itemstack1.count;
                        itemstack1.count = itemstack.b();
                        slot.c();
                    }
                }
                if(flag)
                    k--;
                else
                    k++;
            }
        if(itemstack.count > 0)
        {
            int l;
            if(flag)
                l = j - 1;
            else
                l = i;
            do
            {
                if((flag || l >= j) && (!flag || l < i))
                    break;
                Slot slot1 = (Slot)e.get(l);
                ItemStack itemstack2 = slot1.getItem();
                if(itemstack2 == null)
                {
                    slot1.c(itemstack.j());
                    slot1.c();
                    itemstack.count = 0;
                    break;
                }
                if(flag)
                    l--;
                else
                    l++;
            } while(true);
        }
    }

    public List d;
    public List e;
    public int f;
    private short a;
    protected List g;
    private Set b;
}
