// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldServer.java

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.BlockChangeDelegate;
import org.bukkit.World;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.generator.*;
import org.bukkit.entity.LightningStrike;
import org.bukkit.event.weather.LightningStrikeEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            World, EntityList, PlayerManager, EntityHuman, 
//            WorldProviderHell, WorldProviderSky, ChunkProviderServer, TileEntity, 
//            Entity, Packet71Weather, Packet38EntityStatus, Packet60Explosion, 
//            Packet54PlayNoteBlock, EntityPlayer, Packet70Bed, WorldProvider, 
//            MinecraftServer, PropertyManager, IDataManager, WorldData, 
//            MathHelper, ServerConfigurationManager, EntityTracker, Explosion, 
//            NetServerHandler, IChunkProvider

public class WorldServer extends net.minecraft.server.World
    implements BlockChangeDelegate
{

    public WorldServer(MinecraftServer minecraftserver, IDataManager idatamanager, String s, int i, long j, org.bukkit.World.Environment env, 
            ChunkGenerator gen)
    {
        super(idatamanager, s, j, WorldProvider.a(env.getId()), gen, env);
        weirdIsOpCache = false;
        G = new EntityList();
        server = minecraftserver;
        dimension = i;
        pvpMode = minecraftserver.pvpMode;
        manager = new PlayerManager(minecraftserver, dimension, minecraftserver.propertyManager.getInt("view-distance", 10));
    }

    public void entityJoinedWorld(Entity entity, boolean flag)
    {
        if(entity.passenger == null || !(entity.passenger instanceof EntityHuman))
            super.entityJoinedWorld(entity, flag);
    }

    public void vehicleEnteredWorld(Entity entity, boolean flag)
    {
        super.entityJoinedWorld(entity, flag);
    }

    protected IChunkProvider b()
    {
        IChunkLoader ichunkloader = w.a(worldProvider);
        org.bukkit.craftbukkit.generator.InternalChunkGenerator gen;
        if(generator != null)
            gen = new CustomChunkGenerator(this, getSeed(), generator);
        else
        if(worldProvider instanceof WorldProviderHell)
            gen = new NetherChunkGenerator(this, getSeed());
        else
        if(worldProvider instanceof WorldProviderSky)
            gen = new SkyLandsChunkGenerator(this, getSeed());
        else
            gen = new NormalChunkGenerator(this, getSeed());
        chunkProviderServer = new ChunkProviderServer(this, ichunkloader, gen);
        return chunkProviderServer;
    }

    public List getTileEntities(int i, int j, int k, int l, int i1, int j1)
    {
        ArrayList arraylist = new ArrayList();
        for(int k1 = 0; k1 < c.size(); k1++)
        {
            TileEntity tileentity = (TileEntity)c.get(k1);
            if(tileentity.e >= i && tileentity.f >= j && tileentity.g >= k && tileentity.e < l && tileentity.f < i1 && tileentity.g < j1)
                arraylist.add(tileentity);
        }

        return arraylist;
    }

    public boolean a(EntityHuman entityhuman, int i, int j, int k)
    {
        int l = (int)MathHelper.abs(i - worldData.c());
        int i1 = (int)MathHelper.abs(k - worldData.e());
        if(l > i1)
            i1 = l;
        return i1 > getServer().getSpawnRadius() || server.serverConfigurationManager.isOp(entityhuman.name);
    }

    protected void c(Entity entity)
    {
        super.c(entity);
        G.a(entity.id, entity);
    }

    protected void d(Entity entity)
    {
        super.d(entity);
        G.d(entity.id);
    }

    public Entity getEntity(int i)
    {
        return (Entity)G.a(i);
    }

    public boolean a(Entity entity)
    {
        LightningStrikeEvent lightning = new LightningStrikeEvent(getWorld(), (LightningStrike)entity.getBukkitEntity());
        getServer().getPluginManager().callEvent(lightning);
        if(lightning.isCancelled())
            return false;
        if(super.a(entity))
        {
            server.serverConfigurationManager.a(entity.locX, entity.locY, entity.locZ, 512D, dimension, new Packet71Weather(entity));
            return true;
        } else
        {
            return false;
        }
    }

    public void a(Entity entity, byte b0)
    {
        Packet38EntityStatus packet38entitystatus = new Packet38EntityStatus(entity.id, b0);
        server.b(dimension).b(entity, packet38entitystatus);
    }

    public Explosion createExplosion(Entity entity, double d0, double d1, double d2, 
            float f, boolean flag)
    {
        Explosion explosion = super.createExplosion(entity, d0, d1, d2, f, flag);
        if(explosion.wasCanceled)
        {
            return explosion;
        } else
        {
            server.serverConfigurationManager.a(d0, d1, d2, 64D, dimension, new Packet60Explosion(d0, d1, d2, f, explosion.g));
            return explosion;
        }
    }

    public void d(int i, int j, int k, int l, int i1)
    {
        super.d(i, j, k, l, i1);
        server.serverConfigurationManager.a(i, j, k, 64D, dimension, new Packet54PlayNoteBlock(i, j, k, l, i1));
    }

    public void saveLevel()
    {
        w.e();
    }

    protected void i()
    {
        boolean flag = v();
        super.i();
        if(flag != v())
        {
            for(int i = 0; i < players.size(); i++)
            {
                if(((EntityPlayer)players.get(i)).world != this)
                    continue;
                if(flag)
                    ((EntityPlayer)players.get(i)).netServerHandler.sendPacket(new Packet70Bed(2));
                else
                    ((EntityPlayer)players.get(i)).netServerHandler.sendPacket(new Packet70Bed(1));
            }

        }
    }

    public ChunkProviderServer chunkProviderServer;
    public boolean weirdIsOpCache;
    public boolean E;
    public final MinecraftServer server;
    private EntityList G;
    public final int dimension;
    public EntityTracker tracker;
    public PlayerManager manager;
}
