// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

// Referenced classes of package net.minecraft.server:
//            Block, ItemStack, Item

public class FurnaceRecipes
{

    public static final FurnaceRecipes a()
    {
        return a;
    }

    private FurnaceRecipes()
    {
        b = new HashMap();
        a(Block.IRON_ORE.id, new ItemStack(Item.IRON_INGOT));
        a(Block.GOLD_ORE.id, new ItemStack(Item.GOLD_INGOT));
        a(Block.DIAMOND_ORE.id, new ItemStack(Item.DIAMOND));
        a(Block.SAND.id, new ItemStack(Block.GLASS));
        a(Item.PORK.id, new ItemStack(Item.GRILLED_PORK));
        a(Item.RAW_FISH.id, new ItemStack(Item.COOKED_FISH));
        a(Block.COBBLESTONE.id, new ItemStack(Block.STONE));
        a(Item.CLAY_BALL.id, new ItemStack(Item.CLAY_BRICK));
        a(Block.CACTUS.id, new ItemStack(Item.INK_SACK, 1, 2));
        a(Block.LOG.id, new ItemStack(Item.COAL, 1, 1));
    }

    public void a(int i, ItemStack itemstack)
    {
        b.put(Integer.valueOf(i), itemstack);
    }

    public ItemStack a(int i)
    {
        return (ItemStack)b.get(Integer.valueOf(i));
    }

    public Map b()
    {
        return b;
    }

    private static final FurnaceRecipes a = new FurnaceRecipes();
    private Map b;

}
