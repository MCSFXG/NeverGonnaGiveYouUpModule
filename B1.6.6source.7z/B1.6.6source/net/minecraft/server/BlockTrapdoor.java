// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Block, Material, IBlockAccess, World, 
//            AxisAlignedBB, EntityHuman, Vec3D, MovingObjectPosition

public class BlockTrapdoor extends Block
{

    protected BlockTrapdoor(int i, Material material)
    {
        super(i, material);
        textureId = 84;
        if(material == Material.ORE)
            textureId++;
        float f = 0.5F;
        float f1 = 1.0F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f1, 0.5F + f);
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public AxisAlignedBB d(World world, int i, int j, int k)
    {
        a(world, i, j, k);
        return super.d(world, i, j, k);
    }

    public void a(IBlockAccess iblockaccess, int i, int j, int k)
    {
        c(iblockaccess.getData(i, j, k));
    }

    public void c(int i)
    {
        float f = 0.1875F;
        a(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
        if(d(i))
        {
            if((i & 3) == 0)
                a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
            if((i & 3) == 1)
                a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
            if((i & 3) == 2)
                a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            if((i & 3) == 3)
                a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
    }

    public void b(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        interact(world, i, j, k, entityhuman);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if(material == Material.ORE)
        {
            return true;
        } else
        {
            int l = world.getData(i, j, k);
            world.setData(i, j, k, l ^ 4);
            world.a(entityhuman, 1003, i, j, k, 0);
            return true;
        }
    }

    public void a(World world, int i, int j, int k, boolean flag)
    {
        int l = world.getData(i, j, k);
        boolean flag1 = (l & 4) > 0;
        if(flag1 == flag)
        {
            return;
        } else
        {
            world.setData(i, j, k, l ^ 4);
            world.a(null, 1003, i, j, k, 0);
            return;
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if(world.isStatic)
            return;
        int i1 = world.getData(i, j, k);
        int j1 = i;
        int k1 = k;
        if((i1 & 3) == 0)
            k1++;
        if((i1 & 3) == 1)
            k1--;
        if((i1 & 3) == 2)
            j1++;
        if((i1 & 3) == 3)
            j1--;
        if(!world.d(j1, j, k1))
        {
            world.setTypeId(i, j, k, 0);
            b_(world, i, j, k, i1);
        }
        if(l > 0 && Block.byId[l].isPowerSource())
        {
            boolean flag = world.isBlockIndirectlyPowered(i, j, k);
            a(world, i, j, k, flag);
        }
    }

    public MovingObjectPosition a(World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
    {
        a(((IBlockAccess) (world)), i, j, k);
        return super.a(world, i, j, k, vec3d, vec3d1);
    }

    public void postPlace(World world, int i, int j, int k, int l)
    {
        byte byte0 = 0;
        if(l == 2)
            byte0 = 0;
        if(l == 3)
            byte0 = 1;
        if(l == 4)
            byte0 = 2;
        if(l == 5)
            byte0 = 3;
        world.setData(i, j, k, byte0);
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        if(l == 0)
            return false;
        if(l == 1)
            return false;
        if(l == 2)
            k++;
        if(l == 3)
            k--;
        if(l == 4)
            i++;
        if(l == 5)
            i--;
        return world.d(i, j, k);
    }

    public static boolean d(int i)
    {
        return (i & 4) != 0;
    }
}
