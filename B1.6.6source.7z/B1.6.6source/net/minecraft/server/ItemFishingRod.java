// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            Item, EntityHuman, EntityFish, ItemStack, 
//            World

public class ItemFishingRod extends Item
{

    public ItemFishingRod(int i)
    {
        super(i);
        d(64);
        c(1);
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        if(entityhuman.hookedFish != null)
        {
            int i = entityhuman.hookedFish.h();
            itemstack.damage(i, entityhuman);
            entityhuman.k_();
        } else
        {
            world.makeSound(entityhuman, "random.bow", 0.5F, 0.4F / (b.nextFloat() * 0.4F + 0.8F));
            if(!world.isStatic)
                world.addEntity(new EntityFish(world, entityhuman));
            entityhuman.k_();
        }
        return itemstack;
    }
}
