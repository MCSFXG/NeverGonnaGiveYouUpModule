// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            MaterialTransparent, MaterialMapColor, MaterialLiquid, MaterialLogic, 
//            MaterialPortal

public class Material
{

    public Material(MaterialMapColor materialmapcolor)
    {
        A = materialmapcolor;
    }

    public boolean isLiquid()
    {
        return false;
    }

    public boolean isBuildable()
    {
        return true;
    }

    public boolean blocksLight()
    {
        return true;
    }

    public boolean isSolid()
    {
        return true;
    }

    private Material i()
    {
        D = true;
        return this;
    }

    private Material j()
    {
        canBurn = true;
        return this;
    }

    public boolean isBurnable()
    {
        return canBurn;
    }

    public Material f()
    {
        C = true;
        return this;
    }

    public boolean isReplacable()
    {
        return C;
    }

    public boolean h()
    {
        if(D)
            return false;
        else
            return isSolid();
    }

    public static final Material AIR;
    public static final Material GRASS;
    public static final Material EARTH;
    public static final Material WOOD;
    public static final Material STONE;
    public static final Material ORE;
    public static final Material WATER;
    public static final Material LAVA;
    public static final Material LEAVES;
    public static final Material PLANT;
    public static final Material SPONGE;
    public static final Material CLOTH;
    public static final Material FIRE;
    public static final Material SAND;
    public static final Material ORIENTABLE;
    public static final Material SHATTERABLE;
    public static final Material TNT;
    public static final Material CORAL;
    public static final Material ICE;
    public static final Material SNOW_LAYER;
    public static final Material SNOW_BLOCK;
    public static final Material CACTUS;
    public static final Material CLAY;
    public static final Material PUMPKIN;
    public static final Material PORTAL;
    public static final Material CAKE;
    private boolean canBurn;
    private boolean C;
    private boolean D;
    public final MaterialMapColor A;

    static 
    {
        AIR = new MaterialTransparent(MaterialMapColor.b);
        GRASS = new Material(MaterialMapColor.c);
        EARTH = new Material(MaterialMapColor.l);
        WOOD = (new Material(MaterialMapColor.o)).j();
        STONE = new Material(MaterialMapColor.m);
        ORE = new Material(MaterialMapColor.h);
        WATER = new MaterialLiquid(MaterialMapColor.n);
        LAVA = new MaterialLiquid(MaterialMapColor.f);
        LEAVES = (new Material(MaterialMapColor.i)).j().i();
        PLANT = new MaterialLogic(MaterialMapColor.i);
        SPONGE = new Material(MaterialMapColor.e);
        CLOTH = (new Material(MaterialMapColor.e)).j();
        FIRE = new MaterialTransparent(MaterialMapColor.b);
        SAND = new Material(MaterialMapColor.d);
        ORIENTABLE = new MaterialLogic(MaterialMapColor.b);
        SHATTERABLE = (new Material(MaterialMapColor.b)).i();
        TNT = (new Material(MaterialMapColor.f)).j().i();
        CORAL = new Material(MaterialMapColor.i);
        ICE = (new Material(MaterialMapColor.g)).i();
        SNOW_LAYER = (new MaterialLogic(MaterialMapColor.j)).f().i();
        SNOW_BLOCK = new Material(MaterialMapColor.j);
        CACTUS = (new Material(MaterialMapColor.i)).i();
        CLAY = new Material(MaterialMapColor.k);
        PUMPKIN = new Material(MaterialMapColor.i);
        PORTAL = new MaterialPortal(MaterialMapColor.b);
        CAKE = new Material(MaterialMapColor.b);
    }
}
