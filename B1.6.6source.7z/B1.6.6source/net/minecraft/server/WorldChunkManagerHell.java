// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Arrays;

// Referenced classes of package net.minecraft.server:
//            WorldChunkManager, BiomeBase, ChunkCoordIntPair

public class WorldChunkManagerHell extends WorldChunkManager
{

    public WorldChunkManagerHell(BiomeBase biomebase, double d, double d1)
    {
        e = biomebase;
        f = d;
        g = d1;
    }

    public BiomeBase a(ChunkCoordIntPair chunkcoordintpair)
    {
        return e;
    }

    public BiomeBase getBiome(int i, int j)
    {
        return e;
    }

    public BiomeBase[] a(int i, int j, int k, int l)
    {
        d = a(d, i, j, k, l);
        return d;
    }

    public double[] a(double ad[], int i, int j, int k, int l)
    {
        if(ad == null || ad.length < k * l)
            ad = new double[k * l];
        Arrays.fill(ad, 0, k * l, f);
        return ad;
    }

    public BiomeBase[] a(BiomeBase abiomebase[], int i, int j, int k, int l)
    {
        if(abiomebase == null || abiomebase.length < k * l)
            abiomebase = new BiomeBase[k * l];
        if(a == null || a.length < k * l)
        {
            a = new double[k * l];
            b = new double[k * l];
        }
        Arrays.fill(abiomebase, 0, k * l, e);
        Arrays.fill(b, 0, k * l, g);
        Arrays.fill(a, 0, k * l, f);
        return abiomebase;
    }

    private BiomeBase e;
    private double f;
    private double g;
}
