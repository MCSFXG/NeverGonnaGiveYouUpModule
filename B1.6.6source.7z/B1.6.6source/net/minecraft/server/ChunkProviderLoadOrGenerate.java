// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.IOException;
import java.util.*;

// Referenced classes of package net.minecraft.server:
//            IChunkProvider, EmptyChunk, ChunkCoordIntPair, Chunk, 
//            IChunkLoader, World, IProgressUpdate

public class ChunkProviderLoadOrGenerate
    implements IChunkProvider
{

    public ChunkProviderLoadOrGenerate(World world, IChunkLoader ichunkloader, IChunkProvider ichunkprovider)
    {
        a = new HashSet();
        e = new HashMap();
        f = new ArrayList();
        b = new EmptyChunk(world, new byte[32768], 0, 0);
        g = world;
        d = ichunkloader;
        c = ichunkprovider;
    }

    public boolean isChunkLoaded(int i, int j)
    {
        return e.containsKey(Integer.valueOf(ChunkCoordIntPair.a(i, j)));
    }

    public Chunk getChunkAt(int i, int j)
    {
        int k = ChunkCoordIntPair.a(i, j);
        a.remove(Integer.valueOf(k));
        Chunk chunk = (Chunk)e.get(Integer.valueOf(k));
        if(chunk == null)
        {
            chunk = d(i, j);
            if(chunk == null)
                if(c == null)
                    chunk = b;
                else
                    chunk = c.getOrCreateChunk(i, j);
            e.put(Integer.valueOf(k), chunk);
            f.add(chunk);
            if(chunk != null)
            {
                chunk.loadNOP();
                chunk.addEntities();
            }
            if(!chunk.done && isChunkLoaded(i + 1, j + 1) && isChunkLoaded(i, j + 1) && isChunkLoaded(i + 1, j))
                getChunkAt(((IChunkProvider) (this)), i, j);
            if(isChunkLoaded(i - 1, j) && !getOrCreateChunk(i - 1, j).done && isChunkLoaded(i - 1, j + 1) && isChunkLoaded(i, j + 1) && isChunkLoaded(i - 1, j))
                getChunkAt(((IChunkProvider) (this)), i - 1, j);
            if(isChunkLoaded(i, j - 1) && !getOrCreateChunk(i, j - 1).done && isChunkLoaded(i + 1, j - 1) && isChunkLoaded(i, j - 1) && isChunkLoaded(i + 1, j))
                getChunkAt(((IChunkProvider) (this)), i, j - 1);
            if(isChunkLoaded(i - 1, j - 1) && !getOrCreateChunk(i - 1, j - 1).done && isChunkLoaded(i - 1, j - 1) && isChunkLoaded(i, j - 1) && isChunkLoaded(i - 1, j))
                getChunkAt(((IChunkProvider) (this)), i - 1, j - 1);
        }
        return chunk;
    }

    public Chunk getOrCreateChunk(int i, int j)
    {
        Chunk chunk = (Chunk)e.get(Integer.valueOf(ChunkCoordIntPair.a(i, j)));
        if(chunk == null)
            return getChunkAt(i, j);
        else
            return chunk;
    }

    private Chunk d(int i, int j)
    {
        if(d == null)
            return null;
        try
        {
            Chunk chunk = d.a(g, i, j);
            if(chunk != null)
                chunk.r = g.getTime();
            return chunk;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return null;
    }

    private void a(Chunk chunk)
    {
        if(d == null)
            return;
        try
        {
            d.b(g, chunk);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    private void b(Chunk chunk)
    {
        if(d == null)
            return;
        try
        {
            chunk.r = g.getTime();
            d.a(g, chunk);
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
    }

    public void getChunkAt(IChunkProvider ichunkprovider, int i, int j)
    {
        Chunk chunk = getOrCreateChunk(i, j);
        if(!chunk.done)
        {
            chunk.done = true;
            if(c != null)
            {
                c.getChunkAt(ichunkprovider, i, j);
                chunk.f();
            }
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        int i = 0;
        for(int j = 0; j < f.size(); j++)
        {
            Chunk chunk = (Chunk)f.get(j);
            if(flag && !chunk.p)
                a(chunk);
            if(!chunk.a(flag))
                continue;
            b(chunk);
            chunk.o = false;
            if(++i == 24 && !flag)
                return false;
        }

        if(flag)
        {
            if(d == null)
                return true;
            d.b();
        }
        return true;
    }

    public boolean unloadChunks()
    {
        for(int i = 0; i < 100; i++)
            if(!a.isEmpty())
            {
                Integer integer = (Integer)a.iterator().next();
                Chunk chunk = (Chunk)e.get(integer);
                chunk.removeEntities();
                b(chunk);
                a(chunk);
                a.remove(integer);
                e.remove(integer);
                f.remove(chunk);
            }

        if(d != null)
            d.a();
        return c.unloadChunks();
    }

    public boolean b()
    {
        return true;
    }

    private Set a;
    private Chunk b;
    private IChunkProvider c;
    private IChunkLoader d;
    private Map e;
    private List f;
    private World g;
}
