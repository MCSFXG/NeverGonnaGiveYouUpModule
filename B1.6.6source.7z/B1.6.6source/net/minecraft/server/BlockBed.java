// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Block, Material, World, WorldProvider, 
//            EntityHuman, ChunkCoordinates, EnumBedError, BedBlockTextures, 
//            Item, IBlockAccess

public class BlockBed extends Block
{

    public BlockBed(int i)
    {
        super(i, 134, Material.CLOTH);
        k();
    }

    public boolean interact(World world, int i, int j, int l, EntityHuman entityhuman)
    {
        if(world.isStatic)
            return true;
        int i1 = world.getData(i, j, l);
        if(!d(i1))
        {
            int j1 = c(i1);
            i += a[j1][0];
            l += a[j1][1];
            if(world.getTypeId(i, j, l) != id)
                return true;
            i1 = world.getData(i, j, l);
        }
        if(!world.worldProvider.d())
        {
            double d1 = (double)i + 0.5D;
            double d2 = (double)j + 0.5D;
            double d3 = (double)l + 0.5D;
            world.setTypeId(i, j, l, 0);
            int k1 = c(i1);
            i += a[k1][0];
            l += a[k1][1];
            if(world.getTypeId(i, j, l) == id)
            {
                world.setTypeId(i, j, l, 0);
                d1 = (d1 + (double)i + 0.5D) / 2D;
                d2 = (d2 + (double)j + 0.5D) / 2D;
                d3 = (d3 + (double)l + 0.5D) / 2D;
            }
            world.createExplosion(null, (float)i + 0.5F, (float)j + 0.5F, (float)l + 0.5F, 5F, true);
            return true;
        }
        if(e(i1))
        {
            EntityHuman entityhuman1 = null;
            Iterator iterator = world.players.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                EntityHuman entityhuman2 = (EntityHuman)iterator.next();
                if(entityhuman2.isSleeping())
                {
                    ChunkCoordinates chunkcoordinates = entityhuman2.A;
                    if(chunkcoordinates.x == i && chunkcoordinates.y == j && chunkcoordinates.z == l)
                        entityhuman1 = entityhuman2;
                }
            } while(true);
            if(entityhuman1 == null)
            {
                a(world, i, j, l, false);
            } else
            {
                entityhuman.a("tile.bed.occupied");
                return true;
            }
        }
        EnumBedError enumbederror = entityhuman.a(i, j, l);
        if(enumbederror == EnumBedError.OK)
        {
            a(world, i, j, l, true);
            return true;
        }
        if(enumbederror == EnumBedError.NOT_POSSIBLE_NOW)
            entityhuman.a("tile.bed.noSleep");
        return true;
    }

    public int a(int i, int j)
    {
        if(i == 0)
            return Block.WOOD.textureId;
        int l = c(j);
        int i1 = BedBlockTextures.c[l][i];
        if(d(j))
        {
            if(i1 == 2)
                return textureId + 2 + 16;
            if(i1 == 5 || i1 == 4)
                return textureId + 1 + 16;
            else
                return textureId + 1;
        }
        if(i1 == 3)
            return (textureId - 1) + 16;
        if(i1 == 5 || i1 == 4)
            return textureId + 16;
        else
            return textureId;
    }

    public boolean b()
    {
        return false;
    }

    public boolean a()
    {
        return false;
    }

    public void a(IBlockAccess iblockaccess, int i, int j, int l)
    {
        k();
    }

    public void doPhysics(World world, int i, int j, int l, int i1)
    {
        int j1 = world.getData(i, j, l);
        int k1 = c(j1);
        if(d(j1))
        {
            if(world.getTypeId(i - a[k1][0], j, l - a[k1][1]) != id)
                world.setTypeId(i, j, l, 0);
        } else
        if(world.getTypeId(i + a[k1][0], j, l + a[k1][1]) != id)
        {
            world.setTypeId(i, j, l, 0);
            if(!world.isStatic)
                b_(world, i, j, l, j1);
        }
    }

    public int a(int i, Random random)
    {
        if(d(i))
            return 0;
        else
            return Item.BED.id;
    }

    private void k()
    {
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.5625F, 1.0F);
    }

    public static int c(int i)
    {
        return i & 3;
    }

    public static boolean d(int i)
    {
        return (i & 8) != 0;
    }

    public static boolean e(int i)
    {
        return (i & 4) != 0;
    }

    public static void a(World world, int i, int j, int l, boolean flag)
    {
        int i1 = world.getData(i, j, l);
        if(flag)
            i1 |= 4;
        else
            i1 &= -5;
        world.setData(i, j, l, i1);
    }

    public static ChunkCoordinates g(World world, int i, int j, int l, int i1)
    {
        int j1 = world.getData(i, j, l);
        int k1 = c(j1);
        for(int l1 = 0; l1 <= 1; l1++)
        {
            int i2 = i - a[k1][0] * l1 - 1;
            int j2 = l - a[k1][1] * l1 - 1;
            int k2 = i2 + 2;
            int l2 = j2 + 2;
            for(int i3 = i2; i3 <= k2; i3++)
            {
                for(int j3 = j2; j3 <= l2; j3++)
                {
                    if(!world.d(i3, j - 1, j3) || !world.isEmpty(i3, j, j3) || !world.isEmpty(i3, j + 1, j3))
                        continue;
                    if(i1 > 0)
                        i1--;
                    else
                        return new ChunkCoordinates(i3, j, j3);
                }

            }

        }

        return null;
    }

    public static final int a[][] = {
        {
            0, 1
        }, {
            -1, 0
        }, {
            0, -1
        }, {
            1, 0
        }
    };

}
