// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ServerConfigurationManager.java

package net.minecraft.server;

import java.io.*;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.*;
import org.bukkit.craftbukkit.*;
import org.bukkit.craftbukkit.command.ColouredConsoleSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            WorldServer, Packet3Chat, EntityPlayer, ItemInWorldManager, 
//            Packet70Bed, Packet9Respawn, EntityHuman, Packet4UpdateTime, 
//            MinecraftServer, PropertyManager, IDataManager, PlayerManager, 
//            ChunkProviderServer, PlayerFileData, NetLoginHandler, NetworkManager, 
//            NetServerHandler, EntityTracker, ChunkCoordinates, Packet, 
//            TileEntity

public class ServerConfigurationManager
{

    public ServerConfigurationManager(MinecraftServer minecraftserver)
    {
        players = new ArrayList();
        banByName = new HashSet();
        banByIP = new HashSet();
        h = new HashSet();
        this.i = new HashSet();
        minecraftserver.server = new CraftServer(minecraftserver, this);
        minecraftserver.console = new ColouredConsoleSender(minecraftserver.server);
        cserver = minecraftserver.server;
        server = minecraftserver;
        j = minecraftserver.a("banned-players.txt");
        k = minecraftserver.a("banned-ips.txt");
        l = minecraftserver.a("ops.txt");
        m = minecraftserver.a("white-list.txt");
        int i = minecraftserver.propertyManager.getInt("view-distance", 10);
        maxPlayers = minecraftserver.propertyManager.getInt("max-players", 20);
        o = minecraftserver.propertyManager.getBoolean("white-list", false);
        g();
        i();
        k();
        m();
        h();
        j();
        l();
        n();
    }

    public void setPlayerFileData(WorldServer aworldserver[])
    {
        if(playerFileData != null)
        {
            return;
        } else
        {
            playerFileData = aworldserver[0].p().d();
            return;
        }
    }

    public void a(EntityPlayer entityplayer)
    {
        Iterator i$ = server.worlds.iterator();
        do
        {
            if(!i$.hasNext())
                break;
            WorldServer world = (WorldServer)i$.next();
            if(!world.manager.a.contains(entityplayer))
                continue;
            world.manager.removePlayer(entityplayer);
            break;
        } while(true);
        a(entityplayer.dimension).addPlayer(entityplayer);
        WorldServer worldserver = server.a(entityplayer.dimension);
        worldserver.chunkProviderServer.getChunkAt((int)entityplayer.locX >> 4, (int)entityplayer.locZ >> 4);
    }

    public int a()
    {
        if(server.worlds.size() == 0)
            return server.propertyManager.getInt("view-distance", 10) * 16 - 16;
        else
            return ((WorldServer)server.worlds.get(0)).manager.c();
    }

    private PlayerManager a(int i)
    {
        return server.a(i).manager;
    }

    public void b(EntityPlayer entityplayer)
    {
        playerFileData.b(entityplayer);
    }

    public void c(EntityPlayer entityplayer)
    {
        players.add(entityplayer);
        WorldServer worldserver = server.a(entityplayer.dimension);
        worldserver.chunkProviderServer.getChunkAt((int)entityplayer.locX >> 4, (int)entityplayer.locZ >> 4);
        for(; worldserver.getEntities(entityplayer, entityplayer.boundingBox).size() != 0; entityplayer.setPosition(entityplayer.locX, entityplayer.locY + 1.0D, entityplayer.locZ));
        PlayerJoinEvent playerJoinEvent = new PlayerJoinEvent(cserver.getPlayer(entityplayer), (new StringBuilder()).append("\247e").append(entityplayer.name).append(" joined the game.").toString());
        cserver.getPluginManager().callEvent(playerJoinEvent);
        String joinMessage = playerJoinEvent.getJoinMessage();
        if(joinMessage != null)
            server.serverConfigurationManager.sendAll(new Packet3Chat(joinMessage));
        worldserver.addEntity(entityplayer);
        a(entityplayer.dimension).addPlayer(entityplayer);
    }

    public void d(EntityPlayer entityplayer)
    {
        a(entityplayer.dimension).movePlayer(entityplayer);
    }

    public String disconnect(EntityPlayer entityplayer)
    {
        a(entityplayer.dimension).removePlayer(entityplayer);
        PlayerQuitEvent playerQuitEvent = new PlayerQuitEvent(cserver.getPlayer(entityplayer), (new StringBuilder()).append("\247e").append(entityplayer.name).append(" left the game.").toString());
        cserver.getPluginManager().callEvent(playerQuitEvent);
        playerFileData.a(entityplayer);
        server.a(entityplayer.dimension).kill(entityplayer);
        players.remove(entityplayer);
        a(entityplayer.dimension).removePlayer(entityplayer);
        return playerQuitEvent.getQuitMessage();
    }

    public EntityPlayer a(NetLoginHandler netloginhandler, String s)
    {
        EntityPlayer entity = new EntityPlayer(server, server.a(0), s, new ItemInWorldManager(server.a(0)));
        Player player = entity != null ? (Player)entity.getBukkitEntity() : null;
        PlayerLoginEvent event = new PlayerLoginEvent(player);
        String s1 = netloginhandler.networkManager.getSocketAddress().toString();
        s1 = s1.substring(s1.indexOf("/") + 1);
        s1 = s1.substring(0, s1.indexOf(":"));
        if(banByName.contains(s.trim().toLowerCase()))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_BANNED, "You are banned from this server!");
        else
        if(!isWhitelisted(s))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_WHITELIST, "You are not white-listed on this server!");
        else
        if(banByIP.contains(s1))
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_BANNED, "Your IP address is banned from this server!");
        else
        if(players.size() >= maxPlayers)
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.KICK_FULL, "The server is full!");
        else
            event.disallow(org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED, s1);
        cserver.getPluginManager().callEvent(event);
        if(event.getResult() != org.bukkit.event.player.PlayerLoginEvent.Result.ALLOWED)
        {
            netloginhandler.disconnect(event.getKickMessage());
            return null;
        }
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(entityplayer.name.equalsIgnoreCase(s))
                entityplayer.netServerHandler.disconnect("You logged in from another location");
        }

        return entity;
    }

    public EntityPlayer a(EntityPlayer entityplayer, int i)
    {
        return a(entityplayer, i, null);
    }

    public EntityPlayer a(EntityPlayer entityplayer, int i, Location location)
    {
        server.b(entityplayer.dimension).trackPlayer(entityplayer);
        a(entityplayer.dimension).removePlayer(entityplayer);
        players.remove(entityplayer);
        server.a(entityplayer.dimension).removeEntity(entityplayer);
        ChunkCoordinates chunkcoordinates = entityplayer.M();
        EntityPlayer entityplayer1 = entityplayer;
        if(location == null)
        {
            boolean isBedSpawn = false;
            CraftWorld cw = (CraftWorld)server.server.getWorld(entityplayer.spawnWorld);
            if(cw != null && chunkcoordinates != null)
            {
                ChunkCoordinates chunkcoordinates1 = EntityHuman.getBed(cw.getHandle(), chunkcoordinates);
                if(chunkcoordinates1 != null)
                {
                    isBedSpawn = true;
                    location = new Location(cw, (double)chunkcoordinates1.x + 0.5D, chunkcoordinates1.y, (double)chunkcoordinates1.z + 0.5D);
                } else
                {
                    entityplayer1.netServerHandler.sendPacket(new Packet70Bed(0));
                }
            }
            if(location == null)
            {
                cw = (CraftWorld)server.server.getWorlds().get(0);
                chunkcoordinates = cw.getHandle().getSpawn();
                location = new Location(cw, (double)chunkcoordinates.x + 0.5D, chunkcoordinates.y, (double)chunkcoordinates.z + 0.5D);
            }
            Player respawnPlayer = cserver.getPlayer(entityplayer);
            PlayerRespawnEvent respawnEvent = new PlayerRespawnEvent(respawnPlayer, location, isBedSpawn);
            cserver.getPluginManager().callEvent(respawnEvent);
            location = respawnEvent.getRespawnLocation();
            entityplayer.health = 20;
            entityplayer.fireTicks = 0;
            entityplayer.fallDistance = 0.0F;
        } else
        {
            location.setWorld(server.a(i).getWorld());
        }
        WorldServer worldserver = ((CraftWorld)location.getWorld()).getHandle();
        entityplayer1.setLocation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        worldserver.chunkProviderServer.getChunkAt((int)entityplayer1.locX >> 4, (int)entityplayer1.locZ >> 4);
        for(; worldserver.getEntities(entityplayer1, entityplayer1.boundingBox).size() != 0; entityplayer1.setPosition(entityplayer1.locX, entityplayer1.locY + 1.0D, entityplayer1.locZ));
        byte actualDimension = (byte)worldserver.getWorld().getEnvironment().getId();
        entityplayer1.netServerHandler.sendPacket(new Packet9Respawn((byte)(actualDimension < 0 ? 0 : -1)));
        entityplayer1.netServerHandler.sendPacket(new Packet9Respawn(actualDimension));
        entityplayer1.a(worldserver);
        entityplayer1.dead = false;
        entityplayer1.netServerHandler.teleport(new Location(worldserver.getWorld(), entityplayer1.locX, entityplayer1.locY, entityplayer1.locZ, entityplayer1.yaw, entityplayer1.pitch));
        a(entityplayer1, worldserver);
        a(entityplayer1.dimension).addPlayer(entityplayer1);
        worldserver.addEntity(entityplayer1);
        players.add(entityplayer1);
        g(entityplayer1);
        entityplayer1.w();
        return entityplayer1;
    }

    public void f(EntityPlayer entityplayer)
    {
        int dimension = entityplayer.dimension;
        WorldServer fromWorld = server.a(dimension);
        WorldServer toWorld = server.a(dimension != -1 ? -1 : 0);
        double blockRatio = dimension != -1 ? 0.125D : 8D;
        Location fromLocation = new Location(fromWorld.getWorld(), entityplayer.locX, entityplayer.locY, entityplayer.locZ, entityplayer.yaw, entityplayer.pitch);
        Location toLocation = new Location(toWorld.getWorld(), entityplayer.locX * blockRatio, entityplayer.locY, entityplayer.locZ * blockRatio, entityplayer.yaw, entityplayer.pitch);
        PortalTravelAgent pta = new PortalTravelAgent();
        PlayerPortalEvent event = new PlayerPortalEvent((Player)entityplayer.getBukkitEntity(), fromLocation, toLocation, pta);
        Bukkit.getServer().getPluginManager().callEvent(event);
        if(event.isCancelled())
            return;
        Location finalLocation = event.getTo();
        if(event.useTravelAgent())
            finalLocation = pta.findOrCreate(finalLocation);
        toWorld = ((CraftWorld)finalLocation.getWorld()).getHandle();
        a(entityplayer, toWorld.dimension, finalLocation);
    }

    public void b()
    {
        for(int i = 0; i < server.worlds.size(); i++)
            ((WorldServer)server.worlds.get(i)).manager.flush();

    }

    public void flagDirty(int i, int j, int k, int l)
    {
        a(l).flagDirty(i, j, k);
    }

    public void sendAll(Packet packet)
    {
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public void a(Packet packet, int i)
    {
        for(int j = 0; j < players.size(); j++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(j);
            if(entityplayer.dimension == i)
                entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public String c()
    {
        String s = "";
        for(int i = 0; i < players.size(); i++)
        {
            if(i > 0)
                s = (new StringBuilder()).append(s).append(", ").toString();
            s = (new StringBuilder()).append(s).append(((EntityPlayer)players.get(i)).name).toString();
        }

        return s;
    }

    public void a(String s)
    {
        banByName.add(s.toLowerCase());
        h();
    }

    public void b(String s)
    {
        banByName.remove(s.toLowerCase());
        h();
    }

    private void g()
    {
        try
        {
            banByName.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(j));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                banByName.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ban list: ").append(exception).toString());
        }
    }

    private void h()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(j, false));
            String s;
            for(Iterator iterator = banByName.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ban list: ").append(exception).toString());
        }
    }

    public void c(String s)
    {
        banByIP.add(s.toLowerCase());
        j();
    }

    public void d(String s)
    {
        banByIP.remove(s.toLowerCase());
        j();
    }

    private void i()
    {
        try
        {
            banByIP.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(k));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                banByIP.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ip ban list: ").append(exception).toString());
        }
    }

    private void j()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(k, false));
            String s;
            for(Iterator iterator = banByIP.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ip ban list: ").append(exception).toString());
        }
    }

    public void e(String s)
    {
        h.add(s.toLowerCase());
        l();
    }

    public void f(String s)
    {
        h.remove(s.toLowerCase());
        l();
    }

    private void k()
    {
        try
        {
            h.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(l));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                h.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load ops: ").append(exception).toString());
        }
    }

    private void l()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(l, false));
            String s;
            for(Iterator iterator = h.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save ops: ").append(exception).toString());
        }
    }

    private void m()
    {
        try
        {
            i.clear();
            BufferedReader bufferedreader = new BufferedReader(new FileReader(m));
            for(String s = ""; (s = bufferedreader.readLine()) != null;)
                i.add(s.trim().toLowerCase());

            bufferedreader.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load white-list: ").append(exception).toString());
        }
    }

    private void n()
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(new FileWriter(m, false));
            String s;
            for(Iterator iterator = i.iterator(); iterator.hasNext(); printwriter.println(s))
                s = (String)iterator.next();

            printwriter.close();
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save white-list: ").append(exception).toString());
        }
    }

    public boolean isWhitelisted(String s)
    {
        s = s.trim().toLowerCase();
        return !o || h.contains(s) || i.contains(s);
    }

    public boolean isOp(String s)
    {
        return h.contains(s.trim().toLowerCase());
    }

    public EntityPlayer i(String s)
    {
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(entityplayer.name.equalsIgnoreCase(s))
                return entityplayer;
        }

        return null;
    }

    public void a(String s, String s1)
    {
        EntityPlayer entityplayer = i(s);
        if(entityplayer != null)
            entityplayer.netServerHandler.sendPacket(new Packet3Chat(s1));
    }

    public void a(double d0, double d1, double d2, double d3, int i, Packet packet)
    {
        a((EntityHuman)null, d0, d1, d2, d3, i, packet);
    }

    public void a(EntityHuman entityhuman, double d0, double d1, double d2, 
            double d3, int i, Packet packet)
    {
        for(int j = 0; j < players.size(); j++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(j);
            if(entityplayer == entityhuman || entityplayer.dimension != i)
                continue;
            double d4 = d0 - entityplayer.locX;
            double d5 = d1 - entityplayer.locY;
            double d6 = d2 - entityplayer.locZ;
            if(d4 * d4 + d5 * d5 + d6 * d6 < d3 * d3)
                entityplayer.netServerHandler.sendPacket(packet);
        }

    }

    public void j(String s)
    {
        Packet3Chat packet3chat = new Packet3Chat(s);
        for(int i = 0; i < players.size(); i++)
        {
            EntityPlayer entityplayer = (EntityPlayer)players.get(i);
            if(isOp(entityplayer.name))
                entityplayer.netServerHandler.sendPacket(packet3chat);
        }

    }

    public boolean a(String s, Packet packet)
    {
        EntityPlayer entityplayer = i(s);
        if(entityplayer != null)
        {
            entityplayer.netServerHandler.sendPacket(packet);
            return true;
        } else
        {
            return false;
        }
    }

    public void savePlayers()
    {
        for(int i = 0; i < players.size(); i++)
            playerFileData.a((EntityHuman)players.get(i));

    }

    public void a(int i1, int j1, int k1, TileEntity tileentity1)
    {
    }

    public void k(String s)
    {
        i.add(s);
        n();
    }

    public void l(String s)
    {
        i.remove(s);
        n();
    }

    public Set e()
    {
        return i;
    }

    public void f()
    {
        m();
    }

    public void a(EntityPlayer entityplayer, WorldServer worldserver)
    {
        entityplayer.netServerHandler.sendPacket(new Packet4UpdateTime(worldserver.getTime()));
        if(worldserver.v())
            entityplayer.netServerHandler.sendPacket(new Packet70Bed(1));
    }

    public void g(EntityPlayer entityplayer)
    {
        entityplayer.a(entityplayer.defaultContainer);
        entityplayer.B();
    }

    public static Logger a = Logger.getLogger("Minecraft");
    public List players;
    public MinecraftServer server;
    public int maxPlayers;
    private Set banByName;
    private Set banByIP;
    private Set h;
    private Set i;
    private File j;
    private File k;
    private File l;
    private File m;
    public PlayerFileData playerFileData;
    private boolean o;
    private CraftServer cserver;

}
