// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package net.minecraft.server:
//            NBTTagCompound, World, TileEntityFurnace, TileEntityChest, 
//            TileEntityRecordPlayer, TileEntityDispenser, TileEntitySign, TileEntityMobSpawner, 
//            TileEntityNote, Packet

public class TileEntity
{

    public TileEntity()
    {
    }

    private static void a(Class class1, String s)
    {
        if(b.containsKey(s))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Duplicate id: ").append(s).toString());
        } else
        {
            a.put(s, class1);
            b.put(class1, s);
            return;
        }
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        e = nbttagcompound.e("x");
        f = nbttagcompound.e("y");
        g = nbttagcompound.e("z");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        String s = (String)b.get(getClass());
        if(s == null)
        {
            throw new RuntimeException((new StringBuilder()).append(getClass()).append(" is missing a mapping! This is a bug!").toString());
        } else
        {
            nbttagcompound.setString("id", s);
            nbttagcompound.a("x", e);
            nbttagcompound.a("y", f);
            nbttagcompound.a("z", g);
            return;
        }
    }

    public void g_()
    {
    }

    public static TileEntity c(NBTTagCompound nbttagcompound)
    {
        TileEntity tileentity = null;
        try
        {
            Class class1 = (Class)a.get(nbttagcompound.getString("id"));
            if(class1 != null)
                tileentity = (TileEntity)class1.newInstance();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        if(tileentity != null)
            tileentity.a(nbttagcompound);
        else
            System.out.println((new StringBuilder()).append("Skipping TileEntity with id ").append(nbttagcompound.getString("id")).toString());
        return tileentity;
    }

    public void update()
    {
        if(world != null)
            world.b(e, f, g, this);
    }

    public Packet e()
    {
        return null;
    }

    private static Map a = new HashMap();
    private static Map b = new HashMap();
    public World world;
    public int e;
    public int f;
    public int g;

    static 
    {
        a(net/minecraft/server/TileEntityFurnace, "Furnace");
        a(net/minecraft/server/TileEntityChest, "Chest");
        a(net/minecraft/server/TileEntityRecordPlayer, "RecordPlayer");
        a(net/minecraft/server/TileEntityDispenser, "Trap");
        a(net/minecraft/server/TileEntitySign, "Sign");
        a(net/minecraft/server/TileEntityMobSpawner, "MobSpawner");
        a(net/minecraft/server/TileEntityNote, "Music");
    }
}
