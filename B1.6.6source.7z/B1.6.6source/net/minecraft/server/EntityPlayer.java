// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityPlayer.java

package net.minecraft.server;

import java.util.*;
import org.bukkit.*;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityHuman, ItemStack, WorldServer, ItemInWorldManager, 
//            Packet5EntityEquipment, EntityArrow, ItemWorldMapBase, ChunkCoordIntPair, 
//            Packet51MapChunk, TileEntity, Packet8UpdateHealth, EntityItem, 
//            Packet22Collect, Packet18ArmAnimation, Packet17, Packet39AttachEntity, 
//            Packet100OpenWindow, ContainerWorkbench, ContainerChest, ContainerFurnace, 
//            ContainerDispenser, SlotResult, Packet103SetSlot, Packet104WindowItems, 
//            Packet105CraftProgressBar, Packet101CloseWindow, Packet200Statistic, Packet3Chat, 
//            ICrafting, World, ChunkCoordinates, WorldProvider, 
//            Container, MinecraftServer, EntityTracker, InventoryPlayer, 
//            Item, NetServerHandler, PropertyManager, ServerConfigurationManager, 
//            Entity, EnumBedError, IInventory, TileEntityFurnace, 
//            TileEntityDispenser, Statistic, StatisticStorage

public class EntityPlayer extends EntityHuman
    implements ICrafting
{

    public EntityPlayer(MinecraftServer minecraftserver, World world, String s, ItemInWorldManager iteminworldmanager)
    {
        super(world);
        f = new LinkedList();
        g = new HashSet();
        bK = 0xfa0a1f01;
        bL = 60;
        bN = 0;
        timeOffset = 0L;
        relativeTime = true;
        iteminworldmanager.player = this;
        itemInWorldManager = iteminworldmanager;
        ChunkCoordinates chunkcoordinates = world.getSpawn();
        int i = chunkcoordinates.x;
        int j = chunkcoordinates.z;
        int k = chunkcoordinates.y;
        if(!world.worldProvider.e)
        {
            i += random.nextInt(20) - 10;
            k = world.f(i, j);
            j += random.nextInt(20) - 10;
        }
        setPositionRotation((double)i + 0.5D, k, (double)j + 0.5D, 0.0F, 0.0F);
        b = minecraftserver;
        bs = 0.0F;
        name = s;
        height = 0.0F;
        displayName = name;
    }

    public void a(World world)
    {
        super.a(world);
        if(world == null)
        {
            dead = false;
            ChunkCoordinates position = null;
            if(spawnWorld != null && !spawnWorld.equals(""))
            {
                CraftWorld cw = (CraftWorld)Bukkit.getServer().getWorld(spawnWorld);
                if(cw != null && M() != null)
                {
                    world = cw.getHandle();
                    position = EntityHuman.getBed(cw.getHandle(), M());
                }
            }
            if(world == null || position == null)
            {
                world = ((CraftWorld)Bukkit.getServer().getWorlds().get(0)).getHandle();
                position = world.getSpawn();
            }
            this.world = world;
            setPosition((double)position.x + 0.5D, position.y, (double)position.z + 0.5D);
        }
        dimension = ((WorldServer)this.world).dimension;
        itemInWorldManager = new ItemInWorldManager((WorldServer)world);
        itemInWorldManager.player = this;
    }

    public void syncInventory()
    {
        activeContainer.a(this);
    }

    public net.minecraft.server.ItemStack[] getEquipment()
    {
        return bM;
    }

    protected void j_()
    {
        height = 0.0F;
    }

    public float s()
    {
        return 1.62F;
    }

    public void o_()
    {
        itemInWorldManager.a();
        bL--;
        activeContainer.a();
        for(int i = 0; i < 5; i++)
        {
            net.minecraft.server.ItemStack itemstack = b_(i);
            if(itemstack != bM[i])
            {
                b.b(dimension).a(this, new Packet5EntityEquipment(id, i, itemstack));
                bM[i] = itemstack;
            }
        }

    }

    public net.minecraft.server.ItemStack b_(int i)
    {
        return i != 0 ? inventory.armor[i - 1] : inventory.getItemInHand();
    }

    public void a(Entity entity)
    {
        List loot = new ArrayList();
        for(int i = 0; i < inventory.items.length; i++)
            if(inventory.items[i] != null)
                loot.add(new CraftItemStack(inventory.items[i]));

        for(int i = 0; i < inventory.armor.length; i++)
            if(inventory.armor[i] != null)
                loot.add(new CraftItemStack(inventory.armor[i]));

        CraftEntity craftEntity = (CraftEntity)getBukkitEntity();
        CraftWorld cworld = ((WorldServer)world).getWorld();
        Server server = ((WorldServer)world).getServer();
        EntityDeathEvent event = new EntityDeathEvent(craftEntity, loot);
        server.getPluginManager().callEvent(event);
        for(int i = 0; i < inventory.items.length; i++)
            inventory.items[i] = null;

        for(int i = 0; i < inventory.armor.length; i++)
            inventory.armor[i] = null;

        ItemStack stack;
        for(Iterator i$ = event.getDrops().iterator(); i$.hasNext(); cworld.dropItemNaturally(craftEntity.getLocation(), stack))
            stack = (ItemStack)i$.next();

        x();
    }

    public boolean damageEntity(Entity entity, int i)
    {
        if(bL > 0)
            return false;
        if(!world.pvpMode)
        {
            if(entity instanceof EntityHuman)
                return false;
            if(entity instanceof EntityArrow)
            {
                EntityArrow entityarrow = (EntityArrow)entity;
                if(entityarrow.shooter instanceof EntityHuman)
                    return false;
            }
        }
        return super.damageEntity(entity, i);
    }

    protected boolean t()
    {
        return b.pvpMode;
    }

    public void b(int i)
    {
        super.b(i);
    }

    public void a(boolean flag)
    {
        super.o_();
        for(int i = 0; i < inventory.getSize(); i++)
        {
            net.minecraft.server.ItemStack itemstack = inventory.getItem(i);
            if(itemstack == null || !Item.byId[itemstack.id].b() || netServerHandler.b() > 2)
                continue;
            Packet packet = ((ItemWorldMapBase)Item.byId[itemstack.id]).b(itemstack, world, this);
            if(packet != null)
                netServerHandler.sendPacket(packet);
        }

        if(flag && !f.isEmpty())
        {
            ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)f.get(0);
            if(chunkcoordintpair != null)
            {
                boolean flag1 = false;
                if(netServerHandler.b() < 4)
                    flag1 = true;
                if(flag1)
                {
                    WorldServer worldserver = b.a(dimension);
                    f.remove(chunkcoordintpair);
                    netServerHandler.sendPacket(new Packet51MapChunk(chunkcoordintpair.x * 16, 0, chunkcoordintpair.z * 16, 16, 128, 16, worldserver));
                    List list = worldserver.getTileEntities(chunkcoordintpair.x * 16, 0, chunkcoordintpair.z * 16, chunkcoordintpair.x * 16 + 16, 128, chunkcoordintpair.z * 16 + 16);
                    for(int j = 0; j < list.size(); j++)
                        a((TileEntity)list.get(j));

                }
            }
        }
        if(E)
        {
            if(b.propertyManager.getBoolean("allow-nether", true))
            {
                if(vehicle != null)
                {
                    mount(vehicle);
                } else
                {
                    F += 0.0125F;
                    if(F >= 1.0F)
                    {
                        F = 1.0F;
                        D = 10;
                        b.serverConfigurationManager.f(this);
                    }
                }
                E = false;
            }
        } else
        {
            if(F > 0.0F)
                F -= 0.05F;
            if(F < 0.0F)
                F = 0.0F;
        }
        if(D > 0)
            D--;
        if(health != bK)
        {
            netServerHandler.sendPacket(new Packet8UpdateHealth(health));
            bK = health;
        }
    }

    private void a(TileEntity tileentity)
    {
        if(tileentity != null)
        {
            Packet packet = tileentity.e();
            if(packet != null)
                netServerHandler.sendPacket(packet);
        }
    }

    public void u()
    {
        super.u();
    }

    public void receive(Entity entity, int i)
    {
        if(!entity.dead)
        {
            EntityTracker entitytracker = b.b(dimension);
            if(entity instanceof EntityItem)
                entitytracker.a(entity, new Packet22Collect(entity.id, id));
            if(entity instanceof EntityArrow)
                entitytracker.a(entity, new Packet22Collect(entity.id, id));
        }
        super.receive(entity, i);
        activeContainer.a();
    }

    public void k_()
    {
        if(!p)
        {
            q = -1;
            p = true;
            EntityTracker entitytracker = b.b(dimension);
            entitytracker.a(this, new Packet18ArmAnimation(this, 1));
        }
    }

    public void w()
    {
    }

    public EnumBedError a(int i, int j, int k)
    {
        EnumBedError enumbederror = super.a(i, j, k);
        if(enumbederror == EnumBedError.OK)
        {
            EntityTracker entitytracker = b.b(dimension);
            Packet17 packet17 = new Packet17(this, 0, i, j, k);
            entitytracker.a(this, packet17);
            netServerHandler.a(locX, locY, locZ, yaw, pitch);
            netServerHandler.sendPacket(packet17);
        }
        return enumbederror;
    }

    public void a(boolean flag, boolean flag1, boolean flag2)
    {
        if(isSleeping())
        {
            EntityTracker entitytracker = b.b(dimension);
            entitytracker.b(this, new Packet18ArmAnimation(this, 3));
        }
        super.a(flag, flag1, flag2);
        if(netServerHandler != null)
            netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    public void mount(Entity entity)
    {
        setPassengerOf(entity);
    }

    public void setPassengerOf(Entity entity)
    {
        super.setPassengerOf(entity);
        netServerHandler.sendPacket(new Packet39AttachEntity(this, vehicle));
        netServerHandler.a(locX, locY, locZ, yaw, pitch);
    }

    protected void a(double d1, boolean flag1)
    {
    }

    public void b(double d0, boolean flag)
    {
        super.a(d0, flag);
    }

    private void ah()
    {
        bN = bN % 100 + 1;
    }

    public void b(int i, int j, int k)
    {
        ah();
        netServerHandler.sendPacket(new Packet100OpenWindow(bN, 1, "Crafting", 9));
        activeContainer = new ContainerWorkbench(inventory, world, i, j, k);
        activeContainer.f = bN;
        activeContainer.a(this);
    }

    public void a(IInventory iinventory)
    {
        ah();
        netServerHandler.sendPacket(new Packet100OpenWindow(bN, 0, iinventory.getName(), iinventory.getSize()));
        activeContainer = new ContainerChest(inventory, iinventory);
        activeContainer.f = bN;
        activeContainer.a(this);
    }

    public void a(TileEntityFurnace tileentityfurnace)
    {
        ah();
        netServerHandler.sendPacket(new Packet100OpenWindow(bN, 2, tileentityfurnace.getName(), tileentityfurnace.getSize()));
        activeContainer = new ContainerFurnace(inventory, tileentityfurnace);
        activeContainer.f = bN;
        activeContainer.a(this);
    }

    public void a(TileEntityDispenser tileentitydispenser)
    {
        ah();
        netServerHandler.sendPacket(new Packet100OpenWindow(bN, 3, tileentitydispenser.getName(), tileentitydispenser.getSize()));
        activeContainer = new ContainerDispenser(inventory, tileentitydispenser);
        activeContainer.f = bN;
        activeContainer.a(this);
    }

    public void a(Container container, int i, net.minecraft.server.ItemStack itemstack)
    {
        if(!(container.b(i) instanceof SlotResult) && !h)
            netServerHandler.sendPacket(new Packet103SetSlot(container.f, i, itemstack));
    }

    public void a(Container container)
    {
        a(container, container.b());
    }

    public void a(Container container, List list)
    {
        netServerHandler.sendPacket(new Packet104WindowItems(container.f, list));
        netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.j()));
    }

    public void a(Container container, int i, int j)
    {
        netServerHandler.sendPacket(new Packet105CraftProgressBar(container.f, i, j));
    }

    public void a(net.minecraft.server.ItemStack itemstack1)
    {
    }

    public void x()
    {
        netServerHandler.sendPacket(new Packet101CloseWindow(activeContainer.f));
        z();
    }

    public void y()
    {
        if(!h)
            netServerHandler.sendPacket(new Packet103SetSlot(-1, -1, inventory.j()));
    }

    public void z()
    {
        activeContainer.a(this);
        activeContainer = defaultContainer;
    }

    public void a(float f, float f1, boolean flag, boolean flag1, float f2, float f3)
    {
        az = f;
        aA = f1;
        aC = flag;
        setSneak(flag1);
        pitch = f2;
        yaw = f3;
    }

    public void a(Statistic statistic, int i)
    {
        if(statistic != null && !statistic.g)
        {
            for(; i > 100; i -= 100)
                netServerHandler.sendPacket(new Packet200Statistic(statistic.e, 100));

            netServerHandler.sendPacket(new Packet200Statistic(statistic.e, i));
        }
    }

    public void A()
    {
        if(vehicle != null)
            mount(vehicle);
        if(passenger != null)
            passenger.mount(this);
        if(sleeping)
            a(true, false, false);
    }

    public void B()
    {
        bK = 0xfa0a1f01;
    }

    public void a(String s)
    {
        StatisticStorage statisticstorage = StatisticStorage.a();
        String s1 = statisticstorage.a(s);
        netServerHandler.sendPacket(new Packet3Chat(s1));
    }

    public long getPlayerTime()
    {
        if(relativeTime)
            return world.getTime() + timeOffset;
        else
            return (world.getTime() - world.getTime() % 24000L) + timeOffset;
    }

    public String toString()
    {
        return (new StringBuilder()).append(super.toString()).append("(").append(name).append(" at ").append(locX).append(",").append(locY).append(",").append(locZ).append(")").toString();
    }

    public NetServerHandler netServerHandler;
    public MinecraftServer b;
    public ItemInWorldManager itemInWorldManager;
    public double d;
    public double e;
    public List f;
    public Set g;
    private int bK;
    private int bL;
    private net.minecraft.server.ItemStack bM[] = {
        null, null, null, null, null
    };
    private int bN;
    public boolean h;
    public String displayName;
    public Location compassTarget;
    public long timeOffset;
    public boolean relativeTime;
}
