// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityZombie.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, WorldServer, World, MathHelper, 
//            Item

public class EntityZombie extends EntityMonster
{

    public EntityZombie(World world)
    {
        super(world);
        texture = "/mob/zombie.png";
        aE = 0.5F;
        damage = 5;
    }

    public void u()
    {
        if(world.d())
        {
            float f = c(1.0F);
            if(f > 0.5F && world.isChunkLoaded(MathHelper.floor(locX), MathHelper.floor(locY), MathHelper.floor(locZ)) && random.nextFloat() * 30F < (f - 0.4F) * 2.0F)
            {
                CraftServer server = ((WorldServer)world).getServer();
                EntityCombustEvent event = new EntityCombustEvent(getBukkitEntity());
                server.getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    fireTicks = 300;
            }
        }
        super.u();
    }

    protected String g()
    {
        return "mob.zombie";
    }

    protected String h()
    {
        return "mob.zombiehurt";
    }

    protected String i()
    {
        return "mob.zombiedeath";
    }

    protected int j()
    {
        return Item.FEATHER.id;
    }
}
