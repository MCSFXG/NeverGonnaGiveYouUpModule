// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityMonster.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.entity.*;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityCreature, WorldServer, EntityLiving, EntityHuman, 
//            IMonster, World, Entity, AxisAlignedBB, 
//            MathHelper, EnumSkyBlock, NBTTagCompound

public class EntityMonster extends EntityCreature
    implements IMonster
{

    public EntityMonster(World world)
    {
        super(world);
        damage = 2;
        health = 20;
    }

    public void u()
    {
        float f = c(1.0F);
        if(f > 0.5F)
            ay += 2;
        super.u();
    }

    public void o_()
    {
        super.o_();
        if(!world.isStatic && world.spawnMonsters == 0)
            die();
    }

    protected Entity findTarget()
    {
        EntityHuman entityhuman = world.a(this, 16D);
        return entityhuman == null || !e(entityhuman) ? null : entityhuman;
    }

    public boolean damageEntity(Entity entity, int i)
    {
        if(super.damageEntity(entity, i))
        {
            if(passenger != entity && vehicle != entity)
            {
                if(entity != this)
                {
                    CraftServer server = ((WorldServer)world).getServer();
                    org.bukkit.entity.Entity bukkitTarget = null;
                    if(entity != null)
                        bukkitTarget = entity.getBukkitEntity();
                    EntityTargetEvent event = new EntityTargetEvent(getBukkitEntity(), bukkitTarget, org.bukkit.event.entity.EntityTargetEvent.TargetReason.TARGET_ATTACKED_ENTITY);
                    server.getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                        if(event.getTarget() == null)
                            target = null;
                        else
                            target = ((CraftEntity)event.getTarget()).getHandle();
                }
                return true;
            } else
            {
                return true;
            }
        } else
        {
            return false;
        }
    }

    protected void a(Entity entity, float f)
    {
        if(attackTicks <= 0 && f < 2.0F && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            attackTicks = 20;
            if((entity instanceof EntityLiving) && !(entity instanceof EntityHuman))
            {
                CraftServer server = ((WorldServer)world).getServer();
                org.bukkit.entity.Entity damager = getBukkitEntity();
                org.bukkit.entity.Entity damagee = entity != null ? entity.getBukkitEntity() : null;
                org.bukkit.event.entity.EntityDamageEvent.DamageCause damageType = org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, damageType, damage);
                server.getPluginManager().callEvent(event);
                if(!event.isCancelled())
                    entity.damageEntity(this, event.getDamage());
                return;
            }
            entity.damageEntity(this, damage);
        }
    }

    protected float a(int i, int j, int k)
    {
        return 0.5F - world.m(i, j, k);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
    }

    public boolean d()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(boundingBox.b);
        int k = MathHelper.floor(locZ);
        if(world.a(EnumSkyBlock.SKY, i, j, k) > random.nextInt(32))
            return false;
        int l = world.getLightLevel(i, j, k);
        if(world.u())
        {
            int i1 = world.f;
            world.f = 10;
            l = world.getLightLevel(i, j, k);
            world.f = i1;
        }
        return l <= random.nextInt(8) && super.d();
    }

    protected int damage;
}
