// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.io.*;
import java.util.List;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.server:
//            PlayerFileData, IDataManager, MinecraftException, WorldProviderHell, 
//            ChunkLoader, CompressedStreamTools, NBTTagCompound, WorldData, 
//            EntityHuman, WorldProvider, IChunkLoader

public class PlayerNBTManager
    implements PlayerFileData, IDataManager
{

    public PlayerNBTManager(File file, String s, boolean flag)
    {
        b = new File(file, s);
        b.mkdirs();
        c = new File(b, "players");
        d = new File(b, "data");
        d.mkdirs();
        if(flag)
            c.mkdirs();
        f();
    }

    private void f()
    {
        DataOutputStream dataoutputstream;
        File file = new File(b, "session.lock");
        dataoutputstream = new DataOutputStream(new FileOutputStream(file));
        dataoutputstream.writeLong(e);
        dataoutputstream.close();
        break MISSING_BLOCK_LABEL_70;
        Exception exception;
        exception;
        dataoutputstream.close();
        throw exception;
        IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
        throw new RuntimeException("Failed to check session lock, aborting");
    }

    protected File a()
    {
        return b;
    }

    public void b()
    {
        DataInputStream datainputstream;
        File file = new File(b, "session.lock");
        datainputstream = new DataInputStream(new FileInputStream(file));
        if(datainputstream.readLong() != e)
            throw new MinecraftException("The save is being accessed from another location, aborting");
        datainputstream.close();
        break MISSING_BLOCK_LABEL_80;
        Exception exception;
        exception;
        datainputstream.close();
        throw exception;
        IOException ioexception;
        ioexception;
        throw new MinecraftException("Failed to check session lock, aborting");
    }

    public IChunkLoader a(WorldProvider worldprovider)
    {
        if(worldprovider instanceof WorldProviderHell)
        {
            File file = new File(b, "DIM-1");
            file.mkdirs();
            return new ChunkLoader(file, true);
        } else
        {
            return new ChunkLoader(b, true);
        }
    }

    public WorldData c()
    {
        File file = new File(b, "level.dat");
        if(file.exists())
            try
            {
                NBTTagCompound nbttagcompound = CompressedStreamTools.a(new FileInputStream(file));
                NBTTagCompound nbttagcompound2 = nbttagcompound.k("Data");
                return new WorldData(nbttagcompound2);
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
        file = new File(b, "level.dat_old");
        if(file.exists())
            try
            {
                NBTTagCompound nbttagcompound1 = CompressedStreamTools.a(new FileInputStream(file));
                NBTTagCompound nbttagcompound3 = nbttagcompound1.k("Data");
                return new WorldData(nbttagcompound3);
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
        return null;
    }

    public void a(WorldData worlddata, List list)
    {
        NBTTagCompound nbttagcompound = worlddata.a(list);
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.a("Data", nbttagcompound);
        try
        {
            File file = new File(b, "level.dat_new");
            File file1 = new File(b, "level.dat_old");
            File file2 = new File(b, "level.dat");
            CompressedStreamTools.a(nbttagcompound1, new FileOutputStream(file));
            if(file1.exists())
                file1.delete();
            file2.renameTo(file1);
            if(file2.exists())
                file2.delete();
            file.renameTo(file2);
            if(file.exists())
                file.delete();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public void a(WorldData worlddata)
    {
        NBTTagCompound nbttagcompound = worlddata.a();
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.a("Data", nbttagcompound);
        try
        {
            File file = new File(b, "level.dat_new");
            File file1 = new File(b, "level.dat_old");
            File file2 = new File(b, "level.dat");
            CompressedStreamTools.a(nbttagcompound1, new FileOutputStream(file));
            if(file1.exists())
                file1.delete();
            file2.renameTo(file1);
            if(file2.exists())
                file2.delete();
            file.renameTo(file2);
            if(file.exists())
                file.delete();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public void a(EntityHuman entityhuman)
    {
        try
        {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            entityhuman.d(nbttagcompound);
            File file = new File(c, "_tmp_.dat");
            File file1 = new File(c, (new StringBuilder()).append(entityhuman.name).append(".dat").toString());
            CompressedStreamTools.a(nbttagcompound, new FileOutputStream(file));
            if(file1.exists())
                file1.delete();
            file.renameTo(file1);
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to save player data for ").append(entityhuman.name).toString());
        }
    }

    public void b(EntityHuman entityhuman)
    {
        NBTTagCompound nbttagcompound = a(entityhuman.name);
        if(nbttagcompound != null)
            entityhuman.e(nbttagcompound);
    }

    public NBTTagCompound a(String s)
    {
        try
        {
            File file = new File(c, (new StringBuilder()).append(s).append(".dat").toString());
            if(file.exists())
                return CompressedStreamTools.a(new FileInputStream(file));
        }
        catch(Exception exception)
        {
            a.warning((new StringBuilder()).append("Failed to load player data for ").append(s).toString());
        }
        return null;
    }

    public PlayerFileData d()
    {
        return this;
    }

    public void e()
    {
    }

    public File b(String s)
    {
        return new File(d, (new StringBuilder()).append(s).append(".dat").toString());
    }

    private static final Logger a = Logger.getLogger("Minecraft");
    private final File b;
    private final File c;
    private final File d;
    private final long e = System.currentTimeMillis();

}
