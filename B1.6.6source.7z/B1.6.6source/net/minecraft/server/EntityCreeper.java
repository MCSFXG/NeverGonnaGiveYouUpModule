// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EntityCreeper.java

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.entity.CreeperPowerEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.plugin.PluginManager;

// Referenced classes of package net.minecraft.server:
//            EntityMonster, EntitySkeleton, WorldServer, DataWatcher, 
//            NBTTagCompound, World, Item, EntityWeatherStorm, 
//            Entity

public class EntityCreeper extends EntityMonster
{

    public EntityCreeper(World world)
    {
        super(world);
        texture = "/mob/creeper.png";
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, Byte.valueOf((byte)-1));
        datawatcher.a(17, Byte.valueOf((byte)0));
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        if(datawatcher.a(17) == 1)
            nbttagcompound.a("powered", true);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        datawatcher.b(17, Byte.valueOf((byte)(nbttagcompound.m("powered") ? 1 : 0)));
    }

    protected void b(Entity entity, float f)
    {
        if(!world.isStatic && fuseTicks > 0)
        {
            e(-1);
            fuseTicks--;
            if(fuseTicks < 0)
                fuseTicks = 0;
        }
    }

    public void o_()
    {
        b = fuseTicks;
        if(world.isStatic)
        {
            int i = x();
            if(i > 0 && fuseTicks == 0)
                world.makeSound(this, "random.fuse", 1.0F, 0.5F);
            fuseTicks += i;
            if(fuseTicks < 0)
                fuseTicks = 0;
            if(fuseTicks >= 30)
                fuseTicks = 30;
        }
        super.o_();
        if(target == null && fuseTicks > 0)
        {
            e(-1);
            fuseTicks--;
            if(fuseTicks < 0)
                fuseTicks = 0;
        }
    }

    protected String h()
    {
        return "mob.creeper";
    }

    protected String i()
    {
        return "mob.creeperdeath";
    }

    public void a(Entity entity)
    {
        super.a(entity);
        if(entity instanceof EntitySkeleton)
            b(Item.GOLD_RECORD.id + random.nextInt(2), 1);
    }

    protected void a(Entity entity, float f)
    {
        if(!world.isStatic)
        {
            int i = x();
            if((i > 0 || f >= 3F) && (i <= 0 || f >= 7F))
            {
                e(-1);
                fuseTicks--;
                if(fuseTicks < 0)
                    fuseTicks = 0;
            } else
            {
                if(fuseTicks == 0)
                    world.makeSound(this, "random.fuse", 1.0F, 0.5F);
                e(1);
                fuseTicks++;
                if(fuseTicks >= 30)
                {
                    CraftServer server = ((WorldServer)world).getServer();
                    float radius = t() ? 6F : 3F;
                    ExplosionPrimeEvent event = new ExplosionPrimeEvent(CraftEntity.getEntity(server, this), radius, false);
                    server.getPluginManager().callEvent(event);
                    if(!event.isCancelled())
                    {
                        world.createExplosion(this, locX, locY, locZ, event.getRadius(), event.getFire());
                        die();
                    } else
                    {
                        fuseTicks = 0;
                    }
                }
                e = true;
            }
        }
    }

    public boolean t()
    {
        return datawatcher.a(17) == 1;
    }

    protected int j()
    {
        return Item.SULPHUR.id;
    }

    private int x()
    {
        return datawatcher.a(16);
    }

    private void e(int i)
    {
        datawatcher.b(16, Byte.valueOf((byte)i));
    }

    public void a(EntityWeatherStorm entityweatherstorm)
    {
        super.a(entityweatherstorm);
        CraftServer server = ((WorldServer)world).getServer();
        org.bukkit.entity.Entity entity = getBukkitEntity();
        CreeperPowerEvent event = new CreeperPowerEvent(entity, entityweatherstorm.getBukkitEntity(), org.bukkit.event.entity.CreeperPowerEvent.PowerCause.LIGHTNING);
        server.getPluginManager().callEvent(event);
        if(event.isCancelled())
        {
            return;
        } else
        {
            datawatcher.b(17, Byte.valueOf((byte)1));
            return;
        }
    }

    int fuseTicks;
    int b;
}
