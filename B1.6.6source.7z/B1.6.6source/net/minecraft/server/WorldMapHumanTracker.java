// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            WorldMap, WorldMapOrienter, EntityHuman, ItemStack

public class WorldMapHumanTracker
{

    public WorldMapHumanTracker(WorldMap worldmap, EntityHuman entityhuman)
    {
        d = worldmap;
        super();
        b = new int[128];
        c = new int[128];
        e = 0;
        f = 0;
        a = entityhuman;
        for(int i = 0; i < b.length; i++)
        {
            b[i] = 0;
            c[i] = 127;
        }

    }

    public byte[] a(ItemStack itemstack)
    {
        if(--f < 0)
        {
            f = 4;
            byte abyte0[] = new byte[d.i.size() * 3 + 1];
            abyte0[0] = 1;
            for(int j = 0; j < d.i.size(); j++)
            {
                WorldMapOrienter worldmaporienter = (WorldMapOrienter)d.i.get(j);
                abyte0[j * 3 + 1] = (byte)(worldmaporienter.a + (worldmaporienter.d & 0xf) * 16);
                abyte0[j * 3 + 2] = worldmaporienter.b;
                abyte0[j * 3 + 3] = worldmaporienter.c;
            }

            boolean flag = true;
            if(g == null || g.length != abyte0.length)
            {
                flag = false;
            } else
            {
                int l = 0;
                do
                {
                    if(l >= abyte0.length)
                        break;
                    if(abyte0[l] != g[l])
                    {
                        flag = false;
                        break;
                    }
                    l++;
                } while(true);
            }
            if(!flag)
            {
                g = abyte0;
                return abyte0;
            }
        }
        for(int i = 0; i < 10; i++)
        {
            int k = (e * 11) % 128;
            e++;
            if(b[k] >= 0)
            {
                int i1 = (c[k] - b[k]) + 1;
                int j1 = b[k];
                byte abyte1[] = new byte[i1 + 3];
                abyte1[0] = 0;
                abyte1[1] = (byte)k;
                abyte1[2] = (byte)j1;
                for(int k1 = 0; k1 < abyte1.length - 3; k1++)
                    abyte1[k1 + 3] = d.f[(k1 + j1) * 128 + k];

                c[k] = -1;
                b[k] = -1;
                return abyte1;
            }
        }

        return null;
    }

    public final EntityHuman a;
    public int b[];
    public int c[];
    private int e;
    private int f;
    private byte g[];
    final WorldMap d;
}
