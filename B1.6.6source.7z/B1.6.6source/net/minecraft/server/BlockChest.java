// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            BlockContainer, Material, World, TileEntityChest, 
//            IInventory, ItemStack, EntityItem, InventoryLargeChest, 
//            EntityHuman, TileEntity

public class BlockChest extends BlockContainer
{

    protected BlockChest(int i)
    {
        super(i, Material.WOOD);
        a = new Random();
        textureId = 26;
    }

    public int a(int i)
    {
        if(i == 1)
            return textureId - 1;
        if(i == 0)
            return textureId - 1;
        if(i == 3)
            return textureId + 1;
        else
            return textureId;
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = 0;
        if(world.getTypeId(i - 1, j, k) == id)
            l++;
        if(world.getTypeId(i + 1, j, k) == id)
            l++;
        if(world.getTypeId(i, j, k - 1) == id)
            l++;
        if(world.getTypeId(i, j, k + 1) == id)
            l++;
        if(l > 1)
            return false;
        if(g(world, i - 1, j, k))
            return false;
        if(g(world, i + 1, j, k))
            return false;
        if(g(world, i, j, k - 1))
            return false;
        return !g(world, i, j, k + 1);
    }

    private boolean g(World world, int i, int j, int k)
    {
        if(world.getTypeId(i, j, k) != id)
            return false;
        if(world.getTypeId(i - 1, j, k) == id)
            return true;
        if(world.getTypeId(i + 1, j, k) == id)
            return true;
        if(world.getTypeId(i, j, k - 1) == id)
            return true;
        return world.getTypeId(i, j, k + 1) == id;
    }

    public void remove(World world, int i, int j, int k)
    {
        TileEntityChest tileentitychest = (TileEntityChest)world.getTileEntity(i, j, k);
label0:
        for(int l = 0; l < tileentitychest.getSize(); l++)
        {
            ItemStack itemstack = tileentitychest.getItem(l);
            if(itemstack == null)
                continue;
            float f = a.nextFloat() * 0.8F + 0.1F;
            float f1 = a.nextFloat() * 0.8F + 0.1F;
            float f2 = a.nextFloat() * 0.8F + 0.1F;
            do
            {
                if(itemstack.count <= 0)
                    continue label0;
                int i1 = a.nextInt(21) + 10;
                if(i1 > itemstack.count)
                    i1 = itemstack.count;
                itemstack.count -= i1;
                EntityItem entityitem = new EntityItem(world, (float)i + f, (float)j + f1, (float)k + f2, new ItemStack(itemstack.id, i1, itemstack.getData()));
                float f3 = 0.05F;
                entityitem.motX = (float)a.nextGaussian() * f3;
                entityitem.motY = (float)a.nextGaussian() * f3 + 0.2F;
                entityitem.motZ = (float)a.nextGaussian() * f3;
                world.addEntity(entityitem);
            } while(true);
        }

        super.remove(world, i, j, k);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        Object obj = (TileEntityChest)world.getTileEntity(i, j, k);
        if(world.d(i, j + 1, k))
            return true;
        if(world.getTypeId(i - 1, j, k) == id && world.d(i - 1, j + 1, k))
            return true;
        if(world.getTypeId(i + 1, j, k) == id && world.d(i + 1, j + 1, k))
            return true;
        if(world.getTypeId(i, j, k - 1) == id && world.d(i, j + 1, k - 1))
            return true;
        if(world.getTypeId(i, j, k + 1) == id && world.d(i, j + 1, k + 1))
            return true;
        if(world.getTypeId(i - 1, j, k) == id)
            obj = new InventoryLargeChest("Large chest", (TileEntityChest)world.getTileEntity(i - 1, j, k), ((IInventory) (obj)));
        if(world.getTypeId(i + 1, j, k) == id)
            obj = new InventoryLargeChest("Large chest", ((IInventory) (obj)), (TileEntityChest)world.getTileEntity(i + 1, j, k));
        if(world.getTypeId(i, j, k - 1) == id)
            obj = new InventoryLargeChest("Large chest", (TileEntityChest)world.getTileEntity(i, j, k - 1), ((IInventory) (obj)));
        if(world.getTypeId(i, j, k + 1) == id)
            obj = new InventoryLargeChest("Large chest", ((IInventory) (obj)), (TileEntityChest)world.getTileEntity(i, j, k + 1));
        if(world.isStatic)
        {
            return true;
        } else
        {
            entityhuman.a(((IInventory) (obj)));
            return true;
        }
    }

    protected TileEntity a_()
    {
        return new TileEntityChest();
    }

    private Random a;
}
