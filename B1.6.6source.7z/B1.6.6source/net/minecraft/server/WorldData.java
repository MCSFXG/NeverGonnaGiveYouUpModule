// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WorldData.java

package net.minecraft.server;

import java.util.List;

// Referenced classes of package net.minecraft.server:
//            NBTTagCompound, EntityHuman

public class WorldData
{

    public WorldData(NBTTagCompound nbttagcompound)
    {
        a = nbttagcompound.f("RandomSeed");
        b = nbttagcompound.e("SpawnX");
        c = nbttagcompound.e("SpawnY");
        d = nbttagcompound.e("SpawnZ");
        e = nbttagcompound.f("Time");
        f = nbttagcompound.f("LastPlayed");
        g = nbttagcompound.f("SizeOnDisk");
        name = nbttagcompound.getString("LevelName");
        k = nbttagcompound.e("version");
        m = nbttagcompound.e("rainTime");
        l = nbttagcompound.m("raining");
        o = nbttagcompound.e("thunderTime");
        n = nbttagcompound.m("thundering");
        if(nbttagcompound.hasKey("Player"))
        {
            h = nbttagcompound.k("Player");
            i = h.e("Dimension");
        }
    }

    public WorldData(long i, String s)
    {
        a = i;
        name = s;
    }

    public WorldData(WorldData worlddata)
    {
        a = worlddata.a;
        b = worlddata.b;
        c = worlddata.c;
        d = worlddata.d;
        e = worlddata.e;
        f = worlddata.f;
        g = worlddata.g;
        h = worlddata.h;
        i = worlddata.i;
        name = worlddata.name;
        k = worlddata.k;
        m = worlddata.m;
        l = worlddata.l;
        o = worlddata.o;
        n = worlddata.n;
    }

    public NBTTagCompound a()
    {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        a(nbttagcompound, h);
        return nbttagcompound;
    }

    public NBTTagCompound a(List list)
    {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        EntityHuman entityhuman = null;
        NBTTagCompound nbttagcompound1 = null;
        if(list.size() > 0)
            entityhuman = (EntityHuman)list.get(0);
        if(entityhuman != null)
        {
            nbttagcompound1 = new NBTTagCompound();
            entityhuman.d(nbttagcompound1);
        }
        a(nbttagcompound, nbttagcompound1);
        return nbttagcompound;
    }

    private void a(NBTTagCompound nbttagcompound, NBTTagCompound nbttagcompound1)
    {
        nbttagcompound.a("RandomSeed", a);
        nbttagcompound.a("SpawnX", b);
        nbttagcompound.a("SpawnY", c);
        nbttagcompound.a("SpawnZ", d);
        nbttagcompound.a("Time", e);
        nbttagcompound.a("SizeOnDisk", g);
        nbttagcompound.a("LastPlayed", System.currentTimeMillis());
        nbttagcompound.setString("LevelName", name);
        nbttagcompound.a("version", k);
        nbttagcompound.a("rainTime", m);
        nbttagcompound.a("raining", l);
        nbttagcompound.a("thunderTime", o);
        nbttagcompound.a("thundering", n);
        if(nbttagcompound1 != null)
            nbttagcompound.a("Player", nbttagcompound1);
    }

    public long b()
    {
        return a;
    }

    public int c()
    {
        return b;
    }

    public int d()
    {
        return c;
    }

    public int e()
    {
        return d;
    }

    public long f()
    {
        return e;
    }

    public long g()
    {
        return g;
    }

    public int h()
    {
        return i;
    }

    public void a(long i)
    {
        e = i;
    }

    public void b(long i)
    {
        g = i;
    }

    public void setSpawn(int i, int j, int k)
    {
        b = i;
        c = j;
        d = k;
    }

    public void a(String s)
    {
        name = s;
    }

    public int i()
    {
        return k;
    }

    public void a(int i)
    {
        k = i;
    }

    public boolean j()
    {
        return n;
    }

    public void a(boolean flag)
    {
        n = flag;
    }

    public int k()
    {
        return o;
    }

    public void b(int i)
    {
        o = i;
    }

    public boolean l()
    {
        return l;
    }

    public void b(boolean flag)
    {
        l = flag;
    }

    public int m()
    {
        return m;
    }

    public void c(int i)
    {
        m = i;
    }

    private long a;
    private int b;
    private int c;
    private int d;
    private long e;
    private long f;
    private long g;
    private NBTTagCompound h;
    private int i;
    public String name;
    private int k;
    private boolean l;
    private int m;
    private boolean n;
    private int o;
}
