// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            Block, Material, Entity, World, 
//            AxisAlignedBB

public class BlockWeb extends Block
{

    public BlockWeb(int i, int j)
    {
        super(i, j, Material.CLOTH);
    }

    public void a(World world, int i, int j, int k, Entity entity)
    {
        entity.bf = true;
    }

    public boolean a()
    {
        return false;
    }

    public AxisAlignedBB d(World world, int i, int j, int k)
    {
        return null;
    }
}
