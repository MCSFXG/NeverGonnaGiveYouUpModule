// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityAnimal, DataWatcher, World, EntityLiving, 
//            ItemStack, Block, EntityItem, NBTTagCompound, 
//            Entity

public class EntitySheep extends EntityAnimal
{

    public EntitySheep(World world)
    {
        super(world);
        texture = "/mob/sheep.png";
        b(0.9F, 1.3F);
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Byte((byte)0));
    }

    public boolean damageEntity(Entity entity, int j)
    {
        if(!world.isStatic && !isSheared() && (entity instanceof EntityLiving))
        {
            setSheared(true);
            int k = 1 + random.nextInt(3);
            for(int l = 0; l < k; l++)
            {
                EntityItem entityitem = a(new ItemStack(Block.WOOL.id, 1, getColor()), 1.0F);
                entityitem.motY += random.nextFloat() * 0.05F;
                entityitem.motX += (random.nextFloat() - random.nextFloat()) * 0.1F;
                entityitem.motZ += (random.nextFloat() - random.nextFloat()) * 0.1F;
            }

        }
        return super.damageEntity(entity, j);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Sheared", isSheared());
        nbttagcompound.a("Color", (byte)getColor());
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setSheared(nbttagcompound.m("Sheared"));
        setColor(nbttagcompound.c("Color"));
    }

    protected String g()
    {
        return "mob.sheep";
    }

    protected String h()
    {
        return "mob.sheep";
    }

    protected String i()
    {
        return "mob.sheep";
    }

    public int getColor()
    {
        return datawatcher.a(16) & 0xf;
    }

    public void setColor(int j)
    {
        byte byte0 = datawatcher.a(16);
        datawatcher.b(16, Byte.valueOf((byte)(byte0 & 0xf0 | j & 0xf)));
    }

    public boolean isSheared()
    {
        return (datawatcher.a(16) & 0x10) != 0;
    }

    public void setSheared(boolean flag)
    {
        byte byte0 = datawatcher.a(16);
        if(flag)
            datawatcher.b(16, Byte.valueOf((byte)(byte0 | 0x10)));
        else
            datawatcher.b(16, Byte.valueOf((byte)(byte0 & 0xffffffef)));
    }

    public static int a(Random random)
    {
        int j = random.nextInt(100);
        if(j < 5)
            return 15;
        if(j < 10)
            return 7;
        if(j < 15)
            return 8;
        if(j < 18)
            return 12;
        return random.nextInt(500) != 0 ? 0 : 6;
    }

    public static final float a[][] = {
        {
            1.0F, 1.0F, 1.0F
        }, {
            0.95F, 0.7F, 0.2F
        }, {
            0.9F, 0.5F, 0.85F
        }, {
            0.6F, 0.7F, 0.95F
        }, {
            0.9F, 0.9F, 0.2F
        }, {
            0.5F, 0.8F, 0.1F
        }, {
            0.95F, 0.7F, 0.8F
        }, {
            0.3F, 0.3F, 0.3F
        }, {
            0.6F, 0.6F, 0.6F
        }, {
            0.3F, 0.6F, 0.7F
        }, {
            0.7F, 0.4F, 0.9F
        }, {
            0.2F, 0.4F, 0.8F
        }, {
            0.5F, 0.4F, 0.3F
        }, {
            0.4F, 0.5F, 0.2F
        }, {
            0.8F, 0.3F, 0.3F
        }, {
            0.1F, 0.1F, 0.1F
        }
    };

}
