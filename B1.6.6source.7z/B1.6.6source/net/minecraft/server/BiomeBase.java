// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.*;

// Referenced classes of package net.minecraft.server:
//            Block, BlockGrass, BiomeMeta, EntitySpider, 
//            EntityZombie, EntitySkeleton, EntityCreeper, EntitySlime, 
//            EntitySheep, EntityPig, EntityChicken, EntityCow, 
//            EntitySquid, WorldGenBigTree, WorldGenTrees, EnumCreatureType, 
//            BiomeRainforest, BiomeSwamp, BiomeForest, BiomeDesert, 
//            BiomeTaiga, BiomeHell, BiomeSky, WorldGenerator

public class BiomeBase
{

    protected BiomeBase()
    {
        p = (byte)Block.GRASS.id;
        q = (byte)Block.DIRT.id;
        r = 0x4ee031;
        s = new ArrayList();
        t = new ArrayList();
        u = new ArrayList();
        w = true;
        s.add(new BiomeMeta(net/minecraft/server/EntitySpider, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntityZombie, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntitySkeleton, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntityCreeper, 10));
        s.add(new BiomeMeta(net/minecraft/server/EntitySlime, 10));
        t.add(new BiomeMeta(net/minecraft/server/EntitySheep, 12));
        t.add(new BiomeMeta(net/minecraft/server/EntityPig, 10));
        t.add(new BiomeMeta(net/minecraft/server/EntityChicken, 10));
        t.add(new BiomeMeta(net/minecraft/server/EntityCow, 8));
        u.add(new BiomeMeta(net/minecraft/server/EntitySquid, 10));
    }

    private BiomeBase e()
    {
        w = false;
        return this;
    }

    public static void a()
    {
        for(int i = 0; i < 64; i++)
        {
            for(int j = 0; j < 64; j++)
                x[i + j * 64] = a((float)i / 63F, (float)j / 63F);

        }

        DESERT.p = DESERT.q = (byte)Block.SAND.id;
        ICE_DESERT.p = ICE_DESERT.q = (byte)Block.SAND.id;
    }

    public WorldGenerator a(Random random)
    {
        if(random.nextInt(10) == 0)
            return new WorldGenBigTree();
        else
            return new WorldGenTrees();
    }

    protected BiomeBase b()
    {
        v = true;
        return this;
    }

    protected BiomeBase a(String s1)
    {
        n = s1;
        return this;
    }

    protected BiomeBase a(int i)
    {
        r = i;
        return this;
    }

    protected BiomeBase b(int i)
    {
        o = i;
        return this;
    }

    public static BiomeBase a(double d1, double d2)
    {
        int i = (int)(d1 * 63D);
        int j = (int)(d2 * 63D);
        return x[i + j * 64];
    }

    public static BiomeBase a(float f, float f1)
    {
        f1 *= f;
        if(f < 0.1F)
            return TUNDRA;
        if(f1 < 0.2F)
        {
            if(f < 0.5F)
                return TUNDRA;
            if(f < 0.95F)
                return SAVANNA;
            else
                return DESERT;
        }
        if(f1 > 0.5F && f < 0.7F)
            return SWAMPLAND;
        if(f < 0.5F)
            return TAIGA;
        if(f < 0.97F)
            if(f1 < 0.35F)
                return SHRUBLAND;
            else
                return FOREST;
        if(f1 < 0.45F)
            return PLAINS;
        if(f1 < 0.9F)
            return SEASONAL_FOREST;
        else
            return RAINFOREST;
    }

    public List a(EnumCreatureType enumcreaturetype)
    {
        if(enumcreaturetype == EnumCreatureType.MONSTER)
            return s;
        if(enumcreaturetype == EnumCreatureType.CREATURE)
            return t;
        if(enumcreaturetype == EnumCreatureType.WATER_CREATURE)
            return u;
        else
            return null;
    }

    public boolean c()
    {
        return v;
    }

    public boolean d()
    {
        if(v)
            return false;
        else
            return w;
    }

    public static final BiomeBase RAINFOREST = (new BiomeRainforest()).b(0x8fa36).a("Rainforest").a(0x1ff458);
    public static final BiomeBase SWAMPLAND = (new BiomeSwamp()).b(0x7f9b2).a("Swampland").a(0x8baf48);
    public static final BiomeBase SEASONAL_FOREST = (new BiomeBase()).b(0x9be023).a("Seasonal Forest");
    public static final BiomeBase FOREST = (new BiomeForest()).b(0x56621).a("Forest").a(0x4eba31);
    public static final BiomeBase SAVANNA = (new BiomeDesert()).b(0xd9e023).a("Savanna");
    public static final BiomeBase SHRUBLAND = (new BiomeBase()).b(0xa1ad20).a("Shrubland");
    public static final BiomeBase TAIGA = (new BiomeTaiga()).b(0x2eb153).a("Taiga").b().a(0x7bb731);
    public static final BiomeBase DESERT = (new BiomeDesert()).b(0xfa9418).a("Desert").e();
    public static final BiomeBase PLAINS = (new BiomeDesert()).b(0xffd910).a("Plains");
    public static final BiomeBase ICE_DESERT = (new BiomeDesert()).b(0xffed93).a("Ice Desert").b().e().a(0xc4d339);
    public static final BiomeBase TUNDRA = (new BiomeBase()).b(0x57ebf9).a("Tundra").b().a(0xc4d339);
    public static final BiomeBase HELL = (new BiomeHell()).b(0xff0000).a("Hell").e();
    public static final BiomeBase SKY = (new BiomeSky()).b(0x8080ff).a("Sky").e();
    public String n;
    public int o;
    public byte p;
    public byte q;
    public int r;
    protected List s;
    protected List t;
    protected List u;
    private boolean v;
    private boolean w;
    private static BiomeBase x[] = new BiomeBase[4096];

    static 
    {
        a();
    }
}
