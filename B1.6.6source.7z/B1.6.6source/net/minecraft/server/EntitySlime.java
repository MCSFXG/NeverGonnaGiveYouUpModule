// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;

import java.util.Random;

// Referenced classes of package net.minecraft.server:
//            EntityLiving, IMonster, DataWatcher, NBTTagCompound, 
//            MathHelper, AxisAlignedBB, World, EntityHuman, 
//            Item, Chunk

public class EntitySlime extends EntityLiving
    implements IMonster
{

    public EntitySlime(World world)
    {
        super(world);
        size = 0;
        texture = "/mob/slime.png";
        int l = 1 << random.nextInt(3);
        height = 0.0F;
        size = random.nextInt(20) + 10;
        setSize(l);
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Byte((byte)1));
    }

    public void setSize(int l)
    {
        datawatcher.b(16, new Byte((byte)l));
        b(0.6F * (float)l, 0.6F * (float)l);
        health = l * l;
        setPosition(locX, locY, locZ);
    }

    public int getSize()
    {
        return datawatcher.a(16);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.a("Size", getSize() - 1);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        setSize(nbttagcompound.e("Size") + 1);
    }

    public void o_()
    {
        b = a;
        boolean flag = onGround;
        super.o_();
        if(onGround && !flag)
        {
            int l = getSize();
            for(int i1 = 0; i1 < l * 8; i1++)
            {
                float f = random.nextFloat() * 3.141593F * 2.0F;
                float f1 = random.nextFloat() * 0.5F + 0.5F;
                float f2 = MathHelper.sin(f) * (float)l * 0.5F * f1;
                float f3 = MathHelper.cos(f) * (float)l * 0.5F * f1;
                world.a("slime", locX + (double)f2, boundingBox.b, locZ + (double)f3, 0.0D, 0.0D, 0.0D);
            }

            if(l > 2)
                world.makeSound(this, "mob.slime", k(), ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) / 0.8F);
            a = -0.5F;
        }
        a = a * 0.6F;
    }

    protected void c_()
    {
        T();
        EntityHuman entityhuman = world.a(this, 16D);
        if(entityhuman != null)
            a(entityhuman, 10F, 20F);
        if(onGround && size-- <= 0)
        {
            size = random.nextInt(20) + 10;
            if(entityhuman != null)
                size /= 3;
            aC = true;
            if(getSize() > 1)
                world.makeSound(this, "mob.slime", k(), ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) * 0.8F);
            a = 1.0F;
            az = 1.0F - random.nextFloat() * 2.0F;
            aA = 1 * getSize();
        } else
        {
            aC = false;
            if(onGround)
                az = aA = 0.0F;
        }
    }

    public void die()
    {
        int l = getSize();
        if(!world.isStatic && l > 1 && health == 0)
        {
            for(int i1 = 0; i1 < 4; i1++)
            {
                float f = (((float)(i1 % 2) - 0.5F) * (float)l) / 4F;
                float f1 = (((float)(i1 / 2) - 0.5F) * (float)l) / 4F;
                EntitySlime entityslime = new EntitySlime(world);
                entityslime.setSize(l / 2);
                entityslime.setPositionRotation(locX + (double)f, locY + 0.5D, locZ + (double)f1, random.nextFloat() * 360F, 0.0F);
                world.addEntity(entityslime);
            }

        }
        super.die();
    }

    public void b(EntityHuman entityhuman)
    {
        int l = getSize();
        if(l > 1 && e(entityhuman) && (double)f(entityhuman) < 0.59999999999999998D * (double)l && entityhuman.damageEntity(this, l))
            world.makeSound(this, "mob.slimeattack", 1.0F, (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
    }

    protected String h()
    {
        return "mob.slime";
    }

    protected String i()
    {
        return "mob.slime";
    }

    protected int j()
    {
        if(getSize() == 1)
            return Item.SLIME_BALL.id;
        else
            return 0;
    }

    public boolean d()
    {
        Chunk chunk = world.b(MathHelper.floor(locX), MathHelper.floor(locZ));
        return (getSize() == 1 || world.spawnMonsters > 0) && random.nextInt(10) == 0 && chunk.a(0x3ad8025fL).nextInt(10) == 0 && locY < 16D;
    }

    protected float k()
    {
        return 0.6F;
    }

    public float a;
    public float b;
    private int size;
}
