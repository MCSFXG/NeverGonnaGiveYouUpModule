package net.minecraft.src;

public class WeightedRandomChoice
{
    protected int itemWeight;

    public WeightedRandomChoice(int i)
    {
        itemWeight = i;
    }
}
