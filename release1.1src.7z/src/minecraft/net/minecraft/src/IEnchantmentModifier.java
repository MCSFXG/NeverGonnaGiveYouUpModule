package net.minecraft.src;

interface IEnchantmentModifier
{
    public abstract void calculateModifier(Enchantment enchantment, int i);
}
