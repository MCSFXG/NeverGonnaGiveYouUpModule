package net.minecraft.src;

interface J_ThingWithPosition
{
    public abstract int getColumn();

    public abstract int getRow();
}
