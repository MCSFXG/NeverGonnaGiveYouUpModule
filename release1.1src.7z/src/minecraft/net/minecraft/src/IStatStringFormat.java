package net.minecraft.src;

public interface IStatStringFormat
{
    public abstract String formatString(String s);
}
