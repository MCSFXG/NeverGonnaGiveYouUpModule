package net.minecraft.src;

class RedstoneUpdateInfo
{
    int x;
    int y;
    int z;
    long updateTime;

    public RedstoneUpdateInfo(int i, int j, int k, long l)
    {
        x = i;
        y = j;
        z = k;
        updateTime = l;
    }
}
