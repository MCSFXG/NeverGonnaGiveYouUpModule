package net.minecraft.src;

public class BiomeGenHills extends BiomeGenBase
{
    protected BiomeGenHills(int i)
    {
        super(i);
    }
}
