package net.minecraft.src;

public class GuiSavingLevelString
{
    public String name;
    public int responseTime;

    public GuiSavingLevelString(String s)
    {
        name = s;
    }
}
