package net.minecraft.src;

public interface IStatType
{
    public abstract String format(int i);
}
