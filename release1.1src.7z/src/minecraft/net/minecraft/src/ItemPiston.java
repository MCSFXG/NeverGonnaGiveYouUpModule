package net.minecraft.src;

public class ItemPiston extends ItemBlock
{
    public ItemPiston(int i)
    {
        super(i);
    }

    public int getMetadata(int i)
    {
        return 7;
    }
}
