package net.minecraft.src;

interface J_NodeContainer
{
    public abstract void addNode(J_JsonNodeBuilder j_jsonnodebuilder);

    public abstract void addField(J_JsonFieldBuilder j_jsonfieldbuilder);
}
