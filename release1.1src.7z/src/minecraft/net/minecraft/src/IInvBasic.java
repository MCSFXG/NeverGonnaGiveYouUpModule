package net.minecraft.src;

public interface IInvBasic
{
    public abstract void func_20134_a(InventoryBasic inventorybasic);
}
