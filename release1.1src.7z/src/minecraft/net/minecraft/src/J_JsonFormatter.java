package net.minecraft.src;

public interface J_JsonFormatter
{
    public abstract String format(J_JsonRootNode j_jsonrootnode);
}
