package net.minecraft.src;

public class TextureOffset
{
    public final int field_40734_a;
    public final int field_40733_b;

    public TextureOffset(int i, int j)
    {
        field_40734_a = i;
        field_40733_b = j;
    }
}
