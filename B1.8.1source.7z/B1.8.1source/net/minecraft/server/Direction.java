// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class Direction
{

    public Direction()
    {
    }

    public static final int a[] = {
        0, -1, 0, 1
    };
    public static final int b[] = {
        1, 0, -1, 0
    };
    public static final int c[] = {
        3, 4, 2, 5
    };
    public static final int d[] = {
        -1, -1, 2, 0, 1, 3
    };
    public static final int e[] = {
        2, 3, 0, 1
    };
    public static final int f[] = {
        1, 2, 3, 0
    };
    public static final int g[] = {
        3, 0, 1, 2
    };
    public static final int h[][] = {
        {
            1, 0, 3, 2, 5, 4
        }, {
            1, 0, 5, 4, 2, 3
        }, {
            1, 0, 2, 3, 4, 5
        }, {
            1, 0, 4, 5, 3, 2
        }
    };

}
