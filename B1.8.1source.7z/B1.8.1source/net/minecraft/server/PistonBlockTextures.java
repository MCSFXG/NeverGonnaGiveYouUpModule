// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class PistonBlockTextures
{

    public PistonBlockTextures()
    {
    }

    public static final int a[] = {
        1, 0, 3, 2, 5, 4
    };
    public static final int b[] = {
        0, 0, 0, 0, -1, 1
    };
    public static final int c[] = {
        -1, 1, 0, 0, 0, 0
    };
    public static final int d[] = {
        0, 0, -1, 1, 0, 0
    };

}
