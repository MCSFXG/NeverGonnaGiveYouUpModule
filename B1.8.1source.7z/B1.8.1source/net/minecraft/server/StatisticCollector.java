// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


// Referenced classes of package net.minecraft.server:
//            StatisticStorage

public class StatisticCollector
{

    public StatisticCollector()
    {
    }

    public static String a(String s)
    {
        return a.a(s);
    }

    public static transient String a(String s, Object aobj[])
    {
        return a.a(s, aobj);
    }

    private static StatisticStorage a = StatisticStorage.a();

}
