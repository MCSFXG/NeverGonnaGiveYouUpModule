// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile

package net.minecraft.server;


public class PlayerAbilities
{

    public PlayerAbilities()
    {
        isInvulnerable = false;
        isFlying = false;
        canFly = false;
        canInstantlyBuild = false;
    }

    public boolean isInvulnerable;
    public boolean isFlying;
    public boolean canFly;
    public boolean canInstantlyBuild;
}
